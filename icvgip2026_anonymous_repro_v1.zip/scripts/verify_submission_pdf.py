"""Check submission-PDF size, anonymity text, and embedded fonts."""

from __future__ import annotations

import argparse
from pathlib import Path

from pypdf import PdfReader


MAX_PDF_BYTES = 20 * 1024 * 1024
FORBIDDEN_TEXT = (
    "cha" + "ran",
    "sam" + "sung",
    "smart" + "things",
    "ita" + "chi",
    "kaggle.com/code",
    "c:\\users\\",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf", type=Path)
    return parser.parse_args()


def embedded_font_status(font: object) -> tuple[str, bool]:
    font = font.get_object()
    base = str(font.get("/BaseFont", "unnamed"))
    subtype = str(font.get("/Subtype", "unknown"))
    if subtype == "/Type3":
        return base, True
    descendants = font.get("/DescendantFonts")
    if descendants:
        font = descendants[0].get_object()
    descriptor = font.get("/FontDescriptor")
    if descriptor is None:
        return base, False
    descriptor = descriptor.get_object()
    return base, any(key in descriptor for key in ("/FontFile", "/FontFile2", "/FontFile3"))


def main() -> None:
    args = parse_args()
    size = args.pdf.stat().st_size
    if size > MAX_PDF_BYTES:
        raise RuntimeError(f"PDF is {size} bytes, above the 20 MiB gate")
    reader = PdfReader(args.pdf)
    if not reader.pages:
        raise RuntimeError("PDF has no pages")

    page_texts = [page.extract_text() or "" for page in reader.pages]
    text = "\n".join(page_texts).lower()
    leaked = [needle for needle in FORBIDDEN_TEXT if needle in text]
    if leaked:
        raise RuntimeError(f"Potential identity leak in PDF text: {leaked}")
    if "anonymous" not in text:
        raise RuntimeError("PDF does not contain an anonymous-author marker")

    metadata = reader.metadata or {}
    metadata_text = "\n".join(str(value) for value in metadata.values()).lower()
    metadata_leaks = [needle for needle in FORBIDDEN_TEXT if needle in metadata_text]
    if metadata_leaks:
        raise RuntimeError(f"Potential identity leak in PDF metadata: {metadata_leaks}")
    author_metadata = str(metadata.get("/Author", "")).strip().lower()
    if author_metadata and "anonymous" not in author_metadata:
        raise RuntimeError(f"Non-anonymous PDF Author metadata: {author_metadata!r}")

    reference_pages = [
        index
        for index, page_text in enumerate(page_texts)
        if "REFERENCES" in page_text.upper().splitlines()
    ]
    if not reference_pages:
        raise RuntimeError("Could not locate the references heading in the PDF")
    main_pages = reference_pages[0]
    if main_pages > 8:
        raise RuntimeError(f"References begin after {main_pages} main-content pages")

    fonts: dict[str, bool] = {}
    for page in reader.pages:
        resources = page.get("/Resources", {}).get_object()
        font_map = resources.get("/Font")
        if not font_map:
            continue
        for font in font_map.get_object().values():
            name, embedded = embedded_font_status(font)
            fonts[name] = fonts.get(name, True) and embedded
    missing = sorted(name for name, embedded in fonts.items() if not embedded)
    if missing:
        raise RuntimeError(f"Fonts not embedded: {missing}")

    print(
        f"submission PDF audit passed: {len(reader.pages)} total / {main_pages} main pages, "
        f"{size} bytes, "
        f"{len(fonts)} embedded font resources"
    )


if __name__ == "__main__":
    main()
