"""Reproducible language baseline for ALFRED lamp-toggle target resolution."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score


SEED = 20260713


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--manifest", type=Path, default=Path("data/manifests/alfred_state_actions.jsonl")
    )
    parser.add_argument(
        "--output", type=Path, default=Path("artifacts/baselines/alfred_toggle_text.json")
    )
    return parser.parse_args()


def variants(records: list[dict]) -> list[dict]:
    return [
        {
            "text": text,
            "target": row["target_object_type"],
            "task_id": row["task_id"],
            "floor_plan": row["floor_plan"],
        }
        for row in records
        for text in row["instructions"]
        if text.strip()
    ]


def risk_coverage(targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray) -> list[dict]:
    order = np.argsort(-confidence)
    result = []
    for coverage in np.linspace(0.05, 1.0, 20):
        count = max(1, int(np.ceil(len(order) * coverage)))
        selected = order[:count]
        result.append(
            {
                "coverage": float(count / len(order)),
                "selective_error": float(1.0 - accuracy_score(targets[selected], predictions[selected])),
                "threshold": float(confidence[selected].min()),
            }
        )
    return result


def selective_summary(targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray) -> dict:
    order = np.argsort(-confidence)
    cumulative_errors = np.cumsum(targets[order] != predictions[order])
    counts = np.arange(1, len(order) + 1)
    risks = cumulative_errors / counts
    return {
        "aurc": float(np.mean(risks)),
        "max_coverage_at_error": {
            str(limit): float(
                np.max(counts[risks <= limit]) / len(order)
                if np.any(risks <= limit)
                else 0.0
            )
            for limit in (0.01, 0.05, 0.10)
        },
    }


def task_bootstrap_ci(rows: list[dict], targets: np.ndarray, predictions: np.ndarray) -> list[float]:
    grouped = {}
    for index, row in enumerate(rows):
        grouped.setdefault(row["task_id"], []).append(index)
    task_ids = sorted(grouped)
    rng = np.random.default_rng(SEED)
    values = []
    for _ in range(5000):
        sampled = rng.choice(task_ids, len(task_ids), replace=True)
        indices = [index for task_id in sampled for index in grouped[task_id]]
        values.append(accuracy_score(targets[indices], predictions[indices]))
    return [float(value) for value in np.quantile(values, (0.025, 0.975))]


def evaluate(rows: list[dict], model: LogisticRegression, matrix, majority: str) -> dict:
    targets = np.asarray([row["target"] for row in rows])
    predictions = model.predict(matrix)
    confidence = model.predict_proba(matrix).max(axis=1)
    summary = selective_summary(targets, predictions, confidence)
    return {
        "n_instruction_variants": len(rows),
        "n_tasks": len({row["task_id"] for row in rows}),
        "n_scenes": len({row["floor_plan"] for row in rows}),
        "majority_accuracy": float(np.mean(targets == majority)),
        "tfidf_accuracy": float(accuracy_score(targets, predictions)),
        "tfidf_accuracy_task_bootstrap_95ci": task_bootstrap_ci(
            rows, targets, predictions
        ),
        "tfidf_macro_f1": float(f1_score(targets, predictions, average="macro")),
        "risk_coverage": risk_coverage(targets, predictions, confidence),
        **summary,
        "confusion": {
            true: {
                predicted: int(np.sum((targets == true) & (predictions == predicted)))
                for predicted in sorted(set(targets))
            }
            for true in sorted(set(targets))
        },
    }


def main() -> None:
    args = parse_args()
    records = [
        json.loads(line)
        for line in args.manifest.read_text(encoding="utf-8").splitlines()
        if line
    ]
    by_split = {
        split: variants([row for row in records if row["split"] == split])
        for split in ("train", "valid_seen", "valid_unseen")
    }
    train = by_split["train"]
    vectorizer = TfidfVectorizer(
        analyzer="char_wb", ngram_range=(2, 5), min_df=2, sublinear_tf=True
    )
    train_matrix = vectorizer.fit_transform(row["text"] for row in train)
    model = LogisticRegression(
        class_weight="balanced", max_iter=2000, random_state=SEED, solver="lbfgs"
    )
    targets = np.asarray([row["target"] for row in train])
    model.fit(train_matrix, targets)
    majority = Counter(targets).most_common(1)[0][0]
    output = {
        "task": "DeskLamp versus FloorLamp target type for ALFRED ToggleObject instructions",
        "seed": SEED,
        "train": {
            "n_instruction_variants": len(train),
            "n_tasks": len({row["task_id"] for row in train}),
            "class_counts": dict(Counter(targets)),
        },
        "results": {
            split: evaluate(
                rows,
                model,
                vectorizer.transform(row["text"] for row in rows),
                majority,
            )
            for split, rows in by_split.items()
            if split != "train"
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
