"""Post-hoc six-fold frozen GTE-ModernBERT language-representation audit."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import OneHotEncoder
from transformers import AutoModel, AutoTokenizer

from baseline_look_and_tell_classical_vision import (
    SEED,
    add_history,
    load_recording,
    new_model,
    paired_participant_difference,
    participant_ci,
)


MODEL_ID = "Alibaba-NLP/gte-modernbert-base"
MODEL_REVISION = "e7f32e3c00f91d699e8c43b53106206bcc72bb22"
MODEL_LICENSE = "Apache-2.0"
MAX_LENGTH = 64


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--derived-root", type=Path, default=Path("data/derived/look_and_tell")
    )
    parser.add_argument(
        "--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json")
    )
    parser.add_argument(
        "--cache",
        type=Path,
        default=Path("data/derived/look_and_tell_gte_modernbert_embeddings.npz"),
    )
    parser.add_argument(
        "--model-cache", type=Path, default=Path("third_party/hf")
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/baselines/look_and_tell_modernbert.json"),
    )
    parser.add_argument("--batch-size", type=int, default=32)
    return parser.parse_args()


def row_signature(rows: list[dict]) -> str:
    payload = {
        "model": MODEL_ID,
        "revision": MODEL_REVISION,
        "pooling": "CLS then L2 normalization",
        "max_length": MAX_LENGTH,
        "rows": [
            {
                "recording_uid": row["recording_uid"],
                "frame_path": row["frame_path"],
                "surface_text": row.get("surface_text") or "",
                "reference": row["reference"],
            }
            for row in rows
        ],
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True).encode("utf-8")
    ).hexdigest()


def encode_rows(
    rows: list[dict], cache: Path, model_cache: Path, batch_size: int
) -> tuple[np.ndarray, int, str]:
    signature = row_signature(rows)
    if cache.exists():
        with np.load(cache, allow_pickle=False) as stored:
            if (
                "row_signature" in stored
                and str(stored["row_signature"].item()) == signature
                and "embeddings" in stored
                and stored["embeddings"].shape == (len(rows), 768)
            ):
                return (
                    stored["embeddings"].copy(),
                    int(stored["parameters"].item()),
                    signature,
                )

    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID, revision=MODEL_REVISION, cache_dir=model_cache
    )
    model = AutoModel.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
        cache_dir=model_cache,
        dtype=torch.float32,
    ).eval()
    parameters = sum(parameter.numel() for parameter in model.parameters())
    texts = [row.get("surface_text") or "" for row in rows]
    unique_texts = sorted(set(texts))
    unique_embeddings: dict[str, np.ndarray] = {}
    for start in range(0, len(unique_texts), batch_size):
        batch_texts = unique_texts[start : start + batch_size]
        tokens = tokenizer(
            batch_texts,
            padding=True,
            truncation=True,
            max_length=MAX_LENGTH,
            return_tensors="pt",
        )
        with torch.inference_mode():
            embeddings = model(**tokens).last_hidden_state[:, 0]
            embeddings = F.normalize(embeddings, p=2, dim=1)
        for text, embedding in zip(batch_texts, embeddings.cpu().numpy(), strict=True):
            unique_embeddings[text] = embedding.astype(np.float32)
    matrix = np.vstack([unique_embeddings[text] for text in texts])
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        cache,
        row_signature=np.asarray(signature),
        parameters=np.asarray(parameters),
        embeddings=matrix,
    )
    return matrix, parameters, signature


def main() -> None:
    args = parse_args()
    split_spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows: list[dict] = []
    missing: list[str] = []
    for split in ("train", "val", "test"):
        for recording in split_spec["splits"][split]["recordings"]:
            try:
                rows.extend(load_recording(args.derived_root, recording))
            except FileNotFoundError:
                missing.append(recording)
    embeddings, parameters, signature = encode_rows(
        rows, args.cache, args.model_cache, args.batch_size
    )

    participants = sorted({row["participant_id"] for row in rows})
    rng = np.random.default_rng(SEED)
    shuffled = np.asarray(participants)[rng.permutation(len(participants))]
    folds = [sorted(fold.tolist()) for fold in np.array_split(shuffled, 6)]
    model_names = ("tfidf_history", "modernbert", "modernbert_history")
    out_of_fold = {name: np.empty(len(rows), dtype=object) for name in model_names}
    fold_results = []

    for fold_index, held_out in enumerate(folds):
        test_mask = np.asarray([row["participant_id"] in held_out for row in rows])
        train_indices = np.flatnonzero(~test_mask)
        test_indices = np.flatnonzero(test_mask)
        train_rows = [dict(rows[index]) for index in train_indices]
        test_rows = [dict(rows[index]) for index in test_indices]

        frequencies = Counter(row["reference"] for row in train_rows)
        labels = sorted(frequencies)
        add_history(train_rows, labels, frequencies)
        add_history(test_rows, labels, frequencies)

        history = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
        history_train = history.fit_transform(
            np.asarray([[row["history_prediction"]] for row in train_rows])
        )
        history_test = history.transform(
            np.asarray([[row["history_prediction"]] for row in test_rows])
        )
        text = TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(2, 5),
            min_df=2,
            max_features=20000,
            sublinear_tf=True,
        )
        text_train = text.fit_transform(
            row.get("surface_text") or "" for row in train_rows
        )
        text_test = text.transform(row.get("surface_text") or "" for row in test_rows)
        modern_train = csr_matrix(embeddings[train_indices])
        modern_test = csr_matrix(embeddings[test_indices])
        matrices = {
            "tfidf_history": (
                hstack([text_train, history_train], format="csr"),
                hstack([text_test, history_test], format="csr"),
            ),
            "modernbert": (modern_train, modern_test),
            "modernbert_history": (
                hstack([modern_train, history_train], format="csr"),
                hstack([modern_test, history_test], format="csr"),
            ),
        }
        targets_train = np.asarray([row["reference"] for row in train_rows])
        targets_test = np.asarray([row["reference"] for row in test_rows])
        metrics = {}
        for name, (matrix_train, matrix_test) in matrices.items():
            classifier = new_model()
            classifier.fit(matrix_train, targets_train)
            predictions = classifier.predict(matrix_test)
            out_of_fold[name][test_indices] = predictions
            metrics[name] = {
                "accuracy": float(accuracy_score(targets_test, predictions)),
                "macro_f1": float(
                    f1_score(
                        targets_test, predictions, average="macro", zero_division=0
                    )
                ),
            }
        fold_results.append(
            {
                "fold": fold_index,
                "held_out_participants": held_out,
                "n": len(test_rows),
                "metrics": metrics,
            }
        )

    targets = np.asarray([row["reference"] for row in rows])
    coref = np.asarray(
        [(row.get("mention_type") or "") == "pronoun/coref" for row in rows]
    )
    aggregate = {}
    for name in model_names:
        predictions = out_of_fold[name]
        aggregate[name] = {
            "accuracy": float(accuracy_score(targets, predictions)),
            "accuracy_participant_bootstrap_95ci": participant_ci(
                rows, targets, predictions
            ),
            "macro_f1": float(
                f1_score(targets, predictions, average="macro", zero_division=0)
            ),
            "coref_accuracy": float(accuracy_score(targets[coref], predictions[coref])),
        }

    comparisons = {
        "modernbert_history_minus_tfidf_history": paired_participant_difference(
            rows,
            targets,
            out_of_fold["modernbert_history"],
            out_of_fold["tfidf_history"],
        ),
        "modernbert_history_minus_modernbert": paired_participant_difference(
            rows,
            targets,
            out_of_fold["modernbert_history"],
            out_of_fold["modernbert"],
        ),
    }
    tfidf_correct = out_of_fold["tfidf_history"] == targets
    modern_correct = out_of_fold["modernbert_history"] == targets
    transitions = {
        "n": len(rows),
        "both_correct": int(np.sum(tfidf_correct & modern_correct)),
        "both_wrong": int(np.sum(~tfidf_correct & ~modern_correct)),
        "modernbert_repairs_tfidf_error": int(np.sum(~tfidf_correct & modern_correct)),
        "modernbert_breaks_tfidf_success": int(np.sum(tfidf_correct & ~modern_correct)),
    }
    output = {
        "protocol": "post-hoc six-fold participant-disjoint out-of-fold language-representation audit",
        "seed": SEED,
        "model": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "model_license": MODEL_LICENSE,
        "parameters": parameters,
        "pooling": "CLS then L2 normalization",
        "max_length": MAX_LENGTH,
        "embedding_cache_signature": signature,
        "n_rows": len(rows),
        "n_participants": len(participants),
        "missing_media_recordings": missing,
        "folds": fold_results,
        "aggregate": aggregate,
        "comparisons": comparisons,
        "error_analysis": transitions,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
