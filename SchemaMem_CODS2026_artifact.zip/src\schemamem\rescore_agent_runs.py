"""Re-execute saved agent predictions with the current result comparator."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .agent_experiment import summarize
from .build_benchmark import execute, result_equivalent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--runs", type=Path, default=Path("results/schemamem/agent_runs.jsonl")
    )
    parser.add_argument(
        "--benchmark", type=Path, default=Path("data/schemamem-bench-v1")
    )
    args = parser.parse_args()
    instances = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    lookup = {(row["scenario"], row["question_id"]): row for row in instances}
    rescored = []
    for line in args.runs.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        target = lookup[(row["scenario"], row["question_id"])]
        path = (
            args.benchmark
            / "databases"
            / target["scenario"]
            / target["db_id"]
            / f'{target["db_id"]}.sqlite'
        )
        gold_ok, gold = execute(path, target["new_sql"])
        exec_ok, result = execute(path, row["prediction"])
        row["exec_ok"] = exec_ok
        row["correct"] = gold_ok and exec_ok and result_equivalent(
            result, gold, target["new_sql"]
        )
        row["error"] = None if exec_ok else result
        rescored.append(row)
    temporary = args.runs.with_suffix(args.runs.suffix + ".rescored")
    temporary.write_text(
        "".join(json.dumps(row) + "\n" for row in rescored), encoding="utf-8"
    )
    temporary.replace(args.runs)
    report = summarize(rescored)
    args.runs.with_suffix(".summary.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
