"""Run a minimal AI2-THOR state-change and rendering smoke test."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from ai2thor.controller import Controller
from PIL import Image


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scene", default="FloorPlan1")
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts/smoke/ai2thor"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    controller = Controller(
        scene=args.scene,
        width=640,
        height=480,
        renderInstanceSegmentation=True,
        renderDepthImage=False,
    )
    try:
        before = controller.last_event
        Image.fromarray(before.frame).save(args.output_dir / "before.png")
        toggleable = [obj for obj in before.metadata["objects"] if obj.get("toggleable")]
        visible_toggleable = [obj for obj in toggleable if obj.get("visible")]
        result = {
            "scene": args.scene,
            "toggleable_count": len(toggleable),
            "visible_toggleable_count": len(visible_toggleable),
            "toggleable_types": sorted({obj["objectType"] for obj in toggleable}),
            "visible_toggleable_types": sorted({obj["objectType"] for obj in visible_toggleable}),
            "toggle_test": None,
        }

        if visible_toggleable:
            target = visible_toggleable[0]
            initial_state = bool(target.get("isToggled"))
            action = "ToggleObjectOff" if initial_state else "ToggleObjectOn"
            after = controller.step(action=action, objectId=target["objectId"], forceAction=True)
            Image.fromarray(after.frame).save(args.output_dir / "after.png")
            updated = next(obj for obj in after.metadata["objects"] if obj["objectId"] == target["objectId"])
            result["toggle_test"] = {
                "target_object_id": target["objectId"],
                "target_object_type": target["objectType"],
                "action": action,
                "initial_state": initial_state,
                "final_state": bool(updated.get("isToggled")),
                "last_action_success": after.metadata["lastActionSuccess"],
                "error_message": after.metadata["errorMessage"],
            }

        (args.output_dir / "result.json").write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        print(json.dumps(result, indent=2, sort_keys=True))
    finally:
        controller.stop()


if __name__ == "__main__":
    main()
