# SchemaMem component-ablation and portability protocol

Status: frozen before running the new ablation or cross-engine outcomes.

Frozen on 2026-07-15 after the previously reported full-policy results were
known. This is a mechanism audit, not a new confirmatory accuracy experiment.
Existing outputs must not be modified in response to these outcomes.

## Questions

1. Which safeguards distinguish scoped structural repair from filtering or an
   execution-only compatibility check?
2. Can execution success resolve a structurally ambiguous migration, or can it
   still expose a memory whose safety is not justified by the migration event?
3. Do validated repaired programs retain their result on an independent SQL
   engine for the subset whose schema, data, and query can be translated without
   manual case-specific fixes?

## Frozen component-ablation inputs

The compatible suite contains every already accepted, execution-equivalent
instance from the frozen artifacts:

- 988 identifier-renaming instances from `schemamem-bench-v1`;
- 397 vertical-split instances from `schemamem-split-v1`; and
- 397 reverse-consolidation instances from `schemamem-merge-v1`.

The uncertainty suite contains all 450 balanced cases from
`schemamem-ambiguity-v1`. No case may be dropped after observing an ablation.

## Compatible-suite variants

All variants return an unaffected memory unchanged. On affected memories:

1. **filter-only** withholds the memory;
2. **AST-unvalidated** applies the declared unique mapping with the independent
   runtime structural rewriter and returns any changed parseable program;
3. **schema-validated** additionally requires every referenced identifier to
   resolve uniquely in the migrated schema;
4. **execution-validated** additionally requires a read-only dry run to succeed;
5. **full fail-closed** uses the released SchemaMem decision function.

Evaluation uses the supplied post-migration program only after each decision.
Report coverage, correctness over all cases, precision among returns, execution
errors, and executable-but-result-inequivalent silent errors, overall and by
operator. A dry run observes only success/failure, never the gold result.

## Uncertainty-suite variants

1. **filter-only** is the released version filter.
2. **execution-only stale** returns the old program exactly when its dry run
   succeeds.
3. **first-candidate + schema** deterministically selects the first declared
   candidate for an ambiguous rename/split/merge, runs the same structural
   rewriter, and requires schema validation. Unsupported, unknown, and
   destructive events remain withheld.
4. **first-candidate + execution** additionally requires a successful dry run.
5. **full fail-closed** is the released SchemaMem decision.

The primary safety metric is unsafe-return rate on the 250 cases whose expected
action is `explore` or `invalidate`. Any return on an ambiguous case is unsafe
because the event does not identify a unique mapping, even if one choice happens
to match the finite fixture. Also report safe-case coverage, action accuracy,
execution success, and post-hoc result equivalence where a gold program exists.

## Interpretation rules

- If schema and execution validation do not improve compatible-suite outcomes,
  report them as redundant on the declared constructors rather than claiming an
  empirical benefit.
- If a first-candidate program executes, do not call execution a semantic safety
  proof. The ambiguity label remains the primary safety ground truth.
- The ablation strengthens the paper only if it clarifies a necessary mechanism
  or exposes a useful negative result without displacing stronger evidence.

## Frozen DuckDB portability protocol

DuckDB 1.5.4 is the available independent engine. Start from all 1,782 compatible
instances above. Translation is automated and case-agnostic:

1. expose every SQLite user table and row to an in-memory DuckDB connection
   through DuckDB's SQLite scanner (`ATTACH ... TYPE SQLITE; USE ...`), falling
   back to a generic Python DB-API schema/data copier only if the scanner is
   unavailable;
2. translate both the supplied post-migration SQL and the full-policy returned
   SQL with SQLGlot's SQLite-to-DuckDB transpiler;
3. reject a case before comparison if database import fails, either translation
   fails, either program fails, or the supplied gold result differs between
   SQLite and DuckDB under the existing bag/ordered-result rule;
4. on the remaining portability-eligible cases, compare the repaired and gold
   DuckDB results using the same result-equivalence rule.

No query-specific edits are allowed. Report the complete exclusion taxonomy,
eligible cases and databases, result-equivalent rate, and 95% Wilson interval.
This is a portability diagnostic. Fewer than 100 eligible cases or fewer than
five databases is feasibility evidence only and will not enter the main paper.

Pre-outcome implementation clarification, also frozen on 2026-07-15: a
scanner-backed attached catalog counts as the automated database import in step
1. DuckDB, rather than SQLite, parses, plans, and executes the translated query;
the scanner supplies table rows without duplicating multi-hundred-megabyte
databases in memory. This clarification was recorded after an installation and
one `COUNT(*)` connectivity check on `superhero`, before any benchmark query or
repair was translated or scored.

## Qualitative failure selection

For each declared category, select the lexicographically first frozen record by
`(cluster_id, db_id, question_id, condition)` after the category predicate is
applied. Predicates and selection are coded before inspecting the selected SQL:

- execution-guided maintenance is executable but semantically wrong;
- full policy withholds an ambiguous mapping;
- downstream agent fails after a semantically correct maintained memory;
- unsupported structural scope is conservatively rejected.

Examples may be shortened for typesetting but not substituted because another
example looks more favorable.

## Frontier-model gate

No frontier-model outcome will be run until a separate model/protocol record
freezes the exact provider model identifier, API revision, frozen target hashes,
conditions, temperature, seed support, tool contract, retry policy, and cost
cap. The current 7B results remain primary. Lack of credentials is not a reason
to use an unverified endpoint or relabel a local model as frontier-scale.
