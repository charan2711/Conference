from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results" / "schemamem"
FIGURES = ROOT / "paper" / "figures"
FIGURES.mkdir(parents=True, exist_ok=True)

report = json.loads((RESULTS / "baselines.json").read_text(encoding="utf-8"))
labels = {
    "stale_raw": "Stale memory",
    "global_flush": "Full flush",
    "version_filter": "Version filter",
    "naive_string": "Naive replace",
    "boundary_string": "Boundary replace",
    "schema_aware_repair": "Schema-aware",
}
order = list(labels)
colors = ["#B2182B", "#777777", "#4D4D4D", "#EF8A62", "#67A9CF", "#2166AC"]

fig, ax = plt.subplots(figsize=(7.0, 3.2))
x = np.arange(len(order))
correct = [report["methods"][name]["correct_rate"] for name in order]
coverage = [report["methods"][name]["coverage"] for name in order]
ax.bar(x - 0.18, correct, 0.36, label="Correct memory", color=colors)
ax.bar(
    x + 0.18,
    coverage,
    0.36,
    label="Returned memory",
    color=colors,
    alpha=0.35,
    hatch="//",
)
ax.set_ylim(0, 1.08)
ax.set_ylabel("Fraction of benchmark instances")
ax.set_xticks(x, [labels[name] for name in order], rotation=22, ha="right")
ax.grid(axis="y", color="#dddddd", linewidth=0.7)
ax.spines[["top", "right"]].set_visible(False)
ax.legend(frameon=False, ncol=2, loc="upper left")
fig.tight_layout()
fig.savefig(FIGURES / "memory_maintenance.pdf", bbox_inches="tight")
fig.savefig(FIGURES / "memory_maintenance.png", dpi=240, bbox_inches="tight")
plt.close(fig)

split_report = json.loads((RESULTS / "split_baselines.json").read_text(encoding="utf-8"))
merge_report = json.loads((RESULTS / "merge_baselines.json").read_text(encoding="utf-8"))
common = ["stale_raw", "version_filter", "schema_aware_repair"]
scenario_values = {
    "Identifier renames": [report["methods"][name]["correct_rate"] for name in common],
    "Table splits": [split_report["methods"][name]["correct_rate"] for name in common],
    "Table merges": [merge_report["methods"][name]["correct_rate"] for name in common],
}
fig, ax = plt.subplots(figsize=(6.4, 3.3))
x = np.arange(len(common))
width = 0.24
for offset, (scenario, values), color in zip(
    (-width, 0, width),
    scenario_values.items(),
    ("#67A9CF", "#EF8A62", "#1B9E77"),
):
    bars = ax.bar(x + offset, values, width, label=scenario, color=color)
    ax.bar_label(bars, labels=[f"{value:.1%}" for value in values], padding=2, fontsize=7)
ax.set_ylim(0, 1.12)
ax.set_ylabel("Correctly maintained memories")
ax.set_xticks(x, [labels[name] for name in common])
ax.grid(axis="y", color="#dddddd", linewidth=0.7)
ax.spines[["top", "right"]].set_visible(False)
ax.legend(frameon=False, loc="upper left")
fig.tight_layout()
fig.savefig(FIGURES / "migration_scenarios.pdf", bbox_inches="tight")
fig.savefig(FIGURES / "migration_scenarios.png", dpi=240, bbox_inches="tight")
plt.close(fig)

repair_15 = json.loads((RESULTS / "llm_repair_1.5b.summary.json").read_text(encoding="utf-8"))
repair_7 = json.loads((RESULTS / "llm_repair_runs_7b.summary.json").read_text(encoding="utf-8"))
repair_mistral = json.loads((RESULTS / "llm_repair_runs_mistral7.summary.json").read_text(encoding="utf-8"))
repair_14 = json.loads((RESULTS / "llm_repair_runs_14b.summary.json").read_text(encoding="utf-8"))
models = ["Qwen 1.5B", "Qwen 7B", "Mistral 7B", "Qwen 14B*"]
schema_only = [
    report["conditions"]["schema_only"]["execution_accuracy"]
    for report in (repair_15, repair_7, repair_mistral, repair_14)
]
manifest = [
    report["conditions"]["explicit_manifest"]["execution_accuracy"]
    for report in (repair_15, repair_7, repair_mistral, repair_14)
]
fig, ax = plt.subplots(figsize=(7.0, 3.5))
x = np.arange(len(models))
width = 0.25
for offset, values, label, color in [
    (-width, schema_only, "LLM: schemas only", "#B2ABD2"),
    (0, manifest, "LLM: + manifest", "#8073AC"),
    (width, [1.0] * len(models), "Structural repair", "#2166AC"),
]:
    bars = ax.bar(x + offset, values, width, label=label, color=color)
    ax.bar_label(bars, labels=[f"{value:.0%}" for value in values], padding=2, fontsize=7)
ax.set_ylim(0, 1.23)
ax.set_ylabel("Execution-equivalent repairs")
ax.set_xticks(x, models)
ax.grid(axis="y", color="#dddddd", linewidth=0.7)
ax.spines[["top", "right"]].set_visible(False)
ax.legend(frameon=False, fontsize=8, loc="upper center", ncol=3)
fig.tight_layout()
fig.savefig(FIGURES / "llm_repair.pdf", bbox_inches="tight", facecolor="white")
fig.savefig(FIGURES / "llm_repair.png", dpi=240, bbox_inches="tight", facecolor="white")
plt.close(fig)

fig, ax = plt.subplots(figsize=(4.6, 3.4))
for name, color in zip(order, colors):
    metric = report["methods"][name]
    ax.scatter(
        metric["coverage"],
        metric["precision_when_returned"],
        s=65,
        color=color,
        label=labels[name],
        edgecolor="white",
        linewidth=0.6,
    )
ax.set_xlim(-0.03, 1.04)
ax.set_ylim(0.75, 1.015)
ax.set_xlabel("Memory availability (coverage)")
ax.set_ylabel("Correctness when returned")
ax.grid(color="#dddddd", linewidth=0.7)
ax.spines[["top", "right"]].set_visible(False)
ax.legend(frameon=False, fontsize=7, loc="lower left")
fig.tight_layout()
fig.savefig(FIGURES / "coverage_precision.pdf", bbox_inches="tight")
fig.savefig(FIGURES / "coverage_precision.png", dpi=240, bbox_inches="tight")
plt.close(fig)

ambiguity = json.loads((RESULTS / "ambiguity.json").read_text(encoding="utf-8"))
policy_labels = {
    "global_flush": "Full flush",
    "optimistic_reuse": "Optimistic reuse",
    "version_filter": "Version filter",
    "schemamem": "SchemaMem",
}
policy_colors = {
    "global_flush": "#777777",
    "optimistic_reuse": "#B2182B",
    "version_filter": "#67A9CF",
    "schemamem": "#2166AC",
}
fig, ax = plt.subplots(figsize=(5.0, 3.5))
for name, metric in ambiguity["policies"].items():
    x_value = metric["safe_case_coverage"]
    y_value = metric["unsafe_return_rate"]
    ax.scatter(x_value, y_value, s=75, color=policy_colors[name], edgecolor="white")
    dx, dy = (0.018, 0.025)
    if name == "schemamem":
        dx = -0.23
    ax.annotate(policy_labels[name], (x_value, y_value), xytext=(x_value + dx, y_value + dy), fontsize=8)
ax.set_xlim(-0.03, 1.04)
ax.set_ylim(-0.03, 1.08)
ax.set_xlabel("Safe-case coverage (higher is better)")
ax.set_ylabel("Unsafe return rate (lower is better)")
ax.grid(color="#dddddd", linewidth=0.7)
ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout()
fig.savefig(FIGURES / "ambiguity_tradeoff.pdf", bbox_inches="tight")
fig.savefig(FIGURES / "ambiguity_tradeoff.png", dpi=240, bbox_inches="tight")
plt.close(fig)
