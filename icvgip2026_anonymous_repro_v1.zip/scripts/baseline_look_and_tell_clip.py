"""Frozen OpenAI CLIP gaze-crop baseline for Look and Tell."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import cv2
import numpy as np
import torch
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import OneHotEncoder
from transformers import AutoProcessor, CLIPModel

from baseline_look_and_tell_classical_vision import (
    SEED,
    add_history,
    ece,
    gaze_crop,
    load_recording,
    new_model,
    paired_participant_difference,
    participant_ci,
    risk_coverage,
    selective_summary,
)


MODEL_NAME = "openai/clip-vit-base-patch32"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--derived-root", type=Path, default=Path("data/derived/look_and_tell")
    )
    parser.add_argument(
        "--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json")
    )
    parser.add_argument("--cache-dir", type=Path, default=Path("third_party/hf"))
    parser.add_argument(
        "--embedding-cache",
        type=Path,
        default=Path("data/derived/look_and_tell_clip_gaze_embeddings.npz"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/baselines/look_and_tell_clip.json"),
    )
    parser.add_argument("--batch-size", type=int, default=8)
    return parser.parse_args()


def load_rows(root: Path, spec: dict) -> tuple[dict[str, list[dict]], dict[str, list[str]]]:
    rows_by_split = {}
    missing = {}
    for split in ("train", "val", "test"):
        rows_by_split[split] = []
        missing[split] = []
        for recording in spec["splits"][split]["recordings"]:
            try:
                rows_by_split[split].extend(load_recording(root, recording))
            except FileNotFoundError:
                missing[split].append(recording)
    return rows_by_split, missing


def crop_rgb(row: dict) -> np.ndarray:
    frame = cv2.imread(row["frame_path"], cv2.IMREAD_COLOR)
    if frame is None:
        raise FileNotFoundError(row["frame_path"])
    crop = gaze_crop(
        frame,
        row.get("fix_x"),
        row.get("fix_y"),
        half_size=192,
        output_size=224,
    )
    return cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)


def embed_rows(
    rows: list[dict], model: CLIPModel, processor: AutoProcessor, batch_size: int
) -> np.ndarray:
    batches = []
    with torch.inference_mode():
        for start in range(0, len(rows), batch_size):
            images = [crop_rgb(row) for row in rows[start : start + batch_size]]
            inputs = processor(images=images, return_tensors="pt")
            features = model.get_image_features(**inputs)
            if not isinstance(features, torch.Tensor):
                features = features.pooler_output
            features = torch.nn.functional.normalize(features, dim=1)
            batches.append(features.cpu().numpy().astype(np.float32))
            if start % (batch_size * 20) == 0:
                print(f"embedded {min(start + batch_size, len(rows))}/{len(rows)}", flush=True)
    return np.vstack(batches)


def metric_block(rows: list[dict], targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray) -> dict:
    summary = selective_summary(targets, predictions, confidence)
    coref = np.asarray(
        [(row.get("mention_type") or "") == "pronoun/coref" for row in rows]
    )
    return {
        "n": len(rows),
        "accuracy": float(accuracy_score(targets, predictions)),
        "accuracy_participant_bootstrap_95ci": participant_ci(rows, targets, predictions),
        "macro_f1": float(f1_score(targets, predictions, average="macro", zero_division=0)),
        "coref_accuracy": float(accuracy_score(targets[coref], predictions[coref])),
        "ece_10bin": ece(targets, predictions, confidence),
        "risk_coverage": risk_coverage(targets, predictions, confidence),
        **summary,
    }


def main() -> None:
    args = parse_args()
    torch.set_num_threads(max(1, min(8, (torch.get_num_threads() or 1))))
    spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows_by_split, missing = load_rows(args.derived_root, spec)
    processor = AutoProcessor.from_pretrained(
        MODEL_NAME, cache_dir=args.cache_dir, local_files_only=True
    )
    model = CLIPModel.from_pretrained(
        MODEL_NAME, cache_dir=args.cache_dir, local_files_only=True
    ).eval()

    embeddings = {}
    cached = {}
    if args.embedding_cache.exists():
        with np.load(args.embedding_cache, allow_pickle=False) as archive:
            for split, rows in rows_by_split.items():
                if split in archive and archive[split].shape[0] == len(rows):
                    cached[split] = archive[split].copy()
    for split, rows in rows_by_split.items():
        embeddings[split] = (
            cached[split]
            if split in cached
            else embed_rows(rows, model, processor, args.batch_size)
        )
    if len(cached) != len(rows_by_split):
        args.embedding_cache.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(args.embedding_cache, **embeddings)

    train_rows = rows_by_split["train"]
    frequencies = Counter(row["reference"] for row in train_rows)
    labels = sorted(frequencies)
    for rows in rows_by_split.values():
        add_history(rows, labels, frequencies)

    text = TfidfVectorizer(
        analyzer="char_wb", ngram_range=(2, 5), min_df=2, max_features=20000,
        sublinear_tf=True
    )
    text_matrices = {
        "train": text.fit_transform(row.get("surface_text") or "" for row in train_rows)
    }
    for split in ("val", "test"):
        text_matrices[split] = text.transform(
            row.get("surface_text") or "" for row in rows_by_split[split]
        )

    history = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    history_matrices = {
        "train": history.fit_transform(
            np.asarray([[row["history_prediction"]] for row in train_rows])
        )
    }
    for split in ("val", "test"):
        history_matrices[split] = history.transform(
            np.asarray([[row["history_prediction"]] for row in rows_by_split[split]])
        )
    clip_matrices = {split: csr_matrix(matrix) for split, matrix in embeddings.items()}
    feature_sets = {
        "clip_image": clip_matrices,
        "text_history": {
            split: hstack([text_matrices[split], history_matrices[split]], format="csr")
            for split in ("train", "val", "test")
        },
        "text_clip_history": {
            split: hstack(
                [text_matrices[split], clip_matrices[split], history_matrices[split]],
                format="csr",
            )
            for split in ("train", "val", "test")
        },
    }
    targets_train = np.asarray([row["reference"] for row in train_rows])
    results = {}
    predictions = {}
    for name, matrices in feature_sets.items():
        classifier = new_model()
        classifier.fit(matrices["train"], targets_train)
        results[name] = {}
        predictions[name] = {}
        for split in ("val", "test"):
            targets = np.asarray([row["reference"] for row in rows_by_split[split]])
            predicted = classifier.predict(matrices[split])
            confidence = classifier.predict_proba(matrices[split]).max(axis=1)
            predictions[name][split] = predicted
            results[name][split] = metric_block(
                rows_by_split[split], targets, predicted, confidence
            )

    with torch.inference_mode():
        label_inputs = processor(
            text=[f"a photo of {label}" for label in labels],
            return_tensors="pt",
            padding=True,
        )
        label_features = model.get_text_features(**label_inputs)
        if not isinstance(label_features, torch.Tensor):
            label_features = label_features.pooler_output
        label_features = torch.nn.functional.normalize(label_features, dim=1).cpu().numpy()
    results["clip_zero_shot"] = {}
    for split in ("val", "test"):
        similarities = embeddings[split] @ label_features.T
        indices = similarities.argmax(axis=1)
        predicted = np.asarray([labels[index] for index in indices])
        shifted = similarities - similarities.max(axis=1, keepdims=True)
        probabilities = np.exp(shifted) / np.exp(shifted).sum(axis=1, keepdims=True)
        targets = np.asarray([row["reference"] for row in rows_by_split[split]])
        results["clip_zero_shot"][split] = metric_block(
            rows_by_split[split], targets, predicted, probabilities.max(axis=1)
        )

    paired = {}
    for split in ("val", "test"):
        targets = np.asarray([row["reference"] for row in rows_by_split[split]])
        paired[split] = paired_participant_difference(
            rows_by_split[split],
            targets,
            predictions["text_clip_history"][split],
            predictions["text_history"][split],
        )
    output = {
        "model": MODEL_NAME,
        "model_revision": getattr(model.config, "_commit_hash", None),
        "parameters": int(sum(parameter.numel() for parameter in model.parameters())),
        "device": "cpu",
        "seed": SEED,
        "rows_by_split": {split: len(rows) for split, rows in rows_by_split.items()},
        "missing_media_recordings": missing,
        "results": results,
        "paired_text_clip_history_minus_text_history": paired,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
