"""Run the manuscript and anonymous-supplement release gates in one command."""

from __future__ import annotations

import argparse
import hashlib
import json
import py_compile
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "output" / "supplement" / "icvgip2026_anonymous_repro_v1.zip"
OFFICIAL_TEMPLATE = ROOT / "paper" / "template_2026" / "icvgip2026-latex-template.zip"
TEMPLATE_AUDIT = ROOT / "artifacts" / "audits" / "icvgip2026_template_20260722.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--pdf",
        type=Path,
        default=ROOT / "output" / "pdf" / "icvgip2026_draft_v34.pdf",
    )
    return parser.parse_args()


def run(script: str, *arguments: str) -> None:
    subprocess.run(
        [sys.executable, str(ROOT / "scripts" / script), *arguments],
        cwd=ROOT,
        check=True,
    )


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_official_template() -> None:
    audit = json.loads(TEMPLATE_AUDIT.read_text(encoding="utf-8"))
    template_bytes = OFFICIAL_TEMPLATE.read_bytes()
    if len(template_bytes) != audit["official_zip_bytes"]:
        raise RuntimeError("Official template byte count changed")
    if sha256(template_bytes) != audit["official_zip_sha256"]:
        raise RuntimeError("Official template ZIP hash mismatch")
    with zipfile.ZipFile(OFFICIAL_TEMPLATE) as archive:
        entries = archive.namelist()
        class_entries = [name for name in entries if name.endswith("/acmart.cls")]
        style_entries = [
            name for name in entries if name.endswith("/ACM-Reference-Format.bst")
        ]
        if len(class_entries) != 1 or len(style_entries) != 1:
            raise RuntimeError("Official template class/style entries are ambiguous")
        official_class = archive.read(class_entries[0])
        official_style = archive.read(style_entries[0])
    live_class = (ROOT / "paper" / "acmart.cls").read_bytes()
    live_style = (ROOT / "paper" / "ACM-Reference-Format.bst").read_bytes()
    observed = {
        "official_acmart_sha256": sha256(official_class),
        "live_acmart_sha256": sha256(live_class),
        "official_bibliography_style_sha256": sha256(official_style),
        "live_bibliography_style_sha256": sha256(live_style),
    }
    for key, value in observed.items():
        if value != audit[key]:
            raise RuntimeError(f"Template audit mismatch for {key}")
    if official_class != live_class or official_style != live_style:
        raise RuntimeError("Live class/style differ from the official 2026 template")
    if audit["status"] != "pass_official_2026_template_equivalence":
        raise RuntimeError("Unexpected official-template audit status")
    print("official 2026 template equivalence audit passed")


def verify_archive() -> tuple[str, int]:
    with zipfile.ZipFile(ARCHIVE) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"ZIP CRC failure: {bad}")
        manifest = json.loads(archive.read("MANIFEST.json"))
        listed = {entry["path"] for entry in manifest["files"]}
        archived = set(archive.namelist()) - {"MANIFEST.json"}
        if listed != archived:
            raise RuntimeError(
                f"Manifest/archive file mismatch: listed-only={listed - archived}, "
                f"archive-only={archived - listed}"
            )
        for entry in manifest["files"]:
            data = archive.read(entry["path"])
            if len(data) != entry["bytes"] or sha256(data) != entry["sha256"]:
                raise RuntimeError(f"Manifest digest mismatch: {entry['path']}")
    return sha256(ARCHIVE.read_bytes()), len(listed)


def verify_extracted_archive() -> None:
    with tempfile.TemporaryDirectory(prefix="icvgip-repro-check-") as temporary:
        root = Path(temporary)
        with zipfile.ZipFile(ARCHIVE) as archive:
            archive.extractall(root)
        subprocess.run(
            [sys.executable, str(root / "scripts" / "audit_release_redistribution.py"), "--quiet"],
            cwd=root,
            check=True,
        )
        subprocess.run(
            [sys.executable, str(root / "scripts" / "verify_paper_claims.py")],
            cwd=root,
            check=True,
        )
        for path in sorted((root / "scripts").glob("*.py")):
            py_compile.compile(str(path), doraise=True)


def main() -> None:
    args = parse_args()
    pdf = args.pdf.resolve()
    verify_official_template()
    run("audit_raw_derived_alignment.py", "--quiet")
    run("audit_leakage_integrity.py", "--quiet")
    run("audit_release_redistribution.py")
    run("generate_paper_assets.py", "--check")
    run("verify_paper_claims.py")
    run("verify_nested_threshold_look_and_tell.py")
    run("verify_submission_metadata.py")
    for path in sorted((ROOT / "scripts").glob("*.py")):
        py_compile.compile(str(path), doraise=True)
    run("verify_submission_pdf.py", str(pdf))

    run("build_anonymous_supplement.py")
    first_hash, first_count = verify_archive()
    run("build_anonymous_supplement.py")
    second_hash, second_count = verify_archive()
    if first_hash != second_hash or first_count != second_count:
        raise RuntimeError("Anonymous supplement build is not deterministic")
    verify_extracted_archive()

    print(
        "all submission checks passed: "
        f"pdf={pdf.name}, supplement_files={second_count}, "
        f"supplement_sha256={second_hash}"
    )


if __name__ == "__main__":
    main()
