"""Post-hoc semantic audit of deterministic policy-maintained memories."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from scipy.stats import binomtest

from .build_benchmark import execute, result_equivalent
from .memory_policy import decide_rename
from .tool_agent_experiment import migration_manifest, sqlite_schema


def interval(successes: int, n: int) -> list[float | None]:
    if not n:
        return [None, None]
    estimate = binomtest(successes, n).proportion_ci(method="wilson")
    return [float(estimate.low), float(estimate.high)]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--benchmark", type=Path, required=True)
    parser.add_argument("--original-root", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    instances = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    index = {
        (row["scenario"], row["db_id"], row["question_id"]): row
        for row in instances
        if row["execution_equivalent"]
    }
    migrations = json.loads((args.benchmark / "migrations.json").read_text(encoding="utf-8"))
    original_root = args.original_root or args.benchmark / "original_databases"

    audited = []
    for line in args.runs.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if row["condition"] != "policy_memory":
            continue
        target = index[(row["scenario"], row["db_id"], row["question_id"])]
        memory = index[(row["scenario"], row["db_id"], row["memory_question_id"])]
        current_path = (
            args.benchmark
            / "databases"
            / row["scenario"]
            / row["db_id"]
            / f"{row['db_id']}.sqlite"
        )
        old_path = original_root / row["db_id"] / f"{row['db_id']}.sqlite"
        manifest = migration_manifest(target, migrations[row["db_id"]])
        decision = decide_rename(
            memory["old_sql"],
            sqlite_schema(old_path),
            sqlite_schema(current_path),
            manifest,
        )
        returned = decision.action in {"reuse", "migrate"} and bool(decision.sql)
        gold_ok, gold = execute(current_path, memory["new_sql"], timeout_seconds=10)
        pred_ok, prediction = (
            execute(current_path, decision.sql or "", timeout_seconds=10)
            if returned
            else (False, "withheld")
        )
        semantically_correct = bool(
            returned
            and gold_ok
            and pred_ok
            and result_equivalent(prediction, gold, memory["new_sql"])
        )
        audited.append(
            {
                "scenario": row["scenario"],
                "db_id": row["db_id"],
                "cluster_id": row.get("cluster_id", row["db_id"]),
                "target_question_id": row["question_id"],
                "memory_question_id": row["memory_question_id"],
                "recorded_action": row.get("policy_action"),
                "recomputed_action": decision.action,
                "action_matches_run": row.get("policy_action") == decision.action,
                "recorded_memory_provided": row.get("memory_provided"),
                "recomputed_returned": returned,
                "return_matches_run": bool(row.get("memory_provided")) == returned,
                "returned_sql_executable": pred_ok,
                "returned_sql_semantically_correct": semantically_correct,
                "unsafe_return": bool(returned and not semantically_correct),
            }
        )

    returned_rows = [row for row in audited if row["recomputed_returned"]]
    correct = sum(row["returned_sql_semantically_correct"] for row in returned_rows)
    report = {
        "n": len(audited),
        "actions": dict(Counter(row["recomputed_action"] for row in audited)),
        "returned": len(returned_rows),
        "withheld": len(audited) - len(returned_rows),
        "returned_executable": sum(row["returned_sql_executable"] for row in returned_rows),
        "returned_semantically_correct": correct,
        "returned_semantic_accuracy": correct / len(returned_rows) if returned_rows else None,
        "returned_semantic_wilson_95": interval(correct, len(returned_rows)),
        "unsafe_returns": sum(row["unsafe_return"] for row in audited),
        "action_mismatches": sum(not row["action_matches_run"] for row in audited),
        "return_mismatches": sum(not row["return_matches_run"] for row in audited),
        "audit_note": (
            "gold migrated-memory results are used only after the frozen run; "
            "they never affect the policy decision or downstream agent"
        ),
        "instances": audited,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "instances"}, indent=2))


if __name__ == "__main__":
    main()
