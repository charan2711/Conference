"""Evaluate lifecycle action selection on ambiguous and destructive changes."""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

from .build_benchmark import sqlite_schema
from .memory_policy import decide_merge, decide_rename, decide_split


SAFE_ACTIONS = {"reuse", "migrate"}


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> list[float]:
    proportion = successes / total
    denominator = 1 + z * z / total
    center = (proportion + z * z / (2 * total)) / denominator
    half_width = z * math.sqrt(
        proportion * (1 - proportion) / total + z * z / (4 * total * total)
    ) / denominator
    lower = max(0.0, center - half_width)
    upper = min(1.0, center + half_width)
    return [0.0 if lower < 1e-15 else lower, upper]


def policy_metrics(evaluated: list[dict], actions: list[str]) -> dict:
    safe_total = sum(row["expected_action"] in SAFE_ACTIONS for row in evaluated)
    unsafe_total = len(evaluated) - safe_total
    safe_returns = sum(
        action in SAFE_ACTIONS and row["expected_action"] in SAFE_ACTIONS
        for row, action in zip(evaluated, actions)
    )
    unsafe_returns = sum(
        action in SAFE_ACTIONS and row["expected_action"] not in SAFE_ACTIONS
        for row, action in zip(evaluated, actions)
    )
    return {
        "action_accuracy": sum(
            action == row["expected_action"] for row, action in zip(evaluated, actions)
        ) / len(evaluated),
        "safe_case_coverage": safe_returns / safe_total,
        "safe_case_coverage_95ci": wilson_interval(safe_returns, safe_total),
        "unsafe_return_rate": unsafe_returns / unsafe_total,
        "unsafe_return_rate_95ci": wilson_interval(unsafe_returns, unsafe_total),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", type=Path, default=Path("data/schemamem-ambiguity-v1"))
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/ambiguity.json"))
    args = parser.parse_args()
    rows = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    originals = Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases")
    rename_root = Path("data/schemamem-bench-v1")
    split_root = Path("data/schemamem-split-v1")
    evaluated = []
    for row in rows:
        old_path = originals / row["db_id"] / f'{row["db_id"]}.sqlite'
        if row["scenario"] == "table_merge":
            old_path = split_root / "databases" / row["db_id"] / f'{row["db_id"]}.sqlite'
            current_path = originals / row["db_id"] / f'{row["db_id"]}.sqlite'
        elif row["scenario"] == "table_split":
            current_path = split_root / "databases" / row["db_id"] / f'{row["db_id"]}.sqlite'
        else:
            current_path = rename_root / "databases" / row["scenario"] / row["db_id"] / f'{row["db_id"]}.sqlite'
        old_schema, current_schema = sqlite_schema(old_path), sqlite_schema(current_path)
        if row["scenario"] == "table_merge":
            decision = decide_merge(row["old_sql"], old_schema, current_schema, row["merge_spec"], row["join_candidates"])
        elif row["scenario"] == "table_split":
            decision = decide_split(row["old_sql"], old_schema, current_schema, row["split_spec"], row["join_candidates"])
        else:
            decision = decide_rename(row["old_sql"], old_schema, current_schema, row["manifest"])
        evaluated.append({**row, "decision": decision.to_dict(), "action_correct": decision.action == row["expected_action"]})
    schemamem_actions = [row["decision"]["action"] for row in evaluated]
    version_filter_actions = [
        "reuse" if row["class"] == "unaffected" else "explore" for row in evaluated
    ]
    policy_reports = {
        "global_flush": policy_metrics(evaluated, ["invalidate"] * len(evaluated)),
        "optimistic_reuse": policy_metrics(evaluated, ["reuse"] * len(evaluated)),
        "version_filter": policy_metrics(evaluated, version_filter_actions),
        "schemamem": policy_metrics(evaluated, schemamem_actions),
    }
    report = {
        "n": len(evaluated),
        **policy_reports["schemamem"],
        "policies": policy_reports,
        "by_class": {},
    }
    groups: dict[str, list[dict]] = defaultdict(list)
    for row in evaluated:
        groups[row["class"]].append(row)
    for name, group in sorted(groups.items()):
        report["by_class"][name] = {
            "n": len(group),
            "action_accuracy": sum(row["action_correct"] for row in group) / len(group),
            "actions": dict(__import__("collections").Counter(row["decision"]["action"] for row in group)),
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    args.output.with_name("ambiguity_instances.json").write_text(json.dumps(evaluated, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
