"""Build an executable table-consolidation benchmark from validated splits."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .build_benchmark import execute, result_equivalent


def main() -> None:
    parser = argparse.ArgumentParser()
    root = Path("data/bird-mini-dev/package/minidev/MINIDEV")
    parser.add_argument("--split", type=Path, default=Path("data/schemamem-split-v1"))
    parser.add_argument("--current-databases", type=Path, default=root / "dev_databases")
    parser.add_argument("--output", type=Path, default=Path("data/schemamem-merge-v1"))
    parser.add_argument(
        "--revalidate",
        action="store_true",
        help="repeat the split benchmark's potentially expensive paired executions",
    )
    args = parser.parse_args()

    split_rows = json.loads((args.split / "instances.json").read_text(encoding="utf-8"))
    specs = json.loads((args.split / "migrations.json").read_text(encoding="utf-8"))
    output = []
    for row in split_rows:
        if not row["execution_equivalent"]:
            continue
        db_id = row["db_id"]
        old_db = args.split / "databases" / db_id / f"{db_id}.sqlite"
        current_db = args.current_databases / db_id / f"{db_id}.sqlite"
        old_sql, new_sql = row["new_sql"], row["old_sql"]
        if args.revalidate:
            old_ok, old_result = execute(old_db, old_sql, timeout_seconds=10)
            new_ok, new_result = execute(current_db, new_sql, timeout_seconds=10)
            equivalent = old_ok and new_ok and result_equivalent(
                old_result, new_result, new_sql
            )
        else:
            # These are exactly the same database/query pairs already executed
            # by split-v1, with historical and current directions exchanged.
            old_ok = row["new_exec_ok"]
            new_ok = row["old_exec_ok"]
            equivalent = row["execution_equivalent"]
            new_result = None
        output.append(
            {
                **{key: value for key, value in row.items() if key not in {
                    "scenario", "old_sql", "new_sql", "old_exec_ok", "new_exec_ok",
                    "execution_equivalent", "new_error"
                }},
                "scenario": "table_merge",
                "old_sql": old_sql,
                "new_sql": new_sql,
                "old_exec_ok": old_ok,
                "new_exec_ok": new_ok,
                "execution_equivalent": equivalent,
                "new_error": None if new_ok else new_result,
            }
        )

    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "instances.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    (args.output / "migrations.json").write_text(json.dumps(specs, indent=2), encoding="utf-8")
    validated = [row for row in output if row["execution_equivalent"]]
    summary = {
        "databases": len({row["db_id"] for row in output}),
        "instances": len(output),
        "validated": len(validated),
        "equivalence_rate": len(validated) / len(output) if output else 0,
        "affected_validated": sum(row["affected"] for row in validated),
        "affected_rate_validated": (
            sum(row["affected"] for row in validated) / len(validated) if validated else 0
        ),
        "provenance": (
            "directional inverse of SchemaMem split-v1; paired executions repeated"
            if args.revalidate else
            "directional inverse of SchemaMem split-v1; inherits its paired execution gates"
        ),
    }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
