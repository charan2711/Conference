"""Build and evaluate executable three-transition schema lifecycles.

Each lifecycle starts from a public BIRD Mini-Dev database and applies a
vertical split, a semantically named column-rename migration, and a reverse
consolidation.  Gold programs are produced by the benchmark builders, while
SchemaMem uses the independent runtime rewriters in :mod:`memory_policy`.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path

from .build_benchmark import (
    execute,
    result_equivalent,
    rewrite_sql,
    sqlite_schema,
)
from .memory_policy import decide_merge, decide_rename, decide_split
from .split_benchmark import apply_split, quote, rewrite_split


def parse_column_map(raw: dict[str, str]) -> dict[tuple[str, str], str]:
    return {tuple(key.split(".", 1)): value for key, value in raw.items()}


def adjusted_column_map(
    mapping: dict[tuple[str, str], str], spec: dict
) -> dict[tuple[str, str], str]:
    """Route renames of moved columns to the post-split details relation."""
    keys = {name.casefold() for name in spec["primary_key"]}
    moved = {name.casefold() for name in spec["moved_columns"]}
    adjusted: dict[tuple[str, str], str] = {}
    for (table, old), new in mapping.items():
        if table.casefold() == spec["table"].casefold():
            if old.casefold() in keys:
                # Renaming a duplicated split key would require a coordinated
                # two-table operation and is outside the declared operator.
                continue
            table = spec["details_table"] if old.casefold() in moved else table
        adjusted[(table, old)] = new
    return adjusted


def renamed_spec(spec: dict, mapping: dict[tuple[str, str], str]) -> dict:
    by_column = {
        old.casefold(): new
        for (table, old), new in mapping.items()
        if table.casefold() == spec["table"].casefold()
    }

    def renamed(columns: list[str]) -> list[str]:
        return [by_column.get(column.casefold(), column) for column in columns]

    return {
        **spec,
        "primary_key": renamed(spec["primary_key"]),
        "moved_columns": renamed(spec["moved_columns"]),
        "kept_columns": renamed(spec["kept_columns"]),
    }


def apply_renames(
    source: Path,
    destination: Path,
    mapping: dict[tuple[str, str], str],
) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    with sqlite3.connect(destination) as connection:
        for (table, old), new in mapping.items():
            connection.execute(
                f"ALTER TABLE {quote(table)} RENAME COLUMN {quote(old)} TO {quote(new)}"
            )
    normalize_database(destination)


def normalize_database(path: Path) -> None:
    """Checkpoint inherited WAL state before a generated version is copied."""
    with sqlite3.connect(path) as connection:
        connection.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
        connection.commit()


def apply_consolidation(source: Path, destination: Path, spec: dict) -> None:
    """Consolidate a validated one-to-one vertical split without a gold query."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    table, details = spec["table"], spec["details_table"]
    temporary = f"__schemamem_merge_{table}"
    with sqlite3.connect(destination) as connection:
        base_columns = [
            row[1] for row in connection.execute(f"PRAGMA table_info({quote(table)})")
        ]
        detail_columns = [
            row[1] for row in connection.execute(f"PRAGMA table_info({quote(details)})")
        ]
        keys = {name.casefold() for name in spec["primary_key"]}
        moved = [name for name in detail_columns if name.casefold() not in keys]
        projection = [f"b.{quote(name)}" for name in base_columns] + [
            f"d.{quote(name)}" for name in moved
        ]
        predicate = " AND ".join(
            f"b.{quote(key)} = d.{quote(key)}" for key in spec["primary_key"]
        )
        base_count = connection.execute(
            f"SELECT COUNT(*) FROM {quote(table)}"
        ).fetchone()[0]
        joined_count = connection.execute(
            f"SELECT COUNT(*) FROM {quote(table)} b JOIN {quote(details)} d ON {predicate}"
        ).fetchone()[0]
        if base_count != joined_count:
            raise ValueError("split relations are not a total one-to-one consolidation")
        connection.execute(
            f"CREATE TABLE {quote(temporary)} AS SELECT {', '.join(projection)} "
            f"FROM {quote(table)} b JOIN {quote(details)} d ON {predicate}"
        )
        connection.execute(f"DROP TABLE {quote(details)}")
        connection.execute(f"DROP TABLE {quote(table)}")
        connection.execute(
            f"ALTER TABLE {quote(temporary)} RENAME TO {quote(table)}"
        )
    normalize_database(destination)


def rename_manifest(mapping: dict[tuple[str, str], str]) -> dict:
    candidates = {f"{table}.{old}": [new] for (table, old), new in mapping.items()}
    return {
        "operator": "rename",
        "write_set": list(candidates),
        "column_candidates": candidates,
        "table_candidates": {},
    }


def evaluate_sql(path: Path, sql: str | None, gold: list, gold_sql: str) -> bool:
    if not sql:
        return False
    ok, result = execute(path, sql, timeout_seconds=10)
    return bool(ok and result_equivalent(result, gold, gold_sql))


def build(args: argparse.Namespace) -> dict:
    records = json.loads(args.questions.read_text(encoding="utf-8"))
    by_db: dict[str, list[dict]] = defaultdict(list)
    for record in records:
        by_db[record["db_id"]].append(record)
    split_specs = json.loads((args.split / "migrations.json").read_text(encoding="utf-8"))
    rename_migrations = json.loads(
        (args.rename / "migrations.json").read_text(encoding="utf-8")
    )

    output: list[dict] = []
    lifecycle_specs: dict[str, dict] = {}
    for db_id, spec in sorted(split_specs.items()):
        original = args.databases / db_id / f"{db_id}.sqlite"
        v1 = args.output / "databases" / "v1_split" / db_id / f"{db_id}.sqlite"
        v2 = args.output / "databases" / "v2_rename" / db_id / f"{db_id}.sqlite"
        v3 = args.output / "databases" / "v3_merge" / db_id / f"{db_id}.sqlite"
        raw_map = parse_column_map(rename_migrations[db_id]["column_rename"])
        key_names = {name.casefold() for name in spec["primary_key"]}
        original_map = {
            (table, old): new
            for (table, old), new in raw_map.items()
            if not (
                table.casefold() == spec["table"].casefold()
                and old.casefold() in key_names
            )
        }
        routed_map = adjusted_column_map(original_map, spec)
        merge_spec = renamed_spec(spec, original_map)
        apply_split(original, v1, spec)
        normalize_database(v1)
        apply_renames(v1, v2, routed_map)
        apply_consolidation(v2, v3, merge_spec)
        schemas = [
            sqlite_schema(original),
            sqlite_schema(v1),
            sqlite_schema(v2),
            sqlite_schema(v3),
        ]
        manifest = rename_manifest(routed_map)
        lifecycle_specs[db_id] = {
            "v1_split": spec,
            "v2_column_rename": {
                f"{table}.{old}": new for (table, old), new in routed_map.items()
            },
            "v3_consolidation": merge_spec,
        }

        for record in by_db[db_id]:
            try:
                old_ok, gold = execute(original, record["SQL"], timeout_seconds=10)
                q1, split_changed = rewrite_split(record["SQL"], schemas[0], spec)
                q2, rename_changed = rewrite_sql(q1, schemas[1], routed_map, {})
                q3, final_rename_changed = rewrite_sql(
                    record["SQL"], schemas[0], original_map, {}
                )
                builder_sql = [q1, q2, q3]
                builder_correct = [
                    old_ok and evaluate_sql(path, sql, gold, record["SQL"])
                    for path, sql in zip((v1, v2, v3), builder_sql)
                ]
                if not old_ok or not all(builder_correct):
                    continue

                key = [[(name, name) for name in spec["primary_key"]]]
                d1 = decide_split(record["SQL"], schemas[0], schemas[1], spec, key)
                d2 = (
                    decide_rename(d1.sql, schemas[1], schemas[2], manifest)
                    if d1.sql else None
                )
                merge_keys = [[(name, name) for name in merge_spec["primary_key"]]]
                d3 = (
                    decide_merge(d2.sql, schemas[2], schemas[3], merge_spec, merge_keys)
                    if d2 and d2.sql else None
                )
                policy_sql = [d1.sql, d2.sql if d2 else None, d3.sql if d3 else None]
                policy_correct = [
                    evaluate_sql(path, sql, gold, record["SQL"])
                    for path, sql in zip((v1, v2, v3), policy_sql)
                ]
                stale_correct = [
                    evaluate_sql(path, record["SQL"], gold, record["SQL"])
                    for path in (v1, v2, v3)
                ]
                affected = [
                    split_changed,
                    rename_changed,
                    bool(split_changed),
                ]
                output.append(
                    {
                        "db_id": db_id,
                        "question_id": record["question_id"],
                        "question": record["question"],
                        "old_sql": record["SQL"],
                        "builder_sql": builder_sql,
                        "policy_sql": policy_sql,
                        "policy_actions": [
                            d1.action,
                            d2.action if d2 else "unavailable",
                            d3.action if d3 else "unavailable",
                        ],
                        "affected_steps": affected,
                        "builder_correct": builder_correct,
                        "policy_correct": policy_correct,
                        "stale_correct": stale_correct,
                        "policy_full_lifecycle_correct": all(policy_correct),
                        "stale_full_lifecycle_correct": all(stale_correct),
                        "final_rename_changed": final_rename_changed,
                    }
                )
            except Exception:
                continue

    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "instances.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8"
    )
    (args.output / "migrations.json").write_text(
        json.dumps(lifecycle_specs, indent=2), encoding="utf-8"
    )
    summary = summarize(output)
    (args.output / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    return summary


def summarize(rows: list[dict]) -> dict:
    versions = 3
    n = len(rows)
    return {
        "databases": len({row["db_id"] for row in rows}),
        "validated_lifecycles": n,
        "transitions": n * versions,
        "affected_transitions": sum(sum(row["affected_steps"]) for row in rows),
        "policy_transition_accuracy": (
            sum(sum(row["policy_correct"]) for row in rows) / (n * versions) if n else 0
        ),
        "stale_transition_accuracy": (
            sum(sum(row["stale_correct"]) for row in rows) / (n * versions) if n else 0
        ),
        "policy_full_lifecycle_accuracy": (
            sum(row["policy_full_lifecycle_correct"] for row in rows) / n if n else 0
        ),
        "stale_full_lifecycle_accuracy": (
            sum(row["stale_full_lifecycle_correct"] for row in rows) / n if n else 0
        ),
        "policy_action_counts": dict(
            Counter(action for row in rows for action in row["policy_actions"])
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    root = Path("data/bird-mini-dev/package/minidev/MINIDEV")
    parser.add_argument("--questions", type=Path, default=root / "mini_dev_sqlite.json")
    parser.add_argument("--databases", type=Path, default=root / "dev_databases")
    parser.add_argument("--split", type=Path, default=Path("data/schemamem-split-v1"))
    parser.add_argument("--rename", type=Path, default=Path("data/schemamem-bench-v1"))
    parser.add_argument(
        "--output", type=Path, default=Path("data/schemamem-multiversion-v1")
    )
    args = parser.parse_args()
    print(json.dumps(build(args), indent=2))


if __name__ == "__main__":
    main()
