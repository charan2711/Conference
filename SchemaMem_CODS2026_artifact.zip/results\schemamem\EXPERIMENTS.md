# Primary experiment records

This directory also contains preliminary checkpoints retained for auditability.
The paper's primary model-backed records are:

| Study | Model / configuration | Raw records | Aggregate/statistics |
|---|---|---|---|
| Direct repair, lower-capability pilot | Qwen2.5-Coder-1.5B-Instruct Q4 | `llm_repair_1.5b.jsonl` | `llm_repair_1.5b.summary.json`, `llm_repair_1.5b.statistics.json` |
| Direct repair, primary | Qwen2.5-Coder-7B-Instruct Q4 | `llm_repair_runs_7b.jsonl` | `llm_repair_runs_7b.summary.json`, `llm_repair_7b_expanded.statistics.json` |
| Direct repair, independent family | Mistral-7B-Instruct-v0.3 Q4_K_M | `llm_repair_runs_mistral7.jsonl` | `llm_repair_runs_mistral7.summary.json`, `llm_repair_mistral7.statistics.json` |
| Direct repair, exploratory scale | Qwen2.5-Coder-14B-Instruct Q3_K_M, partial CPU offload | `llm_repair_runs_14b.jsonl` | `llm_repair_runs_14b.summary.json`, `llm_repair_14b.statistics.json` |
| Lifecycle-gate prompt sensitivity | Qwen2.5-Coder-7B-Instruct Q4 | `llm_gate_runs_7b*.jsonl` | matching `*.summary.json` files |
| Different-question downstream, lower-capability pilot | Qwen2.5-Coder-1.5B-Instruct Q4 | `agent_runs.jsonl` | `agent_runs.summary.json`, `agent_statistics.json` |
| Different-question downstream, primary | Qwen2.5-Coder-7B-Instruct Q4 | `agent_runs_7b.jsonl` | `agent_runs_7b.summary.json`, `agent_statistics_7b_expanded.json` |
| Different-question downstream, independent family | Mistral-7B-Instruct-v0.3 Q4_K_M | `agent_runs_mistral7.jsonl` | `agent_runs_mistral7.summary.json`, `agent_statistics_mistral7.json` |
| Bounded tool agent, original pilot | Qwen2.5-Coder-7B-Instruct Q4_K_M | `tool_agent_runs_qwen7_v3_final.jsonl` | matching `summary`, `statistics`, `integrity`, and `errors` JSON files |
| Bounded tool agent, affected-heavy primary | Qwen2.5-Coder-7B-Instruct Q4_K_M | `tool_agent_runs_qwen7_v4_expanded.jsonl` | matching `summary`, `statistics`, `maintenance`, `integrity`, and `errors` JSON files |
| Bounded tool agent, exploratory larger-model control | Qwen2.5-Coder-14B-Instruct Q3_K_M, partial CPU offload | `tool_agent_runs_qwen14_v1_control22.jsonl` | matching `summary`, `statistics`, `maintenance`, `integrity`, and `errors` JSON files; exact-manifest comparison in `tool_agent_model_control_qwen14_vs_qwen7.json` |

Local inference used llama.cpp's Vulkan backend, context length 4,096, one
inference slot, temperature zero, and seed 42. The expanded 7B tool run used
`-ngl 99 -c 4096 -np 1`; the 14B tool control used `-c 4096 -np 1` with
automatic layer fitting and partial CPU offload. Model rationale and official model links are in
`../../research/model_controls.md`. Model weights and inference binaries are not
part of the artifact.
