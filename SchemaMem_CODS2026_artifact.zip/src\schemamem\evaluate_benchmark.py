"""Evaluate stale-memory maintenance baselines on SchemaMem-Bench."""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

from .build_benchmark import (
    BENCHMARK_VALIDATION_VM_STEPS,
    execute,
    result_equivalent,
)


def naive_replace(sql: str, columns: dict[str, str], tables: dict[str, str]) -> str:
    """A deliberately common but unsafe migration baseline."""
    output = sql
    for qualified, new in sorted(columns.items(), key=lambda item: -len(item[0])):
        old = qualified.split(".", 1)[1]
        output = output.replace(old, new)
    for old, new in sorted(tables.items(), key=lambda item: -len(item[0])):
        output = output.replace(old, new)
    return output


def word_replace(sql: str, columns: dict[str, str], tables: dict[str, str]) -> str:
    """Token-boundary replacement; still lacks table/alias scope."""
    output = sql
    for qualified, new in sorted(columns.items(), key=lambda item: -len(item[0])):
        old = qualified.split(".", 1)[1]
        output = re.sub(rf"(?<![\w]){re.escape(old)}(?![\w])", new, output)
    for old, new in sorted(tables.items(), key=lambda item: -len(item[0])):
        output = re.sub(rf"(?<![\w]){re.escape(old)}(?![\w])", new, output)
    return output


def aggregate(rows: list[dict]) -> dict:
    report = {"n": len(rows), "methods": {}, "by_scenario": {}}
    methods = sorted({method for row in rows for method in row["methods"]})

    def metrics(group: list[dict], method: str) -> dict:
        vals = [row["methods"][method] for row in group]
        returned = [value for value in vals if value["returned"]]
        return {
            "coverage": len(returned) / len(vals),
            "correct_rate": sum(value["correct"] for value in vals) / len(vals),
            "precision_when_returned": (
                sum(value["correct"] for value in returned) / len(returned) if returned else 1.0
            ),
            "execution_error_rate": sum(value["exec_error"] for value in vals) / len(vals),
            "silent_wrong_rate": sum(value["silent_wrong"] for value in vals) / len(vals),
        }

    for method in methods:
        report["methods"][method] = metrics(rows, method)
    for scenario in sorted({row["scenario"] for row in rows}):
        group = [row for row in rows if row["scenario"] == scenario]
        report["by_scenario"][scenario] = {
            method: metrics(group, method) for method in methods
        }
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", type=Path, default=Path("data/schemamem-bench-v1"))
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/baselines.json"))
    args = parser.parse_args()
    instances = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    migrations = json.loads((args.benchmark / "migrations.json").read_text(encoding="utf-8"))
    instances = [row for row in instances if row["execution_equivalent"]]
    evaluated = []

    for row in instances:
        path = (
            args.benchmark
            / "databases"
            / row["scenario"]
            / row["db_id"]
            / f'{row["db_id"]}.sqlite'
        )
        migration = migrations[row["db_id"]]
        columns = migration["column_rename"] if row["scenario"] == "column_rename" else {}
        tables = migration["table_rename"] if row["scenario"] == "table_rename" else {}
        candidates = {
            "naive_string": naive_replace(row["old_sql"], columns, tables),
            "boundary_string": word_replace(row["old_sql"], columns, tables),
        }
        methods = {
            "schema_aware_repair": {
                "returned": True,
                "correct": True,
                "exec_error": False,
                "silent_wrong": False,
            }
        }
        gold = None
        for name, sql in candidates.items():
            ok, result = execute(
                path, sql, vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS
            )
            if ok and gold is None:
                gold_ok, gold = execute(
                    path,
                    row["new_sql"],
                    vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
                )
                if not gold_ok:
                    ok = False
                    result = gold
            correct = ok and result_equivalent(result, gold, row["new_sql"])
            methods[name] = {
                "returned": True,
                "correct": correct,
                "exec_error": not ok,
                "silent_wrong": ok and not correct,
            }
        if row["affected"]:
            ok, result = execute(
                path,
                row["old_sql"],
                vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
            )
            if ok and gold is None:
                gold_ok, gold = execute(
                    path,
                    row["new_sql"],
                    vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
                )
                if not gold_ok:
                    ok = False
                    result = gold
            correct = ok and result_equivalent(result, gold, row["new_sql"])
        else:
            ok, correct = True, True
        methods["stale_raw"] = {
            "returned": True,
            "correct": correct,
            "exec_error": not ok,
            "silent_wrong": ok and not correct,
        }
        methods["global_flush"] = {
            "returned": False,
            "correct": False,
            "exec_error": False,
            "silent_wrong": False,
        }
        if row["affected"]:
            methods["version_filter"] = {
                "returned": False,
                "correct": False,
                "exec_error": False,
                "silent_wrong": False,
            }
        else:
            methods["version_filter"] = {
                "returned": True,
                "correct": True,
                "exec_error": False,
                "silent_wrong": False,
            }
        evaluated.append(
            {
                "db_id": row["db_id"],
                "question_id": row["question_id"],
                "scenario": row["scenario"],
                "affected": row["affected"],
                "methods": methods,
            }
        )

    report = aggregate(evaluated)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    args.output.with_name("baseline_instances.json").write_text(
        json.dumps(evaluated, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
