"""Clustered paired statistics for executable multi-version lifecycles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .agent_statistics import paired_report


def make_pairs(rows: list[dict], *, full_lifecycle: bool) -> list[dict]:
    pairs = []
    for row in rows:
        if full_lifecycle:
            pairs.append({
                "policy": {"db_id": row["db_id"], "correct": row["policy_full_lifecycle_correct"]},
                "stale": {"db_id": row["db_id"], "correct": row["stale_full_lifecycle_correct"]},
            })
            continue
        for policy, stale in zip(row["policy_correct"], row["stale_correct"]):
            pairs.append({
                "policy": {"db_id": row["db_id"], "correct": policy},
                "stale": {"db_id": row["db_id"], "correct": stale},
            })
    return pairs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--instances", type=Path,
        default=Path("data/schemamem-multiversion-v1/instances.json")
    )
    parser.add_argument(
        "--output", type=Path,
        default=Path("results/schemamem/multiversion_statistics.json")
    )
    args = parser.parse_args()
    rows = json.loads(args.instances.read_text(encoding="utf-8"))
    report = {
        "transition_level": paired_report(
            make_pairs(rows, full_lifecycle=False), "policy", "stale"
        ),
        "full_lifecycle": paired_report(
            make_pairs(rows, full_lifecycle=True), "policy", "stale"
        ),
        "unit_note": (
            "paired bootstrap treats query transitions as units; primary uncertainty "
            "resamples whole databases and uses an exact database sign-flip test"
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
