"""Aggregate predeclared shuffled-fixation offsets without selecting a run."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FRACTION_FILES = {
    0.20: ROOT / "tmp/shuffle_sensitivity/f020.json",
    0.35: ROOT / "tmp/shuffle_sensitivity/f035.json",
    0.50: ROOT / "artifacts/baselines/look_and_tell_gaze_location_crossval.json",
    0.65: ROOT / "tmp/shuffle_sensitivity/f065.json",
    0.80: ROOT / "tmp/shuffle_sensitivity/f080.json",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "artifacts/baselines/look_and_tell_shuffle_sensitivity.json",
    )
    return parser.parse_args()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    args = parse_args()
    runs = []
    expected_rows = None
    expected_gaze_accuracy = None
    expected_folds = None
    for fraction, path in FRACTION_FILES.items():
        result = json.loads(path.read_text(encoding="utf-8"))
        if result.get("shuffle_fraction") != fraction:
            raise AssertionError(f"Fraction mismatch in {path}: {result.get('shuffle_fraction')}")
        if expected_rows is None:
            expected_rows = result["n_rows"]
            expected_gaze_accuracy = result["aggregate"]["text_gaze_history"]["accuracy"]
            expected_folds = [fold["held_out_participants"] for fold in result["folds"]]
        if result["n_rows"] != expected_rows:
            raise AssertionError(f"Row-count drift in {path}")
        if result["aggregate"]["text_gaze_history"]["accuracy"] != expected_gaze_accuracy:
            raise AssertionError(f"Gaze-model drift in {path}")
        if [fold["held_out_participants"] for fold in result["folds"]] != expected_folds:
            raise AssertionError(f"Fold drift in {path}")

        comparison = result["paired_participant_differences"]["gaze_minus_shuffled"]
        low, high = comparison["bootstrap_95ci"]
        runs.append(
            {
                "shuffle_fraction": fraction,
                "source_sha256": digest(path),
                "shuffled_accuracy": result["aggregate"]["text_shuffled_history"]["accuracy"],
                "shuffled_coref_accuracy": result["aggregate"]["text_shuffled_history"]["coref_accuracy"],
                "gaze_minus_shuffled": comparison,
                "ci_includes_zero": low <= 0.0 <= high,
                "changed_coordinates_available_fixations": result["shuffled_fixation_control"][
                    "changed_coordinates_available_fixations"
                ],
                "available_fixation_rows": result["shuffled_fixation_control"][
                    "available_fixation_rows"
                ],
                "cache_signature": result["shuffled_fixation_control"]["cache_signature"],
            }
        )

    shuffled_accuracies = [run["shuffled_accuracy"] for run in runs]
    differences = [run["gaze_minus_shuffled"]["difference"] for run in runs]
    output = {
        "protocol": (
            "Post-hoc sensitivity over five predeclared label-free cyclic offsets; "
            "all offsets use identical six participant folds, features, models, and "
            "5,000-resample participant bootstrap. No offset is selected."
        ),
        "fractions": list(FRACTION_FILES),
        "n_offsets": len(runs),
        "n_rows": expected_rows,
        "gaze_accuracy": expected_gaze_accuracy,
        "runs": runs,
        "summary": {
            "shuffled_accuracy_range": [min(shuffled_accuracies), max(shuffled_accuracies)],
            "gaze_minus_shuffled_range": [min(differences), max(differences)],
            "all_bootstrap_95ci_include_zero": all(run["ci_includes_zero"] for run in runs),
            "minimum_changed_coordinates_available_fixations": min(
                run["changed_coordinates_available_fixations"] for run in runs
            ),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "shuffle sensitivity summary written: "
        f"offsets={len(runs)}, all_ci_include_zero="
        f"{output['summary']['all_bootstrap_95ci_include_zero']}"
    )


if __name__ == "__main__":
    main()
