"""Build an executable stale-memory benchmark from BIRD Mini-Dev.

Unlike the released EvoSchema labels, this builder applies each migration to a
real SQLite database, rewrites SQL structurally (never by string replacement),
and retains an instance only when old and migrated queries return identical
results. EvoSchema is used only as a source of realistic rename candidates.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

import sqlglot
from sqlglot import exp


def sqlite_schema(path: Path) -> dict[str, set[str]]:
    with sqlite3.connect(path) as conn:
        tables = [
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            )
        ]
        return {
            table: {row[1] for row in conn.execute(f'PRAGMA table_info("{table}")')}
            for table in tables
        }


def refs(sql: str, schema: dict[str, set[str]]) -> tuple[set[str], set[tuple[str, str]]]:
    tree = sqlglot.parse_one(sql, read="sqlite")
    tables = list(tree.find_all(exp.Table))
    alias_to_table = {table.alias_or_name.casefold(): table.name for table in tables}
    used_tables = {table.name for table in tables}
    used_columns: set[tuple[str, str]] = set()
    for column in tree.find_all(exp.Column):
        if column.table:
            base = alias_to_table.get(column.table.casefold())
            if base:
                used_columns.add((base, column.name))
        else:
            owners = [table for table in used_tables if column.name in schema.get(table, set())]
            if len(owners) == 1:
                used_columns.add((owners[0], column.name))
    return used_tables, used_columns


def candidate_maps(evoschema_dir: Path) -> tuple[dict, dict]:
    column_counts: dict[tuple[str, str, str], Counter] = defaultdict(Counter)
    table_counts: dict[tuple[str, str], Counter] = defaultdict(Counter)
    rows = json.loads((evoschema_dir / "rename_columns_bird_dev.json").read_text(encoding="utf-8"))
    for row in rows:
        for table, value in row.get("new_relevant_table", {}).items():
            for old, new in value.get("old_new_column_mappings", {}).items():
                column_counts[(row["db_id"], table, old)][new] += 1
    rows = json.loads((evoschema_dir / "rename_tables_bird_dev.json").read_text(encoding="utf-8"))
    for row in rows:
        for old, new in row.get("old_new_table_mappings", {}).items():
            table_counts[(row["db_id"], old)][new] += 1
    return column_counts, table_counts


def choose_maps(
    db_id: str,
    schema: dict[str, set[str]],
    records: list[dict],
    column_counts: dict,
    table_counts: dict,
    target: float,
) -> tuple[dict[tuple[str, str], str], dict[str, str]]:
    parsed = []
    for record in records:
        try:
            parsed.append(refs(record["SQL"], schema))
        except Exception:
            parsed.append((set(), set()))

    table_candidates = []
    for (candidate_db, old), counts in table_counts.items():
        if candidate_db != db_id or old not in schema:
            continue
        new, support = counts.most_common(1)[0]
        if new.casefold() in {name.casefold() for name in schema} or not new.strip():
            continue
        coverage = {i for i, (tables, _) in enumerate(parsed) if old in tables}
        table_candidates.append((coverage, support, old, new))

    column_candidates = []
    for (candidate_db, table, old), counts in column_counts.items():
        if candidate_db != db_id or old not in schema.get(table, set()):
            continue
        new, support = counts.most_common(1)[0]
        if new.casefold() in {name.casefold() for name in schema[table]} or not new.strip():
            continue
        coverage = {i for i, (_, columns) in enumerate(parsed) if (table, old) in columns}
        column_candidates.append((coverage, support, table, old, new))

    desired = max(1, round(target * len(records)))

    def greedy(candidates: list[tuple], key_offset: int) -> list[tuple]:
        selected, covered = [], set()
        remaining = list(candidates)
        while remaining and len(covered) < desired:
            remaining.sort(
                key=lambda item: (
                    min(len(covered | item[0]), desired) - len(covered),
                    item[1],
                ),
                reverse=True,
            )
            best = remaining.pop(0)
            gain = len((covered | best[0])) - len(covered)
            if gain == 0:
                break
            selected.append(best)
            covered |= best[0]
        return selected

    selected_tables = greedy(table_candidates, 2)
    selected_columns = greedy(column_candidates, 2)
    return (
        {(item[2], item[3]): item[4] for item in selected_columns},
        {item[2]: item[3] for item in selected_tables},
    )


def rewrite_sql(
    sql: str,
    schema: dict[str, set[str]],
    column_map: dict[tuple[str, str], str],
    table_map: dict[str, str],
) -> tuple[str, bool]:
    tree = sqlglot.parse_one(sql, read="sqlite")
    table_nodes = list(tree.find_all(exp.Table))
    alias_to_table = {table.alias_or_name.casefold(): table.name for table in table_nodes}
    used_tables = {table.name for table in table_nodes}
    changed = False

    for column in tree.find_all(exp.Column):
        base = None
        if column.table:
            base = alias_to_table.get(column.table.casefold())
        else:
            owners = [table for table in used_tables if column.name in schema.get(table, set())]
            if len(owners) == 1:
                base = owners[0]
        if base and (base, column.name) in column_map:
            quoted = bool(column.this.args.get("quoted", False))
            column.set("this", exp.to_identifier(column_map[(base, column.name)], quoted=quoted))
            changed = True

    for column in tree.find_all(exp.Column):
        if column.table and column.table in table_map and column.table.casefold() in alias_to_table:
            column.set("table", exp.to_identifier(table_map[column.table]))
            changed = True
    for table in table_nodes:
        if table.name in table_map:
            quoted = bool(table.this.args.get("quoted", False))
            table.set("this", exp.to_identifier(table_map[table.name], quoted=quoted))
            changed = True
    return tree.sql(dialect="sqlite"), changed


def apply_migration(
    original: Path,
    migrated: Path,
    column_map: dict[tuple[str, str], str],
    table_map: dict[str, str],
) -> None:
    migrated.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, migrated)
    with sqlite3.connect(migrated) as conn:
        for (table, old), new in column_map.items():
            conn.execute(f'ALTER TABLE "{table}" RENAME COLUMN "{old}" TO "{new}"')
        for old, new in table_map.items():
            conn.execute(f'ALTER TABLE "{old}" RENAME TO "{new}"')


VM_STEPS_PER_BUDGET_SECOND = 2_000_000
PROGRESS_GRANULARITY = 10_000
BENCHMARK_VALIDATION_VM_STEPS = 100_000_000


def execute(
    path: Path,
    sql: str,
    timeout_seconds: float = 3.0,
    *,
    vm_step_budget: int | None = None,
) -> tuple[bool, list | str]:
    """Execute read-only SQL under a deterministic SQLite VM-step budget.

    ``timeout_seconds`` is retained as a compatibility name for callers and is
    converted to a fixed instruction allowance unless ``vm_step_budget`` is
    supplied explicitly. Unlike a wall-clock deadline, the accepted query set
    does not change with concurrent CPU load.
    """
    try:
        with sqlite3.connect(path, timeout=10) as conn:
            conn.execute("PRAGMA query_only=ON")
            callbacks = 0
            budget = (
                vm_step_budget
                if vm_step_budget is not None
                else int(timeout_seconds * VM_STEPS_PER_BUDGET_SECOND)
            )
            max_callbacks = max(1, budget // PROGRESS_GRANULARITY)

            def budget_exhausted() -> int:
                nonlocal callbacks
                callbacks += 1
                return int(callbacks > max_callbacks)

            conn.set_progress_handler(budget_exhausted, PROGRESS_GRANULARITY)
            return True, conn.execute(sql).fetchall()
    except Exception as error:
        return False, f"{type(error).__name__}: {error}"


def result_equivalent(left: list, right: list, gold_sql: str) -> bool:
    """Compare ordered results only when the outer gold query requests order."""
    try:
        tree = sqlglot.parse_one(gold_sql, read="sqlite")
        ordered = tree.args.get("order") is not None
    except Exception:
        ordered = True
    return left == right if ordered else Counter(left) == Counter(right)


def build(args: argparse.Namespace) -> dict:
    records = json.loads(args.questions.read_text(encoding="utf-8"))
    by_db: dict[str, list[dict]] = defaultdict(list)
    for record in records:
        by_db[record["db_id"]].append(record)
    column_counts, table_counts = candidate_maps(args.evoschema)
    output, migrations = [], {}

    for db_id, db_records in sorted(by_db.items()):
        original = args.databases / db_id / f"{db_id}.sqlite"
        schema = sqlite_schema(original)
        columns, tables = choose_maps(
            db_id, schema, db_records, column_counts, table_counts, args.target_coverage
        )
        scenarios = {"column_rename": (columns, {}), "table_rename": ({}, tables)}
        migrations[db_id] = {
            "column_rename": {f"{table}.{old}": new for (table, old), new in columns.items()},
            "table_rename": tables,
        }
        for scenario, (column_map, table_map) in scenarios.items():
            migrated = args.output / "databases" / scenario / db_id / f"{db_id}.sqlite"
            apply_migration(original, migrated, column_map, table_map)
            for record in db_records:
                try:
                    new_sql, affected = rewrite_sql(
                        record["SQL"], schema, column_map, table_map
                    )
                    old_ok, old_result = execute(
                        original,
                        record["SQL"],
                        vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
                    )
                    new_ok, new_result = execute(
                        migrated,
                        new_sql,
                        vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
                    )
                    equivalent = old_ok and new_ok and result_equivalent(
                        old_result, new_result, record["SQL"]
                    )
                except Exception as error:
                    new_sql, affected, old_ok, new_ok, equivalent = "", False, False, False, False
                    old_result, new_result = "", f"{type(error).__name__}: {error}"
                output.append(
                    {
                        **record,
                        "scenario": scenario,
                        "old_sql": record["SQL"],
                        "new_sql": new_sql,
                        "affected": affected,
                        "old_exec_ok": old_ok,
                        "new_exec_ok": new_ok,
                        "execution_equivalent": equivalent,
                        "old_error": None if old_ok else old_result,
                        "new_error": None if new_ok else new_result,
                    }
                )

    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "instances.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    (args.output / "migrations.json").write_text(json.dumps(migrations, indent=2), encoding="utf-8")
    summary = {
        "instances": len(output),
        "old_exec_rate": sum(row["old_exec_ok"] for row in output) / len(output),
        "new_exec_rate": sum(row["new_exec_ok"] for row in output) / len(output),
        "equivalence_rate": sum(row["execution_equivalent"] for row in output) / len(output),
        "affected_rate": sum(row["affected"] for row in output) / len(output),
        "by_scenario": {},
    }
    for scenario in ("column_rename", "table_rename"):
        group = [row for row in output if row["scenario"] == scenario]
        summary["by_scenario"][scenario] = {
            "n": len(group),
            "affected_rate": sum(row["affected"] for row in group) / len(group),
            "equivalence_rate": sum(row["execution_equivalent"] for row in group) / len(group),
        }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    root = Path("data/bird-mini-dev/package/minidev/MINIDEV")
    parser.add_argument("--questions", type=Path, default=root / "mini_dev_sqlite.json")
    parser.add_argument("--databases", type=Path, default=root / "dev_databases")
    parser.add_argument(
        "--evoschema", type=Path, default=Path("baselines/EvoSchema/eval_benchmark")
    )
    parser.add_argument("--output", type=Path, default=Path("data/schemamem-bench-v1"))
    parser.add_argument("--target-coverage", type=float, default=0.5)
    args = parser.parse_args()
    print(json.dumps(build(args), indent=2))


if __name__ == "__main__":
    main()
