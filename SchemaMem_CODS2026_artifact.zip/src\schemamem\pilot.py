"""Feasibility pilot over EvoSchema identifier migrations.

A previously successful SQL program is treated as a persistent agent memory.
After a schema migration, this pilot measures dependency-based invalidation and
deterministic repair. Downstream LLM experiments are intentionally separate.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

import sqlglot
from sqlglot import exp


def normalize(sql: str | None) -> str | None:
    if not sql:
        return None
    try:
        return sqlglot.parse_one(sql, read="sqlite").sql(dialect="sqlite")
    except Exception:
        return None


def column_mapping(row: dict) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for table in row.get("new_relevant_table", {}).values():
        if isinstance(table, dict):
            mapping.update(table.get("old_new_column_mappings", {}))
    return mapping


def table_mapping(row: dict) -> dict[str, str]:
    mapping = row.get("old_new_table_mappings", {})
    return mapping if isinstance(mapping, dict) else {}


def dependencies(sql: str) -> tuple[set[str], set[str]]:
    tree = sqlglot.parse_one(sql, read="sqlite")
    tables = {node.name.casefold() for node in tree.find_all(exp.Table)}
    columns = {node.name.casefold() for node in tree.find_all(exp.Column)}
    return tables, columns


def is_affected(sql: str, columns: dict[str, str], tables: dict[str, str]) -> bool:
    try:
        used_tables, used_columns = dependencies(sql)
    except Exception:
        return True
    return bool(
        used_tables & {x.casefold() for x in tables}
        or used_columns & {x.casefold() for x in columns}
    )


def migrate(sql: str, columns: dict[str, str], tables: dict[str, str]) -> str | None:
    try:
        tree = sqlglot.parse_one(sql, read="sqlite")
    except Exception:
        return None
    col_lookup = {key.casefold(): value for key, value in columns.items()}
    tab_lookup = {key.casefold(): value for key, value in tables.items()}

    def rewrite(node: exp.Expression) -> exp.Expression:
        if isinstance(node, exp.Table) and node.name.casefold() in tab_lookup:
            quoted = bool(node.this.args.get("quoted", False))
            node.set("this", exp.to_identifier(tab_lookup[node.name.casefold()], quoted=quoted))
        elif isinstance(node, exp.Column) and node.name.casefold() in col_lookup:
            quoted = bool(node.this.args.get("quoted", False))
            node.set("this", exp.to_identifier(col_lookup[node.name.casefold()], quoted=quoted))
        return node

    return tree.transform(rewrite).sql(dialect="sqlite")


def evaluate(path: Path, kind: str) -> list[dict]:
    records = json.loads(path.read_text(encoding="utf-8"))
    output = []
    for record in records:
        old_sql = record["query"]
        gold_sql = record.get("new_gold_sql", old_sql)
        columns = column_mapping(record)
        tables = table_mapping(record)
        repaired = migrate(old_sql, columns, tables)
        old_norm = normalize(old_sql)
        gold_norm = normalize(gold_sql)
        repaired_norm = normalize(repaired)
        output.append(
            {
                "kind": kind,
                "db_id": record["db_id"],
                "affected": is_affected(old_sql, columns, tables),
                "gold_changed": old_norm != gold_norm,
                "raw_exact": old_norm == gold_norm,
                "repaired_exact": repaired_norm == gold_norm,
                "parse_ok": old_norm is not None and gold_norm is not None,
                "mapping_size": len(columns) + len(tables),
            }
        )
    return output


def summarize(rows: list[dict]) -> dict:
    groups: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        groups[row["kind"]].append(row)
    report: dict = {"n": len(rows), "by_kind": {}}
    for kind, group in groups.items():
        n = len(group)
        changed = [row for row in group if row["gold_changed"]]
        tp = sum(row["affected"] and row["gold_changed"] for row in group)
        fp = sum(row["affected"] and not row["gold_changed"] for row in group)
        fn = sum(not row["affected"] and row["gold_changed"] for row in group)
        report["by_kind"][kind] = {
            "n": n,
            "parse_rate": sum(row["parse_ok"] for row in group) / n,
            "stale_rate": len(changed) / n,
            "raw_exact": sum(row["raw_exact"] for row in group) / n,
            "selective_reuse_rate": sum(not row["affected"] for row in group) / n,
            "detection_precision": tp / (tp + fp) if tp + fp else 1.0,
            "detection_recall": tp / (tp + fn) if tp + fn else 1.0,
            "repair_exact_all": sum(row["repaired_exact"] for row in group) / n,
            "repair_exact_changed": (
                sum(row["repaired_exact"] for row in changed) / len(changed)
                if changed
                else 1.0
            ),
            "mapping_sizes": dict(Counter(row["mapping_size"] for row in group)),
        }
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path("baselines/EvoSchema/eval_benchmark"))
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/pilot.json"))
    args = parser.parse_args()
    rows = evaluate(args.data / "rename_columns_bird_dev.json", "rename_columns")
    rows += evaluate(args.data / "rename_tables_bird_dev.json", "rename_tables")
    report = summarize(rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
