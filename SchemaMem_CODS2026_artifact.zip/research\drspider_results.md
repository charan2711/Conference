# Dr.Spider external transfer result

Status: completed after the pre-outcome protocol in
`research/drspider_preregistration.md` was frozen.

## Frozen inputs

- 32 targets, two per base database, across 16 base databases.
- 15 schema-synonym variants and one schema-abbreviation variant.
- Target manifest SHA-256:
  `d42db885dcf04bc03f4fd8c39d185b6ff960fb0a5a6a04eea783eb578bbc39fe`.
- Raw run SHA-256:
  `696527f85912763997479f897471862c26c2d1f45de6c3db6cd1d6524697d2fd`.
- Qwen2.5-Coder-7B-Instruct Q4, llama.cpp Vulkan, one serial worker,
  temperature 0, seed 42, eight calls and 256 generated tokens per call.
- All 160 target-condition records passed the manifest/integrity audit.

## Downstream execution accuracy

| Condition | Correct | Accuracy | Mean total tokens including maintenance |
|---|---:|---:|---:|
| No memory | 16/32 | 50.0% | 2,066.1 |
| Stale memory | 14/32 | 43.8% | 2,975.8 |
| Execution-guided memory | 17/32 | 53.1% | 4,644.7 |
| Gold repaired memory | 25/32 | 78.1% | 1,926.5 |
| SchemaMem policy memory | 24/32 | 75.0% | 1,996.1 |

Database-clustered comparisons use the original base database as the cluster:

- Policy vs stale: +31.25 points, 95% cluster bootstrap [12.5, 50.0], exact
  sign-flip p=0.015625; 10 improvements, 0 degradations.
- Policy vs no memory: +25.0 points, [12.5, 40.625], p=0.015625; 8 improvements,
  0 degradations.
- Policy vs execution-guided (preregistered primary): +21.875 points,
  [0, 43.75], p=0.1484375; 9 improvements, 2 degradations. This is directional,
  not confirmatory.
- Gold repair vs policy: +3.125 points, [-6.25, 12.5], p=1.0.

## Maintenance safety and cost

SchemaMem recomputed 25 `migrate` and seven `explore` decisions. All 25 returned
programs executed and were result-equivalent to the supplied post-migration
memory SQL; there were zero unsafe returns (Wilson 95% lower bound 86.7%).

Execution-guided maintenance generated 27 executable memories, but only 19 were
semantically correct; eight were executable and silently wrong. The downstream
agent was correct on 16/19 targets after a correct maintained memory and 1/13
after an incorrect or failed maintenance attempt. This association is post-hoc
and mechanistic, not a preregistered hypothesis test.

Including maintenance, SchemaMem used 4.875 model calls and 1,996.1 tokens per
target versus 10.5 calls and 4,644.7 tokens for execution-guided maintenance:
53.6% fewer calls and 57.0% fewer tokens. The cluster sign-flip p-value for both
cost reductions is 0.0000305.

## Viability decision

The sample exceeds the preregistered minimum of 30 targets and 15 base
databases. Policy is not more than two points below execution-guided memory; it
is 21.9 points higher. The external transfer therefore passes the declared
viability rule and materially strengthens the submission. The accuracy advantage
over execution-guided maintenance remains statistically uncertain at the
database-cluster level and must not be described as confirmed.
