"""Participant-disjoint fixation-metadata ablation for the gaze audit.

This companion audit reuses the frozen classical feature caches from
``crossval_look_and_tell_gaze_location.py`` but removes the final four
non-image metadata dimensions (normalized fixation x/y, temporal-link flag,
and fixation-availability flag) before fitting each probe.  The crop itself
is unchanged, so the result tests whether the gaze/shuffle comparison is
being driven by explicit metadata rather than pixels in the selected field of
view.  All preprocessing and model fitting remain inside each held-out-
participant fold.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler, normalize

from baseline_look_and_tell_classical_vision import (
    SEED,
    add_history,
    full_frame_features,
    image_features,
    load_recording,
    new_model,
    paired_participant_difference,
    participant_ci,
)
from crossval_look_and_tell_gaze_location import (
    make_shuffled_fixation_rows,
    shuffled_fixation_signature,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--derived-root", type=Path, default=Path("data/derived/look_and_tell"))
    parser.add_argument("--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json"))
    parser.add_argument("--feature-cache", type=Path, default=Path("data/derived/look_and_tell_feature_cache.npz"))
    parser.add_argument("--shuffled-feature-cache", type=Path, default=Path("data/derived/look_and_tell_shuffled_fixation_cache.npz"))
    parser.add_argument("--full-frame-feature-cache", type=Path, default=Path("data/derived/look_and_tell_full_frame_classical_cache.npz"))
    parser.add_argument("--metadata-width", type=int, default=4, help="Number of trailing metadata dimensions to remove.")
    parser.add_argument("--shuffle-fraction", type=float, default=0.5)
    parser.add_argument("--output", type=Path, default=Path("artifacts/baselines/look_and_tell_fixation_metadata_ablation.json"))
    return parser.parse_args()


def load_rows(args: argparse.Namespace) -> tuple[list[dict], dict[str, int], str]:
    split_spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows: list[dict] = []
    split_lengths: dict[str, int] = {}
    missing: list[str] = []
    for split in ("train", "val", "test"):
        before = len(rows)
        for recording in split_spec["splits"][split]["recordings"]:
            try:
                rows.extend(load_recording(args.derived_root, recording))
            except FileNotFoundError:
                missing.append(recording)
        split_lengths[split] = len(rows) - before
    paths: dict[str, list[str]] = {}
    offset = 0
    for split in ("train", "val", "test"):
        end = offset + split_lengths[split]
        paths[split] = [row["frame_path"] for row in rows[offset:end]]
        offset = end
    signature = hashlib.sha256(json.dumps(paths, sort_keys=True).encode("utf-8")).hexdigest()
    return rows, split_lengths, signature


def load_raw_features(args: argparse.Namespace, rows: list[dict], signature: str) -> tuple[dict[str, np.ndarray], str]:
    splits = ("train", "val", "test")
    with np.load(args.feature_cache, allow_pickle=False) as cache:
        if "row_signature" not in cache or str(cache["row_signature"].item()) != signature:
            raise RuntimeError("Classical feature cache row signature mismatch")
        gaze = np.vstack([cache[f"classical_{split}"] for split in splits])
        center = np.vstack([cache[f"center_classical_{split}"] for split in splits])
    if gaze.shape != center.shape or gaze.shape[0] != len(rows):
        raise RuntimeError(f"Row/feature mismatch: rows={len(rows)}, gaze={gaze.shape}, center={center.shape}")
    full = None
    if args.full_frame_feature_cache.exists():
        with np.load(args.full_frame_feature_cache, allow_pickle=False) as cache:
            if "row_signature" in cache and str(cache["row_signature"].item()) == signature and "full_frame_raw" in cache and cache["full_frame_raw"].shape == gaze.shape:
                full = cache["full_frame_raw"].copy()
    if full is None:
        full = np.vstack([full_frame_features(row) for row in rows])
    shuffled_rows, mapping = make_shuffled_fixation_rows(rows, args.shuffle_fraction)
    shuffle_signature = shuffled_fixation_signature(rows, mapping)
    shuffled = None
    if args.shuffled_feature_cache.exists():
        with np.load(args.shuffled_feature_cache, allow_pickle=False) as cache:
            if "shuffle_signature" in cache and str(cache["shuffle_signature"].item()) == shuffle_signature and "shuffled_raw" in cache and cache["shuffled_raw"].shape == gaze.shape:
                shuffled = cache["shuffled_raw"].copy()
    if shuffled is None:
        shuffled = np.vstack([image_features(row) for row in shuffled_rows])
    return {"full_frame": full, "center": center, "gaze": gaze, "shuffled": shuffled}, shuffle_signature


def main() -> None:
    args = parse_args()
    if args.metadata_width <= 0:
        raise ValueError("metadata-width must be positive")
    rows, split_lengths, row_signature = load_rows(args)
    raw, shuffle_signature = load_raw_features(args, rows, row_signature)
    dimensions = {name: matrix.shape[1] for name, matrix in raw.items()}
    if len(set(dimensions.values())) != 1 or next(iter(dimensions.values())) <= args.metadata_width:
        raise RuntimeError(f"Unexpected feature dimensions: {dimensions}")
    visual = {name: matrix[:, :-args.metadata_width] for name, matrix in raw.items()}
    participants = sorted({row["participant_id"] for row in rows})
    rng = np.random.default_rng(SEED)
    order = np.asarray(participants)[rng.permutation(len(participants))]
    folds = [sorted(fold.tolist()) for fold in np.array_split(order, 6)]
    model_names = ("text_history", "text_full_frame_no_fixation_metadata", "text_center_no_fixation_metadata", "text_gaze_no_fixation_metadata", "text_shuffled_no_fixation_metadata")
    predictions = {name: np.empty(len(rows), dtype=object) for name in model_names}
    fold_results = []
    for fold_index, held_out in enumerate(folds):
        test_mask = np.asarray([row["participant_id"] in held_out for row in rows])
        train_indices, test_indices = np.flatnonzero(~test_mask), np.flatnonzero(test_mask)
        train_rows = [dict(rows[index]) for index in train_indices]
        test_rows = [dict(rows[index]) for index in test_indices]
        frequencies = Counter(row["reference"] for row in train_rows)
        labels = sorted(frequencies)
        add_history(train_rows, labels, frequencies)
        add_history(test_rows, labels, frequencies)
        text = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2, max_features=20000, sublinear_tf=True)
        text_train = text.fit_transform(row.get("surface_text") or "" for row in train_rows)
        text_test = text.transform(row.get("surface_text") or "" for row in test_rows)
        history = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
        history_train = history.fit_transform(np.asarray([[row["history_prediction"]] for row in train_rows]))
        history_test = history.transform(np.asarray([[row["history_prediction"]] for row in test_rows]))
        matrices = {"text_history": (hstack([text_train, history_train], format="csr"), hstack([text_test, history_test], format="csr"))}
        for key, suffix in (("full_frame", "full_frame_no_fixation_metadata"), ("center", "center_no_fixation_metadata"), ("gaze", "gaze_no_fixation_metadata"), ("shuffled", "shuffled_no_fixation_metadata")):
            scaler = StandardScaler()
            train_dense = scaler.fit_transform(visual[key][train_indices])
            test_dense = scaler.transform(visual[key][test_indices])
            matrices[f"text_{suffix}"] = (hstack([text_train, normalize(csr_matrix(train_dense), norm="l2"), history_train], format="csr"), hstack([text_test, normalize(csr_matrix(test_dense), norm="l2"), history_test], format="csr"))
        targets_train = np.asarray([row["reference"] for row in train_rows])
        targets_test = np.asarray([row["reference"] for row in test_rows])
        metrics = {}
        for name, (train_matrix, test_matrix) in matrices.items():
            model = new_model()
            model.fit(train_matrix, targets_train)
            pred = model.predict(test_matrix)
            predictions[name][test_indices] = pred
            metrics[name] = {"accuracy": float(accuracy_score(targets_test, pred)), "macro_f1": float(f1_score(targets_test, pred, average="macro", zero_division=0))}
        fold_results.append({"fold": fold_index, "held_out_participants": held_out, "n": len(test_rows), "metrics": metrics})
    targets = np.asarray([row["reference"] for row in rows])
    aggregate = {}
    for name in model_names:
        pred = predictions[name]
        mask = np.asarray([(row.get("mention_type") or "") == "pronoun/coref" for row in rows])
        aggregate[name] = {"accuracy": float(accuracy_score(targets, pred)), "accuracy_participant_bootstrap_95ci": participant_ci(rows, targets, pred), "macro_f1": float(f1_score(targets, pred, average="macro", zero_division=0)), "coref_accuracy": float(accuracy_score(targets[mask], pred[mask]))}
    comparisons = {}
    for candidate in ("full_frame_no_fixation_metadata", "center_no_fixation_metadata", "gaze_no_fixation_metadata", "shuffled_no_fixation_metadata"):
        comparisons[f"{candidate}_minus_text_history"] = paired_participant_difference(rows, targets, predictions[f"text_{candidate}"], predictions["text_history"])
    comparisons["gaze_no_fixation_metadata_minus_shuffled_no_fixation_metadata"] = paired_participant_difference(rows, targets, predictions["text_gaze_no_fixation_metadata"], predictions["text_shuffled_no_fixation_metadata"])
    output = {"protocol": "six-fold participant-disjoint out-of-fold fixation-metadata ablation", "seed": SEED, "metadata_removed": ["normalized_fixation_x", "normalized_fixation_y", "linked_temporally", "fixation_available"], "metadata_width": args.metadata_width, "feature_dimensions_before": dimensions, "feature_dimensions_after": {name: int(matrix.shape[1]) for name, matrix in visual.items()}, "row_signature": row_signature, "shuffle_signature": shuffle_signature, "shuffle_fraction": args.shuffle_fraction, "n_rows": len(rows), "n_participants": len(participants), "split_lengths": split_lengths, "folds": fold_results, "aggregate": aggregate, "paired_participant_differences": comparisons}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
