"""Case-agnostic SQLite-to-DuckDB portability diagnostic for SchemaMem SQL."""

from __future__ import annotations

import argparse
import datetime as dt
import decimal
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import duckdb
from sqlglot import exp, parse_one

from .build_benchmark import (
    BENCHMARK_VALIDATION_VM_STEPS,
    execute,
    result_equivalent,
)
from .component_ablation import compatible_cases, validator_for
from .evaluate_ambiguity import wilson_interval


FORBIDDEN = (exp.Insert, exp.Update, exp.Delete, exp.Create, exp.Drop, exp.Alter, exp.Command)


def translate(sql: str) -> str:
    tree = parse_one(sql, read="sqlite")
    if any(isinstance(node, FORBIDDEN) for node in tree.walk()):
        raise ValueError("non-read-only SQL")
    return tree.sql(dialect="duckdb")


def canonical_scalar(value: Any) -> Any:
    """Remove DB-API representation differences without numerical tolerance."""
    if isinstance(value, decimal.Decimal):
        return int(value) if value == value.to_integral_value() else float(value)
    if isinstance(value, (dt.date, dt.time, dt.datetime)):
        return value.isoformat(sep=" ") if isinstance(value, dt.datetime) else value.isoformat()
    if isinstance(value, memoryview):
        return bytes(value)
    if isinstance(value, float) and math.isnan(value):
        return "__NaN__"
    return value


def canonical_rows(rows: list[tuple]) -> list[tuple]:
    return [tuple(canonical_scalar(value) for value in row) for row in rows]


def equivalent(left: list[tuple], right: list[tuple], gold_sql: str) -> bool:
    left, right = canonical_rows(left), canonical_rows(right)
    try:
        ordered = parse_one(gold_sql, read="sqlite").args.get("order") is not None
    except Exception:
        ordered = True
    return left == right if ordered else Counter(left) == Counter(right)


def _attach(path: Path) -> duckdb.DuckDBPyConnection:
    connection = duckdb.connect()
    connection.execute("SET threads=1")
    connection.execute("LOAD sqlite")
    escaped = str(path.resolve()).replace("'", "''")
    connection.execute(f"ATTACH '{escaped}' AS sm (TYPE SQLITE, READ_ONLY)")
    connection.execute("USE sm")
    return connection


def _execute_duck(connection: duckdb.DuckDBPyConnection, sql: str) -> tuple[bool, Any]:
    try:
        return True, connection.execute(sql).fetchall()
    except Exception as error:
        return False, f"{type(error).__name__}: {error}"


def run(validator_mode: str = "legacy_flat") -> tuple[dict, list[dict]]:
    validate = validator_for(validator_mode)
    cases = compatible_cases()
    grouped: dict[Path, list[dict]] = defaultdict(list)
    for case in cases:
        grouped[case["current_path"]].append(case)

    audited: list[dict] = []
    for path in sorted(grouped, key=lambda value: str(value)):
        try:
            connection = _attach(path)
            attach_error = None
        except Exception as error:
            connection = None
            attach_error = f"{type(error).__name__}: {error}"
        for case in grouped[path]:
            base = {
                "scenario": case["scenario"],
                "db_id": case["db_id"],
                "question_id": case["question_id"],
                "affected": case["affected"],
            }
            if connection is None:
                audited.append({**base, "eligible": False, "exclusion": "database_attach_failed"})
                continue
            decision = case["full"]()
            repair_sql = decision.sql if decision.action in {"reuse", "migrate"} else None
            if case["affected"] and repair_sql and not validate(repair_sql, case["current_schema"]):
                repair_sql = None
            if not repair_sql:
                audited.append({**base, "eligible": False, "exclusion": "full_policy_withheld"})
                continue
            sqlite_gold_ok, sqlite_gold = execute(
                path,
                case["new_sql"],
                timeout_seconds=30,
                vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
            )
            sqlite_repair_ok, sqlite_repair = execute(
                path,
                repair_sql,
                timeout_seconds=30,
                vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
            )
            if not sqlite_gold_ok:
                audited.append({**base, "eligible": False, "exclusion": "sqlite_gold_failed"})
                continue
            if not sqlite_repair_ok:
                audited.append({**base, "eligible": False, "exclusion": "sqlite_repair_failed"})
                continue
            if not result_equivalent(sqlite_repair, sqlite_gold, case["new_sql"]):
                audited.append({**base, "eligible": False, "exclusion": "sqlite_repair_wrong"})
                continue
            try:
                duck_gold_sql = translate(case["new_sql"])
            except Exception:
                audited.append({**base, "eligible": False, "exclusion": "gold_translation_failed"})
                continue
            try:
                duck_repair_sql = translate(repair_sql)
            except Exception:
                audited.append({**base, "eligible": False, "exclusion": "repair_translation_failed"})
                continue
            duck_gold_ok, duck_gold = _execute_duck(connection, duck_gold_sql)
            if not duck_gold_ok:
                audited.append({**base, "eligible": False, "exclusion": "duckdb_gold_failed"})
                continue
            duck_repair_ok, duck_repair = _execute_duck(connection, duck_repair_sql)
            if not duck_repair_ok:
                audited.append({**base, "eligible": False, "exclusion": "duckdb_repair_failed"})
                continue
            if not equivalent(sqlite_gold, duck_gold, case["new_sql"]):
                audited.append(
                    {**base, "eligible": False, "exclusion": "cross_engine_gold_mismatch"}
                )
                continue
            correct = equivalent(duck_repair, duck_gold, case["new_sql"])
            audited.append(
                {
                    **base,
                    "eligible": True,
                    "exclusion": None,
                    "duckdb_repair_correct": correct,
                    "duckdb_repair_exec_ok": True,
                }
            )
        if connection is not None:
            connection.close()

    eligible = [row for row in audited if row["eligible"]]
    correct = sum(row["duckdb_repair_correct"] for row in eligible)
    exclusions = Counter(row["exclusion"] for row in audited if not row["eligible"])
    report = {
        "protocol": "research/ablation_portability_preregistration.md",
        "duckdb_version": duckdb.__version__,
        "input_cases": len(audited),
        "input_databases": len({row["db_id"] for row in audited}),
        "eligible_cases": len(eligible),
        "eligible_databases": len({row["db_id"] for row in eligible}),
        "eligibility_rate": len(eligible) / len(audited),
        "correct": correct,
        "result_equivalent_rate": correct / len(eligible) if eligible else None,
        "result_equivalent_wilson_95": (
            wilson_interval(correct, len(eligible)) if eligible else [None, None]
        ),
        "exclusions": dict(sorted(exclusions.items())),
        "by_scenario": {},
        "interpretation": (
            "portability diagnostic; scanner-backed attached SQLite supplies rows, "
            "while DuckDB parses, plans, and executes SQLGlot-translated queries"
        ),
    }
    for scenario in sorted({row["scenario"] for row in audited}):
        group = [row for row in audited if row["scenario"] == scenario]
        group_eligible = [row for row in group if row["eligible"]]
        group_correct = sum(row.get("duckdb_repair_correct", False) for row in group_eligible)
        report["by_scenario"][scenario] = {
            "input": len(group),
            "eligible": len(group_eligible),
            "correct": group_correct,
            "result_equivalent_rate": (
                group_correct / len(group_eligible) if group_eligible else None
            ),
            "exclusions": dict(
                sorted(Counter(row["exclusion"] for row in group if not row["eligible"]).items())
            ),
        }
    return report, audited


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=Path("results/schemamem/duckdb_portability.json")
    )
    parser.add_argument(
        "--instances-output",
        type=Path,
        default=Path("results/schemamem/duckdb_portability.instances.json"),
    )
    parser.add_argument(
        "--validator",
        choices=("legacy_flat", "current"),
        default="legacy_flat",
        help="policy validator used before the cross-engine eligibility gate",
    )
    args = parser.parse_args()
    report, instances = run(args.validator)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    args.instances_output.write_text(
        json.dumps(instances, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
