"""Freeze the exact complete target/memory pairs used by an agent experiment."""

from __future__ import annotations

import argparse
import json
import random
from collections import defaultdict
from pathlib import Path


REQUIRED = {
    "no_memory",
    "stale_memory",
    "version_filter",
    "schema_aware_memory",
    "policy_memory",
}


def freeze(runs: Path) -> list[dict]:
    grouped: dict[tuple[str, str, int], list[dict]] = defaultdict(list)
    for line in runs.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        grouped[(row["scenario"], row["db_id"], row["question_id"])].append(row)

    targets = []
    for (scenario, db_id, question_id), rows in sorted(grouped.items()):
        by_condition = {row["condition"]: row for row in rows}
        if not REQUIRED <= set(by_condition):
            continue
        memory_ids = {row["memory_question_id"] for row in rows}
        if len(memory_ids) != 1:
            raise ValueError(f"inconsistent memory for {(scenario, db_id, question_id)}")
        reference = by_condition["stale_memory"]
        targets.append(
            {
                "scenario": scenario,
                "db_id": db_id,
                "question_id": question_id,
                "memory_question_id": memory_ids.pop(),
                "target_affected": reference["target_affected"],
                "memory_affected": reference["memory_affected"],
                "retrieval_score": reference["retrieval_score"],
            }
        )
    return targets


def balanced_sample(targets: list[dict], per_db: int, seed: int = 42) -> list[dict]:
    """Sample affected/unaffected memories within each database when possible."""
    rng = random.Random(seed)
    by_db: dict[str, list[dict]] = defaultdict(list)
    for target in targets:
        by_db[target["db_id"]].append(target)
    selected = []
    for db_id in sorted(by_db):
        affected = [row for row in by_db[db_id] if row["memory_affected"]]
        unaffected = [row for row in by_db[db_id] if not row["memory_affected"]]
        rng.shuffle(affected)
        rng.shuffle(unaffected)
        chosen = []
        while len(chosen) < per_db and (affected or unaffected):
            if affected and len(chosen) < per_db:
                chosen.append(affected.pop())
            if unaffected and len(chosen) < per_db:
                chosen.append(unaffected.pop())
        remaining = affected + unaffected
        rng.shuffle(remaining)
        chosen.extend(remaining[: max(0, per_db - len(chosen))])
        selected.extend(chosen)
    return selected


def affected_plus_unaffected_controls(
    targets: list[dict], unaffected_per_db: int, seed: int = 42
) -> list[dict]:
    """Keep every affected memory and seeded unaffected controls per database."""
    affected = [row for row in targets if row["memory_affected"]]
    unaffected = [row for row in targets if not row["memory_affected"]]
    controls = balanced_sample(unaffected, unaffected_per_db, seed)
    return sorted(
        [*affected, *controls],
        key=lambda row: (row["db_id"], row["scenario"], row["question_id"]),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--runs", type=Path, default=Path("results/schemamem/agent_runs_7b.jsonl")
    )
    parser.add_argument(
        "--output", type=Path, default=Path("data/schemamem-agent-targets-v1.json")
    )
    parser.add_argument("--per-db", type=int)
    parser.add_argument(
        "--expanded-unaffected-per-db",
        type=int,
        help="retain all affected memories plus this many unaffected controls per database",
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--memory-status", choices=("all", "affected", "unaffected"), default="all"
    )
    args = parser.parse_args()
    targets = freeze(args.runs)
    if args.expanded_unaffected_per_db:
        if args.memory_status != "all" or args.per_db:
            parser.error(
                "--expanded-unaffected-per-db cannot be combined with --memory-status or --per-db"
            )
        targets = affected_plus_unaffected_controls(
            targets, args.expanded_unaffected_per_db, args.seed
        )
    elif args.memory_status != "all":
        wanted = args.memory_status == "affected"
        targets = [row for row in targets if row["memory_affected"] is wanted]
    if args.per_db:
        targets = balanced_sample(targets, args.per_db, args.seed)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(targets, indent=2), encoding="utf-8")
    report = {
        "targets": len(targets),
        "databases": len({row["db_id"] for row in targets}),
        "scenarios": sorted({row["scenario"] for row in targets}),
        "affected_memories": sum(row["memory_affected"] for row in targets),
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
