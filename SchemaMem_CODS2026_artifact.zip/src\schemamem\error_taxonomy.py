"""Summarize execution-grounded failure modes in JSONL model runs."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def category(row: dict) -> str:
    if row.get("correct") or row.get("correct_sql"):
        return "correct"
    trace = row.get("trace") or []
    if any(str(event.get("raw", "")).count('{"action"') > 1 for event in trace):
        return "multi_action_contract_violation"
    if "finalized" in row and not row.get("finalized"):
        return "tool_budget_or_contract_failure"
    if row.get("exec_ok"):
        return "silent_wrong_result"
    error = str(row.get("error") or "").casefold()
    if "timeout" in error or "interrupted" in error:
        return "timeout"
    if "no such table" in error:
        return "unknown_table"
    if "no such column" in error:
        return "unknown_column"
    if "ambiguous column" in error:
        return "ambiguous_column"
    if "syntax" in error or "incomplete input" in error or "unrecognized token" in error:
        return "syntax_error"
    if row.get("response_type") in {"abstain", "invalidate"}:
        return row["response_type"]
    return "other_execution_error"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("runs", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    rows = [json.loads(line) for line in args.runs.read_text(encoding="utf-8").splitlines()]
    groups: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        key = row.get("condition") or row.get("class") or "all"
        groups[key].append(row)
    report = {
        "source": str(args.runs),
        "n": len(rows),
        "overall": dict(Counter(category(row) for row in rows)),
        "groups": {
            name: {"n": len(group), "categories": dict(Counter(category(row) for row in group))}
            for name, group in sorted(groups.items())
        },
    }
    output = args.output or args.runs.with_suffix(".errors.json")
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
