# Third-party data and model notice

## BIRD Mini-Dev

SchemaMem's generated benchmark records are derived from the public BIRD
Mini-Dev questions, SQL programs, evidence, and database schemas:

- Project: https://github.com/bird-bench/mini_dev
- Paper: Jinyang Li et al., *Can LLM Already Serve as A Database Interface? A
  BIg Bench for Large-Scale Database Grounded Text-to-SQLs*, NeurIPS 2023.
- Dataset license displayed by the project: Creative Commons Attribution-
  ShareAlike 4.0 International (CC BY-SA 4.0),
  https://creativecommons.org/licenses/by-sa/4.0/

The SchemaMem supplement does not redistribute the BIRD SQLite databases.
Reviewers obtain Mini-Dev from the official project and place it at the path
documented in `ARTIFACT.md`. Derived benchmark JSON retains the source database
and question identifiers needed for attribution and traceability.

## EvoSchema

EvoSchema supplies an evolution taxonomy and candidate identifier names. Its
repository is an external input and is not redistributed:

- Project: https://github.com/zhangtianshu/EvoSchema
- Paper: Tianshu Zhang et al., *EvoSchema: Towards Text-to-SQL Robustness
  Against Schema Evolution*, PVLDB 18(10), 2025.

SchemaMem independently rebuilds executable before/after databases and does not
use EvoSchema's rewritten SQL as ground truth.

## Dr.Spider and Spider

The external transfer suite is derived from Dr.Spider's database-schema synonym
and abbreviation perturbations and the corresponding Spider 1.0 databases:

- Dr.Spider project: https://github.com/awslabs/diagnostic-robustness-text-to-sql
- Dr.Spider paper: Shuaichen Chang et al., *Dr.Spider: A Diagnostic Evaluation
  Benchmark towards Text-to-SQL Robustness*, ICLR 2023.
- Spider project: https://yale-lily.github.io/spider
- Dr.Spider repository license: Apache License 2.0; released annotations are
  marked CC BY 4.0 in the repository.

The supplement does not redistribute Dr.Spider or Spider SQLite databases. It
includes the deterministic adapter, preregistration, target manifest, derived
metadata, frozen model traces, and statistical/audit outputs. Reviewers obtain
the databases from the official projects and rebuild the same 32-target suite
using the documented command and frozen hashes.

## Local language models

Model weights and inference binaries are not redistributed. The exact model
families, quantizations, and official model links are documented in
`research/model_controls.md`; users must follow the corresponding upstream
licenses when obtaining weights.
