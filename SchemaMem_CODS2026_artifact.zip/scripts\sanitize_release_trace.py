"""Redact email-shaped database values from a JSONL trace for anonymous release.

The original run remains immutable.  This utility changes string values only,
records every changed JSON path without recording the matched value, and checks
that all non-trace top-level fields are identical before writing the release
copy.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any


EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
REPLACEMENT = "[REDACTED_DATABASE_EMAIL]"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _redact(value: Any, path: str, changed_paths: Counter[str]) -> Any:
    if isinstance(value, str):
        replaced, count = EMAIL.subn(REPLACEMENT, value)
        if count:
            changed_paths[path] += count
        return replaced
    if isinstance(value, list):
        return [
            _redact(item, f"{path}[{index}]", changed_paths)
            for index, item in enumerate(value)
        ]
    if isinstance(value, dict):
        return {
            key: _redact(item, f"{path}.{key}" if path else key, changed_paths)
            for key, item in value.items()
        }
    return value


def _scientific_projection(record: dict[str, Any]) -> dict[str, Any]:
    """Fields used by integrity/statistics scripts; traces are diagnostic only."""
    return {key: value for key, value in record.items() if key != "trace"}


def sanitize(source: Path, output: Path, audit_output: Path) -> dict[str, Any]:
    records: list[dict[str, Any]] = []
    changed_paths: Counter[str] = Counter()
    changed_records = 0

    for line_number, line in enumerate(source.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        original = json.loads(line)
        before = sum(changed_paths.values())
        sanitized = _redact(original, "", changed_paths)
        if sum(changed_paths.values()) > before:
            changed_records += 1
        if _scientific_projection(original) != _scientific_projection(sanitized):
            raise ValueError(f"redaction changed a scientific field on line {line_number}")
        records.append(sanitized)

    if not changed_paths:
        raise ValueError("expected at least one email-shaped database value to redact")

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    residual = EMAIL.search(output.read_text(encoding="utf-8"))
    if residual:
        raise ValueError("email-shaped value remains after redaction")

    audit = {
        "status": "passed",
        "source_sha256": _sha256(source),
        "release_sha256": _sha256(output),
        "records": len(records),
        "changed_records": changed_records,
        "redactions": sum(changed_paths.values()),
        "changed_json_paths": dict(sorted(changed_paths.items())),
        "replacement": REPLACEMENT,
        "invariant": "all top-level fields except trace are byte-value equivalent after JSON parsing",
    }
    audit_output.parent.mkdir(parents=True, exist_ok=True)
    audit_output.write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    return audit


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--audit", required=True, type=Path)
    args = parser.parse_args()
    audit = sanitize(args.source, args.output, args.audit)
    print(
        "release trace redaction: passed "
        f"({audit['redactions']} values in {audit['changed_records']} records)"
    )


if __name__ == "__main__":
    main()
