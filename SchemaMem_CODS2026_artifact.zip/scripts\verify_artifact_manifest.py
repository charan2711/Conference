"""Verify every file listed in a SchemaMem artifact SHA-256 manifest."""

from __future__ import annotations

import argparse
import hashlib
import re
import sys
import zipfile
from pathlib import Path, PurePosixPath


LINE = re.compile(r"^([0-9a-f]{64})  (.+)$")


def parse_manifest(text: str) -> dict[str, str]:
    expected: dict[str, str] = {}
    for number, raw in enumerate(text.splitlines(), start=1):
        match = LINE.fullmatch(raw.strip("\ufeff"))
        if not match:
            raise ValueError(f"malformed MANIFEST.sha256 line {number}")
        digest, name = match.groups()
        path = PurePosixPath(name)
        if path.is_absolute() or ".." in path.parts or "\\" in name:
            raise ValueError(f"unsafe manifest path: {name}")
        if name in expected:
            raise ValueError(f"duplicate manifest path: {name}")
        expected[name] = digest
    if not expected:
        raise ValueError("manifest contains no files")
    return expected


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def verify_directory(root: Path) -> tuple[int, list[str]]:
    manifest = root / "MANIFEST.sha256"
    expected = parse_manifest(manifest.read_text(encoding="utf-8-sig"))
    actual = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path != manifest
    }
    errors = []
    if set(expected) != actual:
        for name in sorted(set(expected) - actual):
            errors.append(f"missing: {name}")
        for name in sorted(actual - set(expected)):
            errors.append(f"unlisted: {name}")
    for name, digest in expected.items():
        path = root.joinpath(*PurePosixPath(name).parts)
        if path.is_file():
            actual_digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if actual_digest != digest:
                errors.append(f"hash mismatch: {name}")
    return len(expected), errors


def verify_zip(path: Path) -> tuple[int, list[str]]:
    errors: list[str] = []
    with zipfile.ZipFile(path) as archive:
        names = [name for name in archive.namelist() if not name.endswith("/")]
        for name in sorted({item for item in names if names.count(item) > 1}):
            errors.append(f"duplicate archive path: {name}")
        for name in names:
            parsed = PurePosixPath(name)
            if parsed.is_absolute() or ".." in parsed.parts or "\\" in name:
                errors.append(f"unsafe archive path: {name}")
        if names.count("MANIFEST.sha256") != 1:
            return 0, errors + ["archive must contain exactly one MANIFEST.sha256"]
        expected = parse_manifest(archive.read("MANIFEST.sha256").decode("utf-8-sig"))
        actual = set(names) - {"MANIFEST.sha256"}
        if set(expected) != actual:
            for name in sorted(set(expected) - actual):
                errors.append(f"missing: {name}")
            for name in sorted(actual - set(expected)):
                errors.append(f"unlisted: {name}")
        for name, digest in expected.items():
            if name in actual and sha256_bytes(archive.read(name)) != digest:
                errors.append(f"hash mismatch: {name}")
    return len(expected), errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact", type=Path)
    args = parser.parse_args()
    if args.artifact.is_dir():
        count, errors = verify_directory(args.artifact)
    elif args.artifact.is_file() and args.artifact.suffix.lower() == ".zip":
        count, errors = verify_zip(args.artifact)
    else:
        parser.error("artifact must be a staging directory or ZIP file")
    if errors:
        print(f"artifact manifest: failed ({len(errors)} errors)")
        for error in errors:
            print(error)
        return 1
    print(f"artifact manifest: passed ({count} files verified)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
