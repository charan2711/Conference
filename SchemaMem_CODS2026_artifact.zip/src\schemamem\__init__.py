"""Schema-aware maintenance for persistent data-agent memories."""

