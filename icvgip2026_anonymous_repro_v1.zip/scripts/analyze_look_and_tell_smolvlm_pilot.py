"""Audit the bounded SmolVLM pilot and compare it on the identical rows."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np
from scipy.sparse import hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import OneHotEncoder

from baseline_look_and_tell_classical_vision import (
    SEED,
    add_history,
    load_recording,
    new_model,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--pilot",
        type=Path,
        default=Path("artifacts/baselines/look_and_tell_smolvlm_pilot.json"),
    )
    parser.add_argument(
        "--derived-root", type=Path, default=Path("data/derived/look_and_tell")
    )
    parser.add_argument(
        "--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json")
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/audits/look_and_tell_smolvlm_pilot_analysis.json"),
    )
    return parser.parse_args()


def load_rows(root: Path, spec: dict) -> list[dict]:
    rows: list[dict] = []
    for split in ("train", "val", "test"):
        for recording in spec["splits"][split]["recordings"]:
            try:
                rows.extend(load_recording(root, recording))
            except FileNotFoundError:
                pass
    for index, row in enumerate(rows):
        row["_global_index"] = index
    return rows


def paired_summary(
    first: list[dict], second: list[dict], draws: int = 5000
) -> dict:
    by_first = {row["row_index"]: row for row in first}
    by_second = {row["row_index"]: row for row in second}
    if set(by_first) != set(by_second):
        raise RuntimeError("Condition row IDs differ")
    row_ids = sorted(by_first)
    for row_id in row_ids:
        if by_first[row_id]["target"] != by_second[row_id]["target"]:
            raise RuntimeError(f"Condition target mismatch at row {row_id}")
    first_correct = np.asarray(
        [by_first[row_id]["prediction"] == by_first[row_id]["target"] for row_id in row_ids],
        dtype=float,
    )
    second_correct = np.asarray(
        [by_second[row_id]["prediction"] == by_second[row_id]["target"] for row_id in row_ids],
        dtype=float,
    )
    participants = sorted({by_first[row_id]["participant_id"] for row_id in row_ids})
    participant_indices = {
        participant: np.asarray(
            [
                position
                for position, row_id in enumerate(row_ids)
                if by_first[row_id]["participant_id"] == participant
            ]
        )
        for participant in participants
    }
    rng = np.random.default_rng(SEED)
    differences = np.empty(draws, dtype=float)
    for draw in range(draws):
        sampled = rng.choice(participants, size=len(participants), replace=True)
        indices = np.concatenate([participant_indices[participant] for participant in sampled])
        differences[draw] = float(
            np.mean(first_correct[indices] - second_correct[indices])
        )
    first_unique = int(np.sum((first_correct == 1) & (second_correct == 0)))
    second_unique = int(np.sum((second_correct == 1) & (first_correct == 0)))
    return {
        "n": len(row_ids),
        "participants": participants,
        "difference_points": float(100 * np.mean(first_correct - second_correct)),
        "participant_bootstrap_95ci_points": [
            float(100 * np.quantile(differences, 0.025)),
            float(100 * np.quantile(differences, 0.975)),
        ],
        "first_unique_correct": first_unique,
        "second_unique_correct": second_unique,
    }


def text_history_baseline(
    rows: list[dict], held_out: set[str], eval_ids: set[int]
) -> tuple[dict, list[dict]]:
    train = [dict(row) for row in rows if row["participant_id"] not in held_out]
    outer_eval = [dict(row) for row in rows if row["participant_id"] in held_out]
    frequencies = Counter(row["reference"] for row in train)
    labels = sorted(frequencies)
    add_history(train, labels, frequencies)
    add_history(outer_eval, labels, frequencies)
    evaluation = [row for row in outer_eval if row["_global_index"] in eval_ids]

    vectorizer = TfidfVectorizer(
        analyzer="char_wb",
        ngram_range=(2, 5),
        min_df=2,
        max_features=20000,
        sublinear_tf=True,
    )
    train_text = vectorizer.fit_transform(row.get("surface_text") or "" for row in train)
    eval_text = vectorizer.transform(row.get("surface_text") or "" for row in evaluation)
    history = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    train_history = history.fit_transform(
        np.asarray([[row["history_prediction"]] for row in train])
    )
    eval_history = history.transform(
        np.asarray([[row["history_prediction"]] for row in evaluation])
    )
    model = new_model()
    model.fit(hstack([train_text, train_history]), [row["reference"] for row in train])
    targets = np.asarray([row["reference"] for row in evaluation])
    predictions = model.predict(hstack([eval_text, eval_history]))
    coreference = np.asarray(
        [row.get("mention_type") == "pronoun/coref" for row in evaluation], dtype=bool
    )
    summary = {
        "n": len(evaluation),
        "accuracy": float(accuracy_score(targets, predictions)),
        "macro_f1": float(f1_score(targets, predictions, average="macro", zero_division=0)),
        "coreference_n": int(coreference.sum()),
        "coreference_accuracy": float(
            accuracy_score(targets[coreference], predictions[coreference])
        ),
    }
    details = [
        {
            "row_index": row["_global_index"],
            "participant_id": row["participant_id"],
            "recording_uid": row["recording_uid"],
            "mention_type": row.get("mention_type"),
            "target": target,
            "prediction": prediction,
        }
        for row, target, prediction in zip(evaluation, targets, predictions, strict=True)
    ]
    return summary, details


def main() -> None:
    args = parse_args()
    pilot_bytes = args.pilot.read_bytes()
    pilot = json.loads(pilot_bytes)
    if pilot["status"] != "pilot_only_not_for_paper_claims":
        raise RuntimeError("Unexpected pilot status")
    required = {"full", "center", "gaze", "shuffled"}
    if set(pilot["predictions"]) != required:
        raise RuntimeError("Pilot does not contain all four matched conditions")
    full_ids = {row["row_index"] for row in pilot["predictions"]["full"]}
    for condition in required:
        if {row["row_index"] for row in pilot["predictions"][condition]} != full_ids:
            raise RuntimeError(f"Row mismatch for {condition}")

    spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows = load_rows(args.derived_root, spec)
    held_out = set(pilot["protocol"]["held_out_participants"])
    text_summary, text_predictions = text_history_baseline(rows, held_out, full_ids)
    comparisons = {
        name: paired_summary(pilot["predictions"][first], pilot["predictions"][second])
        for name, first, second in (
            ("full_minus_center", "full", "center"),
            ("full_minus_gaze", "full", "gaze"),
            ("full_minus_shuffled", "full", "shuffled"),
            ("gaze_minus_center", "gaze", "center"),
            ("gaze_minus_shuffled", "gaze", "shuffled"),
            ("full_minus_text_history", "full", "text_history"),
        )
        if first != "text_history" and second != "text_history"
    }
    comparisons["full_minus_text_history"] = paired_summary(
        pilot["predictions"]["full"], text_predictions
    )

    output = {
        "status": "pass_pilot_audit_not_for_paper_claims",
        "pilot_sha256": hashlib.sha256(pilot_bytes).hexdigest(),
        "sample": {
            "n": len(full_ids),
            "held_out_participants": sorted(held_out),
            "participant_counts": dict(
                sorted(Counter(row["participant_id"] for row in pilot["predictions"]["full"]).items())
            ),
        },
        "vlm_results": {
            condition: pilot["results"][condition]["evaluation"]
            for condition in sorted(required)
        },
        "same_row_text_history": text_summary,
        "paired_comparisons": comparisons,
        "interpretation": (
            "The connector-only VLM pilot is computationally feasible but undertrained. "
            "Its 24-row estimates and four-participant intervals are not substitutes for "
            "the preregistered six-fold experiment."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
