# Dr.Spider release-trace redaction

The immutable raw Dr.Spider run has SHA-256
`696527f85912763997479f897471862c26c2d1f45de6c3db6cd1d6524697d2fd`.
Three trial traces contain two email-shaped values returned from a public
benchmark database. They are data values, not author identifiers, and do not
affect a prediction, action, token count, execution result, or correctness
label. The conservative anonymity gate nevertheless correctly refuses to
package them.

The anonymous artifact therefore contains a derived release copy at the same
documented result path. `scripts/sanitize_release_trace.py` replaces only those
email-shaped strings in diagnostic `trace` observations. It verifies that every
top-level scientific field other than `trace` is unchanged and writes
`results/schemamem/tool_agent_runs_qwen7_drspider_v1.release_redaction.json`
with source/release hashes, counts, and changed JSON paths. The original raw
hash remains disclosed above so custodians can verify the unredacted run
privately if required.

The adaptive scope-refined policy-only rerun is handled identically. Its raw
SHA-256 is
`c32b14bf27cc01f56b7dc1e8b052bed9418fdad0831b8ec64df3dd01d916a361`;
one trial trace contains the public database email-shaped values. The packaged
copy is accompanied by
`results/schemamem/tool_agent_runs_qwen7_drspider_scope_refined_v2.release_redaction.json`.
