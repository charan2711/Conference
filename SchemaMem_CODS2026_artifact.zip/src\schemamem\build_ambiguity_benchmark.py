"""Build decision cases where a memory policy must repair, reuse, or abstain."""

from __future__ import annotations

import argparse
import json
import random
from collections import defaultdict
from pathlib import Path

from .build_benchmark import refs, sqlite_schema


def rename_manifest(row: dict, migrations: dict, old_schema: dict, current_schema: dict) -> dict | None:
    spec = migrations[row["db_id"]]
    columns = spec["column_rename"] if row["scenario"] == "column_rename" else {}
    tables = spec["table_rename"] if row["scenario"] == "table_rename" else {}
    used_tables, used_columns = refs(row["old_sql"], old_schema)
    relevant_columns = {
        key: value
        for key, value in columns.items()
        if tuple(key.split(".", 1)) in used_columns
    }
    relevant_tables = {key: value for key, value in tables.items() if key in used_tables}
    if row["affected"] and not (relevant_columns or relevant_tables):
        return None
    write_set = [*columns, *tables]
    return {
        "operator": "rename",
        "write_set": write_set,
        "column_candidates": {key: [value] for key, value in columns.items()},
        "table_candidates": {key: [value] for key, value in tables.items()},
        "relevant_columns": relevant_columns,
        "relevant_tables": relevant_tables,
    }


def ambiguous_copy(manifest: dict, current_schema: dict) -> dict | None:
    output = json.loads(json.dumps(manifest))
    if manifest["relevant_columns"]:
        key, true_name = next(iter(manifest["relevant_columns"].items()))
        table = key.split(".", 1)[0]
        candidates = sorted(current_schema.get(table, set()) - {true_name})
        if not candidates:
            return None
        output["column_candidates"][key] = [true_name, candidates[0]]
    elif manifest["relevant_tables"]:
        key, true_name = next(iter(manifest["relevant_tables"].items()))
        candidates = sorted(set(current_schema) - {true_name})
        if not candidates:
            return None
        output["table_candidates"][key] = [true_name, candidates[0]]
    else:
        return None
    output.pop("relevant_columns", None)
    output.pop("relevant_tables", None)
    return output


def clean_manifest(manifest: dict) -> dict:
    output = json.loads(json.dumps(manifest))
    output.pop("relevant_columns", None)
    output.pop("relevant_tables", None)
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--per-class", type=int, default=50)
    parser.add_argument("--output", type=Path, default=Path("data/schemamem-ambiguity-v1"))
    args = parser.parse_args()
    rename_root = Path("data/schemamem-bench-v1")
    split_root = Path("data/schemamem-split-v1")
    merge_root = Path("data/schemamem-merge-v1")
    originals = Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases")
    rename_rows = [
        row
        for row in json.loads((rename_root / "instances.json").read_text(encoding="utf-8"))
        if row["execution_equivalent"]
    ]
    rename_specs = json.loads((rename_root / "migrations.json").read_text(encoding="utf-8"))
    split_rows = [
        row
        for row in json.loads((split_root / "instances.json").read_text(encoding="utf-8"))
        if row["execution_equivalent"]
    ]
    split_specs = json.loads((split_root / "migrations.json").read_text(encoding="utf-8"))
    merge_rows = [
        row
        for row in json.loads((merge_root / "instances.json").read_text(encoding="utf-8"))
        if row["execution_equivalent"]
    ]
    merge_specs = json.loads((merge_root / "migrations.json").read_text(encoding="utf-8"))
    cases: dict[str, list[dict]] = defaultdict(list)

    for row in rename_rows:
        old_path = originals / row["db_id"] / f'{row["db_id"]}.sqlite'
        new_path = rename_root / "databases" / row["scenario"] / row["db_id"] / f'{row["db_id"]}.sqlite'
        old_schema, current_schema = sqlite_schema(old_path), sqlite_schema(new_path)
        manifest = rename_manifest(row, rename_specs, old_schema, current_schema)
        if manifest is None:
            continue
        base = {
            "scenario": row["scenario"],
            "db_id": row["db_id"],
            "question_id": row["question_id"],
            "old_sql": row["old_sql"],
            "gold_new_sql": row["new_sql"],
        }
        if row["affected"]:
            cases["safe_rename"].append({**base, "class": "safe_rename", "expected_action": "migrate", "manifest": clean_manifest(manifest)})
            ambiguous = ambiguous_copy(manifest, current_schema)
            if ambiguous:
                cases["ambiguous_rename"].append({**base, "class": "ambiguous_rename", "expected_action": "explore", "manifest": ambiguous})
            drop = clean_manifest(manifest)
            drop["operator"] = "drop"
            cases["referenced_drop"].append({**base, "class": "referenced_drop", "expected_action": "invalidate", "manifest": drop})
            unknown = {"operator": "unknown", "write_set": manifest["write_set"]}
            cases["unknown_change"].append({**base, "class": "unknown_change", "expected_action": "explore", "manifest": unknown})
        else:
            cases["unaffected"].append({**base, "class": "unaffected", "expected_action": "reuse", "manifest": clean_manifest(manifest)})

    for row in split_rows:
        if not row["affected"]:
            continue
        spec = split_specs[row["db_id"]]
        base = {
            "scenario": "table_split",
            "db_id": row["db_id"],
            "question_id": row["question_id"],
            "old_sql": row["old_sql"],
            "gold_new_sql": row["new_sql"],
            "split_spec": spec,
        }
        true_join = [[(key, key) for key in spec["primary_key"]]]
        cases["safe_split"].append({**base, "class": "safe_split", "expected_action": "migrate", "join_candidates": true_join})
        if spec["kept_columns"] and spec["moved_columns"]:
            false_join = [(spec["kept_columns"][-1], spec["moved_columns"][0])]
            cases["ambiguous_split"].append({**base, "class": "ambiguous_split", "expected_action": "explore", "join_candidates": [true_join[0], false_join]})

    for row in merge_rows:
        if not row["affected"]:
            continue
        spec = merge_specs[row["db_id"]]
        base = {
            "scenario": "table_merge",
            "db_id": row["db_id"],
            "question_id": row["question_id"],
            "old_sql": row["old_sql"],
            "gold_new_sql": row["new_sql"],
            "merge_spec": spec,
        }
        true_join = [[(key, key) for key in spec["primary_key"]]]
        cases["safe_merge"].append(
            {**base, "class": "safe_merge", "expected_action": "migrate", "join_candidates": true_join}
        )
        false_join = [(spec["kept_columns"][-1], spec["moved_columns"][0])]
        cases["ambiguous_merge"].append(
            {**base, "class": "ambiguous_merge", "expected_action": "explore", "join_candidates": [true_join[0], false_join]}
        )

    rng = random.Random(42)
    output = []
    for name, group in sorted(cases.items()):
        rng.shuffle(group)
        output.extend(group[: args.per_class])
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "instances.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    summary = {"n": len(output), "by_class": {name: sum(row["class"] == name for row in output) for name in sorted(cases)}}
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
