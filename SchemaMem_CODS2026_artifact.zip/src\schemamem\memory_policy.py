"""Conservative lifecycle decisions for dependency-bearing SQL memories."""

from __future__ import annotations

from dataclasses import asdict, dataclass

from sqlglot import exp, parse_one
from sqlglot.optimizer.qualify import qualify

from .build_benchmark import refs


@dataclass(frozen=True)
class Decision:
    action: str
    reason: str
    sql: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def _valid(sql: str, schema: dict[str, set[str]]) -> bool:
    """Validate physical and derived identifiers in their lexical scopes."""
    try:
        tree = parse_one(sql, read="sqlite")
        typed_schema = {
            table: {column: "UNKNOWN" for column in columns}
            for table, columns in schema.items()
        }
        qualify(
            tree,
            schema=typed_schema,
            dialect="sqlite",
            validate_qualify_columns=True,
            identify=False,
        )
        return True
    except Exception:
        return False


def _migrate_rename(
    sql: str,
    old_schema: dict[str, set[str]],
    column_map: dict[tuple[str, str], str],
    table_map: dict[str, str],
) -> tuple[str, bool]:
    """Runtime rename implementation, independent of the benchmark builder."""
    tree = parse_one(sql, read="sqlite")
    table_nodes = list(tree.find_all(exp.Table))
    aliases = {node.alias_or_name.casefold(): node.name for node in table_nodes}
    used = {node.name for node in table_nodes}
    folded_columns = {
        (table.casefold(), column.casefold()): new
        for (table, column), new in column_map.items()
    }
    folded_tables = {old.casefold(): new for old, new in table_map.items()}
    schema_fold = {
        table: {column.casefold() for column in columns}
        for table, columns in old_schema.items()
    }
    changed = False
    for node in tree.find_all(exp.Column):
        owner = aliases.get(node.table.casefold()) if node.table else None
        if not node.table:
            owners = [
                table
                for table in used
                if node.name.casefold() in schema_fold.get(table, set())
            ]
            owner = owners[0] if len(owners) == 1 else None
        replacement = folded_columns.get(
            ((owner or "").casefold(), node.name.casefold())
        )
        if replacement:
            node.set("this", exp.to_identifier(replacement))
            changed = True
    # Only unaliased table qualifiers track a table rename; explicit aliases are
    # stable by definition.
    unaliased = {
        node.name.casefold(): folded_tables[node.name.casefold()]
        for node in table_nodes
        if not node.alias and node.name.casefold() in folded_tables
    }
    for node in tree.find_all(exp.Column):
        replacement = unaliased.get(node.table.casefold()) if node.table else None
        if replacement:
            node.set("table", exp.to_identifier(replacement))
            changed = True
    for node in table_nodes:
        replacement = folded_tables.get(node.name.casefold())
        if replacement:
            node.set("this", exp.to_identifier(replacement))
            changed = True
    return tree.sql(dialect="sqlite"), changed


def _migrate_split(
    sql: str, old_schema: dict[str, set[str]], spec: dict
) -> tuple[str, bool]:
    """Runtime vertical-split repair, independent of benchmark construction."""
    tree = parse_one(sql, read="sqlite")
    selects = list(tree.find_all(exp.Select))
    if len(selects) != 1 or any(True for _ in tree.find_all(exp.Star)):
        raise ValueError("unsupported nested query or star")
    targets = [
        node
        for node in tree.find_all(exp.Table)
        if node.name.casefold() == spec["table"].casefold()
    ]
    if len(targets) != 1:
        return tree.sql(dialect="sqlite"), False
    target = targets[0]
    target_alias = target.alias_or_name
    tables = list(tree.find_all(exp.Table))
    aliases = {node.alias_or_name.casefold(): node.name for node in tables}
    used = {node.name for node in tables}
    schema_fold = {
        table: {column.casefold() for column in columns}
        for table, columns in old_schema.items()
    }
    moved = {column.casefold() for column in spec["moved_columns"]}
    keys = {column.casefold() for column in spec["primary_key"]}
    kept = {column.casefold() for column in spec["kept_columns"]} - keys
    moved_nodes, kept_nodes = [], []
    for node in tree.find_all(exp.Column):
        owner = aliases.get(node.table.casefold()) if node.table else None
        if not node.table:
            owners = [
                table
                for table in used
                if node.name.casefold() in schema_fold.get(table, set())
            ]
            owner = owners[0] if len(owners) == 1 else None
        if owner and owner.casefold() == spec["table"].casefold():
            if node.name.casefold() in moved:
                moved_nodes.append(node)
            elif node.name.casefold() in kept:
                kept_nodes.append(node)
    if not moved_nodes:
        return tree.sql(dialect="sqlite"), False
    details = spec["details_table"]
    if not kept_nodes:
        target.set("this", exp.to_identifier(details))
        return tree.sql(dialect="sqlite"), True
    detail_alias = "__sm_details"
    for node in moved_nodes:
        node.set("table", exp.to_identifier(detail_alias))
    predicates = " AND ".join(
        f"{target_alias}.{key} = {detail_alias}.{key}"
        for key in spec["primary_key"]
    )
    scaffold = parse_one(
        f"SELECT 1 FROM __old INNER JOIN {details} AS {detail_alias} ON {predicates}",
        read="sqlite",
    )
    detail_join = scaffold.args["joins"][0]
    select = selects[0]
    select.set("joins", [detail_join, *select.args.get("joins", [])])
    return tree.sql(dialect="sqlite"), True


def _migrate_merge(sql: str, spec: dict) -> tuple[str, bool]:
    """Repair SQL after a vertically split relation is consolidated again.

    The implementation intentionally does not invert ``rewrite_split`` from the
    benchmark builder.  It recognizes the two observable historical programs:
    a query over only the details relation, or a query joining the base and
    details relations, then produces a query over the consolidated base table.
    """
    tree = parse_one(sql, read="sqlite")
    if len(list(tree.find_all(exp.Select))) != 1:
        raise ValueError("unsupported nested query")
    base_name = spec["table"]
    details_name = spec["details_table"]
    details_nodes = [
        node
        for node in tree.find_all(exp.Table)
        if node.name.casefold() == details_name.casefold()
    ]
    if len(details_nodes) != 1:
        return tree.sql(dialect="sqlite"), False
    details = details_nodes[0]
    details_alias = details.alias_or_name
    base_nodes = [
        node
        for node in tree.find_all(exp.Table)
        if node.name.casefold() == base_name.casefold()
    ]

    # A details-only historical query now reads from the consolidated relation.
    if not base_nodes:
        details.set("this", exp.to_identifier(base_name))
        return tree.sql(dialect="sqlite"), True
    if len(base_nodes) != 1:
        raise ValueError("multiple base relations are unsupported")

    base = base_nodes[0]
    base_alias = base.alias_or_name
    select = next(tree.find_all(exp.Select))
    joins = list(select.args.get("joins", []))
    details_join = next(
        (
            join
            for join in joins
            if isinstance(join.this, exp.Table) and join.this is details
        ),
        None,
    )
    if details_join is None:
        raise ValueError("details relation is not a removable join")

    # Verify the removable edge is precisely the declared key equality.  This
    # prevents deleting a semantically meaningful or many-to-many join merely
    # because it happens to mention the details relation.
    on = details_join.args.get("on")
    equalities = list(on.flatten()) if isinstance(on, exp.And) else [on]
    observed: set[tuple[str, str]] = set()
    for predicate in equalities:
        if not isinstance(predicate, exp.EQ):
            raise ValueError("non-equality merge predicate")
        left, right = predicate.left, predicate.right
        if not isinstance(left, exp.Column) or not isinstance(right, exp.Column):
            raise ValueError("non-column merge predicate")
        pair = {
            (left.table.casefold(), left.name.casefold()),
            (right.table.casefold(), right.name.casefold()),
        }
        for key in spec["primary_key"]:
            expected = {
                (base_alias.casefold(), key.casefold()),
                (details_alias.casefold(), key.casefold()),
            }
            if pair == expected:
                observed.add((key.casefold(), key.casefold()))
                break
        else:
            raise ValueError("merge predicate does not match declared key")
    if len(observed) != len(spec["primary_key"]):
        raise ValueError("incomplete merge key")

    for column in tree.find_all(exp.Column):
        if column.table.casefold() == details_alias.casefold():
            column.set("table", exp.to_identifier(base_alias))
    select.set("joins", [join for join in joins if join is not details_join])
    return tree.sql(dialect="sqlite"), True


def decide_rename(
    sql: str,
    old_schema: dict[str, set[str]],
    current_schema: dict[str, set[str]],
    manifest: dict,
) -> Decision:
    try:
        used_tables, used_columns = refs(sql, old_schema)
    except Exception:
        return Decision("explore", "parse_failure")
    write_set = set(manifest.get("write_set", []))
    dependencies = set(used_tables) | {f"{table}.{column}" for table, column in used_columns}
    if dependencies.isdisjoint(write_set):
        return Decision("reuse", "dependencies_unaffected", sql)
    operator = manifest.get("operator")
    if operator == "drop":
        return Decision("invalidate", "referenced_object_dropped")
    if operator != "rename":
        return Decision("explore", "unsupported_or_unknown_operator")
    column_candidates = manifest.get("column_candidates", {})
    table_candidates = manifest.get("table_candidates", {})
    relevant_columns = {
        key: values
        for key, values in column_candidates.items()
        if key in dependencies
    }
    relevant_tables = {
        key: values for key, values in table_candidates.items() if key in used_tables
    }
    relevant = [*relevant_columns.values(), *relevant_tables.values()]
    if not relevant:
        return Decision("explore", "affected_dependency_has_no_mapping")
    if any(len(set(values)) != 1 for values in relevant):
        return Decision("explore", "mapping_is_ambiguous")
    columns = {}
    for qualified, values in column_candidates.items():
        table, old = qualified.split(".", 1)
        columns[(table, old)] = values[0]
    tables = {old: values[0] for old, values in table_candidates.items()}
    try:
        repaired, changed = _migrate_rename(sql, old_schema, columns, tables)
    except Exception:
        return Decision("explore", "structural_rewrite_failed")
    if not changed or not _valid(repaired, current_schema):
        return Decision("explore", "candidate_failed_schema_validation")
    return Decision("migrate", "unique_validated_mapping", repaired)


def decide_split(
    sql: str,
    old_schema: dict[str, set[str]],
    current_schema: dict[str, set[str]],
    spec: dict,
    join_candidates: list[list[tuple[str, str]]],
) -> Decision:
    try:
        _, columns = refs(sql, old_schema)
    except Exception:
        return Decision("explore", "parse_failure")
    moved = {(spec["table"], column) for column in spec["moved_columns"]}
    if columns.isdisjoint(moved):
        return Decision("reuse", "dependencies_unaffected", sql)
    if len(join_candidates) != 1:
        return Decision("explore", "split_join_is_ambiguous")
    # JSON round-trips tuples as lists; compare the semantic pairs instead of
    # their in-memory container representation.
    declared = [tuple(pair) for pair in join_candidates[0]]
    expected = [(key, key) for key in spec["primary_key"]]
    if declared != expected:
        return Decision("explore", "split_join_does_not_match_declared_key")
    try:
        repaired, changed = _migrate_split(sql, old_schema, spec)
    except Exception:
        return Decision("explore", "structural_rewrite_failed")
    if not changed or not _valid(repaired, current_schema):
        return Decision("explore", "candidate_failed_schema_validation")
    return Decision("migrate", "unique_validated_split", repaired)


def decide_merge(
    sql: str,
    old_schema: dict[str, set[str]],
    current_schema: dict[str, set[str]],
    spec: dict,
    join_candidates: list[list[tuple[str, str]]],
) -> Decision:
    """Decide whether a memory can survive vertical-table consolidation."""
    try:
        used_tables, _ = refs(sql, old_schema)
    except Exception:
        return Decision("explore", "parse_failure")
    if spec["details_table"] not in used_tables:
        return Decision("reuse", "dependencies_unaffected", sql)
    if len(join_candidates) != 1:
        return Decision("explore", "merge_join_is_ambiguous")
    declared = [tuple(pair) for pair in join_candidates[0]]
    expected = [(key, key) for key in spec["primary_key"]]
    if declared != expected:
        return Decision("explore", "merge_join_does_not_match_declared_key")
    try:
        repaired, changed = _migrate_merge(sql, spec)
    except Exception:
        return Decision("explore", "structural_rewrite_failed")
    if not changed or not _valid(repaired, current_schema):
        return Decision("explore", "candidate_failed_schema_validation")
    return Decision("migrate", "unique_validated_merge", repaired)
