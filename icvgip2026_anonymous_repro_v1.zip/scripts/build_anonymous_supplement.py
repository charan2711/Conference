"""Build a deterministic, identity-scanned anonymous supplement ZIP."""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "output" / "supplement"
ARCHIVE = OUTPUT_DIR / "icvgip2026_anonymous_repro_v1.zip"
SIDECAR = OUTPUT_DIR / "icvgip2026_anonymous_repro_v1.manifest.json"

FIXED_FILES = (
    "README.md",
    "requirements-research.txt",
    "supplement/README.md",
    "data/manifests/look_and_tell_splits.json",
    "docs/citation_audit.md",
    "docs/dataset_decisions.md",
    "docs/experiment_log.md",
    "docs/license_and_provenance_audit.md",
    "docs/submission_checklist.md",
    "paper/main.tex",
    "paper/references.bib",
    "paper/README.md",
)

GLOBS = (
    "scripts/*.py",
    "artifacts/audits/*.json",
    "artifacts/baselines/*.json",
    "paper/generated/*.tex",
)

# This scan targets user identity, machine paths, and the leaked-token prefix.
# Generic words such as "token" are intentionally allowed in research prose.
FORBIDDEN = {
    "kaggle_token": re.compile(rb"KGAT_[A-Za-z0-9]+", re.IGNORECASE),
    "windows_user_path": re.compile(rb"[A-Za-z]:[\\/]Users[\\/]", re.IGNORECASE),
    # Split deny-list literals so this scanner can safely include its own source.
    "known_account": re.compile(b"charan" + b"charanitachi", re.IGNORECASE),
    "known_employer": re.compile(
        b"Sam" + b"sung|Smart" + b"Things", re.IGNORECASE
    ),
}


def selected_files() -> list[Path]:
    paths = {ROOT / name for name in FIXED_FILES}
    for pattern in GLOBS:
        paths.update(ROOT.glob(pattern))
    missing = sorted(path for path in paths if not path.is_file())
    if missing:
        raise FileNotFoundError(f"Missing supplement files: {missing}")
    return sorted(paths, key=lambda path: path.relative_to(ROOT).as_posix())


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    files = selected_files()
    payloads: dict[str, bytes] = {}
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        for label, pattern in FORBIDDEN.items():
            if pattern.search(data):
                raise RuntimeError(f"Anonymous supplement scan failed: {label} in {relative}")
        payloads[relative] = data

    manifest = {
        "archive": ARCHIVE.name,
        "deterministic_zip_timestamp": "1980-01-01T00:00:00",
        "exclusions": [
            "credentials and .env files",
            "raw or transformed dataset media",
            "dataset source annotations except the frozen participant split",
            "model weights and derived feature caches",
            "Kaggle account metadata and simulator logs",
        ],
        "files": [
            {"path": name, "bytes": len(data), "sha256": digest(data)}
            for name, data in payloads.items()
        ],
    }
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in payloads.items():
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
        info = zipfile.ZipInfo("MANIFEST.json", date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, manifest_bytes)

    SIDECAR.write_bytes(manifest_bytes)
    print(f"wrote {ARCHIVE.relative_to(ROOT)} ({ARCHIVE.stat().st_size} bytes)")
    print(f"sha256 {digest(ARCHIVE.read_bytes())}")
    print(f"included {len(payloads)} files plus MANIFEST.json")


if __name__ == "__main__":
    main()
