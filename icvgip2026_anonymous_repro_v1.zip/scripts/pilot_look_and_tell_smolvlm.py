"""Participant-disjoint SmolVLM adapter pilot for Look and Tell.

This script supports both the original bounded connector-only feasibility pilot
and a parameter-efficient end-to-end LoRA protocol.  The latter trains the full
multimodal connector plus low-rank adapters in every vision- and language-
attention block from the same pinned base checkpoint for each matched image
condition.  Full paper claims require all six outer folds and the predeclared
uncertainty analysis.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import random
import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image
from sklearn.metrics import accuracy_score, f1_score
from transformers import AutoModelForMultimodalLM, AutoProcessor

from baseline_look_and_tell_classical_vision import (
    SEED,
    add_history,
    gaze_crop,
    load_recording,
)
from crossval_look_and_tell_gaze_location import make_shuffled_fixation_rows


MODEL_ID = "HuggingFaceTB/SmolVLM-256M-Instruct"
MODEL_REVISION = "7e3e67edbbed1bf9888184d9df282b700a323964"
CONDITIONS = ("full", "center", "gaze", "shuffled")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--derived-root", type=Path, default=Path("data/derived/look_and_tell")
    )
    parser.add_argument(
        "--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json")
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/baselines/look_and_tell_smolvlm_pilot.json"),
    )
    parser.add_argument("--fold-index", type=int, default=0)
    parser.add_argument("--train-limit", type=int, default=48)
    parser.add_argument("--eval-limit", type=int, default=24)
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--image-size", type=int, default=512)
    parser.add_argument("--conditions", nargs="+", choices=CONDITIONS, default=CONDITIONS)
    parser.add_argument(
        "--adaptation-scope",
        choices=("connector", "end_to_end_lora"),
        default="connector",
    )
    parser.add_argument("--lora-r", type=int, default=4)
    parser.add_argument("--lora-alpha", type=int, default=8)
    parser.add_argument("--lora-dropout", type=float, default=0.05)
    parser.add_argument("--allow-download", action="store_true")
    return parser.parse_args()


def load_rows(root: Path, spec: dict) -> tuple[list[dict], list[str]]:
    rows: list[dict] = []
    missing: list[str] = []
    for split in ("train", "val", "test"):
        for recording in spec["splits"][split]["recordings"]:
            try:
                rows.extend(load_recording(root, recording))
            except FileNotFoundError:
                missing.append(recording)
    for index, row in enumerate(rows):
        row["_global_index"] = index
    return rows, missing


def participant_folds(rows: list[dict]) -> list[list[str]]:
    participants = sorted({row["participant_id"] for row in rows})
    rng = np.random.default_rng(SEED)
    shuffled = np.asarray(participants)[rng.permutation(len(participants))]
    return [sorted(part.tolist()) for part in np.array_split(shuffled, 6)]


def balanced_subset(indices: list[int], rows: list[dict], limit: int, seed: int) -> list[int]:
    if limit <= 0 or limit >= len(indices):
        return list(indices)
    rng = random.Random(seed)
    groups: dict[tuple[str, str], list[int]] = defaultdict(list)
    for index in indices:
        row = rows[index]
        groups[(row.get("mention_type") or "unknown", row["reference"])].append(index)
    for values in groups.values():
        rng.shuffle(values)
    keys = sorted(groups)
    rng.shuffle(keys)
    selected: list[int] = []
    while len(selected) < limit:
        progressed = False
        for key in keys:
            if groups[key] and len(selected) < limit:
                selected.append(groups[key].pop())
                progressed = True
        if not progressed:
            break
    return selected


def prepare_history(
    rows: list[dict],
    outer_train_indices: list[int],
    outer_eval_indices: list[int],
    train_indices: list[int],
    eval_indices: list[int],
) -> tuple[list[dict], list[dict], list[str]]:
    outer_train_rows = [dict(rows[index]) for index in outer_train_indices]
    outer_eval_rows = [dict(rows[index]) for index in outer_eval_indices]
    frequencies = Counter(row["reference"] for row in outer_train_rows)
    labels = sorted(frequencies)
    add_history(outer_train_rows, labels, frequencies)
    add_history(outer_eval_rows, labels, frequencies)
    train_by_index = {row["_global_index"]: row for row in outer_train_rows}
    eval_by_index = {row["_global_index"]: row for row in outer_eval_rows}
    train_rows = [train_by_index[index] for index in train_indices]
    eval_rows = [eval_by_index[index] for index in eval_indices]
    return train_rows, eval_rows, labels


def prompt_text(row: dict, labels: list[str]) -> str:
    history = row.get("history_prediction") or "unknown"
    return (
        "Resolve the spoken reference to one canonical object label. "
        f"Speech: {row.get('surface_text') or ''!r}. "
        f"Previous predicted referent: {history!r}. "
        f"Candidate labels: {', '.join(labels)}. "
        "Return exactly one candidate label and nothing else."
    )


def messages(row: dict, labels: list[str], with_answer: bool) -> list[dict]:
    result = [
        {
            "role": "user",
            "content": [
                {"type": "image"},
                {"type": "text", "text": prompt_text(row, labels)},
            ],
        }
    ]
    if with_answer:
        result.append(
            {
                "role": "assistant",
                "content": [{"type": "text", "text": row["reference"]}],
            }
        )
    return result


def image_for_condition(
    row: dict, shuffled_row: dict, condition: str, image_size: int
) -> Image.Image:
    frame = cv2.imread(row["frame_path"], cv2.IMREAD_COLOR)
    if frame is None:
        raise FileNotFoundError(row["frame_path"])
    if condition == "full":
        output = cv2.resize(frame, (image_size, image_size), interpolation=cv2.INTER_AREA)
    else:
        source = shuffled_row if condition == "shuffled" else row
        x = None if condition == "center" else source.get("fix_x")
        y = None if condition == "center" else source.get("fix_y")
        output = gaze_crop(frame, x, y, output_size=image_size)
    return Image.fromarray(cv2.cvtColor(output, cv2.COLOR_BGR2RGB))


def load_model(
    local_only: bool,
    adaptation_scope: str,
    lora_r: int,
    lora_alpha: int,
    lora_dropout: float,
) -> tuple[object, torch.nn.Module, dict[str, int]]:
    processor = AutoProcessor.from_pretrained(
        MODEL_ID, revision=MODEL_REVISION, local_files_only=local_only
    )
    processor.image_processor.do_image_splitting = False
    model = AutoModelForMultimodalLM.from_pretrained(
        MODEL_ID,
        revision=MODEL_REVISION,
        local_files_only=local_only,
        dtype=torch.float32,
        _attn_implementation="eager",
    )
    for parameter in model.parameters():
        parameter.requires_grad = False
    if adaptation_scope == "connector":
        for parameter in model.model.connector.parameters():
            parameter.requires_grad = True
    else:
        try:
            from peft import LoraConfig, get_peft_model
        except ImportError as exc:
            raise RuntimeError(
                "end_to_end_lora requires peft; install requirements-research.txt"
            ) from exc
        config = LoraConfig(
            r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "out_proj"],
            modules_to_save=["connector"],
            bias="none",
        )
        model = get_peft_model(model, config)
        model.config.use_cache = False
        model.enable_input_require_grads()
        model.gradient_checkpointing_enable(
            gradient_checkpointing_kwargs={"use_reentrant": False}
        )
    counts = {
        "total": sum(parameter.numel() for parameter in model.parameters()),
        "trainable": sum(
            parameter.numel() for parameter in model.parameters() if parameter.requires_grad
        ),
        "vision_lora": sum(
            parameter.numel()
            for name, parameter in model.named_parameters()
            if "vision_model" in name and "lora_" in name and parameter.requires_grad
        ),
        "text_lora": sum(
            parameter.numel()
            for name, parameter in model.named_parameters()
            if "text_model" in name and "lora_" in name and parameter.requires_grad
        ),
        "connector": sum(
            parameter.numel()
            for name, parameter in model.named_parameters()
            if "connector" in name and parameter.requires_grad
        ),
    }
    return processor, model, counts


def train_one(
    model: torch.nn.Module,
    processor: object,
    row: dict,
    shuffled_row: dict,
    labels: list[str],
    condition: str,
    image_size: int,
) -> torch.Tensor:
    image = image_for_condition(row, shuffled_row, condition, image_size)
    prompt = processor.apply_chat_template(
        messages(row, labels, with_answer=False), add_generation_prompt=True
    )
    full = processor.apply_chat_template(
        messages(row, labels, with_answer=True), add_generation_prompt=False
    )
    prompt_inputs = processor(text=prompt, images=[image], return_tensors="pt")
    full_inputs = processor(text=full, images=[image], return_tensors="pt")
    target = full_inputs["input_ids"].clone()
    target[:, : prompt_inputs["input_ids"].shape[1]] = -100
    return model(**full_inputs, labels=target).loss


def label_token_sequences(processor: object, labels: list[str]) -> dict[tuple[int, ...], str]:
    sequences: dict[tuple[int, ...], str] = {}
    for label in labels:
        tokens = tuple(processor.tokenizer.encode(f" {label}", add_special_tokens=False))
        if not tokens:
            raise RuntimeError(f"Label tokenized to an empty sequence: {label!r}")
        if tokens in sequences and sequences[tokens] != label:
            raise RuntimeError(f"Two labels share a token sequence: {label!r}")
        sequences[tokens] = label
    return sequences


def constrained_prediction(
    model: torch.nn.Module,
    processor: object,
    row: dict,
    shuffled_row: dict,
    labels: list[str],
    condition: str,
    image_size: int,
) -> tuple[str, float, float]:
    image = image_for_condition(row, shuffled_row, condition, image_size)
    prompt = processor.apply_chat_template(
        messages(row, labels, with_answer=False), add_generation_prompt=True
    )
    inputs = processor(text=prompt, images=[image], return_tensors="pt")
    prompt_length = inputs["input_ids"].shape[1]
    candidates = label_token_sequences(processor, labels)
    end_token = processor.tokenizer.convert_tokens_to_ids("<end_of_utterance>")
    terminal_sequences = {tokens + (end_token,): label for tokens, label in candidates.items()}

    def allowed_tokens(_batch_id: int, input_ids: torch.Tensor) -> list[int]:
        generated = tuple(input_ids.tolist()[prompt_length:])
        matches = [sequence for sequence in terminal_sequences if sequence[: len(generated)] == generated]
        if not matches:
            return [end_token]
        return sorted({sequence[len(generated)] for sequence in matches if len(sequence) > len(generated)})

    started = time.perf_counter()
    with torch.inference_mode():
        generation = model.generate(
            **inputs,
            max_new_tokens=max(len(sequence) for sequence in terminal_sequences),
            do_sample=False,
            prefix_allowed_tokens_fn=allowed_tokens,
            eos_token_id=end_token,
            pad_token_id=end_token,
            return_dict_in_generate=True,
            output_scores=True,
        )
    elapsed = time.perf_counter() - started
    generated_tokens = tuple(generation.sequences[0, prompt_length:].tolist())
    # Scores are taken after the prefix constraint, so the product is the
    # normalized probability of the selected leaf in the candidate-label trie.
    log_probability = 0.0
    for token, scores in zip(generated_tokens, generation.scores, strict=True):
        log_probability += float(torch.log_softmax(scores[0], dim=-1)[token])
    confidence = float(np.exp(max(log_probability, -745.0)))
    new_tokens = generated_tokens
    if end_token in new_tokens:
        new_tokens = new_tokens[: new_tokens.index(end_token)]
    if new_tokens not in candidates:
        decoded = processor.decode(new_tokens, skip_special_tokens=True)
        normalized = re.sub(r"[^a-z0-9]+", " ", decoded.lower()).strip()
        by_normalized = {
            re.sub(r"[^a-z0-9]+", " ", label.lower()).strip(): label for label in labels
        }
        if normalized not in by_normalized:
            raise RuntimeError(f"Constrained decoding produced no label: {decoded!r}")
        prediction = by_normalized[normalized]
    else:
        prediction = candidates[new_tokens]
    return prediction, confidence, elapsed


def evaluate_condition(
    model: torch.nn.Module,
    processor: object,
    rows: list[dict],
    shuffled_rows: list[dict],
    labels: list[str],
    condition: str,
    image_size: int,
) -> tuple[dict, list[dict]]:
    targets: list[str] = []
    predictions: list[str] = []
    details: list[dict] = []
    inference_seconds = 0.0
    for position, row in enumerate(rows, start=1):
        index = row["_global_index"]
        prediction, confidence, elapsed = constrained_prediction(
            model,
            processor,
            row,
            shuffled_rows[index],
            labels,
            condition,
            image_size,
        )
        targets.append(row["reference"])
        predictions.append(prediction)
        inference_seconds += elapsed
        details.append(
            {
                "row_index": index,
                "participant_id": row["participant_id"],
                "recording_uid": row["recording_uid"],
                "mention_type": row.get("mention_type"),
                "target": row["reference"],
                "prediction": prediction,
                "confidence": confidence,
            }
        )
        print(
            f"{condition}: evaluated {position}/{len(rows)} "
            f"running_accuracy={accuracy_score(targets, predictions):.3f}",
            flush=True,
        )
    target_array = np.asarray(targets)
    prediction_array = np.asarray(predictions)
    coreference = np.asarray(
        [row.get("mention_type") == "pronoun/coref" for row in rows], dtype=bool
    )
    summary = {
        "n": len(rows),
        "accuracy": float(accuracy_score(target_array, prediction_array)),
        "macro_f1": float(
            f1_score(target_array, prediction_array, average="macro", zero_division=0)
        ),
        "coreference_n": int(coreference.sum()),
        "coreference_accuracy": (
            float(accuracy_score(target_array[coreference], prediction_array[coreference]))
            if coreference.any()
            else None
        ),
        "inference_seconds": inference_seconds,
    }
    return summary, details


def main() -> None:
    args = parse_args()
    if not 0 <= args.fold_index < 6:
        raise ValueError("--fold-index must be in [0, 5]")
    if args.train_limit < 1 or args.eval_limit < 1 or args.epochs < 1:
        raise ValueError("limits and epochs must be positive")
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    random.seed(SEED)

    spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows, missing = load_rows(args.derived_root, spec)
    shuffled_rows, shuffle_mapping = make_shuffled_fixation_rows(rows)
    folds = participant_folds(rows)
    held_out = folds[args.fold_index]
    outer_train = [
        index for index, row in enumerate(rows) if row["participant_id"] not in held_out
    ]
    outer_eval = [
        index for index, row in enumerate(rows) if row["participant_id"] in held_out
    ]
    train_indices = balanced_subset(outer_train, rows, args.train_limit, SEED + 11)
    eval_indices = balanced_subset(outer_eval, rows, args.eval_limit, SEED + 29)
    train_rows, eval_rows, labels = prepare_history(
        rows, outer_train, outer_eval, train_indices, eval_indices
    )
    row_digest = hashlib.sha256(
        "\n".join(
            f"{row['_global_index']}|{row['recording_uid']}|{row['frame_path']}"
            for row in train_rows + eval_rows
        ).encode("utf-8")
    ).hexdigest()
    split_digest = hashlib.sha256(args.splits.read_bytes()).hexdigest()
    shuffle_digest = hashlib.sha256(
        json.dumps(shuffle_mapping, sort_keys=True).encode("utf-8")
    ).hexdigest()

    results: dict[str, dict] = {}
    prediction_details: dict[str, list[dict]] = {}
    parameter_counts = None
    total_started = time.perf_counter()
    for condition in args.conditions:
        # Each matched condition must start from the same initialization and RNG
        # state; otherwise dropout masks can become a condition-specific confound.
        torch.manual_seed(SEED)
        np.random.seed(SEED)
        random.seed(SEED)
        print(f"loading {MODEL_ID} for {condition}", flush=True)
        processor, model, counts = load_model(
            local_only=not args.allow_download,
            adaptation_scope=args.adaptation_scope,
            lora_r=args.lora_r,
            lora_alpha=args.lora_alpha,
            lora_dropout=args.lora_dropout,
        )
        processor.image_processor.size = {"longest_edge": args.image_size}
        parameter_counts = counts
        optimizer = torch.optim.AdamW(
            (parameter for parameter in model.parameters() if parameter.requires_grad),
            lr=args.learning_rate,
        )
        model.train()
        losses: list[float] = []
        training_started = time.perf_counter()
        for epoch in range(args.epochs):
            order = list(range(len(train_rows)))
            random.Random(SEED + epoch).shuffle(order)
            for step, position in enumerate(order, start=1):
                row = train_rows[position]
                loss = train_one(
                    model,
                    processor,
                    row,
                    shuffled_rows[row["_global_index"]],
                    labels,
                    condition,
                    args.image_size,
                )
                loss.backward()
                torch.nn.utils.clip_grad_norm_(
                    (parameter for parameter in model.parameters() if parameter.requires_grad),
                    1.0,
                )
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
                losses.append(float(loss.detach()))
                if step == 1 or step % 8 == 0 or step == len(order):
                    print(
                        f"{condition}: epoch {epoch + 1}/{args.epochs} "
                        f"step {step}/{len(order)} loss={losses[-1]:.4f}",
                        flush=True,
                    )
        training_seconds = time.perf_counter() - training_started
        model.eval()
        evaluation, details = evaluate_condition(
            model,
            processor,
            eval_rows,
            shuffled_rows,
            labels,
            condition,
            args.image_size,
        )
        results[condition] = {
            "training": {
                "steps": len(losses),
                "initial_loss": losses[0],
                "final_loss": losses[-1],
                "mean_loss": float(np.mean(losses)),
                "seconds": training_seconds,
            },
            "evaluation": evaluation,
        }
        prediction_details[condition] = details
        del optimizer, model, processor

    payload = {
        "schema_version": 2,
        "status": "pilot_only_not_for_paper_claims",
        "model": {
            "id": MODEL_ID,
            "revision": MODEL_REVISION,
            "architecture": "Idefics3ForConditionalGeneration",
            "license": "Apache-2.0",
            "precision": "float32",
            "device": "cpu",
            "adaptation_scope": args.adaptation_scope,
            "parameter_counts": parameter_counts,
            "lora": (
                {
                    "rank": args.lora_r,
                    "alpha": args.lora_alpha,
                    "dropout": args.lora_dropout,
                    "target_modules": [
                        "q_proj",
                        "k_proj",
                        "v_proj",
                        "o_proj",
                        "out_proj",
                    ],
                    "modules_to_save": ["connector"],
                }
                if args.adaptation_scope == "end_to_end_lora"
                else None
            ),
        },
        "protocol": {
            "seed": SEED,
            "fold_index": args.fold_index,
            "held_out_participants": held_out,
            "outer_train_participants": sorted(
                {rows[index]["participant_id"] for index in outer_train}
            ),
            "outer_train_rows": len(outer_train),
            "outer_eval_rows": len(outer_eval),
            "sampled_train_rows": len(train_rows),
            "sampled_eval_rows": len(eval_rows),
            "epochs": args.epochs,
            "learning_rate": args.learning_rate,
            "image_size": args.image_size,
            "conditions": list(args.conditions),
            "candidate_labels": labels,
            "row_signature_sha256": row_digest,
            "split_manifest_sha256": split_digest,
            "shuffle_mapping_sha256": shuffle_digest,
            "missing_recordings": missing,
            "decoding": "greedy constrained to outer-training label vocabulary",
        },
        "environment": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "transformers": __import__("transformers").__version__,
            "platform": platform.platform(),
            "cpu_threads": torch.get_num_threads(),
            "peft": (
                __import__("peft").__version__
                if args.adaptation_scope == "end_to_end_lora"
                else None
            ),
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        },
        "results": results,
        "predictions": prediction_details,
        "total_seconds": time.perf_counter() - total_started,
        "interpretation_boundary": (
            "Feasibility evidence only. Do not replace the paper's VLM placeholders "
            "without six complete participant-disjoint folds, all matched controls, "
            "and participant-cluster uncertainty intervals."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"wrote {args.output}", flush=True)
    print(json.dumps({name: value["evaluation"] for name, value in results.items()}, indent=2))


if __name__ == "__main__":
    main()
