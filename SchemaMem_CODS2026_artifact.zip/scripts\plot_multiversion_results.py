from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SUMMARY = ROOT / "data" / "schemamem-multiversion-v1" / "summary.json"
REAL = ROOT / "data" / "schemamem-real-migrations-v1" / "summary.json"
OUT = ROOT / "paper" / "figures"

lifecycle = json.loads(SUMMARY.read_text(encoding="utf-8"))
real = json.loads(REAL.read_text(encoding="utf-8"))

fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.65), layout="constrained")

groups = ["Per transition", "Complete lifecycle"]
stale = [
    lifecycle["stale_transition_accuracy"],
    lifecycle["stale_full_lifecycle_accuracy"],
]
policy = [
    lifecycle["policy_transition_accuracy"],
    lifecycle["policy_full_lifecycle_accuracy"],
]
x = np.arange(len(groups))
width = 0.32
bars = axes[0].bar(x - width / 2, stale, width, color="#D6604D", label="Stale memory")
axes[0].bar_label(bars, labels=[f"{value:.1%}" for value in stale], padding=2, fontsize=7)
bars = axes[0].bar(x + width / 2, policy, width, color="#2166AC", label="SchemaMem")
axes[0].bar_label(bars, labels=[f"{value:.1%}" for value in policy], padding=2, fontsize=7)
axes[0].set_xticks(x, groups)
axes[0].set_ylim(0, 1.16)
axes[0].set_ylabel("Execution accuracy")
axes[0].set_title("397 three-transition lifecycles", fontsize=9)
axes[0].legend(frameon=False, fontsize=7, loc="upper left")

classes = ["Renames", "Destructive", "Non-schema"]
counts = [
    real["by_operator"]["column_rename"]["n"]
    + real["by_operator"]["table_rename"]["n"],
    real["by_operator"]["drop_add"]["n"],
    real["by_operator"]["metadata_only"]["n"]
    + real["by_operator"]["value_only"]["n"],
]
colors = ["#4393C3", "#D6604D", "#92C5DE"]
bars = axes[1].bar(np.arange(3), counts, color=colors)
axes[1].bar_label(bars, labels=[str(value) for value in counts], padding=2, fontsize=8)
axes[1].set_xticks(np.arange(3), classes, rotation=18, ha="right")
axes[1].set_ylim(0, max(counts) * 1.25)
axes[1].set_ylabel("Commit-pinned cases")
axes[1].set_title("26 cases; 7 public repositories", fontsize=9)
axes[1].text(
    0.98,
    0.94,
    "26/26 intended\ndecisions",
    transform=axes[1].transAxes,
    ha="right",
    va="top",
    fontsize=8,
    color="#2166AC",
)

for axis in axes:
    axis.grid(axis="y", color="#DDDDDD", linewidth=0.65)
    axis.spines[["top", "right"]].set_visible(False)

OUT.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT / "multiversion_results.pdf", bbox_inches="tight", facecolor="white")
fig.savefig(OUT / "multiversion_results.png", dpi=260, bbox_inches="tight", facecolor="white")
plt.close(fig)
