"""Validate the SchemaMem bibliography locally and against primary registries."""

from __future__ import annotations

import argparse
import json
import re
import unicodedata
import xml.etree.ElementTree as ET
from difflib import SequenceMatcher
from pathlib import Path
from urllib.parse import quote

import requests


ROOT = Path(__file__).resolve().parents[1]
BIB = ROOT / "paper" / "references.bib"
TEX = ROOT / "paper" / "main.tex"
DEFAULT_OUTPUT = ROOT / "results" / "schemamem" / "bibliography_audit.json"
ENTRY = re.compile(r"(?ms)^@(\w+)\{([^,]+),\s*(.*?)(?=^@|\Z)")
FIELD = re.compile(r"(?m)^\s*(\w+)\s*=\s*\{(.*)\},?\s*$")
ARXIV_NS = {"atom": "http://www.w3.org/2005/Atom"}
HEADERS = {"User-Agent": "SchemaMem-bibliography-audit/1.0"}


def parse_bib(text: str) -> dict[str, dict[str, str]]:
    entries: dict[str, dict[str, str]] = {}
    for match in ENTRY.finditer(text):
        kind, key, body = match.groups()
        if key in entries:
            raise ValueError(f"duplicate bibliography key: {key}")
        fields = {name.lower(): value for name, value in FIELD.findall(body)}
        entries[key] = {"entry_type": kind.lower(), **fields}
    return entries


def normalize_title(value: str) -> str:
    value = re.sub(r"\\[A-Za-z]+", " ", value)
    value = value.replace("{", "").replace("}", "")
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return " ".join(re.findall(r"[a-z0-9]+", value.lower()))


def title_similarity(left: str, right: str) -> float:
    return SequenceMatcher(None, normalize_title(left), normalize_title(right)).ratio()


def cited_keys(tex: str) -> set[str]:
    keys: set[str] = set()
    for group in re.findall(r"\\cite\{([^}]+)\}", tex):
        keys.update(key.strip() for key in group.split(","))
    return keys


def check_arxiv(entries: dict[str, dict[str, str]], errors: list[str], checks: list[dict]) -> None:
    expected = {row["eprint"]: (key, row["title"]) for key, row in entries.items() if "eprint" in row}
    if not expected:
        return
    response = requests.get(
        "https://export.arxiv.org/api/query",
        params={"id_list": ",".join(expected)},
        headers=HEADERS,
        timeout=30,
    )
    response.raise_for_status()
    root = ET.fromstring(response.text)
    observed: dict[str, str] = {}
    for item in root.findall("atom:entry", ARXIV_NS):
        identifier = (item.findtext("atom:id", namespaces=ARXIV_NS) or "").rstrip("/").split("/")[-1]
        identifier = re.sub(r"v\d+$", "", identifier)
        observed[identifier] = item.findtext("atom:title", namespaces=ARXIV_NS) or ""
    for identifier, (key, title) in expected.items():
        found = observed.get(identifier)
        similarity = title_similarity(title, found or "")
        passed = found is not None and similarity >= 0.82
        checks.append({"key": key, "source": "arXiv", "identifier": identifier,
                       "title_similarity": similarity, "passed": passed})
        if not passed:
            errors.append(f"arXiv metadata mismatch or missing: {key} ({identifier})")


def check_dois(entries: dict[str, dict[str, str]], errors: list[str], checks: list[dict]) -> None:
    for key, row in entries.items():
        doi = row.get("doi")
        if not doi:
            continue
        response = requests.get(
            f"https://api.crossref.org/works/{quote(doi, safe='')}",
            headers=HEADERS,
            timeout=30,
        )
        response.raise_for_status()
        message = response.json()["message"]
        registered = (message.get("title") or [""])[0]
        similarity = title_similarity(row["title"], registered)
        passed = similarity >= 0.75
        checks.append({"key": key, "source": "Crossref", "identifier": doi,
                       "title_similarity": similarity, "passed": passed})
        if not passed:
            errors.append(f"DOI title mismatch: {key} ({doi})")


def check_urls(entries: dict[str, dict[str, str]], errors: list[str], checks: list[dict]) -> None:
    for key, row in entries.items():
        url = row.get("url")
        if not url:
            continue
        response = requests.get(url, headers=HEADERS, timeout=30, allow_redirects=True, stream=True)
        passed = response.status_code < 400
        checks.append({"key": key, "source": "URL", "identifier": url,
                       "http_status": response.status_code, "passed": passed})
        response.close()
        if not passed:
            errors.append(f"source URL unavailable ({response.status_code}): {key}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--online", action="store_true", help="check arXiv, Crossref, and source URLs")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    errors: list[str] = []
    checks: list[dict] = []
    entries = parse_bib(BIB.read_text(encoding="utf-8"))
    cited = cited_keys(TEX.read_text(encoding="utf-8"))
    missing = sorted(cited - set(entries))
    unused = sorted(set(entries) - cited)
    if missing:
        errors.append(f"undefined citation keys: {missing}")
    if unused:
        errors.append(f"uncited bibliography keys: {unused}")
    for key, row in entries.items():
        absent = [name for name in ("author", "title", "year") if not row.get(name)]
        if absent:
            errors.append(f"missing required fields for {key}: {absent}")
        if not any(row.get(name) for name in ("doi", "eprint", "url")):
            errors.append(f"no verifiable locator for {key}")
    checks.append({"source": "static", "entries": len(entries), "cited": len(cited),
                   "missing": missing, "unused": unused, "passed": not errors})

    if args.online:
        try:
            check_arxiv(entries, errors, checks)
            check_dois(entries, errors, checks)
            check_urls(entries, errors, checks)
        except (requests.RequestException, ET.ParseError, KeyError, ValueError) as exc:
            errors.append(f"online verification failed: {type(exc).__name__}: {exc}")

    report = {
        "status": "passed" if not errors else "failed",
        "online": args.online,
        "entries": len(entries),
        "cited_keys": len(cited),
        "checks": checks,
        "errors": errors,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"bibliography audit: {report['status']} ({len(entries)} entries, {len(checks)} checks)")
    for error in errors:
        print(f"FAIL {error}")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
