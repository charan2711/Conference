"""Paired accuracy report for two model runs on an exact frozen target set."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from .agent_statistics import paired_report


TargetKey = tuple[str, str, int]


def target_key(row: dict) -> TargetKey:
    return row["scenario"], row["db_id"], int(row["question_id"])


def index_rows(rows: list[dict]) -> dict[tuple[TargetKey, str], dict]:
    indexed: dict[tuple[TargetKey, str], dict] = {}
    for row in rows:
        key = (target_key(row), row["condition"])
        if key in indexed:
            raise ValueError(f"duplicate run cell: {key}")
        indexed[key] = row
    return indexed


def compare_runs(
    smaller_rows: list[dict],
    larger_rows: list[dict],
    targets: list[dict],
    conditions: list[str],
) -> dict:
    """Compare models only where target, retrieved memory, and condition match."""
    expected = {target_key(row): row for row in targets}
    if len(expected) != len(targets):
        raise ValueError("target manifest contains duplicate target keys")
    smaller = index_rows(smaller_rows)
    larger = index_rows(larger_rows)

    labels = {
        "smaller": sorted({row["model_label"] for row in smaller_rows}),
        "larger": sorted({row["model_label"] for row in larger_rows}),
    }
    if any(len(value) != 1 for value in labels.values()):
        raise ValueError(f"each run must contain exactly one model label: {labels}")

    report = {
        "targets": len(expected),
        "database_clusters": len({key[1] for key in expected}),
        "models": {name: value[0] for name, value in labels.items()},
        "conditions": {},
    }
    for condition in conditions:
        pairs = []
        for key, spec in expected.items():
            cell = (key, condition)
            if cell not in smaller or cell not in larger:
                raise ValueError(f"missing matched run cell: {cell}")
            small = smaller[cell]
            large = larger[cell]
            for row_name, row in (("smaller", small), ("larger", large)):
                if int(row["memory_question_id"]) != int(spec["memory_question_id"]):
                    raise ValueError(f"{row_name} memory mismatch: {cell}")
                if bool(row["memory_affected"]) != bool(spec["memory_affected"]):
                    raise ValueError(f"{row_name} affected flag mismatch: {cell}")
            pairs.append({"smaller": small, "larger": large})

        accuracy = paired_report(pairs, "larger", "smaller")
        cost = {}
        for metric in ("model_calls", "tool_calls", "prompt_tokens", "completion_tokens"):
            cost[metric] = {
                "smaller_mean": sum(float(pair["smaller"][metric]) for pair in pairs)
                / len(pairs),
                "larger_mean": sum(float(pair["larger"][metric]) for pair in pairs)
                / len(pairs),
            }
        report["conditions"][condition] = {"accuracy": accuracy, "interaction": cost}
    return report


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--smaller-runs", type=Path, required=True)
    parser.add_argument("--larger-runs", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--conditions", nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    target_bytes = args.targets.read_bytes()
    report = compare_runs(
        read_jsonl(args.smaller_runs),
        read_jsonl(args.larger_runs),
        json.loads(target_bytes),
        args.conditions,
    )
    report["provenance"] = {
        "target_manifest": args.targets.as_posix(),
        "target_manifest_sha256": hashlib.sha256(target_bytes).hexdigest(),
        "smaller_runs": args.smaller_runs.as_posix(),
        "smaller_runs_sha256": hashlib.sha256(args.smaller_runs.read_bytes()).hexdigest(),
        "larger_runs": args.larger_runs.as_posix(),
        "larger_runs_sha256": hashlib.sha256(args.larger_runs.read_bytes()).hexdigest(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
