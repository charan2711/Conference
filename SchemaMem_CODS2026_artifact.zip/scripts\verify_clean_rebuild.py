"""Compare a clean deterministic rebuild with the frozen release JSON."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


FILES = (
    "data/schemamem-bench-v1/instances.json",
    "data/schemamem-bench-v1/migrations.json",
    "data/schemamem-bench-v1/summary.json",
    "data/schemamem-split-v1/instances.json",
    "data/schemamem-split-v1/migrations.json",
    "data/schemamem-split-v1/summary.json",
    "data/schemamem-merge-v1/instances.json",
    "data/schemamem-merge-v1/migrations.json",
    "data/schemamem-merge-v1/summary.json",
    "data/schemamem-ambiguity-v1/instances.json",
    "data/schemamem-ambiguity-v1/summary.json",
    "data/schemamem-multiversion-v1/instances.json",
    "data/schemamem-multiversion-v1/migrations.json",
    "data/schemamem-multiversion-v1/summary.json",
    "data/schemamem-real-migrations-v1/instances.json",
    "data/schemamem-real-migrations-v1/summary.json",
    "results/schemamem/baselines.json",
    "results/schemamem/baseline_instances.json",
    "results/schemamem/statistics.json",
    "results/schemamem/split_baselines.json",
    "results/schemamem/split_baseline_instances.json",
    "results/schemamem/merge_baselines.json",
    "results/schemamem/merge_baseline_instances.json",
    "results/schemamem/ambiguity.json",
    "results/schemamem/ambiguity_instances.json",
    "results/schemamem/multiversion_statistics.json",
    "results/schemamem/evoschema_audit.json",
)


def canonical_digest(path: Path) -> str:
    payload = json.loads(path.read_text(encoding="utf-8"))
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def compare_roots(reference: Path, candidate: Path) -> dict:
    checks = []
    for relative in FILES:
        left = reference / relative
        right = candidate / relative
        if not left.is_file() or not right.is_file():
            checks.append({
                "file": relative,
                "status": "missing",
                "reference_present": left.is_file(),
                "candidate_present": right.is_file(),
            })
            continue
        left_hash = canonical_digest(left)
        right_hash = canonical_digest(right)
        checks.append({
            "file": relative,
            "status": "matched" if left_hash == right_hash else "mismatch",
            "canonical_sha256": left_hash,
        })
    passed = sum(item["status"] == "matched" for item in checks)
    return {
        "status": "passed" if passed == len(checks) else "failed",
        "files_checked": len(checks),
        "files_matched": passed,
        "timing_outputs_excluded": ["results/schemamem/policy_overhead.json"],
        "checks": checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference-root", type=Path, default=Path("."))
    parser.add_argument("--candidate-root", type=Path, required=True)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/schemamem/clean_rebuild_audit.json"),
    )
    args = parser.parse_args()
    report = compare_roots(args.reference_root.resolve(), args.candidate_root.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(
        f"clean rebuild audit: {report['status']} "
        f"({report['files_matched']}/{report['files_checked']} files matched)"
    )
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
