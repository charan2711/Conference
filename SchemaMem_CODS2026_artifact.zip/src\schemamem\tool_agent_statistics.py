"""Accuracy, uncertainty, and interaction-cost reports for tool-agent runs."""

from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from .agent_statistics import paired_report


CONDITIONS = {
    "no_memory",
    "stale_memory",
    "version_filter",
    "reexplore_on_change",
    "execution_guided_memory",
    "schema_aware_memory",
    "policy_memory",
}
COSTS = (
    "model_calls",
    "tool_calls",
    "sql_executions",
    "prompt_tokens",
    "completion_tokens",
    "total_tokens",
    "model_seconds",
    "total_model_calls_with_maintenance",
    "total_tool_calls_with_maintenance",
    "total_tokens_with_maintenance",
    "total_model_seconds_with_maintenance",
)


def paired_cost(pairs: list[dict], treatment: str, control: str, metric: str) -> dict:
    usable = [row for row in pairs if treatment in row and control in row]
    delta = np.asarray(
        [row[treatment][metric] - row[control][metric] for row in usable],
        dtype=float,
    )
    if not len(delta):
        return {"n": 0, "mean_difference": None, "paired_bootstrap_95": [None, None]}
    rng = np.random.default_rng(42)
    indices = rng.integers(0, len(delta), size=(20_000, len(delta)))
    means = delta[indices].mean(axis=1)
    clusters: dict[str, list[float]] = defaultdict(list)
    for row in usable:
        cluster = row[treatment].get("cluster_id", row[treatment]["db_id"])
        clusters[cluster].append(
            float(row[treatment][metric]) - float(row[control][metric])
        )
    names = sorted(clusters)
    totals = np.asarray([sum(clusters[name]) for name in names], dtype=float)
    sizes = np.asarray([len(clusters[name]) for name in names], dtype=float)
    sampled = rng.integers(0, len(names), size=(20_000, len(names)))
    cluster_means = totals[sampled].sum(axis=1) / sizes[sampled].sum(axis=1)
    observed = abs(float(totals.sum()))
    if len(totals) <= 18:
        randomized = [
            abs(float(np.dot(np.asarray(signs, dtype=float), totals)))
            for signs in itertools.product((-1, 1), repeat=len(totals))
        ]
        signflip_p = float(
            np.mean(np.asarray(randomized) >= observed - 1e-12)
        )
    else:
        signs = rng.choice((-1.0, 1.0), size=(100_000, len(totals)))
        signflip_p = float(np.mean(np.abs(signs @ totals) >= observed - 1e-12))
    return {
        "n": len(delta),
        "mean_difference": float(delta.mean()),
        "paired_bootstrap_95": [float(x) for x in np.quantile(means, [0.025, 0.975])],
        "database_clusters": len(names),
        "cluster_bootstrap_95": [
            float(x) for x in np.quantile(cluster_means, [0.025, 0.975])
        ],
        "cluster_signflip_p": signflip_p,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--conditions", nargs="+", choices=sorted(CONDITIONS))
    args = parser.parse_args()

    grouped: dict[tuple, dict] = defaultdict(dict)
    all_rows = []
    for line in args.runs.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        row["total_tokens"] = row["prompt_tokens"] + row["completion_tokens"]
        row["total_model_calls_with_maintenance"] = (
            row["model_calls"] + row.get("maintenance_model_calls", 0)
        )
        row["total_tool_calls_with_maintenance"] = (
            row["tool_calls"] + row.get("maintenance_tool_calls", 0)
        )
        row["total_tokens_with_maintenance"] = (
            row["total_tokens"]
            + row.get("maintenance_prompt_tokens", 0)
            + row.get("maintenance_completion_tokens", 0)
        )
        row["total_model_seconds_with_maintenance"] = (
            row["model_seconds"] + row.get("maintenance_model_seconds", 0.0)
        )
        all_rows.append(row)
        grouped[(row["scenario"], row["db_id"], row["question_id"])][
            row["condition"]
        ] = row
    required = set(args.conditions or {name for row in grouped.values() for name in row})
    complete = [row for row in grouped.values() if required <= set(row)]
    complete_rows = [condition for target in complete for condition in target.values()]

    report = {
        "complete_targets": len(complete),
        "database_clusters": len(
            {row.get("cluster_id", row["db_id"]) for row in complete_rows}
        ),
        "conditions": {},
        "comparisons": {},
    }
    for condition in sorted(required):
        rows = [target[condition] for target in complete]
        report["conditions"][condition] = {
            "n": len(rows),
            "execution_accuracy": (
                sum(row["correct"] for row in rows) / len(rows) if rows else None
            ),
            "valid_sql_rate": (
                sum(row["exec_ok"] for row in rows) / len(rows) if rows else None
            ),
            "finalization_rate": (
                sum(row.get("finalized", False) for row in rows) / len(rows)
                if rows else None
            ),
            **{
                f"mean_{metric}": (
                    sum(row[metric] for row in rows) / len(rows) if rows else None
                )
                for metric in COSTS
            },
        }

    comparisons = {
        "policy_vs_stale": ("policy_memory", "stale_memory"),
        "policy_vs_no_memory": ("policy_memory", "no_memory"),
        "policy_vs_reexplore": ("policy_memory", "reexplore_on_change"),
        "oracle_vs_policy": ("schema_aware_memory", "policy_memory"),
        "reexplore_vs_stale": ("reexplore_on_change", "stale_memory"),
        "policy_vs_execution_guided": ("policy_memory", "execution_guided_memory"),
        "execution_guided_vs_stale": ("execution_guided_memory", "stale_memory"),
    }
    for subset_name, subset in {
        "all": complete,
        "memory_affected": [
            row for row in complete if row["stale_memory"]["memory_affected"]
        ],
        "memory_unaffected": [
            row for row in complete if not row["stale_memory"]["memory_affected"]
        ],
    }.items():
        report["comparisons"][subset_name] = {}
        for name, (treatment, control) in comparisons.items():
            if treatment not in required or control not in required:
                continue
            report["comparisons"][subset_name][name] = {
                "accuracy": paired_report(subset, treatment, control),
                "cost_differences": {
                    metric: paired_cost(subset, treatment, control, metric)
                    for metric in COSTS
                },
            }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
