# Can Canonical-Label Benchmarks Validate Gaze Localization?

Research workspace for a feasibility-first ICVGIP 2026 submission on selective
reference resolution for wearable assistants, motivated by safe smart-home
control.

## Current status

- The primary real-world source is the late-2025 Look and Tell/KTH-ARIA
  Referential release: real Aria gaze, ego video, word-timed speech, and
  references. The raw-annotation audit found 2,596 currently downloadable rows
  in 120 files, including 595 pronoun/coreference cases.
- The repository has a paper/release mismatch (paper: 25 participants and 2,707
  mentions; current manifest: 26 IDs, with ten absent/empty reference files).
  Experiments use only hashed, non-empty fetched files and disclose this.
- The matched-media benchmark uses 1,644 train, 380 validation, and 306 locked
  test rows; three upstream videos return HTTP 404 and are disclosed.
- Text+history+fixation-crop fusion reaches 81.05% validation and 83.66% test
  accuracy. A post-test center-crop audit shows the gaze-location advantage does
  not generalize robustly, constraining the claim to visual context rather than
  gaze centering.
- Six-fold out-of-fold evaluation over all 24 participants confirms this:
  text+history is 80.64%, center-crop fusion 82.15%, and gaze-crop fusion 81.85%;
  gaze minus center is -0.30 points (95% CI -1.08 to +0.43).
- A matched full-frame control reaches 82.88%, +2.23 points over text+history
  (95% CI +1.08 to +3.51). On 587 coreference rows it reaches 55.88% and
  exceeds the center crop by +3.24 points (95% CI +0.90 to +5.52), showing that
  broad context helps even though gaze localization does not.
- The out-of-fold risk--coverage audit exposes the hard case: a retrospective
  5%-error envelope retains 93.63% of explicit mentions but only 4.09% of
  pronoun/coreference mentions. It is not presented as a deployment threshold.
- A within-recording shuffled-fixation control reaches 81.76%; true gaze minus
  shuffled fixation is +0.09 points (95% CI -0.79 to +0.89), and exactly zero
  on rows with an available fixation.
- Removing normalized fixation x/y, temporal-link, and availability metadata
  leaves gaze at 81.76% and shuffled at 81.80% (difference -0.04 points; 95% CI
  -0.91 to +0.78), so the null is not driven by explicit metadata channels.
- A nested five-inner-fold threshold-transfer audit retains 91.11% of explicit
  mentions at 4.09% error but only 31.18% of coreference at 20.22% error; the
  outer-fold overall error is 5.76%, so this is an honest transfer diagnostic,
  not a guaranteed safety bound.
- A post-hoc 2025 SigLIP 2 audit reaches 82.15% for center crops and 82.36% for
  gaze crops, but the +0.21-point difference remains inconclusive (95% CI
  -0.69 to +1.08). It confirms appearance value without a robust gaze-location
  advantage.
- A completed six-fold parameter-efficient SmolVLM-256M audit evaluates 576
  unique held-out rows across all 24 participants. True-gaze and shuffled-gaze
  models reach 57.47% and 57.29%; the +0.17-point paired difference has a 95%
  participant-bootstrap interval of -1.98 to +2.41. The audit is compute-bounded
  and does not replace the stronger text baseline, but it shows that learned
  cross-modal interactions do not reverse the matched-control result.
- ALFRED contributes 794 lamp-control trajectories and 2,358 human instruction
  variants. Text target resolution reaches 76.40% on unseen scenes.
- The documented TEACh S3 archives currently return HTTP 403 and are not treated
  as available data.
- Nine private Kaggle AI2-THOR attempts are preserved. The final T4-requested
  runtime exposed no NVIDIA Vulkan ICD, so no simulator result is claimed.
- ALFRED is auxiliary because it is older and lamp-only for this task.
- HD-EPIC (CVPR 2025, gaze files updated January 2026) is an optional real-home
  transfer set; its annotation audit found 808 appliance open/close/switch
  narrations across 106 videos.

See `docs/dataset_decisions.md` for the latest-data decision record and
`docs/experiment_log.md` for measured results. Submission gates are tracked in
`docs/submission_checklist.md`; recent citations are checked in
`docs/citation_audit.md`. The copy-ready portal metadata is in
`docs/openreview_submission_fields.md`, and the mandatory independent author
review is organized in `docs/human_review_packet.md`.

The current feasibility-first project decision, refreshed against 2026
literature on July 15, is in `docs/decision_memo_2026-07-15.md`. It retains the
completed gaze-necessity study as primary, recommends ShiftCal only as a gated
backup, and downgrades the earlier anomaly-routing ideas because of recent
method collisions.

The current verified evidence-only manuscript is
`output/pdf/icvgip2026_draft_v34.pdf` (seven pages total, five main-content
pages). It reframes the contribution as a benchmark-validity audit and includes
the completed measured SmolVLM control. All submission and deterministic-
supplement checks pass.
The live OpenReview invitation gives a hard deadline of 2026-07-31 00:00 UTC
(05:30 IST); the internal upload deadline remains 2026-07-30 23:59 IST.

## Build the anonymous supplement

```powershell
.\.venv\Scripts\python.exe scripts\build_anonymous_supplement.py
```

This creates a deterministic, identity-scanned archive under
`output/supplement/`. Licensed media, credentials, account metadata, weights,
and feature caches are excluded.

## Run all submission checks

```powershell
.\.venv\Scripts\python.exe scripts\run_submission_checks.py
```

This checks manuscript claims, compiles all Python sources, audits the PDF,
rebuilds the supplement twice, and verifies each archived file against its
SHA-256 manifest.

## Reproduce the Look and Tell annotation audit

```powershell
.\.venv\Scripts\python.exe scripts\audit_look_and_tell.py
```

Output: `artifacts/audits/look_and_tell_summary.json`

## Reproduce the real-media baselines

The fixation-metadata ablation and nested threshold-transfer audit are:

```powershell
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_fixation_metadata_ablation.py
.\.venv\Scripts\python.exe scripts\nested_threshold_look_and_tell.py
```

Their JSON artifacts are included in the anonymous supplement.

After preparing licensed media locally and obtaining the ONNX Model Zoo
ResNet-50 file:

```powershell
.\.venv\Scripts\python.exe scripts\baseline_look_and_tell_classical_vision.py --evaluate val test
```

Output: `artifacts/baselines/look_and_tell_classical_vision.json`

Six-fold gaze-location audit and frozen CLIP baseline:

```powershell
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_gaze_location.py
.\.venv\Scripts\python.exe scripts\baseline_look_and_tell_clip.py
.\.venv\Scripts\python.exe scripts\baseline_look_and_tell_siglip2.py
```

Fixation-metadata ablation (same six folds, all four explicit metadata channels
removed from visual descriptors):

```powershell
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_fixation_metadata_ablation.py
```

## Reproduce the ALFRED audit

```powershell
.\.venv\Scripts\python.exe scripts\audit_alfred_state_actions.py
```

Outputs:

- `data/manifests/alfred_state_actions.jsonl`
- `artifacts/audits/alfred_state_actions_summary.json`

Command-target baseline:

```powershell
.\.venv\Scripts\python.exe scripts\baseline_alfred_toggle_text.py
```

## Cloud rendering pilot

See `notebooks/KAGGLE_AI2THOR.md` and
`scripts/capture_ai2thor_toggle_pairs.py`.
