"""Audit split isolation, causal history, cache alignment, and fold coverage."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from baseline_look_and_tell_classical_vision import add_history, load_recording
from crossval_look_and_tell_gaze_location import (
    make_shuffled_fixation_rows,
    shuffled_fixation_signature,
)
from baseline_look_and_tell_modernbert import row_signature as modernbert_signature


ROOT = Path(__file__).resolve().parents[1]
SPLITS = ROOT / "data" / "manifests" / "look_and_tell_splits.json"
CLASSICAL_CACHE = ROOT / "data" / "derived" / "look_and_tell_feature_cache.npz"
SIGLIP_CACHE = ROOT / "data" / "derived" / "look_and_tell_siglip2_embeddings.npz"
SHUFFLED_CACHE = (
    ROOT / "data" / "derived" / "look_and_tell_shuffled_fixation_cache.npz"
)
MODERNBERT_CACHE = (
    ROOT / "data" / "derived" / "look_and_tell_gte_modernbert_embeddings.npz"
)
OUTPUT = ROOT / "artifacts" / "audits" / "look_and_tell_leakage_integrity.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def load_rows(spec: dict) -> tuple[dict[str, list[dict]], dict[str, list[str]]]:
    rows_by_split: dict[str, list[dict]] = {}
    missing: dict[str, list[str]] = {}
    derived = ROOT / "data" / "derived" / "look_and_tell"
    for split in ("train", "val", "test"):
        rows_by_split[split] = []
        missing[split] = []
        for recording in spec["splits"][split]["recordings"]:
            try:
                rows_by_split[split].extend(load_recording(derived, recording))
            except FileNotFoundError:
                missing[split].append(recording)
    return rows_by_split, missing


def classical_signature(rows_by_split: dict[str, list[dict]]) -> str:
    payload = {
        split: [row["frame_path"] for row in rows]
        for split, rows in rows_by_split.items()
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


def siglip_signature(rows: list[dict]) -> str:
    payload = "\n".join(
        f"{row['recording_uid']}|{row.get('frame_path')}|{row.get('reference')}"
        for row in rows
    ).encode()
    return hashlib.sha256(payload).hexdigest()


def audit_source_isolation() -> dict[str, list[str]]:
    required = {
        "scripts/crossval_look_and_tell_gaze_location.py": [
            "text.fit_transform(row.get(\"surface_text\") or \"\" for row in train_rows)",
            "text.transform(row.get(\"surface_text\") or \"\" for row in test_rows)",
            "scaler.fit_transform(raw[train_indices])",
            "scaler.transform(raw[test_indices])",
            "history.fit_transform(",
            "history.transform(",
        ],
        "scripts/baseline_look_and_tell_siglip2.py": [
            "text.fit_transform(row.get(\"surface_text\") or \"\" for row in train_rows)",
            "text.transform(row.get(\"surface_text\") or \"\" for row in test_rows)",
            "scaler.fit_transform(raw[train_indices])",
            "scaler.transform(raw[test_indices])",
            "history.fit_transform(",
            "history.transform(",
        ],
        "scripts/baseline_look_and_tell_classical_vision.py": [
            "text.fit_transform(row.get(\"surface_text\") or \"\" for row in train_rows)",
            "scaler.fit_transform(vision_raw[\"train\"])",
            "center_scaler.fit(center_raw[\"train\"])",
            "resnet_scaler.fit(resnet_raw[\"train\"])",
            "history.fit_transform(",
        ],
        "scripts/baseline_look_and_tell_modernbert.py": [
            "text.fit_transform(",
            "text.transform(",
            "history.fit_transform(",
            "history.transform(",
            "MODEL_REVISION = \"e7f32e3c00f91d699e8c43b53106206bcc72bb22\"",
        ],
    }
    for relative, snippets in required.items():
        source = (ROOT / relative).read_text(encoding="utf-8")
        for snippet in snippets:
            require(snippet in source, f"Preprocessing-isolation marker missing: {relative}: {snippet}")
    return required


def main() -> None:
    args = parse_args()
    spec = json.loads(SPLITS.read_text(encoding="utf-8"))
    split_names = ("train", "val", "test")
    participant_sets = {
        split: set(spec["splits"][split]["participants"]) for split in split_names
    }
    recording_sets = {
        split: set(spec["splits"][split]["recordings"]) for split in split_names
    }
    for index, left in enumerate(split_names):
        for right in split_names[index + 1 :]:
            require(not participant_sets[left] & participant_sets[right], f"Participant overlap: {left}/{right}")
            require(not recording_sets[left] & recording_sets[right], f"Recording overlap: {left}/{right}")

    rows_by_split, missing = load_rows(spec)
    expected_lengths = {"train": 1644, "val": 380, "test": 306}
    require(
        {split: len(rows_by_split[split]) for split in split_names} == expected_lengths,
        "Matched-media row counts drifted",
    )

    frame_sets = {
        split: {row["frame_path"] for row in rows_by_split[split]}
        for split in split_names
    }
    for index, left in enumerate(split_names):
        for right in split_names[index + 1 :]:
            require(not frame_sets[left] & frame_sets[right], f"Frame overlap: {left}/{right}")

    recording_rows: dict[str, list[dict]] = defaultdict(list)
    for split in split_names:
        for row in rows_by_split[split]:
            require(
                row["participant_id"] in participant_sets[split],
                f"Row participant assigned to wrong split: {row['recording_uid']}",
            )
            recording_rows[row["recording_uid"]].append(row)
    for recording, rows in recording_rows.items():
        indices = [int(row["frame_index"]) for row in rows]
        require(indices == sorted(indices), f"Non-causal row order: {recording}")
        mention_ids = [row.get("mention_id") for row in rows]
        require(len(mention_ids) == len(set(mention_ids)), f"Duplicate mention ID: {recording}")

    frequencies = Counter(row["reference"] for row in rows_by_split["train"])
    labels = sorted(frequencies)
    history_rows_checked = 0
    for split in split_names:
        original = [dict(row) for row in rows_by_split[split]]
        add_history(original, labels, frequencies)
        expected_history = [row["history_prediction"] for row in original]

        target_mutated = [dict(row, reference="__MUTATED_TARGET__") for row in rows_by_split[split]]
        add_history(target_mutated, labels, frequencies)
        require(
            [row["history_prediction"] for row in target_mutated] == expected_history,
            f"History depends on current/previous ground-truth targets: {split}",
        )
        require(
            set(expected_history) <= set(labels) | {"<NONE>"},
            f"History produced a label outside the train vocabulary: {split}",
        )
        history_rows_checked += len(original)

    for recording, rows in recording_rows.items():
        full = [dict(row) for row in rows]
        add_history(full, labels, frequencies)
        for end in range(1, len(rows) + 1):
            prefix = [dict(row) for row in rows[:end]]
            add_history(prefix, labels, frequencies)
            require(
                prefix[-1]["history_prediction"] == full[end - 1]["history_prediction"],
                f"History depends on a future expression: {recording}:{end}",
            )

    expected_classical_signature = classical_signature(rows_by_split)
    with np.load(CLASSICAL_CACHE, allow_pickle=False) as cache:
        require(
            str(cache["row_signature"].item()) == expected_classical_signature,
            "Classical cache signature mismatch",
        )
        for split in split_names:
            for family in ("classical", "center_classical", "resnet"):
                require(
                    cache[f"{family}_{split}"].shape[0] == expected_lengths[split],
                    f"Classical cache row count mismatch: {family}/{split}",
                )
        classical_shape = cache["classical_train"].shape[1]

    all_rows = [row for split in split_names for row in rows_by_split[split]]
    shuffled_rows, shuffle_mapping = make_shuffled_fixation_rows(all_rows)
    expected_shuffled_signature = shuffled_fixation_signature(
        all_rows, shuffle_mapping
    )
    for original, shuffled, mapping in zip(
        all_rows, shuffled_rows, shuffle_mapping, strict=True
    ):
        has_fixation = (
            original.get("fix_x") is not None and original.get("fix_y") is not None
        )
        require(
            mapping["target_has_fixation"] == has_fixation,
            "Shuffled control availability marker mismatch",
        )
        require(
            (shuffled.get("fix_x") is not None and shuffled.get("fix_y") is not None)
            == has_fixation,
            "Shuffled control changes fixation availability",
        )
        require(
            not mapping["coordinates_changed"] or has_fixation,
            "Shuffled control changes a missing-fixation row",
        )
    with np.load(SHUFFLED_CACHE, allow_pickle=False) as cache:
        require(
            str(cache["shuffle_signature"].item()) == expected_shuffled_signature,
            "Shuffled-fixation cache signature mismatch",
        )
        require(
            cache["shuffled_raw"].shape == (2330, classical_shape),
            "Shuffled-fixation cache shape mismatch",
        )

    expected_siglip_signature = siglip_signature(all_rows)
    with np.load(SIGLIP_CACHE, allow_pickle=False) as cache:
        require(
            str(cache["row_signature"].item()) == expected_siglip_signature,
            "SigLIP 2 cache signature mismatch",
        )
        require(cache["center"].shape == (2330, 768), "SigLIP center cache shape mismatch")
        require(cache["gaze"].shape == (2330, 768), "SigLIP gaze cache shape mismatch")

    expected_modernbert_signature = modernbert_signature(all_rows)
    with np.load(MODERNBERT_CACHE, allow_pickle=False) as cache:
        require(
            str(cache["row_signature"].item()) == expected_modernbert_signature,
            "GTE-ModernBERT cache signature mismatch",
        )
        require(
            cache["embeddings"].shape == (2330, 768),
            "GTE-ModernBERT cache shape mismatch",
        )

    fold_artifacts = {}
    for name, relative in (
        ("lightweight", "artifacts/baselines/look_and_tell_gaze_location_crossval.json"),
        ("siglip2", "artifacts/baselines/look_and_tell_siglip2.json"),
        ("modernbert", "artifacts/baselines/look_and_tell_modernbert.json"),
    ):
        artifact = json.loads((ROOT / relative).read_text(encoding="utf-8"))
        held_out = [participant for fold in artifact["folds"] for participant in fold["held_out_participants"]]
        require(len(held_out) == len(set(held_out)) == 24, f"Fold participant coverage drift: {name}")
        require(sum(fold["n"] for fold in artifact["folds"]) == 2330, f"OOF row coverage drift: {name}")
        fold_artifacts[name] = {
            "folds": len(artifact["folds"]),
            "unique_held_out_participants": len(set(held_out)),
            "out_of_fold_rows": sum(fold["n"] for fold in artifact["folds"]),
        }
        if name == "lightweight":
            control = artifact["shuffled_fixation_control"]
            require(
                control["cache_signature"] == expected_shuffled_signature,
                "Shuffled-fixation artifact signature mismatch",
            )
            require(
                control["available_fixation_rows"] == 2138,
                "Shuffled-control available-row count drift",
            )
            require(
                control["nontrivial_shuffled_rows"] == 2136,
                "Shuffled-control nontrivial-row count drift",
            )

    source_markers = audit_source_isolation()
    output = {
        "status": "passed",
        "participant_split": {
            "disjoint": True,
            "counts": {split: len(participant_sets[split]) for split in split_names},
            "total": len(set().union(*participant_sets.values())),
        },
        "recording_split": {
            "disjoint": True,
            "counts": {split: len(recording_sets[split]) for split in split_names},
        },
        "matched_media_rows": expected_lengths,
        "missing_media_recordings": missing,
        "chronological_recordings_checked": len(recording_rows),
        "causal_history": {
            "rows_checked": history_rows_checked,
            "target_invariant": True,
            "prefix_future_invariant": True,
            "vocabulary_from_training_only": True,
        },
        "cache_alignment": {
            "classical_signature": expected_classical_signature,
            "siglip2_signature": expected_siglip_signature,
            "shuffled_fixation_signature": expected_shuffled_signature,
            "modernbert_signature": expected_modernbert_signature,
            "classical_shapes_match": True,
            "siglip2_shapes_match": True,
            "shuffled_fixation_shape_matches": True,
            "modernbert_shape_matches": True,
        },
        "out_of_fold_coverage": fold_artifacts,
        "preprocessing_source_markers": source_markers,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if not args.quiet:
        print(json.dumps(output, indent=2, sort_keys=True))
    else:
        print("leakage and integrity audit passed")


if __name__ == "__main__":
    main()
