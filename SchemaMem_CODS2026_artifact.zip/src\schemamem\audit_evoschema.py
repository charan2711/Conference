"""Audit invariants in EvoSchema's released rename labels."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import sqlglot
from sqlglot import exp


def literals(sql: str) -> list[str] | None:
    try:
        tree = sqlglot.parse_one(sql, read="sqlite")
        return [node.this for node in tree.find_all(exp.Literal) if node.is_string]
    except Exception:
        return None


def contains_identifier(ddl: str, name: str) -> bool:
    return bool(re.search(rf"(?<![\w]){re.escape(name)}(?![\w])", ddl, flags=re.I))


def audit(path: Path) -> dict:
    rows = json.loads(path.read_text(encoding="utf-8"))
    parsed = 0
    mutated = []
    declarations = new_missing = old_retained = 0
    unique_declarations, unique_new_missing, unique_old_retained = set(), set(), set()
    for row in rows:
        old_literals = literals(row["query"])
        new_literals = literals(row.get("new_gold_sql", row["query"]))
        if old_literals is not None and new_literals is not None:
            parsed += 1
            if old_literals != new_literals:
                mutated.append(
                    {
                        "db_id": row["db_id"],
                        "question": row["question"],
                        "old_literals": old_literals,
                        "new_literals": new_literals,
                    }
                )
        for table, value in row.get("new_relevant_table", {}).items():
            ddl = value.get("ddl", "") if isinstance(value, dict) else ""
            for old, new in value.get("old_new_column_mappings", {}).items():
                key = (row["db_id"], table, old, new)
                declarations += 1
                unique_declarations.add(key)
                missing = not contains_identifier(ddl, new)
                retained = contains_identifier(ddl, old)
                new_missing += missing
                old_retained += retained
                if missing:
                    unique_new_missing.add(key)
                if retained:
                    unique_old_retained.add(key)
    return {
        "file": path.name,
        "n": len(rows),
        "literal_pairs_parsed": parsed,
        "literal_mutation_count": len(mutated),
        "literal_mutation_rate": len(mutated) / parsed if parsed else None,
        "column_mapping_declarations": declarations,
        "mapped_name_missing_from_new_ddl": new_missing,
        "old_name_retained_in_new_ddl": old_retained,
        "unique_column_mappings": len(unique_declarations),
        "unique_mapped_name_missing_from_new_ddl": len(unique_new_missing),
        "unique_old_name_retained_in_new_ddl": len(unique_old_retained),
        "unique_missing_examples": [list(item) for item in sorted(unique_new_missing)[:10]],
        "literal_mutation_examples": mutated[:10],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path("baselines/EvoSchema/eval_benchmark"))
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/evoschema_audit.json"))
    args = parser.parse_args()
    report = {
        "rename_columns": audit(args.data / "rename_columns_bird_dev.json"),
        "rename_tables": audit(args.data / "rename_tables_bird_dev.json"),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
