"""Executable table-split migration pilot for SchemaMem-Bench."""

from __future__ import annotations

import argparse
import json
import shutil
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path

import sqlglot
from sqlglot import exp

from .build_benchmark import execute, refs, result_equivalent, sqlite_schema


def quote(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def choose_split(
    path: Path, records: list[dict], schema: dict[str, set[str]], target: float
) -> dict | None:
    parsed = []
    for record in records:
        try:
            parsed.append(refs(record["SQL"], schema))
        except Exception:
            parsed.append((set(), set()))
    table_use = Counter(table for tables, _ in parsed for table in tables)
    with sqlite3.connect(path) as conn:
        candidates = []
        for table, columns in schema.items():
            info = list(conn.execute(f"PRAGMA table_info({quote(table)})"))
            primary = [row[1] for row in info if row[5]]
            if primary and len(columns) >= 6 and table_use[table] >= 5:
                candidates.append((table_use[table], table, primary, [row[1] for row in info]))
    if not candidates:
        return None
    _, table, primary, ordered_columns = max(candidates)
    movable = [column for column in ordered_columns if column not in primary]
    coverage = {
        column: {
            i for i, (_, columns) in enumerate(parsed) if (table, column) in columns
        }
        for column in movable
    }
    desired = max(1, round(target * len(records)))
    selected, covered = [], set()
    while len(covered) < desired:
        remaining = [column for column in movable if column not in selected]
        if not remaining:
            break
        best = max(remaining, key=lambda column: len((covered | coverage[column]) - covered))
        if not (coverage[best] - covered):
            break
        selected.append(best)
        covered |= coverage[best]
    if not selected:
        return None
    details = f"{table}_details"
    if details.casefold() in {name.casefold() for name in schema}:
        details += "_v2"
    return {
        "table": table,
        "details_table": details,
        "primary_key": primary,
        "moved_columns": selected,
        "kept_columns": [column for column in ordered_columns if column not in selected],
    }


def apply_split(original: Path, migrated: Path, spec: dict) -> None:
    migrated.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, migrated)
    table, details = spec["table"], spec["details_table"]
    moved = spec["primary_key"] + spec["moved_columns"]
    kept = spec["kept_columns"]
    temp = f"__schemamem_{table}"
    with sqlite3.connect(migrated) as conn:
        conn.execute("PRAGMA foreign_keys=OFF")
        conn.execute(
            f"CREATE TABLE {quote(details)} AS SELECT "
            + ", ".join(map(quote, moved))
            + f" FROM {quote(table)}"
        )
        conn.execute(
            f"CREATE TABLE {quote(temp)} AS SELECT "
            + ", ".join(map(quote, kept))
            + f" FROM {quote(table)}"
        )
        conn.execute(f"DROP TABLE {quote(table)}")
        conn.execute(f"ALTER TABLE {quote(temp)} RENAME TO {quote(table)}")
        keys = ", ".join(map(quote, spec["primary_key"]))
        conn.execute(
            f"CREATE INDEX {quote('__idx_' + details)} ON {quote(details)} ({keys})"
        )
        conn.execute(f"CREATE INDEX {quote('__idx_' + table)} ON {quote(table)} ({keys})")


def rewrite_split(sql: str, schema: dict[str, set[str]], spec: dict) -> tuple[str, bool]:
    tree = sqlglot.parse_one(sql, read="sqlite")
    if len(list(tree.find_all(exp.Select))) != 1:
        raise ValueError("nested query excluded from split pilot")
    target_nodes = [table for table in tree.find_all(exp.Table) if table.name == spec["table"]]
    if len(target_nodes) != 1:
        return tree.sql(dialect="sqlite"), False
    if any(isinstance(node, exp.Star) for node in tree.find_all(exp.Star)):
        raise ValueError("star projection excluded from split pilot")
    table_node = target_nodes[0]
    alias = table_node.alias_or_name
    moved = {name.casefold() for name in spec["moved_columns"]}
    kept_nonkey = {
        name.casefold()
        for name in set(spec["kept_columns"]) - set(spec["primary_key"])
    }
    moved_nodes, kept_nodes = [], []
    used_tables = {table.name for table in tree.find_all(exp.Table)}
    alias_map = {table.alias_or_name.casefold(): table.name for table in tree.find_all(exp.Table)}
    for column in tree.find_all(exp.Column):
        owner = alias_map.get(column.table.casefold()) if column.table else None
        if not column.table:
            owners = [
                name
                for name in used_tables
                if column.name.casefold()
                in {candidate.casefold() for candidate in schema.get(name, set())}
            ]
            owner = owners[0] if len(owners) == 1 else None
        if owner == spec["table"] and column.name.casefold() in moved:
            moved_nodes.append(column)
        elif owner == spec["table"] and column.name.casefold() in kept_nonkey:
            kept_nodes.append(column)
    if not moved_nodes:
        return tree.sql(dialect="sqlite"), False
    details = spec["details_table"]
    if not kept_nodes:
        table_node.set("this", exp.to_identifier(details))
        return tree.sql(dialect="sqlite"), True

    detail_alias = "__sm_details"
    for column in moved_nodes:
        column.set("table", exp.to_identifier(detail_alias))
    conditions = [f"{alias}.{key} = {detail_alias}.{key}" for key in spec["primary_key"]]
    # The new relation must be introduced before any pre-existing join whose ON
    # expression was rebound to it. Appending the join can create a forward
    # reference and, on SQLite, a disastrous intermediate product.
    scaffold = sqlglot.parse_one(
        f"SELECT 1 FROM __base INNER JOIN {details} AS {detail_alias} "
        f"ON {' AND '.join(conditions)}",
        read="sqlite",
    )
    detail_join = scaffold.args["joins"][0]
    select = tree if isinstance(tree, exp.Select) else tree.find(exp.Select)
    select.set("joins", [detail_join, *select.args.get("joins", [])])
    return tree.sql(dialect="sqlite"), True


def main() -> None:
    parser = argparse.ArgumentParser()
    root = Path("data/bird-mini-dev/package/minidev/MINIDEV")
    parser.add_argument("--questions", type=Path, default=root / "mini_dev_sqlite.json")
    parser.add_argument("--databases", type=Path, default=root / "dev_databases")
    parser.add_argument("--output", type=Path, default=Path("data/schemamem-split-v1"))
    parser.add_argument("--target-coverage", type=float, default=0.5)
    args = parser.parse_args()
    records = json.loads(args.questions.read_text(encoding="utf-8"))
    by_db: dict[str, list[dict]] = defaultdict(list)
    for record in records:
        by_db[record["db_id"]].append(record)
    output, specs = [], {}
    for db_id, group in sorted(by_db.items()):
        original = args.databases / db_id / f"{db_id}.sqlite"
        schema = sqlite_schema(original)
        spec = choose_split(original, group, schema, args.target_coverage)
        if not spec:
            continue
        specs[db_id] = spec
        migrated = args.output / "databases" / db_id / f"{db_id}.sqlite"
        apply_split(original, migrated, spec)
        for record in group:
            try:
                new_sql, affected = rewrite_split(record["SQL"], schema, spec)
                old_ok, old_result = execute(original, record["SQL"], timeout_seconds=10)
                new_ok, new_result = execute(migrated, new_sql, timeout_seconds=10)
                equivalent = old_ok and new_ok and result_equivalent(
                    old_result, new_result, record["SQL"]
                )
            except Exception as error:
                new_sql, affected, old_ok, new_ok, equivalent = "", False, False, False, False
                old_result, new_result = None, f"{type(error).__name__}: {error}"
            output.append(
                {
                    **record,
                    "scenario": "table_split",
                    "old_sql": record["SQL"],
                    "new_sql": new_sql,
                    "affected": affected,
                    "old_exec_ok": old_ok,
                    "new_exec_ok": new_ok,
                    "execution_equivalent": equivalent,
                    "new_error": None if new_ok else new_result,
                }
            )
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "instances.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    (args.output / "migrations.json").write_text(json.dumps(specs, indent=2), encoding="utf-8")
    valid = [row for row in output if row["execution_equivalent"]]
    summary = {
        "databases": len(specs),
        "instances": len(output),
        "validated": len(valid),
        "equivalence_rate": len(valid) / len(output) if output else 0,
        "affected_validated": sum(row["affected"] for row in valid),
        "affected_rate_validated": (
            sum(row["affected"] for row in valid) / len(valid) if valid else 0
        ),
    }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
