"""Paired uncertainty estimates for the downstream memory experiment."""

from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import binomtest


def bootstrap_delta(
    left: np.ndarray, right: np.ndarray, *, seed: int = 42, draws: int = 20_000
) -> tuple[float, float]:
    """Return a percentile 95% CI for mean(left - right), paired by target."""
    if not len(left):
        return (float("nan"), float("nan"))
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(left), size=(draws, len(left)))
    deltas = (left[indices] - right[indices]).mean(axis=1)
    return tuple(float(x) for x in np.quantile(deltas, [0.025, 0.975]))


def cluster_bootstrap_delta(
    pairs: list[dict], treatment: str, control: str, *, seed: int = 42, draws: int = 20_000
) -> tuple[float, float, int]:
    """Bootstrap whole databases to preserve within-database dependence."""
    usable = [row for row in pairs if treatment in row and control in row]
    clusters: dict[str, list[float]] = defaultdict(list)
    for row in usable:
        cluster = row[treatment].get("cluster_id", row[treatment]["db_id"])
        clusters[cluster].append(
            float(row[treatment]["correct"]) - float(row[control]["correct"])
        )
    names = sorted(clusters)
    if not names:
        return (float("nan"), float("nan"), 0)
    rng = np.random.default_rng(seed)
    totals = np.asarray([sum(clusters[name]) for name in names], dtype=float)
    sizes = np.asarray([len(clusters[name]) for name in names], dtype=float)
    sampled = rng.integers(0, len(names), size=(draws, len(names)))
    estimates = totals[sampled].sum(axis=1) / sizes[sampled].sum(axis=1)
    low, high = (float(x) for x in np.quantile(estimates, [0.025, 0.975]))
    return low, high, len(names)


def cluster_signflip_p(pairs: list[dict], treatment: str, control: str) -> float:
    """Two-sided database-cluster randomization test for a paired mean delta."""
    usable = [row for row in pairs if treatment in row and control in row]
    clusters: dict[str, float] = defaultdict(float)
    for row in usable:
        cluster = row[treatment].get("cluster_id", row[treatment]["db_id"])
        clusters[cluster] += (
            float(row[treatment]["correct"]) - float(row[control]["correct"])
        )
    totals = np.asarray(list(clusters.values()), dtype=float)
    if not len(totals) or np.allclose(totals, 0):
        return 1.0
    observed = abs(float(totals.sum()))
    if len(totals) <= 18:
        values = [
            abs(float(np.dot(np.asarray(signs, dtype=float), totals)))
            for signs in itertools.product((-1, 1), repeat=len(totals))
        ]
        return float(np.mean(np.asarray(values) >= observed - 1e-12))
    rng = np.random.default_rng(42)
    signs = rng.choice((-1.0, 1.0), size=(100_000, len(totals)))
    return float(np.mean(np.abs(signs @ totals) >= observed - 1e-12))


def paired_report(pairs: list[dict], treatment: str, control: str) -> dict:
    usable = [row for row in pairs if treatment in row and control in row]
    left = np.asarray([row[treatment]["correct"] for row in usable], dtype=float)
    right = np.asarray([row[control]["correct"] for row in usable], dtype=float)
    improved = int(np.sum((left == 1) & (right == 0)))
    degraded = int(np.sum((left == 0) & (right == 1)))
    discordant = improved + degraded
    p_value = (
        float(binomtest(min(improved, degraded), discordant, 0.5).pvalue)
        if discordant
        else 1.0
    )
    low, high = bootstrap_delta(left, right)
    cluster_low, cluster_high, cluster_count = cluster_bootstrap_delta(
        usable, treatment, control
    )
    return {
        "n": len(usable),
        "treatment_accuracy": float(left.mean()) if len(left) else None,
        "control_accuracy": float(right.mean()) if len(right) else None,
        "paired_difference": float((left - right).mean()) if len(left) else None,
        "paired_bootstrap_95": [low, high],
        "database_clusters": cluster_count,
        "cluster_bootstrap_95": [cluster_low, cluster_high],
        "cluster_signflip_p": cluster_signflip_p(usable, treatment, control),
        "improved": improved,
        "degraded": degraded,
        "exact_mcnemar_p": p_value,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--runs", type=Path, default=Path("results/schemamem/agent_runs.jsonl")
    )
    parser.add_argument(
        "--output", type=Path, default=Path("results/schemamem/agent_statistics.json")
    )
    parser.add_argument(
        "--targets", type=Path, help="optional frozen target manifest used to filter runs"
    )
    args = parser.parse_args()
    allowed = None
    if args.targets:
        specs = json.loads(args.targets.read_text(encoding="utf-8"))
        allowed = {
            (row["scenario"], row["db_id"], row["question_id"]) for row in specs
        }
    grouped: dict[tuple, dict] = defaultdict(dict)
    for line in args.runs.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        key = (row["scenario"], row["db_id"], row["question_id"])
        if allowed is not None and key not in allowed:
            continue
        grouped[key][row["condition"]] = row
    pairs = list(grouped.values())
    complete = [
        row
        for row in pairs
        if {"no_memory", "stale_memory", "version_filter", "schema_aware_memory"}
        <= set(row)
    ]
    comparisons = {}
    for subset_name, subset in {
        "all": complete,
        "memory_affected": [
            row for row in complete if row["stale_memory"]["memory_affected"]
        ],
        "memory_unaffected": [
            row for row in complete if not row["stale_memory"]["memory_affected"]
        ],
    }.items():
        subset_report = {
            "schema_aware_vs_stale": paired_report(
                subset, "schema_aware_memory", "stale_memory"
            ),
            "schema_aware_vs_no_memory": paired_report(
                subset, "schema_aware_memory", "no_memory"
            ),
            "version_filter_vs_stale": paired_report(
                subset, "version_filter", "stale_memory"
            ),
            "policy_vs_stale": paired_report(
                subset, "policy_memory", "stale_memory"
            ),
            "policy_vs_no_memory": paired_report(
                subset, "policy_memory", "no_memory"
            ),
        }
        if any("reexplore_on_change" in row for row in subset):
            subset_report["reexplore_vs_stale"] = paired_report(
                subset, "reexplore_on_change", "stale_memory"
            )
            subset_report["policy_vs_reexplore"] = paired_report(
                subset, "policy_memory", "reexplore_on_change"
            )
        comparisons[subset_name] = subset_report
    report = {"complete_targets": len(complete), "comparisons": comparisons}
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
