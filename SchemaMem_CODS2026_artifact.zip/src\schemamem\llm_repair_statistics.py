"""Paired exact tests for schema-only versus manifest-guided LLM repair."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

from scipy.stats import binomtest


def comparison(pairs: list[dict]) -> dict:
    complete = [row for row in pairs if {"schema_only", "explicit_manifest"} <= set(row)]
    improved = sum(
        row["explicit_manifest"]["correct"] and not row["schema_only"]["correct"]
        for row in complete
    )
    degraded = sum(
        row["schema_only"]["correct"] and not row["explicit_manifest"]["correct"]
        for row in complete
    )
    discordant = improved + degraded
    return {
        "n": len(complete),
        "schema_only_correct": sum(row["schema_only"]["correct"] for row in complete),
        "manifest_correct": sum(row["explicit_manifest"]["correct"] for row in complete),
        "improved": improved,
        "degraded": degraded,
        "exact_mcnemar_p": (
            float(binomtest(min(improved, degraded), discordant, 0.5).pvalue)
            if discordant
            else 1.0
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("runs", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    grouped: dict[tuple, dict] = defaultdict(dict)
    for line in args.runs.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        grouped[(row["scenario"], row["question_id"])][row["condition"]] = row
    pairs = list(grouped.values())
    report = {
        "all": comparison(pairs),
        "by_scenario": {
            scenario: comparison(
                [row for row in pairs if row["schema_only"]["scenario"] == scenario]
            )
            for scenario in sorted(
                {row["schema_only"]["scenario"] for row in pairs if "schema_only" in row}
            )
        },
    }
    output = args.output or args.runs.with_suffix(".statistics.json")
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
