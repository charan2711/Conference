"""Download the raw Look and Tell annotations without the 54.6 GB media.

The source dataset is CC BY-NC-ND 4.0. This downloader preserves the upstream
directory layout and bytes and writes a separate local provenance manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from urllib.parse import quote

import requests


REPOSITORY = "annadeichler/KTH-ARIA-referential"
REVISION = "main"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("data/raw/look_and_tell"))
    parser.add_argument("--participant-count", type=int, default=25)
    parser.add_argument("--recordings-per-participant", type=int, default=5)
    parser.add_argument("--include-gaze", action="store_true")
    return parser.parse_args()


def source_url(path: str) -> str:
    encoded_path = "/".join(quote(part) for part in path.split("/"))
    return f"https://huggingface.co/datasets/{REPOSITORY}/resolve/{REVISION}/{encoded_path}"


def download(session: requests.Session, path: str, output_root: Path) -> dict:
    destination = output_root / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    response = session.get(source_url(path), timeout=120)
    if response.status_code == 404:
        return {"path": path, "status": "missing"}
    response.raise_for_status()
    destination.write_bytes(response.content)
    return {
        "path": path,
        "status": "downloaded",
        "bytes": len(response.content),
        "sha256": hashlib.sha256(response.content).hexdigest(),
        "source_url": source_url(path),
    }


def main() -> None:
    args = parse_args()
    paths = [
        "README.md",
        "data/manifests/metadata.csv",
        "data/manifests/recipes.json",
        "data/manifests/recipes_ext.json",
    ]
    for participant in range(1, args.participant_count + 1):
        for recording in range(1, args.recordings_per_participant + 1):
            prefix = f"data/par_{participant:02d}"
            paths.extend(
                [
                    f"{prefix}/annotations/v1/rec_{recording:02d}/references.csv",
                    f"{prefix}/annotations/v1/rec_{recording:02d}/whisperx_transcription.tsv",
                ]
            )
            if args.include_gaze:
                paths.append(f"{prefix}/raw/rec_{recording:02d}/ego_gaze.csv")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    records = [download(session, path, args.output_dir) for path in paths]
    downloaded = [record for record in records if record["status"] == "downloaded"]
    summary = {
        "repository": REPOSITORY,
        "revision": REVISION,
        "license": "CC BY-NC-ND 4.0",
        "requested_files": len(records),
        "downloaded_files": len(downloaded),
        "missing_files": [record["path"] for record in records if record["status"] == "missing"],
        "downloaded_bytes": sum(record["bytes"] for record in downloaded),
        "files": records,
    }
    (args.output_dir / "provenance.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in summary.items() if key != "files"},
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
