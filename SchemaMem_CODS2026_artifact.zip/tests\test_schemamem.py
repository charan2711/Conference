import sqlite3
import warnings
import zipfile

from schemamem.build_benchmark import execute as benchmark_execute
from schemamem.build_benchmark import result_equivalent, rewrite_sql
from schemamem.build_drspider_benchmark import pure_column_rename_map
from schemamem.component_ablation import legacy_flat_valid, validator_for
from schemamem.agent_statistics import cluster_bootstrap_delta, cluster_signflip_p
from schemamem.memory_policy import _valid, decide_merge, decide_rename, decide_split
from schemamem.freeze_agent_targets import balanced_sample
from schemamem.split_benchmark import rewrite_split
from schemamem.tool_agent_experiment import (
    execution_guided_repair,
    parse_action,
    read_only_execute,
    schema_text,
)
from schemamem.multiversion_benchmark import adjusted_column_map
from schemamem.model_control_statistics import compare_runs
from scripts.verify_anonymity import check_payload, zip_payloads
from scripts.verify_artifact_manifest import verify_zip
from scripts.verify_submission_pdf import audit_pdf


def test_table_rename_does_not_modify_string_literal() -> None:
    schema = {"schools": {"name", "category"}}
    sql = "SELECT name FROM schools WHERE category = 'schools'"
    rewritten, changed = rewrite_sql(sql, schema, {}, {"schools": "institutions"})
    assert changed
    assert "FROM institutions" in rewritten
    assert "'schools'" in rewritten


def test_scope_validator_accepts_derived_table_outputs() -> None:
    schema = {"people": {"id", "full_name"}}
    sql = (
        "SELECT person_name, rnk FROM ("
        "SELECT full_name AS person_name, "
        "RANK() OVER (ORDER BY id) AS rnk FROM people"
        ") AS ranked WHERE rnk <= 5"
    )
    assert _valid(sql, schema)


def test_frozen_flat_validator_preserves_pre_refinement_behavior() -> None:
    schema = {"people": {"id", "full_name"}}
    sql = (
        "SELECT person_name, rnk FROM ("
        "SELECT full_name AS person_name, "
        "RANK() OVER (ORDER BY id) AS rnk FROM people"
        ") AS ranked WHERE rnk <= 5"
    )
    assert not legacy_flat_valid(sql, schema)
    assert validator_for("legacy_flat") is legacy_flat_valid
    assert validator_for("current") is _valid


def test_scope_validator_rejects_missing_derived_output() -> None:
    schema = {"people": {"id", "full_name"}}
    sql = "SELECT missing FROM (SELECT full_name FROM people) AS names"
    assert not _valid(sql, schema)


def test_scope_validator_rejects_ambiguous_unqualified_column() -> None:
    schema = {"people": {"id", "name"}, "teams": {"id", "name"}}
    sql = "SELECT name FROM people JOIN teams ON people.id = teams.id"
    assert not _valid(sql, schema)


def test_execution_budget_is_instruction_based_and_fail_closed(tmp_path) -> None:
    path = tmp_path / "budget.sqlite"
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE seed(value INTEGER)")
        conn.execute("INSERT INTO seed VALUES (1)")
    ok, error = benchmark_execute(
        path,
        "WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x + 1 FROM n "
        "WHERE x < 100000000) SELECT SUM(x) FROM n",
        timeout_seconds=0.001,
    )
    assert not ok and "interrupted" in error


def test_column_rename_is_scoped_to_owning_table() -> None:
    schema = {"customers": {"id", "name"}, "orders": {"id", "name"}}
    sql = "SELECT c.name, o.name FROM customers c JOIN orders o ON c.id = o.id"
    rewritten, changed = rewrite_sql(
        sql, schema, {("customers", "name"): "customer_name"}, {}
    )
    assert changed
    assert "c.customer_name" in rewritten
    assert "o.name" in rewritten


def test_unaffected_query_is_preserved_structurally() -> None:
    schema = {"customers": {"id", "name"}}
    sql = "SELECT id FROM customers"
    rewritten, changed = rewrite_sql(
        sql, schema, {("customers", "name"): "customer_name"}, {}
    )
    assert not changed
    assert rewritten == sql


def test_table_split_adds_join_and_rebinds_moved_column() -> None:
    schema = {"customers": {"id", "name", "city"}}
    spec = {
        "table": "customers",
        "details_table": "customers_details",
        "primary_key": ["id"],
        "moved_columns": ["city"],
        "kept_columns": ["id", "name"],
    }
    sql, changed = rewrite_split("SELECT c.name, c.city FROM customers c", schema, spec)
    assert changed
    assert "JOIN customers_details AS __sm_details" in sql
    assert "__sm_details.city" in sql
    assert "c.name" in sql


def test_table_split_is_case_insensitive_and_inserts_dependency_first() -> None:
    schema = {
        "cards": {"id", "uuid", "side"},
        "rulings": {"uuid", "text"},
    }
    spec = {
        "table": "cards",
        "details_table": "cards_details",
        "primary_key": ["id"],
        "moved_columns": ["uuid"],
        "kept_columns": ["id", "side"],
    }
    sql, changed = rewrite_split(
        "SELECT c.Side, r.text FROM cards c JOIN rulings r ON c.uuid = r.uuid",
        schema,
        spec,
    )
    assert changed
    assert sql.index("JOIN cards_details") < sql.index("JOIN rulings")
    assert "c.Side" in sql
    assert "__sm_details.uuid = r.uuid" in sql


def test_result_equivalence_respects_only_declared_order() -> None:
    left = [(1,), (2,), (2,)]
    right = [(2,), (1,), (2,)]
    assert result_equivalent(left, right, "SELECT value FROM items")
    assert not result_equivalent(left, right, "SELECT value FROM items ORDER BY value")


def test_ambiguous_rename_is_withheld() -> None:
    old = {"customers": {"id", "name"}}
    current = {"customers": {"id", "full_name", "display_name"}}
    manifest = {
        "operator": "rename",
        "write_set": ["customers.name"],
        "column_candidates": {"customers.name": ["full_name", "display_name"]},
        "table_candidates": {},
    }
    decision = decide_rename("SELECT name FROM customers", old, current, manifest)
    assert decision.action == "explore"
    assert decision.sql is None


def test_unique_runtime_rename_is_scoped_and_preserves_literals() -> None:
    old = {"customers": {"id", "name"}, "orders": {"id", "name"}}
    current = {"customers": {"id", "full_name"}, "orders": {"id", "name"}}
    manifest = {
        "operator": "rename",
        "write_set": ["customers.name"],
        "column_candidates": {"customers.name": ["full_name"]},
        "table_candidates": {},
    }
    decision = decide_rename(
        "SELECT c.name, o.name FROM customers c JOIN orders o ON c.id = o.id "
        "WHERE o.name = 'name'",
        old,
        current,
        manifest,
    )
    assert decision.action == "migrate"
    assert "c.full_name" in decision.sql
    assert "o.name" in decision.sql
    assert "'name'" in decision.sql


def test_unique_runtime_table_rename_updates_unaliased_qualifier() -> None:
    old = {"customers": {"id", "name"}}
    current = {"clients": {"id", "name"}}
    manifest = {
        "operator": "rename",
        "write_set": ["customers"],
        "column_candidates": {},
        "table_candidates": {"customers": ["clients"]},
    }
    decision = decide_rename(
        "SELECT customers.name FROM customers",
        old,
        current,
        manifest,
    )
    assert decision.action == "migrate"
    assert "clients.name" in decision.sql
    assert "FROM clients" in decision.sql


def test_referenced_drop_is_invalidated() -> None:
    old = {"customers": {"id", "name"}}
    manifest = {"operator": "drop", "write_set": ["customers.name"]}
    decision = decide_rename("SELECT name FROM customers", old, {"customers": {"id"}}, manifest)
    assert decision.action == "invalidate"


def test_ambiguous_split_join_is_withheld() -> None:
    old = {"customers": {"id", "name", "city"}}
    current = {"customers": {"id", "name"}, "customers_details": {"id", "city"}}
    spec = {
        "table": "customers",
        "details_table": "customers_details",
        "primary_key": ["id"],
        "moved_columns": ["city"],
        "kept_columns": ["id", "name"],
    }
    decision = decide_split(
        "SELECT name, city FROM customers",
        old,
        current,
        spec,
        [[("id", "id")], [("name", "city")]],
    )
    assert decision.action == "explore"


def test_unique_split_join_survives_json_container_conversion() -> None:
    old = {"customers": {"id", "name", "city"}}
    current = {"customers": {"id", "name"}, "customers_details": {"id", "city"}}
    spec = {
        "table": "customers",
        "details_table": "customers_details",
        "primary_key": ["id"],
        "moved_columns": ["city"],
        "kept_columns": ["id", "name"],
    }
    decision = decide_split(
        "SELECT name, city FROM customers",
        old,
        current,
        spec,
        [[["id", "id"]]],
    )
    assert decision.action == "migrate"


def test_merge_removes_details_join_and_rebinds_columns() -> None:
    old = {
        "customers": {"id", "city"},
        "customers_details": {"id", "name"},
    }
    current = {"customers": {"id", "city", "name"}}
    spec = {
        "table": "customers", "details_table": "customers_details",
        "primary_key": ["id"], "moved_columns": ["name"],
        "kept_columns": ["id", "city"],
    }
    decision = decide_merge(
        "SELECT d.name, c.city FROM customers c "
        "JOIN customers_details d ON c.id = d.id",
        old, current, spec, [[("id", "id")]],
    )
    assert decision.action == "migrate"
    assert "customers_details" not in decision.sql
    assert "c.name" in decision.sql


def test_merge_replaces_details_only_relation() -> None:
    old = {"customers": {"id", "city"}, "customers_details": {"id", "name"}}
    current = {"customers": {"id", "city", "name"}}
    spec = {
        "table": "customers", "details_table": "customers_details",
        "primary_key": ["id"], "moved_columns": ["name"],
        "kept_columns": ["id", "city"],
    }
    decision = decide_merge(
        "SELECT d.name FROM customers_details d", old, current, spec,
        [[("id", "id")]],
    )
    assert decision.action == "migrate"
    assert "FROM customers AS d" in decision.sql


def test_ambiguous_merge_is_withheld() -> None:
    old = {"customers": {"id"}, "customers_details": {"id", "name"}}
    current = {"customers": {"id", "name"}}
    spec = {
        "table": "customers", "details_table": "customers_details",
        "primary_key": ["id"], "moved_columns": ["name"],
        "kept_columns": ["id"],
    }
    decision = decide_merge(
        "SELECT name FROM customers_details", old, current, spec,
        [[("id", "id")], [("legacy_id", "id")]],
    )
    assert decision.action == "explore"
    assert decision.reason == "merge_join_is_ambiguous"


def test_balanced_target_sample_is_seeded_and_stratified() -> None:
    targets = [
        {"db_id": "a", "question_id": 1, "memory_affected": True},
        {"db_id": "a", "question_id": 2, "memory_affected": True},
        {"db_id": "a", "question_id": 3, "memory_affected": False},
        {"db_id": "b", "question_id": 4, "memory_affected": False},
    ]
    first = balanced_sample(targets, per_db=2, seed=42)
    second = balanced_sample(targets, per_db=2, seed=42)
    assert first == second
    a_rows = [row for row in first if row["db_id"] == "a"]
    assert {row["memory_affected"] for row in a_rows} == {True, False}
    assert [row for row in first if row["db_id"] == "b"] == [targets[-1]]


def test_tool_action_parser_accepts_json_and_sql_fallback() -> None:
    assert parse_action('{"action":"inspect_schema"}') == {
        "action": "inspect_schema",
        "sql": "",
        "table": "",
    }
    assert parse_action('{"action":"inspect_schema","table":"schools"}') == {
        "action": "inspect_schema",
        "sql": "",
        "table": "schools",
    }
    assert parse_action('{"action":"execute","sql":"SELECT 1"}') == {
        "action": "execute_sql",
        "sql": "SELECT 1",
        "table": "",
    }
    assert parse_action("```sql\nSELECT 2\n```") == {
        "action": "final",
        "sql": "SELECT 2",
        "table": "",
    }


def test_tool_executor_rejects_mutation_and_formats_schema(tmp_path) -> None:
    path = tmp_path / "agent.sqlite"
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE items(id INTEGER, name TEXT)")
        conn.execute("INSERT INTO items VALUES (1, 'one')")
    assert schema_text({"items": {"name", "id"}}) == "items(id, name)"
    ok, rows = read_only_execute(path, "SELECT name FROM items")
    assert ok and rows == [("one",)]
    ok, error = read_only_execute(path, "DELETE FROM items")
    assert not ok and "read-only" in error


def test_execution_guided_memory_reuses_an_executable_program_without_model(tmp_path) -> None:
    path = tmp_path / "agent.sqlite"
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE items(id INTEGER, name TEXT)")
        conn.execute("INSERT INTO items VALUES (1, 'one')")
    repaired = execution_guided_repair(
        url="http://invalid.local",
        path=path,
        memory={"question": "name?", "old_sql": "SELECT name FROM items"},
        max_calls=2,
        max_tokens=32,
    )
    assert repaired["action"] == "reuse_on_execution_success"
    assert repaired["exec_ok"]
    assert repaired["model_calls"] == 0
    assert repaired["sql_executions"] == 1


def test_execution_guided_memory_cannot_detect_silent_semantic_staleness(tmp_path) -> None:
    path = tmp_path / "agent.sqlite"
    with sqlite3.connect(path) as conn:
        conn.execute("CREATE TABLE archived_items(id INTEGER, name TEXT)")
        conn.execute("CREATE TABLE current_items(id INTEGER, name TEXT)")
        conn.execute("INSERT INTO archived_items VALUES (1, 'obsolete')")
        conn.execute("INSERT INTO current_items VALUES (1, 'current')")
    repaired = execution_guided_repair(
        url="http://invalid.local",
        path=path,
        memory={
            "question": "current item name?",
            "old_sql": "SELECT name FROM archived_items",
        },
        max_calls=2,
        max_tokens=32,
    )
    assert repaired["action"] == "reuse_on_execution_success"
    assert repaired["prediction"] == "SELECT name FROM archived_items"
    assert repaired["model_calls"] == 0


def test_multiversion_rename_routes_moved_columns_to_details_relation() -> None:
    spec = {
        "table": "customers",
        "details_table": "customers_details",
        "primary_key": ["id"],
        "moved_columns": ["city"],
        "kept_columns": ["id", "name"],
    }
    mapping = {
        ("customers", "city"): "location",
        ("customers", "name"): "full_name",
        ("orders", "status"): "state",
    }
    assert adjusted_column_map(mapping, spec) == {
        ("customers_details", "city"): "location",
        ("customers", "name"): "full_name",
        ("orders", "status"): "state",
    }


def test_cluster_statistics_resample_whole_databases() -> None:
    pairs = []
    for db_id in ("a", "b"):
        for _ in range(2):
            pairs.append(
                {
                    "treatment": {"db_id": db_id, "correct": True},
                    "control": {"db_id": db_id, "correct": False},
                }
            )
    low, high, clusters = cluster_bootstrap_delta(
        pairs, "treatment", "control", draws=200
    )
    assert clusters == 2
    assert (low, high) == (1.0, 1.0)
    assert cluster_signflip_p(pairs, "treatment", "control") == 0.5


def test_cluster_statistics_do_not_treat_schema_variants_as_databases() -> None:
    pairs = [
        {
            "treatment": {"db_id": "base_0", "cluster_id": "base", "correct": True},
            "control": {"db_id": "base_0", "cluster_id": "base", "correct": False},
        },
        {
            "treatment": {"db_id": "base_1", "cluster_id": "base", "correct": True},
            "control": {"db_id": "base_1", "cluster_id": "base", "correct": False},
        },
    ]
    _, _, clusters = cluster_bootstrap_delta(
        pairs, "treatment", "control", draws=100
    )
    assert clusters == 1


def test_drspider_adapter_accepts_only_fixed_ordinal_column_renames(tmp_path) -> None:
    old = tmp_path / "old.sqlite"
    new = tmp_path / "new.sqlite"
    with sqlite3.connect(old) as conn:
        conn.execute("CREATE TABLE people(id INTEGER PRIMARY KEY, name TEXT)")
    with sqlite3.connect(new) as conn:
        conn.execute("CREATE TABLE people(id INTEGER PRIMARY KEY, full_name TEXT)")
    assert pure_column_rename_map(old, new) == {("people", "name"): "full_name"}


def test_drspider_rename_targets_are_scoped_by_table(tmp_path) -> None:
    old = tmp_path / "old.sqlite"
    new = tmp_path / "new.sqlite"
    with sqlite3.connect(old) as conn:
        conn.execute("CREATE TABLE people(person_id INTEGER, person_name TEXT)")
        conn.execute("CREATE TABLE teams(team_id INTEGER, team_name TEXT)")
    with sqlite3.connect(new) as conn:
        conn.execute("CREATE TABLE people(person_id INTEGER, name TEXT)")
        conn.execute("CREATE TABLE teams(team_id INTEGER, name TEXT)")
    assert pure_column_rename_map(old, new) == {
        ("people", "person_name"): "name",
        ("teams", "team_name"): "name",
    }


def test_anonymity_audit_detects_credentials_without_echoing_them() -> None:
    failures = check_payload(
        "clean.txt",
        b"api_" + b"token=" + b"abcdefghijklmnop",
        [],
    )
    assert failures == [{"path": "clean.txt", "rule": "generic_secret_assignment"}]
    assert "abcdefghijklmnop" not in str(failures)


def test_anonymity_audit_marks_unsafe_zip_member(tmp_path) -> None:
    archive_path = tmp_path / "unsafe.zip"
    with zipfile.ZipFile(archive_path, "w") as archive:
        archive.writestr("../escape.txt", "anonymous")
    payloads = list(zip_payloads(archive_path))
    assert payloads == [("../escape.txt", b"", "unsafe_archive_path")]


def test_manifest_audit_rejects_duplicate_zip_member(tmp_path) -> None:
    archive_path = tmp_path / "duplicate.zip"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with zipfile.ZipFile(archive_path, "w") as archive:
            archive.writestr("payload.txt", "first")
            archive.writestr("payload.txt", "second")
            archive.writestr("MANIFEST.sha256", "0" * 64 + "  payload.txt\n")
    _, errors = verify_zip(archive_path)
    assert "duplicate archive path: payload.txt" in errors


def test_model_control_statistics_require_exact_matched_memory() -> None:
    targets = [
        {
            "scenario": "column_rename",
            "db_id": "db",
            "question_id": 1,
            "memory_question_id": 2,
            "memory_affected": True,
        }
    ]
    common = {
        "scenario": "column_rename",
        "db_id": "db",
        "question_id": 1,
        "memory_question_id": 2,
        "memory_affected": True,
        "condition": "policy_memory",
        "model_calls": 1,
        "tool_calls": 1,
        "prompt_tokens": 10,
        "completion_tokens": 2,
    }
    smaller = [{**common, "model_label": "small", "correct": False}]
    larger = [{**common, "model_label": "large", "correct": True}]
    report = compare_runs(smaller, larger, targets, ["policy_memory"])
    accuracy = report["conditions"]["policy_memory"]["accuracy"]
    assert accuracy["n"] == 1
    assert accuracy["paired_difference"] == 1.0
    assert accuracy["improved"] == 1 and accuracy["degraded"] == 0


def test_submission_pdf_audit_rejects_author_metadata(tmp_path) -> None:
    from pypdf import PdfWriter

    path = tmp_path / "identified.pdf"
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    writer.add_metadata({"/Author": "Identified Author"})
    with path.open("wb") as stream:
        writer.write(stream)
    report = audit_pdf(path)
    assert {item["rule"] for item in report["failures"]} >= {
        "author_metadata_present",
        "blank_or_unreadable_page",
        "references_heading_missing",
    }
