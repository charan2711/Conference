"""Classical gaze-crop vision baselines for Look and Tell.

This is a deliberately lightweight, weight-free visual baseline: HSV histograms,
low-frequency DCT coefficients, and HOG are extracted from a crop centered on
the released fixation. It runs on the laptop and establishes whether image
content at the gaze location adds signal before expensive pretrained encoders.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import cv2
import numpy as np
from scipy.sparse import csr_matrix, hstack
from scipy.optimize import minimize_scalar
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler, normalize


TOKEN_RE = re.compile(r"[a-z0-9]+")
SEED = 20260713


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--derived-root", type=Path, default=Path("data/derived/look_and_tell"))
    parser.add_argument("--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json"))
    parser.add_argument(
        "--output", type=Path, default=Path("artifacts/baselines/look_and_tell_classical_vision.json")
    )
    parser.add_argument("--evaluate", nargs="+", default=["val"])
    parser.add_argument(
        "--resnet-onnx",
        type=Path,
        default=Path("third_party/onnx/resnet50-v2-7.onnx"),
    )
    parser.add_argument(
        "--feature-cache",
        type=Path,
        default=Path("data/derived/look_and_tell_feature_cache.npz"),
    )
    return parser.parse_args()


def tokens(text: str) -> set[str]:
    return set(TOKEN_RE.findall(text.lower()))


def lexical_prediction(surface: str, labels: list[str], frequencies: Counter[str]) -> str | None:
    query = tokens(surface)
    if not query:
        return None
    scored = []
    for label in labels:
        label_tokens = tokens(label)
        overlap = len(query & label_tokens)
        if overlap:
            scored.append((overlap / len(query | label_tokens), overlap, frequencies[label], label))
    return max(scored)[-1] if scored else None


def load_recording(derived_root: Path, recording_uid: str) -> list[dict]:
    participant, _, recording_number = recording_uid.partition("_rec_")
    manifest = derived_root / participant / f"rec_{recording_number}" / "manifest.jsonl"
    if not manifest.exists():
        raise FileNotFoundError(f"Missing derived manifest: {manifest}")
    rows = [json.loads(line) for line in manifest.read_text(encoding="utf-8").splitlines() if line]
    rows = [row for row in rows if (row.get("reference") or "").strip()]
    for row in rows:
        row["participant_id"] = participant
        row["recording_uid"] = recording_uid
    return rows


def gaze_crop(
    frame: np.ndarray,
    x: float | None,
    y: float | None,
    half_size: int = 192,
    output_size: int = 128,
) -> np.ndarray:
    height, width = frame.shape[:2]
    center_x = int(round(x)) if x is not None else width // 2
    center_y = int(round(y)) if y is not None else height // 2
    padded = cv2.copyMakeBorder(
        frame, half_size, half_size, half_size, half_size, cv2.BORDER_REFLECT_101
    )
    center_x += half_size
    center_y += half_size
    crop = padded[
        center_y - half_size : center_y + half_size,
        center_x - half_size : center_x + half_size,
    ]
    return cv2.resize(crop, (output_size, output_size), interpolation=cv2.INTER_AREA)


def hog_features(gray: np.ndarray, cells: int = 8, bins: int = 9) -> np.ndarray:
    """Small dependency-free unsigned-gradient histogram descriptor."""
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=1)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=1)
    magnitude, angle = cv2.cartToPolar(gx, gy, angleInDegrees=True)
    angle %= 180.0
    cell_height = gray.shape[0] // cells
    cell_width = gray.shape[1] // cells
    output = []
    for cell_y in range(cells):
        for cell_x in range(cells):
            y0, y1 = cell_y * cell_height, (cell_y + 1) * cell_height
            x0, x1 = cell_x * cell_width, (cell_x + 1) * cell_width
            histogram, _ = np.histogram(
                angle[y0:y1, x0:x1],
                bins=bins,
                range=(0.0, 180.0),
                weights=magnitude[y0:y1, x0:x1],
            )
            histogram = histogram.astype(np.float32)
            histogram /= np.linalg.norm(histogram) + 1e-6
            output.append(histogram)
    return np.concatenate(output)


def image_features(row: dict, centered: bool = False) -> np.ndarray:
    frame = cv2.imread(row["frame_path"], cv2.IMREAD_COLOR)
    if frame is None:
        raise FileNotFoundError(row["frame_path"])
    crop = gaze_crop(
        frame,
        None if centered else row.get("fix_x"),
        None if centered else row.get("fix_y"),
    )

    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    histogram = cv2.calcHist([hsv], [0, 1, 2], None, [8, 4, 4], [0, 180, 0, 256, 0, 256])
    histogram = cv2.normalize(histogram, None).reshape(-1)

    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
    dct = cv2.dct(gray)[:16, :16].reshape(-1)
    hog = hog_features(gray)
    moments = np.concatenate(
        [crop.reshape(-1, 3).mean(axis=0), crop.reshape(-1, 3).std(axis=0)]
    ) / 255.0
    height, width = frame.shape[:2]
    spatial = np.asarray(
        [
            (row.get("fix_x") or width / 2) / width,
            (row.get("fix_y") or height / 2) / height,
            float(row.get("linked_temporally", False)),
            float(row.get("fix_x") is not None and row.get("fix_y") is not None),
        ]
    )
    return np.concatenate([histogram, dct, hog, moments, spatial]).astype(np.float32)


def full_frame_features(row: dict) -> np.ndarray:
    """Apply the classical descriptor to the complete frame at matched output size.

    The descriptor dimensionality and non-image metadata match ``image_features``;
    only the visual field of view changes. This supports a controlled diagnostic of
    whether a local crop is useful relative to the complete egocentric frame.
    """
    frame = cv2.imread(row["frame_path"], cv2.IMREAD_COLOR)
    if frame is None:
        raise FileNotFoundError(row["frame_path"])
    visual = cv2.resize(frame, (128, 128), interpolation=cv2.INTER_AREA)

    hsv = cv2.cvtColor(visual, cv2.COLOR_BGR2HSV)
    histogram = cv2.calcHist(
        [hsv], [0, 1, 2], None, [8, 4, 4], [0, 180, 0, 256, 0, 256]
    )
    histogram = cv2.normalize(histogram, None).reshape(-1)

    gray = cv2.cvtColor(visual, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
    dct = cv2.dct(gray)[:16, :16].reshape(-1)
    hog = hog_features(gray)
    moments = np.concatenate(
        [visual.reshape(-1, 3).mean(axis=0), visual.reshape(-1, 3).std(axis=0)]
    ) / 255.0
    height, width = frame.shape[:2]
    spatial = np.asarray(
        [
            (row.get("fix_x") or width / 2) / width,
            (row.get("fix_y") or height / 2) / height,
            float(row.get("linked_temporally", False)),
            float(row.get("fix_x") is not None and row.get("fix_y") is not None),
        ]
    )
    return np.concatenate([histogram, dct, hog, moments, spatial]).astype(np.float32)


def resnet_features(row: dict, network: cv2.dnn.Net) -> np.ndarray:
    frame = cv2.imread(row["frame_path"], cv2.IMREAD_COLOR)
    if frame is None:
        raise FileNotFoundError(row["frame_path"])
    crop = gaze_crop(
        frame, row.get("fix_x"), row.get("fix_y"), half_size=192, output_size=256
    )
    # ONNX Model Zoo preprocessing: RGB, ImageNet mean/std, NCHW.
    crop = crop[16:240, 16:240]
    rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB).astype(np.float32)
    rgb = (rgb - np.asarray([123.675, 116.28, 103.53], dtype=np.float32)) / np.asarray(
        [58.395, 57.12, 57.375], dtype=np.float32
    )
    blob = np.transpose(rgb, (2, 0, 1))[None]
    network.setInput(blob)
    return network.forward().reshape(-1).astype(np.float32)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def add_history(rows: list[dict], labels: list[str], frequencies: Counter[str]) -> None:
    previous_by_recording: dict[str, str] = {}
    for row in rows:
        recording = row["recording_uid"]
        row["history_prediction"] = previous_by_recording.get(recording, "<NONE>")
        lexical = lexical_prediction(row.get("surface_text") or "", labels, frequencies)
        if lexical is not None:
            previous_by_recording[recording] = lexical


def ece(targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray) -> float:
    correct = (targets == predictions).astype(np.float64)
    total = 0.0
    for lower, upper in zip(np.linspace(0, 0.9, 10), np.linspace(0.1, 1.0, 10)):
        mask = (confidence > lower) & (confidence <= upper)
        if mask.any():
            total += mask.mean() * abs(correct[mask].mean() - confidence[mask].mean())
    return float(total)


def participant_ci(rows: list[dict], targets: np.ndarray, predictions: np.ndarray) -> list[float]:
    grouped: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped[row["participant_id"]].append(index)
    participants = sorted(grouped)
    rng = np.random.default_rng(SEED)
    values = []
    for _ in range(2000):
        sampled = rng.choice(participants, len(participants), replace=True)
        indices = [i for participant in sampled for i in grouped[participant]]
        values.append(accuracy_score(targets[indices], predictions[indices]))
    return [float(value) for value in np.quantile(values, [0.025, 0.975])]


def paired_participant_difference(
    rows: list[dict], targets: np.ndarray, first: np.ndarray, second: np.ndarray
) -> dict:
    grouped: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped[row["participant_id"]].append(index)
    participants = sorted(grouped)
    rng = np.random.default_rng(SEED)
    differences = []
    for _ in range(5000):
        sampled = rng.choice(participants, len(participants), replace=True)
        indices = [i for participant in sampled for i in grouped[participant]]
        differences.append(
            accuracy_score(targets[indices], first[indices])
            - accuracy_score(targets[indices], second[indices])
        )
    return {
        "difference": float(accuracy_score(targets, first) - accuracy_score(targets, second)),
        "bootstrap_95ci": [
            float(value) for value in np.quantile(differences, (0.025, 0.975))
        ],
        "probability_difference_le_zero": float(np.mean(np.asarray(differences) <= 0)),
    }


def risk_coverage(
    targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray
) -> list[dict]:
    order = np.argsort(-confidence)
    output = []
    for coverage in np.linspace(0.05, 1.0, 20):
        count = max(1, int(np.ceil(len(order) * coverage)))
        selected = order[:count]
        output.append(
            {
                "coverage": float(count / len(order)),
                "selective_error": float(
                    1.0 - accuracy_score(targets[selected], predictions[selected])
                ),
                "threshold": float(confidence[selected].min()),
            }
        )
    return output


def selective_summary(
    targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray
) -> dict:
    order = np.argsort(-confidence)
    cumulative_errors = np.cumsum(targets[order] != predictions[order])
    counts = np.arange(1, len(order) + 1)
    risks = cumulative_errors / counts
    return {
        "aurc": float(np.mean(risks)),
        "max_coverage_at_error": {
            str(limit): float(
                np.max(counts[risks <= limit]) / len(order)
                if np.any(risks <= limit)
                else 0.0
            )
            for limit in (0.01, 0.05, 0.10)
        },
    }


def softmax(scores: np.ndarray, temperature: float = 1.0) -> np.ndarray:
    scaled = scores / temperature
    scaled -= scaled.max(axis=1, keepdims=True)
    exponential = np.exp(scaled)
    return exponential / exponential.sum(axis=1, keepdims=True)


def nll(probabilities: np.ndarray, target_indices: np.ndarray) -> float:
    chosen = probabilities[np.arange(len(target_indices)), target_indices]
    return float(-np.log(np.clip(chosen, 1e-12, 1.0)).mean())


def fit_temperature(scores: np.ndarray, target_indices: np.ndarray) -> float:
    result = minimize_scalar(
        lambda log_temperature: nll(
            softmax(scores, float(np.exp(log_temperature))), target_indices
        ),
        bounds=(math.log(0.05), math.log(20.0)),
        method="bounded",
    )
    return float(np.exp(result.x))


def validation_selected_operating_point(
    val_targets: np.ndarray,
    val_predictions: np.ndarray,
    val_confidence: np.ndarray,
    test_targets: np.ndarray,
    test_predictions: np.ndarray,
    test_confidence: np.ndarray,
    maximum_validation_error: float = 0.05,
) -> dict:
    """Choose a confidence threshold on validation and apply it unchanged to test."""
    candidates = np.unique(val_confidence)[::-1]
    feasible: list[tuple[int, float, float]] = []
    for threshold in candidates:
        accepted = val_confidence >= threshold
        error = float(np.mean(val_predictions[accepted] != val_targets[accepted]))
        if error <= maximum_validation_error:
            feasible.append((int(accepted.sum()), float(threshold), error))
    if not feasible:
        raise RuntimeError("No non-empty validation operating point satisfies the error bound")
    val_count, threshold, val_error = max(feasible, key=lambda item: (item[0], -item[1]))
    test_accepted = test_confidence >= threshold
    return {
        "maximum_validation_error": maximum_validation_error,
        "calibrated_confidence_threshold": threshold,
        "validation": {
            "accepted": val_count,
            "total": int(len(val_targets)),
            "coverage": float(val_count / len(val_targets)),
            "selective_error": val_error,
        },
        "test": {
            "accepted": int(test_accepted.sum()),
            "total": int(len(test_targets)),
            "coverage": float(test_accepted.mean()),
            "selective_error": float(
                np.mean(test_predictions[test_accepted] != test_targets[test_accepted])
            ) if test_accepted.any() else None,
        },
    }


def evaluate(rows: list[dict], model: LogisticRegression, matrix) -> dict:
    targets = np.asarray([row["reference"] for row in rows])
    predictions = model.predict(matrix)
    confidence = model.predict_proba(matrix).max(axis=1)
    grouped: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped[row.get("mention_type") or "unknown"].append(index)
    summary = selective_summary(targets, predictions, confidence)
    return {
        "n": len(rows),
        "accuracy": float(accuracy_score(targets, predictions)),
        "accuracy_participant_bootstrap_95ci": participant_ci(rows, targets, predictions),
        "macro_f1": float(f1_score(targets, predictions, average="macro", zero_division=0)),
        "ece_10bin": ece(targets, predictions, confidence),
        "risk_coverage": risk_coverage(targets, predictions, confidence),
        **summary,
        "by_mention_type": {
            name: {
                "n": len(indices),
                "accuracy": float(accuracy_score(targets[indices], predictions[indices])),
            }
            for name, indices in sorted(grouped.items())
        },
    }


def new_model() -> LogisticRegression:
    return LogisticRegression(
        C=1.0,
        class_weight="balanced",
        max_iter=2000,
        random_state=SEED,
        solver="lbfgs",
    )


def main() -> None:
    args = parse_args()
    spec = json.loads(args.splits.read_text(encoding="utf-8"))
    required_splits = ["train", *args.evaluate]
    rows_by_split = {}
    missing_recordings = {}
    for split in required_splits:
        rows_by_split[split] = []
        missing_recordings[split] = []
        for recording in spec["splits"][split]["recordings"]:
            try:
                rows_by_split[split].extend(load_recording(args.derived_root, recording))
            except FileNotFoundError:
                missing_recordings[split].append(recording)
    train_rows = rows_by_split["train"]
    frequency = Counter(row["reference"] for row in train_rows)
    labels = sorted(frequency)
    for rows in rows_by_split.values():
        add_history(rows, labels, frequency)

    text = TfidfVectorizer(
        analyzer="char_wb", ngram_range=(2, 5), min_df=2, max_features=20000, sublinear_tf=True
    )
    text_train = text.fit_transform(row.get("surface_text") or "" for row in train_rows)
    text_matrices = {
        split: text.transform(row.get("surface_text") or "" for row in rows)
        for split, rows in rows_by_split.items()
    }

    row_signature = hashlib.sha256(
        json.dumps(
            {
                split: [row["frame_path"] for row in rows]
                for split, rows in rows_by_split.items()
            },
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()
    cached_arrays = {}
    if args.feature_cache.exists():
        with np.load(args.feature_cache, allow_pickle=False) as candidate:
            signature_matches = (
                "row_signature" in candidate
                and str(candidate["row_signature"].item()) == row_signature
            )
            if signature_matches:
                for split, rows in rows_by_split.items():
                    for family in ("classical", "center_classical", "resnet"):
                        key = f"{family}_{split}"
                        if key in candidate and candidate[key].shape[0] == len(rows):
                            cached_arrays[key] = candidate[key].copy()
    vision_raw = {
        split: cached_arrays.get(f"classical_{split}")
        if f"classical_{split}" in cached_arrays
        else np.vstack([image_features(row) for row in rows])
        for split, rows in rows_by_split.items()
    }
    center_raw = {
        split: cached_arrays.get(f"center_classical_{split}")
        if f"center_classical_{split}" in cached_arrays
        else np.vstack([image_features(row, centered=True) for row in rows])
        for split, rows in rows_by_split.items()
    }
    scaler = StandardScaler()
    vision_train = scaler.fit_transform(vision_raw["train"])
    vision_matrices = {
        split: normalize(csr_matrix(scaler.transform(matrix)), norm="l2")
        for split, matrix in vision_raw.items()
    }
    center_scaler = StandardScaler()
    center_scaler.fit(center_raw["train"])
    center_matrices = {
        split: normalize(csr_matrix(center_scaler.transform(matrix)), norm="l2")
        for split, matrix in center_raw.items()
    }

    resnet = cv2.dnn.readNetFromONNX(str(args.resnet_onnx))
    resnet_raw = {
        split: cached_arrays.get(f"resnet_{split}")
        if f"resnet_{split}" in cached_arrays
        else np.vstack([resnet_features(row, resnet) for row in rows])
        for split, rows in rows_by_split.items()
    }
    if any(
        f"{family}_{split}" not in cached_arrays
        for split in required_splits
        for family in ("classical", "center_classical", "resnet")
    ):
        args.feature_cache.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            args.feature_cache,
            row_signature=np.asarray(row_signature),
            **{f"classical_{split}": matrix for split, matrix in vision_raw.items()},
            **{f"center_classical_{split}": matrix for split, matrix in center_raw.items()},
            **{f"resnet_{split}": matrix for split, matrix in resnet_raw.items()},
        )
    resnet_scaler = StandardScaler()
    resnet_scaler.fit(resnet_raw["train"])
    resnet_matrices = {
        split: normalize(csr_matrix(resnet_scaler.transform(matrix)), norm="l2")
        for split, matrix in resnet_raw.items()
    }

    history = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    history_train = history.fit_transform(
        np.asarray([[row["history_prediction"]] for row in train_rows])
    )
    history_matrices = {
        split: history.transform(np.asarray([[row["history_prediction"]] for row in rows]))
        for split, rows in rows_by_split.items()
    }

    feature_sets = {
        "gaze_crop_classical": {
            split: vision_matrices[split] for split in required_splits
        },
        "center_crop_classical": {
            split: center_matrices[split] for split in required_splits
        },
        "text": {split: text_matrices[split] for split in required_splits},
        "text_plus_crop": {
            split: hstack([text_matrices[split], vision_matrices[split]], format="csr")
            for split in required_splits
        },
        "text_plus_center_crop": {
            split: hstack([text_matrices[split], center_matrices[split]], format="csr")
            for split in required_splits
        },
        "resnet50_logits": {
            split: resnet_matrices[split] for split in required_splits
        },
        "text_plus_resnet50": {
            split: hstack([text_matrices[split], resnet_matrices[split]], format="csr")
            for split in required_splits
        },
        "text_history": {
            split: hstack([text_matrices[split], history_matrices[split]], format="csr")
            for split in required_splits
        },
        "text_crop_history": {
            split: hstack(
                [text_matrices[split], vision_matrices[split], history_matrices[split]],
                format="csr",
            )
            for split in required_splits
        },
        "text_center_history": {
            split: hstack(
                [text_matrices[split], center_matrices[split], history_matrices[split]],
                format="csr",
            )
            for split in required_splits
        },
        "text_resnet50_history": {
            split: hstack(
                [text_matrices[split], resnet_matrices[split], history_matrices[split]],
                format="csr",
            )
            for split in required_splits
        },
    }
    targets = np.asarray([row["reference"] for row in train_rows])
    results = {}
    predictions_by_model = {}
    models_by_name = {}
    for name, matrices in feature_sets.items():
        model = new_model()
        model.fit(matrices["train"], targets)
        models_by_name[name] = model
        predictions_by_model[name] = {
            split: model.predict(matrices[split]) for split in args.evaluate
        }
        results[name] = {
            split: evaluate(rows_by_split[split], model, matrices[split])
            for split in args.evaluate
        }

    calibration = None
    if "val" in args.evaluate and "test" in args.evaluate:
        final_name = "text_crop_history"
        final_model = models_by_name[final_name]
        val_scores = final_model.decision_function(feature_sets[final_name]["val"])
        val_targets = np.asarray([row["reference"] for row in rows_by_split["val"]])
        class_to_index = {label: index for index, label in enumerate(final_model.classes_)}
        val_known = np.asarray([label in class_to_index for label in val_targets])
        val_indices = np.asarray([class_to_index[label] for label in val_targets[val_known]])
        temperature = fit_temperature(val_scores[val_known], val_indices)
        val_predictions = final_model.predict(feature_sets[final_name]["val"])
        test_scores = final_model.decision_function(feature_sets[final_name]["test"])
        test_targets = np.asarray([row["reference"] for row in rows_by_split["test"]])
        test_known = np.asarray([label in class_to_index for label in test_targets])
        test_indices = np.asarray([class_to_index[label] for label in test_targets[test_known]])
        test_predictions = final_model.predict(feature_sets[final_name]["test"])
        uncalibrated = softmax(test_scores)
        calibrated = softmax(test_scores, temperature)
        val_calibrated = softmax(val_scores, temperature)
        calibration = {
            "model": final_name,
            "temperature_fitted_on": "validation",
            "temperature": temperature,
            "validation_known_target_rows": int(val_known.sum()),
            "test_known_target_rows": int(test_known.sum()),
            "test_nll_before_known_targets": nll(uncalibrated[test_known], test_indices),
            "test_nll_after_known_targets": nll(calibrated[test_known], test_indices),
            "test_ece_before": ece(
                test_targets, test_predictions, uncalibrated.max(axis=1)
            ),
            "test_ece_after": ece(
                test_targets, test_predictions, calibrated.max(axis=1)
            ),
            "validation_selected_operating_point_5pct_error": (
                validation_selected_operating_point(
                    val_targets,
                    val_predictions,
                    val_calibrated.max(axis=1),
                    test_targets,
                    test_predictions,
                    calibrated.max(axis=1),
                )
            ),
        }

    paired_differences = {}
    for split in args.evaluate:
        split_targets = np.asarray([row["reference"] for row in rows_by_split[split]])
        paired_differences[split] = {
            "gaze_crop_minus_center_crop_with_text": paired_participant_difference(
                rows_by_split[split],
                split_targets,
                predictions_by_model["text_plus_crop"][split],
                predictions_by_model["text_plus_center_crop"][split],
            ),
            "gaze_crop_minus_center_crop_with_text_history": paired_participant_difference(
                rows_by_split[split],
                split_targets,
                predictions_by_model["text_crop_history"][split],
                predictions_by_model["text_center_history"][split],
            ),
            "text_plus_crop_minus_text": paired_participant_difference(
                rows_by_split[split],
                split_targets,
                predictions_by_model["text_plus_crop"][split],
                predictions_by_model["text"][split],
            ),
            "text_plus_resnet50_minus_text": paired_participant_difference(
                rows_by_split[split],
                split_targets,
                predictions_by_model["text_plus_resnet50"][split],
                predictions_by_model["text"][split],
            ),
            "text_crop_history_minus_text_history": paired_participant_difference(
                rows_by_split[split],
                split_targets,
                predictions_by_model["text_crop_history"][split],
                predictions_by_model["text_history"][split],
            ),
            "text_resnet50_history_minus_text_history": paired_participant_difference(
                rows_by_split[split],
                split_targets,
                predictions_by_model["text_resnet50_history"][split],
                predictions_by_model["text_history"][split],
            ),
        }

    output = {
        "task": "canonical target label prediction; empty targets excluded",
        "feature_scope": "Classical HOG, HSV, DCT, moments, and spatial features from fixation-centered RGB crops.",
        "resnet50_onnx": {
            "path": str(args.resnet_onnx),
            "sha256": file_sha256(args.resnet_onnx),
            "feature": "1000 pre-softmax ImageNet logits from fixation-centered crops",
        },
        "split_seed": spec["seed"],
        "model_seed": SEED,
        "evaluated_splits": args.evaluate,
        "missing_media_recordings": missing_recordings,
        "rows_by_split": {split: len(rows) for split, rows in rows_by_split.items()},
        "paired_participant_differences": paired_differences,
        "temperature_calibration": calibration,
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
