# ICVGIP 2026 submission checklist

Updated: 2026-07-29 IST

## Verified conference constraints

- [x] Paper deadline recorded as July 31, 2026 on the official conference site;
  the live OpenReview invitation gives a due time of July 31, 00:00 UTC
  (05:30 IST), with a 30-minute expiration grace that must not be relied on.
- [x] Main manuscript is at most eight pages; references may continue afterward.
- [x] PDF size limit is 20 MB.
- [x] Optional supplementary-material limit is 50 MB.
- [x] Double-blind requirements are reflected in the review-mode manuscript.
- [x] Topic is in scope: multimodal learning, HCI, assistive vision, and
  trustworthy vision systems.
- [x] The working official 2026 LaTeX ZIP was downloaded on July 22 and hashed.
  Its `acmart.cls` and bibliography style are byte-identical to the live files,
  so no class replacement is necessary.
- [x] The July 13 OpenReview form was audited from its public API. It requests
  title, author profiles, keywords, optional TL;DR, abstract, and PDF; it has no
  supplement, code/data, subject-area, or generative-AI disclosure field.
- [ ] Recheck the official page and OpenReview form immediately before
  submission because chairs can revise fields and policies.

## Research and artifact gates

- [x] Frozen participant split is stored in
  `data/manifests/look_and_tell_splits.json`.
- [x] Dataset counts and missing upstream files are recorded.
- [x] Validation and locked-test results are separated in the artifacts.
- [x] Post-test center-crop and six-fold analyses are labelled as diagnostics,
  not used to replace the frozen model.
- [x] The six-fold adapted SmolVLM audit is complete, participant-disjoint, and
  explicitly bounded as a 576-row parameter-efficient diagnostic.
- [x] Participant/task-cluster bootstrap is used for correlated observations.
- [x] Every headline paper number is checked by `scripts/verify_paper_claims.py`.
- [x] Anonymous supplement ZIP is identity/credential scanned and deterministic.
  The current OpenReview form has no supplement field, so retain it for an
  anonymous repository/rebuttal or upload only if the chairs add a field.
- [x] Restricted media, model weights, feature caches, Kaggle metadata, and
  credentials are excluded from the supplement.
- [x] Official upstream licenses and conservative redistribution decisions are
  recorded in `docs/license_and_provenance_audit.md` and enforced by
  `scripts/audit_release_redistribution.py`.
- [ ] Human authors must choose a license (or retain copyright) for the newly
  written project code before a public repository release.
- [ ] A human author must independently inspect the raw examples, code logic,
  and statistical interpretation.
- [x] Recent/task-defining entries have an internal primary-source audit in
  `docs/citation_audit.md`.
- [ ] A human author must verify every bibliography entry against the cited
  primary source.

## Final manuscript gates

- [x] No names, affiliations, acknowledgments, employer, local user path, or
  private account URL appears in the manuscript.
- [x] No result placeholders or fabricated simulator results remain.
- [x] Claims distinguish canonical reference prediction from localization,
  device execution, and post-action verification.
- [x] Latest rendered draft was visually inspected page by page.
- [x] The requesting author approved replacing the broad question title with a
  canonical-label benchmark-validity title; all coauthors must still consent.
- [ ] Authors must supply the OpenReview author list and conflict information.
- [ ] Add the paper ID if the final 2026 template or portal requires it.
- [ ] Perform a final proofread by at least two human authors.
- [x] Confirm PDF fonts, page count, file size, and supplementary ZIP size after
  verification against the official 2026 template.
- [ ] Complete any AI-assistance disclosure required by the submission form or
  the authors' institutions. Preserve human responsibility for all claims.

## Current submission blockers

The draft is not ready to upload without human review. The official template
and current submission form are verified. The main scientific limitation is
now explicit in the central claim: canonical labels do not evaluate same-class
instance selection. The study also does not demonstrate end-to-end smart-home
execution, and the adapted VLM remains compute-bounded.
