"""Frozen text/gaze fusion baselines for Look and Tell target labels.

This script deliberately uses only released reference and fixation fields. It
does not claim visual grounding; image-based baselines are evaluated separately.
Hyperparameters are fixed in source before the first run on the held-out split.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler


TOKEN_RE = re.compile(r"[a-z0-9]+")
IMAGE_SIZE = 1408.0
SEED = 20260713


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, default=Path("data/raw/look_and_tell"))
    parser.add_argument("--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json"))
    parser.add_argument(
        "--output", type=Path, default=Path("artifacts/baselines/look_and_tell_multimodal.json")
    )
    return parser.parse_args()


def tokens(text: str) -> set[str]:
    return set(TOKEN_RE.findall(text.lower()))


def lexical_prediction(surface: str, labels: list[str], frequencies: Counter[str]) -> str | None:
    query = tokens(surface)
    if not query:
        return None
    scored = []
    for label in labels:
        label_tokens = tokens(label)
        overlap = len(query & label_tokens)
        if overlap:
            scored.append((overlap / len(query | label_tokens), overlap, frequencies[label], label))
    return max(scored)[-1] if scored else None


def load_recording(raw_root: Path, recording_uid: str) -> list[dict]:
    participant, _, recording_number = recording_uid.partition("_rec_")
    path = (
        raw_root
        / "data"
        / participant
        / "annotations"
        / "v1"
        / f"rec_{recording_number}"
        / "references.csv"
    )
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = [row for row in csv.DictReader(stream) if (row.get("reference") or "").strip()]
    for row in rows:
        row["recording_uid"] = recording_uid
        row["participant_id"] = participant
    return rows


def as_float(row: dict, key: str, default: float = 0.0) -> float:
    try:
        value = float(row.get(key) or default)
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


def gaze_features(rows: list[dict]) -> np.ndarray:
    features = []
    for row in rows:
        has_gaze = bool(row.get("fix_x") and row.get("fix_y"))
        features.append(
            [
                as_float(row, "fix_x") / IMAGE_SIZE,
                as_float(row, "fix_y") / IMAGE_SIZE,
                min(as_float(row, "fix_duration_ms") / 1000.0, 10.0),
                min(as_float(row, "overlap_ms") / 1000.0, 10.0),
                np.clip(as_float(row, "delta_end_to_mention_start_ms") / 1000.0, -10.0, 10.0),
                np.clip(as_float(row, "delta_start_to_mention_start_ms") / 1000.0, -10.0, 10.0),
                as_float(row, "fix_dispersion_px") / IMAGE_SIZE,
                float(row.get("linked_temporally") == "True"),
                float(has_gaze),
            ]
        )
    return np.asarray(features, dtype=np.float64)


def add_history(rows: list[dict], labels: list[str], frequencies: Counter[str], majority: str) -> None:
    previous_by_recording: dict[str, str] = {}
    for row in rows:
        recording = row["recording_uid"]
        row["history_prediction"] = previous_by_recording.get(recording, "<NONE>")
        lexical = lexical_prediction(row.get("tsv_words") or "", labels, frequencies)
        if lexical is not None:
            previous_by_recording[recording] = lexical
        row["lexical_prediction"] = lexical or majority


def expected_calibration_error(targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray) -> float:
    correct = (targets == predictions).astype(np.float64)
    edges = np.linspace(0.0, 1.0, 11)
    ece = 0.0
    for lower, upper in zip(edges[:-1], edges[1:]):
        mask = (confidence > lower) & (confidence <= upper)
        if mask.any():
            ece += mask.mean() * abs(correct[mask].mean() - confidence[mask].mean())
    return float(ece)


def risk_coverage(targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray) -> dict:
    order = np.argsort(-confidence)
    correct = (targets[order] == predictions[order]).astype(np.float64)
    cumulative_risk = 1.0 - np.cumsum(correct) / np.arange(1, len(correct) + 1)
    coverage = np.arange(1, len(correct) + 1) / len(correct)
    points = {}
    for requested in (0.25, 0.5, 0.75, 1.0):
        index = min(len(correct) - 1, max(0, math.ceil(requested * len(correct)) - 1))
        points[f"{int(requested * 100)}pct"] = {
            "coverage": float(coverage[index]),
            "risk": float(cumulative_risk[index]),
        }
    return {"aurc": float(np.trapezoid(cumulative_risk, coverage)), "points": points}


def participant_bootstrap_accuracy(
    rows: list[dict], targets: np.ndarray, predictions: np.ndarray, draws: int = 2000
) -> list[float]:
    grouped: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped[row["participant_id"]].append(index)
    participants = sorted(grouped)
    rng = np.random.default_rng(SEED)
    values = []
    for _ in range(draws):
        sampled = rng.choice(participants, size=len(participants), replace=True)
        indices = [index for participant in sampled for index in grouped[participant]]
        values.append(float(accuracy_score(targets[indices], predictions[indices])))
    return [float(x) for x in np.quantile(values, [0.025, 0.975])]


def paired_participant_bootstrap_difference(
    rows: list[dict], targets: np.ndarray, predictions_a: np.ndarray, predictions_b: np.ndarray
) -> dict:
    grouped: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped[row["participant_id"]].append(index)
    participants = sorted(grouped)
    rng = np.random.default_rng(SEED)
    differences = []
    for _ in range(5000):
        sampled = rng.choice(participants, size=len(participants), replace=True)
        indices = [index for participant in sampled for index in grouped[participant]]
        differences.append(
            accuracy_score(targets[indices], predictions_a[indices])
            - accuracy_score(targets[indices], predictions_b[indices])
        )
    observed = accuracy_score(targets, predictions_a) - accuracy_score(targets, predictions_b)
    return {
        "accuracy_difference": float(observed),
        "participant_bootstrap_95ci": [
            float(value) for value in np.quantile(differences, [0.025, 0.975])
        ],
        "bootstrap_probability_difference_le_zero": float(np.mean(np.asarray(differences) <= 0)),
    }


def evaluate(rows: list[dict], model: LogisticRegression, matrix) -> dict:
    targets = np.asarray([row["reference"] for row in rows])
    predictions = model.predict(matrix)
    probabilities = model.predict_proba(matrix)
    confidence = probabilities.max(axis=1)
    result = {
        "n": len(rows),
        "accuracy": float(accuracy_score(targets, predictions)),
        "accuracy_participant_bootstrap_95ci": participant_bootstrap_accuracy(
            rows, targets, predictions
        ),
        "macro_f1": float(f1_score(targets, predictions, average="macro", zero_division=0)),
        "ece_10bin": expected_calibration_error(targets, predictions, confidence),
        "risk_coverage": risk_coverage(targets, predictions, confidence),
        "by_mention_type": {},
    }
    grouped: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped[row.get("mention_type") or "unknown"].append(index)
    for mention_type, indices in sorted(grouped.items()):
        result["by_mention_type"][mention_type] = {
            "n": len(indices),
            "accuracy": float(accuracy_score(targets[indices], predictions[indices])),
        }
    return result


def new_model() -> LogisticRegression:
    return LogisticRegression(
        C=1.0,
        class_weight="balanced",
        max_iter=2000,
        random_state=SEED,
        solver="lbfgs",
    )


def main() -> None:
    args = parse_args()
    split_spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows_by_split = {
        split_name: [
            row
            for recording in split["recordings"]
            for row in load_recording(args.raw_root, recording)
        ]
        for split_name, split in split_spec["splits"].items()
    }
    train_rows = rows_by_split["train"]
    train_frequency = Counter(row["reference"] for row in train_rows)
    labels = sorted(train_frequency)
    majority = train_frequency.most_common(1)[0][0]
    for rows in rows_by_split.values():
        add_history(rows, labels, train_frequency, majority)

    vectorizer = TfidfVectorizer(
        analyzer="char_wb",
        ngram_range=(2, 5),
        min_df=2,
        max_features=20000,
        sublinear_tf=True,
    )
    text_train = vectorizer.fit_transform(row.get("tsv_words") or "" for row in train_rows)
    text_matrices = {
        split: vectorizer.transform(row.get("tsv_words") or "" for row in rows)
        for split, rows in rows_by_split.items()
    }

    scaler = StandardScaler()
    gaze_train = scaler.fit_transform(gaze_features(train_rows))
    gaze_matrices = {
        split: csr_matrix(scaler.transform(gaze_features(rows)))
        for split, rows in rows_by_split.items()
    }

    history_encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    history_train = history_encoder.fit_transform(
        np.asarray([[row["history_prediction"]] for row in train_rows])
    )
    history_matrices = {
        split: history_encoder.transform(
            np.asarray([[row["history_prediction"]] for row in rows])
        )
        for split, rows in rows_by_split.items()
    }

    feature_sets = {
        "text_tfidf": {
            "train": text_train,
            **{split: text_matrices[split] for split in ("val", "test")},
        },
        "gaze_numeric": {
            "train": csr_matrix(gaze_train),
            **{split: gaze_matrices[split] for split in ("val", "test")},
        },
        "text_plus_gaze": {
            "train": hstack([text_train, csr_matrix(gaze_train)], format="csr"),
            **{
                split: hstack([text_matrices[split], gaze_matrices[split]], format="csr")
                for split in ("val", "test")
            },
        },
        "text_plus_history": {
            "train": hstack([text_train, history_train], format="csr"),
            **{
                split: hstack(
                    [text_matrices[split], history_matrices[split]], format="csr"
                )
                for split in ("val", "test")
            },
        },
        "text_gaze_history": {
            "train": hstack([text_train, csr_matrix(gaze_train), history_train], format="csr"),
            **{
                split: hstack(
                    [text_matrices[split], gaze_matrices[split], history_matrices[split]],
                    format="csr",
                )
                for split in ("val", "test")
            },
        },
    }

    train_targets = np.asarray([row["reference"] for row in train_rows])
    results = {}
    predictions_by_model: dict[str, dict[str, np.ndarray]] = {}
    for name, matrices in feature_sets.items():
        model = new_model()
        model.fit(matrices["train"], train_targets)
        predictions_by_model[name] = {
            split: model.predict(matrices[split]) for split in ("val", "test")
        }
        results[name] = {
            split: evaluate(rows_by_split[split], model, matrices[split])
            for split in ("val", "test")
        }

    comparisons = {}
    for split in ("val", "test"):
        rows = rows_by_split[split]
        targets = np.asarray([row["reference"] for row in rows])
        comparisons[split] = {
            "text_plus_gaze_minus_text": paired_participant_bootstrap_difference(
                rows,
                targets,
                predictions_by_model["text_plus_gaze"][split],
                predictions_by_model["text_tfidf"][split],
            ),
            "text_plus_history_minus_text": paired_participant_bootstrap_difference(
                rows,
                targets,
                predictions_by_model["text_plus_history"][split],
                predictions_by_model["text_tfidf"][split],
            ),
            "text_gaze_history_minus_text_history": paired_participant_bootstrap_difference(
                rows,
                targets,
                predictions_by_model["text_gaze_history"][split],
                predictions_by_model["text_plus_history"][split],
            ),
        }

    output = {
        "task": "canonical target label prediction; empty targets excluded",
        "split_seed": split_spec["seed"],
        "model_seed": SEED,
        "train_rows": len(train_rows),
        "train_labels": len(labels),
        "feature_scope": (
            "Released text/fixation metadata only; these are multimodal metadata baselines, "
            "not image-based visual grounding results."
        ),
        "results": results,
        "paired_participant_bootstrap_comparisons": comparisons,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
