# Primary-source citation audit

Checked: 2026-07-13 IST

This audit covers the recent and task-defining references most likely to change
or be miscited. It complements, but does not replace, a human-author review of
all bibliography entries.

| Key | Verified metadata | Primary evidence |
|---|---|---|
| `deichler2025look` | Anna Deichler and Jonas Beskow; *Look and Tell: A Dataset for Multimodal Grounding Across Egocentric and Exocentric Views*; arXiv:2510.22672 (2025). | [arXiv record](https://arxiv.org/abs/2510.22672) |
| `sun2025visualintention` | Pengzhan Sun et al.; *Visual Intention Grounding for Egocentric Assistants*; ICCV 2025, pp. 2512--2522. | [CVF proceedings page](https://openaccess.thecvf.com/content/ICCV2025/html/Sun_Visual_Intention_Grounding_for_Egocentric_Assistants_ICCV_2025_paper.html) |
| `perrett2025hdepic` | Toby Perrett et al.; *HD-EPIC: A Highly-Detailed Egocentric Video Dataset*; CVPR 2025, pp. 23901--23913. January 2026 frame-wise intermediate data is documented by the project. | [arXiv record](https://arxiv.org/abs/2502.04144), [official project](https://hd-epic.github.io/site/) |
| `chen2022onestage` | Jianhang Chen et al.; *One-Stage Object Referring With Gaze Estimation*; CVPR Workshops 2022. The CVF page lists pp. 5021--5030, which is retained in the bibliography. | [CVF proceedings page](https://openaccess.thecvf.com/content/CVPR2022W/GAZE/html/Chen_One-Stage_Object_Referring_With_Gaze_Estimation_CVPRW_2022_paper.html) |
| `lee2024gazepointar` | Jaewook Lee et al.; *GazePointAR: A Context-Aware Multimodal Voice Assistant for Pronoun Disambiguation in Wearable Augmented Reality*; arXiv:2404.08213 (2024). | [arXiv record](https://arxiv.org/abs/2404.08213) |
| `tschannen2025siglip2` | Michael Tschannen et al.; *SigLIP 2: Multilingual Vision-Language Encoders with Improved Semantic Understanding, Localization, and Dense Features*; arXiv:2502.14786 (2025). | [arXiv record](https://arxiv.org/abs/2502.14786), [official checkpoint](https://huggingface.co/google/siglip2-base-patch16-224) |
| `alibaba2025gtemodernbert` | Tongyi Lab, Alibaba Group; *GTE-ModernBERT-base* model card (2025); 149M parameters; Apache-2.0. | [Official checkpoint](https://huggingface.co/Alibaba-NLP/gte-modernbert-base), pinned revision `e7f32e3c00f91d699e8c43b53106206bcc72bb22` |
| `li2026beyond` | Ling Li et al.; *Beyond Language: Grounding Referring Expressions with Hand Pointing in Egocentric Vision*; arXiv:2603.26646 (2026). | [arXiv record](https://arxiv.org/abs/2603.26646) |
| `yang2026copilot` | Sicheng Yang et al.; *Egocentric Co-Pilot: Web-Native Smart-Glasses Agents for Assistive Egocentric AI*; ACM Web Conference 2026; DOI 10.1145/3774904.3792996. | [DOI registry](https://doi.org/10.1145/3774904.3792996) |
| `zhang2026gazeify` | Zheng Zhang et al.; *Gazeify Then Voiceify: Physical Object Referencing Through Gaze and Voice Interaction with Displayless Smart Glasses*; IUI 2026; DOI 10.1145/3742413.3789112. | [DOI registry](https://doi.org/10.1145/3742413.3789112) |
| `lai2025famhri` | Yuzhi Lai et al.; *FAM-HRI: Foundation-Model Assisted Multi-Modal Human-Robot Interaction Combining Gaze and Speech*; arXiv:2503.16492 (2025). | [arXiv record](https://arxiv.org/abs/2503.16492) |
| `jiang2026superglasses` | Zhuohang Jiang et al.; *SuperGlasses: Benchmarking Vision Language Models as Intelligent Agents for AI Smart Glasses*; CVPR Findings 2026, pp. 2165--2175. | [CVF proceedings page](https://openaccess.thecvf.com/content/CVPR2026F/html/Jiang_SuperGlasses_Benchmarking_Vision_Language_Models_as_Intelligent_Agents_for_AI_CVPRF_2026_paper.html) |
| `wu2026abstaineqa` | Tao Wu et al.; *When Robots Should Say ``I Don't Know'': Benchmarking Abstention in Embodied Question Answering*; CVPR 2026, pp. 15266--15275. | [CVF proceedings page](https://openaccess.thecvf.com/content/CVPR2026/html/Wu_When_Robots_Should_Say_I_Dont_Know_Benchmarking_Abstention_in_CVPR_2026_paper.html) |
| `vasudevan2018object` | Arun Balajee Vasudevan, Dengxin Dai, and Luc Van Gool; *Object Referring in Videos With Language and Human Gaze*; CVPR 2018, pp. 4129--4138. | [CVF proceedings page](https://openaccess.thecvf.com/content_cvpr_2018/html/Vasudevan_Object_Referring_in_CVPR_2018_paper.html) |
| `kolve2017ai2thor` | Eric Kolve et al.; *AI2-THOR: An Interactive 3D Environment for Visual AI*; arXiv:1712.05474 (2017). The current arXiv metadata has 13 authors; the prior local entry omitted Matt Deitke, Kiana Ehsani, and Aniruddha Kembhavi and was corrected. | [arXiv record](https://arxiv.org/abs/1712.05474) |
| `shridhar2020alfred` | Mohit Shridhar et al.; *ALFRED: A Benchmark for Interpreting Grounded Instructions for Everyday Tasks*; CVPR 2020, pp. 10740--10749. | [CVF proceedings page](https://openaccess.thecvf.com/content_CVPR_2020/html/Shridhar_ALFRED_A_Benchmark_for_Interpreting_Grounded_Instructions_for_Everyday_Tasks_CVPR_2020_paper.html) |
| `radford2021clip` | Alec Radford et al.; *Learning Transferable Visual Models From Natural Language Supervision*; ICML 2021, PMLR 139, pp. 8748--8763. | [PMLR proceedings page](https://proceedings.mlr.press/v139/radford21a.html) |
| `geifman2017selective` | Yonatan Geifman and Ran El-Yaniv; *Selective Classification for Deep Neural Networks*; NeurIPS 30 (2017). | [NeurIPS proceedings page](https://proceedings.neurips.cc/paper_files/paper/2017/hash/4a8423d5e91fda00bb7e46540e2b0cf1-Abstract.html) |
| `guo2017calibration` | Chuan Guo, Geoff Pleiss, Yu Sun, and Kilian Q. Weinberger; *On Calibration of Modern Neural Networks*; ICML 2017, PMLR 70, pp. 1321--1330. | [PMLR proceedings page](https://proceedings.mlr.press/v70/guo17a.html) |
| `he2016resnet` | Kaiming He, Xiangyu Zhang, Shaoqing Ren, and Jian Sun; *Deep Residual Learning for Image Recognition*; CVPR 2016, pp. 770--778. | [CVF proceedings page](https://openaccess.thecvf.com/content_cvpr_2016/html/He_Deep_Residual_Learning_CVPR_2016_paper.html) |
| `marafioti2025smolvlm` | Andr{\'e}s Marafioti et al.; *SmolVLM: Redefining Small and Efficient Multimodal Models*; arXiv:2504.05299 (2025). | [arXiv record](https://arxiv.org/abs/2504.05299), [official checkpoint](https://huggingface.co/HuggingFaceTB/SmolVLM-256M-Instruct) |

Crossref/DOI content negotiation confirmed the exact titles, ACM publisher,
proceedings-article type, and 2026 issue dates for the two ACM entries. The
SigLIP 2 and EgoPoint-Ground DOI records resolve to arXiv with the titles and
years shown above.

The AI2-THOR author-list mismatch was corrected in the manuscript bibliography.
No other verified mismatch requires a manuscript change. The human authors
should still check author spelling, capitalization, and final venue metadata for
every entry before submission, especially concurrent 2026 work.
