# Expanded Tool-Agent Protocol Freeze

Frozen before aggregate inspection on 2026-07-13.

## Primary Qwen-7B expansion

- Target manifest: `data/schemamem-agent-targets-expanded78.json`
- SHA-256: `74e2a04552e3a23f2193bca0d7519d828cbe18cdc15683365f5d0ff29f04adab`
- Targets: 78 across 11 databases; all 56 available affected-memory pairs
  plus two seeded unaffected controls per database (22 controls).
- Conditions: no memory, stale memory, version filter, re-explore on change,
  execution-guided memory maintenance, builder repaired-memory upper bound, and
  SchemaMem policy memory.
- One model slot and one experiment worker. Temperature 0, seed 42, maximum
  eight model calls per downstream or maintenance loop, 256 completion tokens
  per call.
- Primary comparisons: SchemaMem versus stale memory and versus
  execution-guided maintenance, first on affected memories and then on all
  targets. Database-cluster bootstrap intervals and exact database sign-flip
  tests are primary; target-level McNemar tests are secondary.
- Interaction cost for execution-guided maintenance includes both the
  maintenance and downstream loops.

The execution-guided baseline first executes the stored program against the
current database. It retains any executable program without consulting gold
answers. Only an observable execution failure triggers a schema/SQL tool loop;
any executable repair is retained even when it is semantically wrong. It never
receives the migration manifest.

## Larger-model control

- Exact target manifest: `data/schemamem-agent-targets-balanced22.json`
- SHA-256: `7dbd7877543da9a6159d04b3bc8c1b503446020ae060ce8bb43b7511516eefb9`
- Targets: two per database, 9 affected and 13 unaffected.
- Same seven conditions and bounded serial protocol.
- Qwen2.5-Coder-14B-Instruct Q3_K_M with partial CPU offload. This is an
  exploratory robustness control, not an isolated parameter-scaling study.

## Diagnostic exclusions

- The one-target smoke test is excluded from aggregates.
- Earlier two-slot throughput diagnostics remain excluded because identical
  prompts sometimes decoded differently under concurrent batching.
- The original 22-target Qwen-7B confirmatory file remains immutable and is not
  merged into the expanded file.

## Evaluator-only amendment, 2026-07-14

One predeclared target (`table_rename/financial/159`) completed its gold query
in 3.4--3.8 seconds but was repeatedly skipped by the generic 3-second
validation guard before any model condition ran. The gold-only guard was raised
to 30 seconds and the seven missing paired conditions were then appended. This
does not alter prompts, model/tool budgets, condition data, or scoring; all
agent-issued SQL retains the original execution guard. The final file contains
all 546 expected unique target-condition rows.
