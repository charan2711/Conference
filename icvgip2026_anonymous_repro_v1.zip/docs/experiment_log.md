# Experiment log

## 2026-07-13 - Full raw-to-derived alignment audit

- Compared all 2,330 matched-media derived rows against 117 released
  `references.csv` files.
- Verified exact surface text, canonical target, mention type, antecedent and
  chain identifiers, midpoint-frame calculation, and fixation coordinates.
- Opened every referenced JPEG header; all 2,330 midpoint frames exist at
  1408x1408. The audit independently recovers 192 rows without fixation.
- Artifact: `artifacts/audits/look_and_tell_raw_derived_alignment.json`.
- This closes a preprocessing-fidelity gap left by the split/cache audits; it
  does not replace human interpretation of whether a released gaze sample
  visually targets the intended referent.

## 2026-07-13 - Post-hoc GTE-ModernBERT language audit

- Pinned the Apache-2.0 `Alibaba-NLP/gte-modernbert-base` checkpoint at revision
  `e7f32e3c00f91d699e8c43b53106206bcc72bb22` (149,014,272 parameters).
- Cached normalized CLS embeddings for the 520 unique expressions across all
  2,330 matched-media rows, then used the same six participant folds and causal
  predicted-history construction as the lightweight audit.
- ModernBERT alone reaches 66.35% accuracy (95% CI: 63.05--69.88) and 6.98%
  coreference accuracy. Adding predicted history raises accuracy to 78.54%
  (76.18--80.92) and coreference accuracy to 49.57%.
- Character TF-IDF plus the identical history channel remains stronger at
  80.64%; ModernBERT+history minus TF-IDF+history is -2.10 points (paired
  participant-bootstrap 95% CI: -3.43 to -0.84).
- ModernBERT repairs 41 TF-IDF+history errors but breaks 90 TF-IDF successes.
- A cache-backed rerun produced byte-identical JSON, SHA-256
  `7C52D8D80FA51FEA4B6490D8256572F36DE85C1B7F84293C998F5744A9030863`.

Artifact: `artifacts/baselines/look_and_tell_modernbert.json`. Embeddings and
weights remain local and are excluded from the anonymous supplement.

## 2026-07-13 - Availability-preserving shuffled-fixation control

- Added a label-agnostic alignment control to the fixed six-fold lightweight
  audit. Within each recording, valid fixation coordinates are cyclically
  shifted by half the valid sequence; missing fixations remain missing.
- The control preserves all 192 missing-fixation rows and changes coordinates
  on 2,136 of 2,138 rows with a released fixation.
- The artifact's 194 all-row coordinate collisions decompose into the 192
  preserved missing rows and only two available rows with unchanged numeric
  coordinates. One of those has a lone valid fixation in its recording; the
  other receives a different donor row with identical coordinates.
- A post-hoc sensitivity audit repeats the identical six-fold pipeline at five
  predeclared label-free cyclic offsets (0.20, 0.35, 0.50, 0.65, 0.80). Shuffled
  accuracy ranges from 81.12% to 81.93%, and gaze minus shuffled ranges from
  -0.09 to +0.73 points. Every participant-bootstrap 95% interval includes
  zero; no offset is selected for reporting.
- Text+history reaches 80.64%, true-gaze fusion 81.85%, frame-center fusion
  82.15%, and shuffled-fixation fusion 81.76%.
- True gaze minus shuffled fixation is +0.09 points overall (participant
  bootstrap 95% CI: -0.79 to +0.89). On the 2,138 fixation-available rows the
  difference is exactly 0.00 points (95% CI: -0.90 to +0.87).
- Shuffled fixation still improves over text+history by +1.12 points (95% CI:
  +0.23 to +2.08), supporting generic local appearance rather than a verified
  gaze-alignment mechanism.
- A cached rerun produced byte-identical JSON, SHA-256
  `A24DB27A6C0C3BD145F75D316A69B68ABF871E9C3E88408BB26BE4A53EE7265A`.

Artifact: `artifacts/baselines/look_and_tell_gaze_location_crossval.json`.

## 2026-07-22 - Six-fold parameter-efficient SmolVLM audit

To test whether the matched-control result is specific to frozen linear probes,
we adapted `HuggingFaceTB/SmolVLM-256M-Instruct` at revision
`7e3e67edbbed1bf9888184d9df282b700a323964`. Rank-4 LoRA is trained in both
vision and language attention projections and the multimodal connector is fully
trained. This exposes 7,833,600 of 264,318,528 parameters (2.96%). Every visual
condition resets the identical initialization and random state.

The compute-bounded protocol uses the same six participant-disjoint outer
folds. Each fold trains for one epoch on a deterministic mention/label-balanced
sample of 96 outer-training rows and evaluates 96 held-out rows. The concatenated
evaluation contains 576 unique rows across all 24 participants.

| Condition | Accuracy | Participant-bootstrap 95% CI | Macro F1 | Coref. acc. |
|---|---:|---:|---:|---:|
| Same-row text + history | **73.78%** | 69.76--77.57% | **66.91%** | 52.19% |
| Full frame | 54.17% | 50.19--58.28% | 43.57% | 51.32% |
| Center crop | 55.73% | 51.99--59.67% | 43.93% | 53.95% |
| True gaze crop | 57.47% | 53.87--61.35% | 47.21% | **54.82%** |
| Shuffled gaze crop | 57.29% | 53.51--61.09% | 45.78% | 54.39% |

True gaze minus shuffled gaze is +0.17 points (95% CI: -1.98 to +2.41);
true gaze minus center is +1.74 points (-0.50 to +4.11). The VLM underperforms
the same-row text baseline, so it is not presented as a performance model. Its
role is a model-family diagnostic showing that learned cross-modal interactions
do not reverse the gaze-versus-shuffled finding on this subsample. The result
does not rule out larger models, full-data training, or temporal gaze inputs.

Aggregate artifact:
`artifacts/audits/look_and_tell_smolvlm_crossval.json`. It records the pinned
model/license/configuration, six fold-artifact hashes, participant coverage,
paired comparisons, and scope boundary.

## 2026-07-22 - End-to-end SmolVLM cross-validation launched

The feasibility pilot was upgraded to a parameter-efficient end-to-end VLM
protocol using the pinned `HuggingFaceTB/SmolVLM-256M-Instruct` revision
`7e3e67edbbed1bf9888184d9df282b700a323964`. The protocol trains the complete
multimodal connector plus rank-4 LoRA adapters in every vision- and
language-attention block: 7,833,600/264,318,528 parameters are trainable
(2.96%), including 294,912 vision-LoRA, 460,800 text-LoRA, and 7,077,888
connector parameters.

A matched four-condition smoke run passed on CPU with full-frame, frame-center,
true-gaze, and within-recording shuffled-gaze inputs. Gradient checkpointing is
enabled to fit the 16 GB host; candidate-label confidence is the normalized
probability of the selected leaf in the constrained decoding trie. Each
condition resets the same seed and reloads the same pinned base checkpoint.

The resumable six-fold run uses 96 balanced outer-training rows and 96 held-out
rows per fold at 256-pixel input, for 576 unique out-of-fold evaluation rows per
condition. `scripts/analyze_look_and_tell_smolvlm_crossval.py` will reject the
aggregate unless folds 0--5 are complete, participants are disjoint, row sets
match across conditions, the split hash and hyperparameters agree, and vision,
text, and connector trainability are all verified. It will report accuracy,
macro F1, coreference accuracy, 10-bin ECE, AURC, participant-cluster intervals,
and paired full/center/gaze/shuffled contrasts. No paper result is claimed while
the run is incomplete.

## 2026-07-21 - Fixation metadata and nested threshold-transfer audits

To test whether the null gaze-location result was carried by explicit fixation
metadata rather than crop content, we removed normalized fixation x/y,
temporal-link, and fixation-availability features while keeping every crop,
fold, seed, and classifier unchanged. Full-frame, gaze, and shuffled fusion
reach 82.92%, 81.76%, and 81.80%; gaze minus shuffled is -0.04 points (95% CI
-0.91 to +0.78).

We also selected confidence thresholds inside five inner participant-disjoint
folds of each outer fold, then transferred each frozen threshold to its held-out
participants. Overall outer coverage is 76.01% at 5.76% selective error;
explicit mentions retain 91.11% coverage at 4.09% error, while coreference
retains 31.18% at 20.22% error. The outer-fold range is 1.73--11.04%, so the
nominal 5% target is a transfer diagnostic rather than a finite-sample safety
guarantee.

Artifacts: `artifacts/baselines/look_and_tell_fixation_metadata_ablation.json`
and `artifacts/baselines/look_and_tell_full_frame_nested_threshold.json`.

## 2026-07-22 - SmolVLM connector-tuning feasibility pilot

We executed a bounded participant-disjoint pilot with the cached
`HuggingFaceTB/SmolVLM-256M-Instruct` checkpoint at immutable revision
`7e3e67edbbed1bf9888184d9df282b700a323964` (Apache-2.0). The CPU-only run
fine-tuned the 7,077,888-parameter multimodal connector independently from the
same base weights for full-frame, center-crop, true-gaze, and within-recording
shuffled-gaze conditions. Decoding was greedily constrained to the outer-train
canonical-label vocabulary. Fold 0 held out participants 03, 09, 13, and 20;
the feasibility sample used 48 training and 24 held-out rows for one epoch.

| Condition | Pilot accuracy | Macro F1 | Coreference accuracy |
|---|---:|---:|---:|
| Full frame | 54.17% | 38.70% | 66.67% (6/9) |
| Center crop | 45.83% | 33.33% | 44.44% (4/9) |
| True gaze crop | 33.33% | 22.98% | 44.44% (4/9) |
| Shuffled gaze crop | 37.50% | 23.79% | 66.67% (6/9) |

On exactly the same 24 rows, the existing character TF-IDF plus causal
predicted-history baseline reaches 91.67% overall and 88.89% on coreference.
Full minus center is +8.33 points (four-participant bootstrap 95% interval
-14.29 to +19.35); gaze minus center is -12.50 (-28.57 to +7.14), and gaze
minus shuffled is -4.17 (-17.14 to +15.00). Thus the model and training path are
locally feasible, but the 48-row connector pilot is severely undertrained and
does not support replacing any manuscript placeholder or making a VLM claim.

Commands:

```powershell
.\.venv\Scripts\python.exe scripts\pilot_look_and_tell_smolvlm.py
.\.venv\Scripts\python.exe scripts\analyze_look_and_tell_smolvlm_pilot.py
```

Artifacts: `artifacts/baselines/look_and_tell_smolvlm_pilot.json` and
`artifacts/audits/look_and_tell_smolvlm_pilot_analysis.json`.

## 2026-07-21 - Fixation-metadata ablation

To test whether the gaze/shuffle null is driven by explicit metadata rather
than image evidence, we removed normalized fixation $x/y$, temporal-link, and
fixation-availability features from every cached visual descriptor. Crops and
full-frame pixels, training-only standardization, classifier, participant folds,
and seed were unchanged. The six-fold out-of-fold results were:

| Model | Accuracy | Participant-bootstrap 95% CI | Coref. acc. |
|---|---:|---:|---:|
| Text + history | 80.64% | 78.55--82.83% | 50.43% |
| + full frame, metadata removed | 82.92% | 81.04--84.88% | 55.88% |
| + gaze, metadata removed | 81.76% | 79.74--83.97% | 52.81% |
| + shuffled, metadata removed | 81.80% | 79.80--83.90% | 53.49% |

Gaze minus shuffled is -0.04 points (95% CI -0.91 to +0.78), so explicit
fixation metadata is not driving the null gaze-location result. Artifact:
`artifacts/baselines/look_and_tell_fixation_metadata_ablation.json`.
Cache: `data/derived/look_and_tell_shuffled_fixation_cache.npz` (local only).

## 2026-07-13 - Validation-selected selective operating point

- Fit the existing temperature on validation after freezing the classifier.
- Among calibrated confidence thresholds, the largest validation subset at no
  more than 5% error accepts 264/380 queries (69.47%) at 4.92% error.
- Applying the same threshold (`0.7729228415`) unchanged to locked test accepts
  236/306 queries (77.12%) at 6.78% error. The nominal validation error bound
  therefore does not transfer exactly; the manuscript now reports this rather
  than independently optimizing a threshold on each split.

Artifact: `artifacts/baselines/look_and_tell_classical_vision.json`.

## 2026-07-13 - License provenance and redistribution gate

- Verified Look and Tell (CC BY-NC-ND 4.0), HD-EPIC (CC BY-NC 4.0), ALFRED
  (MIT), OpenAI CLIP (MIT), SigLIP 2 (Apache-2.0), and ONNX Model Zoo ResNet
  (Apache-2.0) against official project pages.
- Added an executable audit over the exact anonymous-supplement selection. It
  rejects source annotations, media, transformed frames, model weights, feature
  caches, credentials, and restricted local paths.
- Cross-checked frozen CLIP/SigLIP revisions and the ONNX ResNet SHA-256 against
  measured artifacts. The only selected file below `data/` is the participant
  split identifier manifest.

Artifact: `artifacts/audits/release_redistribution.json`. Human authors retain
responsibility for the final release and project-license decision.

## 2026-07-12 - Look and Tell release audit

- Raw upstream annotation bytes downloaded with per-file SHA-256 provenance.
- 2,596 reference rows in 120 non-empty files; 2,376 rows have a non-empty
  target label, and the repository manifest lists 3.655 hours.
- 1,603 ingredient, 150 object, 595 pronoun/coreference, 28 distractor and 220
  empty/unknown-target rows.
- Ten expected files were absent or empty despite a manifest/paper count
  mismatch. Results will use only fetched non-empty files.

Artifact: `artifacts/audits/look_and_tell_summary.json`.

## 2026-07-12 - Look and Tell media pilot

- Source: `par_01_rec_01`, SHA-256
  `d2071e2e9d3f39de7892d749580b67b71253438354aa48f93c46c4e3fab7b766`.
- Video: 1,408 x 1,408, 30 fps, 1,739 frames, 26,168,603 bytes.
- Extracted 20/20 unique annotated mention midpoint frames.
- The raw video was deleted after extraction; derived frames remain local and
  must not be redistributed under CC BY-NC-ND 4.0.

Artifact: `data/derived/look_and_tell/pilot_summary.json` (ignored by Git).

## 2026-07-12 - Frozen participant split

- Seed: 20260713. The inspected pilot participant is in training.
- Train: 16 participants, 80 recordings, 1,817 total rows.
- Validation: 4 participants, 20 recordings, 418 total rows.
- Test: 4 untouched participants, 20 recordings, 361 total rows.

Artifact: `data/manifests/look_and_tell_splits.json`.

## 2026-07-12 - Text-only baseline

Rows with no canonical target were excluded. Results are deterministic; the
test set is now locked for model development.

| Method | Val accuracy | Val macro F1 | Test accuracy | Test macro F1 |
|---|---:|---:|---:|---:|
| Train-majority (`Pan`) | 12.63% | 0.80% | 8.07% | 0.52% |
| Closed-set lexical | 59.21% | 63.38% | 60.56% | 54.68% |
| Lexical + last explicit discourse memory | 70.79% | 68.38% | 77.02% | 62.01% |

The lexical model reached only 9.92% validation accuracy on pronoun/coreference
mentions; simple discourse memory raised this to 51.24%. This establishes a
real, non-ceiling baseline and motivates gaze-conditioned memory. No method
changes may be selected using the reported test results.

Artifact: `artifacts/baselines/look_and_tell_text.json`.

## 2026-07-12 - HD-EPIC annotation audit

- 59,454 total narrations.
- 808 narrations contain a control verb paired with an appliance noun.
- 106 videos, all nine participants; 437 open, 369 close and two switch pairs.
- Gaze priming annotations cover 153 videos.

Artifact: `artifacts/audits/hd_epic_controls_summary.json`.

## 2026-07-12 - Kaggle AI2-THOR smoke test v1

- Private GPU kernel launched successfully on Kaggle Linux with Python 3.12.13.
- It failed before importing AI2-THOR because the worker could not resolve PyPI;
  all five pip retries returned a temporary DNS failure even though kernel
  metadata requested internet access.
- This is an environment/dependency failure, not a simulator rendering result;
  the AI2-THOR feasibility gate remains unresolved.
- Remediation: package the official AI2-THOR 5.0 wheel, uncommon Python
  dependencies, and the SHA-verified 5.0 CloudRendering Unity build as a private
  Kaggle dataset, then rerun fully offline with `local_executable_path`.

Artifact: `artifacts/kaggle/ai2thor_smoke_v1/icvgip-ai2-thor-toggle-smoke-test.log`.

## 2026-07-12 - Look and Tell released-metadata fusion baselines

The experiment uses frozen character TF--IDF and balanced logistic-regression
hyperparameters with released fixation coordinates. It does not use image pixels
and must not be described as visual grounding.

| Model | Val accuracy | Val macro F1 | Val coref. accuracy | ECE |
|---|---:|---:|---:|---:|
| Gaze coordinates | 2.63% | 2.17% | 1.65% | 11.53% |
| Text TF--IDF | 61.05% | 63.14% | 11.57% | 9.07% |
| Text + gaze | 64.74% | 65.65% | 14.05% | 11.39% |
| Text + history | **78.68%** | **73.58%** | **50.41%** | 20.48% |
| Text + gaze + history | 76.84% | 67.35% | 46.28% | 17.78% |

The raw gaze feature gives a small gain over text alone but does not survive the
strong discourse-history comparison: adding gaze to text+history lowers
validation accuracy by 1.84 points. This negative ablation prevents a claim that
coordinates alone improve reference resolution and motivates the planned
gaze-conditioned visual-proposal experiment.

Paired participant bootstrap comparisons reinforce this conclusion. Text+gaze
beats text on validation by 3.68 points (95% CI: 1.33 to 5.22) but is 1.86 points
worse on test (95% CI: -5.07 to 2.77). Text+history improves validation over
text by 17.63 points (95% CI: 13.33 to 20.50). Coordinate-only gaze fusion is
therefore treated as split-sensitive rather than a robust improvement.

Artifact: `artifacts/baselines/look_and_tell_multimodal.json`.

## 2026-07-12 - Kaggle AI2-THOR offline feasibility audit (v2--v9)

- The official AI2-THOR 5.0 CloudRendering archive was verified against its
  published SHA-256 (`1fd5f998...b67bb9`) and attached through a private Kaggle
  dataset with the 5.0 wheel and offline dependencies.
- v4 reached AI2-THOR's platform check and failed because `libvulkan1` was not
  installed. An Ubuntu Jammy `libvulkan1` package was then verified against
  SHA-256 `192adcff...88548b` and unpacked in user space.
- v6 loaded that Vulkan library successfully. Unity then aborted at
  `vkEnumeratePhysicalDevices`; its native `Player.log` was preserved.
- v9 was explicitly submitted with Kaggle's `NvidiaTeslaT4` accelerator option.
  Pulled server metadata reports `enable_gpu: true` and `machine_shape: Gpu`, but
  the execution container exposed no NVIDIA Vulkan ICD, NVIDIA user-space Vulkan
  library, or `nvidia-smi`; Unity again aborted before rendering.
- Therefore no simulator images or transition results are claimed. This is a
  reproducible feasibility failure of the current CLI-launched Kaggle runtime,
  not evidence that AI2-THOR itself is defective. The paper's primary evidence
  remains real egocentric data; simulator experiments are optional unless a
  Vulkan-capable runtime becomes available.

Artifacts: `artifacts/kaggle/ai2thor_smoke_v4` through
`artifacts/kaggle/ai2thor_smoke_v9`.

## 2026-07-12 - ALFRED toggle-command target baseline

We treat each human instruction variant as a query and predict whether the
ALFRED `ToggleObject` target is a desk lamp or floor lamp. The official split is
preserved; no simulator rendering is required.

| Split | Queries | Tasks | Majority acc. | TF--IDF acc. | Macro F1 |
|---|---:|---:|---:|---:|---:|
| Valid seen | 87 | 29 | 55.17% | 77.01% | 76.76% |
| Valid unseen | 161 | 54 | 40.99% | 76.40% | 73.99% |

Task-cluster bootstrap 95% accuracy intervals are 67.44--86.21% (seen) and
69.81--82.66% (unseen).

On unseen scenes, retaining only the 50.31% most confident queries reduces
selective error from 23.60% at full coverage to 6.17%. This is evidence for an
abstaining command resolver, not a complete vision-based controller: the target
ontology contains only desk and floor lamps and the baseline uses text alone.

Artifact: `artifacts/baselines/alfred_toggle_text.json`.

## 2026-07-12 - Look and Tell fixation-crop visual baselines

We extracted 2,199 unique mention-midpoint frames from 98/100 train/validation
recordings. Two upstream training videos (`par_11_rec_02`, `par_11_rec_04`)
return HTTP 404 and are excluded from all matched-media methods. Validation is
complete. The raw videos were removed after extraction.

Each visual modality is standardized and then L2-normalized before sparse
late fusion, preventing dimensionality from overwhelming text. The learned
models are balanced logistic regressions with frozen seed 20260713.

| Model | Val acc. | Macro F1 | Coref. acc. | ECE |
|---|---:|---:|---:|---:|
| Classical fixation crop | 12.63% | 11.30% | 9.09% | 2.95% |
| ResNet-50 fixation crop | 15.26% | 13.22% | 9.09% | 1.27% |
| Text | 60.53% | 63.80% | 9.92% | 8.93% |
| Text + classical crop | 68.16% | 68.31% | 17.36% | 17.60% |
| Text + ResNet-50 crop | 66.84% | 65.23% | 17.36% | 14.12% |
| Text + history | 79.21% | 73.95% | 52.07% | 21.15% |
| Text + history + ResNet-50 | 80.53% | 77.44% | 52.89% | 22.32% |
| Text + history + classical crop | **81.05%** | **78.69%** | **55.37%** | 24.30% |

Against text+history, the best classical-crop fusion gains 1.84 accuracy points
(paired participant-bootstrap 95% CI: +0.56 to +3.61; bootstrap probability of
a non-positive difference 0.0038). ResNet-50 fusion gains 1.32 points (95% CI:
+0.29 to +2.03). At 50% coverage, both history-aware visual fusions make one
error in 190 retained validation queries (0.53% selective error), although their
raw ECE remains poor and requires calibration.

The official ONNX Model Zoo ResNet-50 v2 file has SHA-256
`79102261eb6e5fd7af5d27f41316293e388c5cb691e5d25bfb035c4f64fefe31`.

Artifact: `artifacts/baselines/look_and_tell_classical_vision.json`.

Dense selective evaluation gives AURC 4.00% on validation and 4.04% on test.
The best fusion retains 70.00% of validation or 64.05% of test queries at no
more than 5% selective error. A temperature of 0.5257 fitted on validation
reduces frozen-test ECE from 22.44% to 3.94% and NLL from 0.761 to 0.514 on
303 known-vocabulary test targets without changing predictions or ranking.

### One-time frozen test evaluation

After selecting normalized fusion on validation, test media were extracted and
the model was evaluated once. `par_14_rec_01` also returns HTTP 404, leaving 306
matched-media test rows from 19 recordings.

| Model | Test acc. | Macro F1 | Coref. acc. | Error at 50% coverage |
|---|---:|---:|---:|---:|
| Text | 66.34% | 60.14% | 6.41% | 5.23% |
| Text + classical crop | 68.95% | 60.96% | 10.26% | 2.61% |
| Text + ResNet-50 crop | 69.28% | 63.13% | 10.26% | 3.27% |
| Text + history | 82.03% | 71.31% | 58.97% | 2.61% |
| Text + history + ResNet-50 | 83.01% | 74.15% | 61.54% | 2.61% |
| Text + history + classical crop | **83.66%** | **76.73%** | **62.82%** | **1.31%** |

The classical history-aware fusion is +1.63 points above text+history on test,
but its paired participant-bootstrap interval touches zero (95% CI: 0.00 to
+4.18; bootstrap probability of a non-positive difference 0.0656). The frozen
test therefore confirms the direction but not a conclusive participant-level
gain.

### Post-test gaze-location audit

After the frozen test evaluation, we added a diagnostic that holds the
classical descriptor and released coordinate features fixed but moves the image
crop from the fixation to the frame center. This is explicitly post hoc and is
not used to select a new final model.

| Fusion | Val acc. | Test acc. |
|---|---:|---:|
| Text + center crop | 65.26% | 68.63% |
| Text + gaze crop | 68.16% | 68.95% |
| Text + history + center crop | 79.74% | 84.64% |
| Text + history + gaze crop | 81.05% | 83.66% |

Without history, gaze centering beats center cropping by 2.89 points on
validation (95% CI: 0.00 to 4.68) but only 0.33 points on test (95% CI: -0.88
to 2.22). With history, the gaze-minus-center difference is +1.32 points on
validation (95% CI: -0.27 to 2.22) and -0.98 points on test (95% CI: -1.48 to
-0.31). Thus visual appearance helps target prediction, but this experiment
does not establish that fixation centering is the cause. This negative result
must constrain the paper's novelty and claims.

### Six-fold participant-disjoint location audit

To reduce dependence on the four-participant validation/test partitions, we
performed deterministic six-fold cross-validation over all 24 participants and
2,330 matched-media rows. Every score below is out-of-fold; text vocabulary,
history encoding, visual scaling, and the classifier are refit inside each fold.

| Model | Accuracy | Participant-bootstrap 95% CI | Macro F1 | Coref. acc. |
|---|---:|---:|---:|---:|
| Text + history | 80.64% | 78.55--82.83% | 70.01% | 50.43% |
| Text + history + center crop | **82.15%** | 80.24--84.16% | **71.73%** | 52.64% |
| Text + history + gaze crop | 81.85% | 79.79--84.12% | 68.96% | **52.98%** |

Center appearance improves over text+history by 1.50 points (paired 95% CI:
+0.65 to +2.45); gaze appearance improves it by 1.20 points (95% CI: +0.09 to
+2.27). Gaze minus center is -0.30 points (95% CI: -1.08 to +0.43). The robust
finding is therefore that local visual appearance helps; fixation localization
does not outperform a center-crop control under this descriptor.

Artifact: `artifacts/baselines/look_and_tell_gaze_location_crossval.json`.

Fixation-distance quartiles also fail to reveal a gaze-specific regime. From
nearest to farthest from frame center, gaze-minus-center differences are -0.86,
-0.34, -0.17 and +0.17 points; every participant-bootstrap 95% interval spans
zero. Differences are likewise inconclusive within ingredient, object,
distractor, and pronoun/coreference subsets.

Relative to text+history, visual gains are concentrated in 1,568 ingredient
mentions: +1.59 points for center (95% CI: +0.97 to +2.17) and +0.96 for gaze
(+0.26 to +1.70). On 587 coreference mentions, center and gaze improve by +2.21
and +2.56 points, but their intervals cross zero (-0.36 to +4.89 and -0.34 to
+5.65). Visual crops therefore do not robustly solve the main pronoun failure
mode.

The paired out-of-fold error-transition audit shows why the gains remain
modest. Center and gaze crops each repair 64 text+history errors, but they break
29 and 36 previously correct predictions, respectively. The two crop models
disagree on 133/2,330 rows (5.71%): center alone is correct on 41, gaze alone on
34, and both predict different wrong labels on 58. The visual gain is therefore
carried by a small decision-boundary subset, not by a broadly reliable
gaze-specific correction mechanism.

## 2026-07-13 - Frozen OpenAI CLIP baseline

The official `openai/clip-vit-base-patch32` checkpoint (Hugging Face revision
`3d74acf9a28c67741b2f4f2ea7635f0aaf6f0268`, 151,277,313 parameters) was run on
CPU over the same local fixation crops. Licensed frames were not uploaded.

| Model | Val acc. | Test acc. | Val macro F1 | Val coref. |
|---|---:|---:|---:|---:|
| CLIP zero-shot target retrieval | 4.74% | 1.63% | 6.24% | 2.48% |
| CLIP image features | 11.32% | 9.48% | 8.94% | 6.61% |
| Text + history | 79.21% | 82.03% | 73.95% | 52.07% |
| Text + history + CLIP | 79.74% | 83.33% | 73.87% | 52.07% |

CLIP fusion is +0.53 points on validation (paired participant-bootstrap 95% CI:
-1.24 to +2.00) and +1.31 on test (95% CI: 0.00 to +3.14). The improvement is
not robust on validation. Generic CLIP semantics therefore do not replace the
discourse signal or establish a gaze-specific benefit.

Artifact: `artifacts/baselines/look_and_tell_clip.json`.

## 2026-07-13 - Post-hoc frozen SigLIP 2 location audit

To address representation freshness without selecting a new primary model on
the opened test partition, we ran `google/siglip2-base-patch16-224` at pinned
revision `02c35f2c035e0ed4a367fb10a892c1fe2a3f364e` (375,187,970 parameters).
Licensed frames remained local. Both fixation and frame-center embeddings were
evaluated with the same fixed six participant folds; text vocabulary, predicted
history, embedding standardization, and the classifier were refit in each fold.

| Model | OOF accuracy | Participant-bootstrap 95% CI | Macro F1 | Coref. acc. |
|---|---:|---:|---:|---:|
| Text + history | 80.64% | 78.55--82.83% | 70.01% | 50.43% |
| + center SigLIP 2 | 82.15% | 80.22--84.20% | 70.88% | 52.64% |
| + gaze SigLIP 2 | **82.36%** | 80.36--84.42% | 70.53% | **54.00%** |

Center improves over text+history by +1.50 points (95% CI: +0.67 to +2.44),
and gaze improves by +1.72 (+0.50 to +3.02). Gaze minus center is only +0.21
points (95% CI: -0.69 to +1.08). The direction reverses relative to the
lightweight descriptor, but neither representation establishes a robust
gaze-location benefit. This is reported as a post-hoc robustness audit and is
not used to replace the frozen primary model.

The subgroup audit does not reveal a hidden gaze-specific regime. On 587
pronoun/coreference rows, gaze exceeds center by +1.36 points, but the paired
participant-bootstrap interval crosses zero (-1.46 to +4.32). Gaze-minus-center
differences across fixation-distance quartiles are +0.34, -1.55, +1.20, and
+0.86 points; every interval spans zero. SigLIP 2 center fusion repairs 81
text+history errors and breaks 46 successes; gaze repairs 86 and also breaks 46.
The crop models disagree on 174/2,330 rows (7.47%), with center uniquely correct
on 47, gaze on 52, and both choosing different wrong labels on 75.

Artifact: `artifacts/baselines/look_and_tell_siglip2.json`.

## 2026-07-13 - Leakage and cache-integrity audit

An executable audit verifies participant/recording disjointness, chronological
row order in 117 matched-media recordings, and causal predicted history over all
2,330 rows. History predictions are unchanged when every target is replaced by
a sentinel and when future expressions are removed. Text vocabulary, history
encoding, and visual scaling are fitted on training rows in each split/fold.

The audit identified a reproducibility defect in the classical cache loader: it
stored a row-order signature but previously accepted cached arrays using only
their length. Both the fixed-split and six-fold loaders now require an exact
signature match. The existing cache signature matched the current ordered rows.
After the fix, complete reruns produced byte-identical artifacts:

- classical fixed-split SHA-256:
  `a387e09e1576a9c998b5612a85d603e7b112c14e2355019aae9e02c8135b5f0a`;
- lightweight six-fold SHA-256:
  `ddf53d18b986468dc9fd63ca27f549a485c4869061c24e39de2cab05d1217c65`.

Thus the loader hardening changes no reported result. Audit artifact:
`artifacts/audits/look_and_tell_leakage_integrity.json`.

## 2026-07-15 - Matched full-frame and selective-coreference controls

We added a label-free field-of-view control to the fixed six-fold protocol.
The complete 1408x1408 frame is resized to the same 128x128 descriptor input
used for every crop; feature dimension, original fixation metadata, training
preprocessing, classifier, folds, and seed remain identical. Only the visible
field of view changes. All 2,330 predictions remain out of fold.

| Model | Accuracy | Participant-bootstrap 95% CI | Macro F1 | Coref. acc. |
|---|---:|---:|---:|---:|
| Text + history | 80.64% | 78.55--82.83% | 70.01% | 50.43% |
| + center crop | 82.15% | 80.24--84.16% | 71.73% | 52.64% |
| + full frame | **82.88%** | 81.00--84.85% | **72.23%** | **55.88%** |
| + gaze crop | 81.85% | 79.79--84.12% | 68.96% | 52.98% |
| + shuffled fixation | 81.76% | 79.78--83.81% | 71.73% | 53.49% |

Full-frame fusion improves over text+history by +2.23 points (95% CI +1.08
to +3.51) and over gaze crops by +1.03 points (+0.08 to +1.93). The clean
field-of-view contrast is strongest on the 587 pronoun/coreference rows:
full frame exceeds center by +3.24 points (95% CI +0.90 to +5.52) and text by
+5.45 points (+2.11 to +9.19). It beats text+history in all six folds and is
better than center in three folds and tied in three. Full frame repairs 86 text
errors and breaks 34 text successes, a net +52 correct predictions.

Out-of-fold confidence was also sliced without refitting. The retrospective
5%-error risk--coverage envelope retains 93.63% of 1,743 explicit mentions but
only 4.09% of 587 coreference mentions; coreference AURC is 25.63%, versus
1.19% for explicit mentions. These values diagnose ranking and do not define a
deployment threshold. The existing validation-selected threshold remains the
only threshold applied unchanged to a locked test set.

Artifact: `artifacts/baselines/look_and_tell_gaze_location_crossval.json`.
