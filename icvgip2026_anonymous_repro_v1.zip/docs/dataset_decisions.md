# Dataset decision record

Frozen: 2026-07-12. Revisit only if a feasibility gate fails or an upstream
release changes materially.

## Selected

### Look and Tell / KTH-ARIA Referential (late 2025)

Role: primary real smart-glasses gaze-speech grounding benchmark.

Why selected: real Meta Aria ego video, gaze, word timestamps, natural explicit
and coreferential references, permissive access without credentials, and only
about 3.7 hours of ego video. The original paper reports descriptive synchrony
analysis and an annotation pipeline, not learned grounding benchmark results.

Verified locally: 2,596 downloadable reference rows, of which 2,376 have a
non-empty target label, including 595 pronoun/coreference rows; we also verified
successful decoding/alignment of a 1,408 x 1,408
pilot recording. License: CC BY-NC-ND 4.0; do not redistribute derived frames.

Source: https://huggingface.co/datasets/annadeichler/KTH-ARIA-referential

### AI2-THOR (attempted, not used for reported results)

Role: attempted controlled smart-home benchmark; dropped from the reported
evaluation after the rendering feasibility gate failed.

Why selected: exact object instance, visibility, capability and state labels;
controllable lamps, televisions, switches, laptops and other appliances; and
counterfactual actions can be generated without physical hardware.

Verified constraint: rendering is unsupported on native Windows. Nine private
Kaggle runs packaged AI2-THOR 5.0 and a SHA-verified Vulkan loader; even the run
explicitly requesting a T4 exposed no NVIDIA Vulkan ICD and Unity aborted before
rendering. No simulator result is claimed.

Source: https://ai2thor.allenai.org/

### HD-EPIC (CVPR 2025; gaze update January 2026)

Role: optional real-home transfer/stress test, not a command dataset.

Why selected: real Aria video in nine homes, gaze, 3D fixtures, object movements,
and detailed action narrations. The local annotation audit found 808
control-like appliance narrations across 106 videos and all nine participants:
437 open, 369 close and two switch pairs. These are observed physical actions,
primarily taps, fridges and dishwashers, not spoken IoT commands.

License: CC BY-NC 4.0. Full MP4 media is 115.5 GB, so only a predeclared
recording subset may be downloaded if the core experiments finish early.

Sources: https://hd-epic.github.io/site/ and
https://github.com/hd-epic/hd-epic-annotations

## Auxiliary only

### ALFRED (2020)

Role: human-instruction language sanity check. It has 794 audited toggle
trajectories but only DeskLamp/FloorLamp targets for this task. It is too old and
narrow to be the headline dataset.

### VirtualHome

Role: dropped. It does not strengthen the current selective reference-resolution
claim enough to justify its replay and archive cost.

## Considered but not selected for core experiments

### Wearable AI Dataset (ECCV 2026)

This is newer and highly relevant to wearable assistants, but it is access-gated,
contains 340 GB of media, and focuses on long-video QA/conversation/proactivity
rather than gaze-grounded device state control. The 25 MB annotations may be
used only for related-work context unless the human authors independently accept
the Hugging Face access conditions.

Source: https://huggingface.co/datasets/facebook/wearable-ai

### TEACh

The documented public S3 archives returned HTTP 403 during verification. TEACh
is therefore not treated as reproducibly downloadable for this project.

## Selection principle

"Latest" is not treated as a sufficient reason by itself. A dataset must add a
needed label or evaluation setting and be downloadable, licensed for academic
use, computationally affordable, and compatible with the remaining schedule.
