# SchemaMem: CODS 2026 Research Workspace

This workspace contains a falsification-driven study of persistent data-agent
memory under database schema evolution. The current executable benchmark has
988 validated rename cases, 397 validated table-split cases, and 397 validated
table-merge-direction cases. An expanded
113-target Qwen-7B downstream study compares no memory, stale memory, version
filtering, an oracle repaired-memory upper bound, and the actual runtime policy;
a 36-target Mistral-7B run provides an independent-family directional control.
A separate 450-case lifecycle suite tests safe reuse/repair against ambiguity,
drops, and unknown changes.
An executable multi-version suite composes split, rename, and consolidation
into 397 three-transition lifecycles (1,191 transitions); SchemaMem is correct
through all declared transitions, while stale programs survive 46.3% of
transitions and 31.0% of complete lifecycles. A separate diagnostic suite
replays 26 commit-pinned migration cases from 21 files in seven public
repositories on constructed SQLite fixtures; it is not presented as a
production workload.
The frozen serial tool-agent expansion contains 78 paired targets over 11
databases. Runtime-policy memory reaches 35.9% execution accuracy, versus 33.3%
with no memory, 32.1% with filtering, and 30.8% with stale, forced
re-exploration, or failure-triggered execution-guided memory. Policy improves
four targets and degrades none relative to stale and execution-guided memory
(+5.1 points), but the database-clustered intervals touch zero and the exact
cluster sign-flip p-value is 0.25. Including maintenance, the execution-guided
baseline costs 9.56 model calls, 9.03 tool calls, and 5.47k tokens per target,
versus 5.68, 4.81, and 3.28k for the runtime policy; its maintenance audit finds
six silently wrong executable repairs. The original 22-target run remains a
separate pilot.

A preregistered external transfer test uses Dr.Spider's independently authored
schema synonym/abbreviation pairs: 32 affected-memory targets over 16 base
databases. Runtime-policy memory reaches 75.0% accuracy versus 43.8% stale,
50.0% no memory, 53.1% execution-guided maintenance, and 78.1% gold repair.
Policy gains over stale and no memory have database-cluster sign-flip p=0.0156;
the +21.9-point primary comparison with execution-guided memory remains
directional (cluster p=0.148). SchemaMem returns 25 memories, all semantically
correct, while execution-guided maintenance produces 19/32 correct memories and
eight silently wrong executable repairs. Including maintenance, SchemaMem uses
57.0% fewer tokens (2.00k versus 4.64k).

A preregistered component audit separates rewriting, schema validation,
execution validation, and ambiguity handling over all 1,782 compatible cases
and the 450-case uncertainty suite. The frozen flat validator conservatively
returned 1,744/1,782 compatible repairs; a generic, preregistered scope-aware
refinement recovered all 38 derived-scope false rejections with 1,782/1,782
correct repairs and 0/250 unsafe ambiguity returns. The corresponding adaptive
Dr.Spider rerun returns 26/26 semantically correct memories but leaves downstream
accuracy unchanged at 24/32 (75.0%), so the refinement is reported as coverage,
not an accuracy gain. A DuckDB 1.5.4 diagnostic independently parses, plans, and
executes translated queries for 1,318 eligible cases across all 11 databases;
all 1,318 repairs remain result-equivalent. This scanner-backed test is a
portability diagnostic, not a production concurrency claim.

## Current reproducible pipeline

1. Install Python dependencies:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
   ```

2. Obtain BIRD Mini-Dev from its official repository/package and place it under
   `data/bird-mini-dev/package/minidev/MINIDEV`.

3. Build and validate the executable migration suites:

   ```powershell
   $env:PYTHONPATH = "src"
   .\.venv\Scripts\python.exe -m schemamem.build_benchmark
   .\.venv\Scripts\python.exe -m schemamem.revalidate_benchmark
   .\.venv\Scripts\python.exe -m schemamem.split_benchmark
   .\.venv\Scripts\python.exe -m schemamem.merge_benchmark
   .\.venv\Scripts\python.exe -m schemamem.multiversion_benchmark
   .\.venv\Scripts\python.exe -m schemamem.real_migration_benchmark --verify-sources
   .\.venv\Scripts\python.exe -m schemamem.build_ambiguity_benchmark --per-class 50
   ```

4. Evaluate deterministic policies:

   ```powershell
   .\.venv\Scripts\python.exe -m schemamem.evaluate_benchmark
   .\.venv\Scripts\python.exe -m schemamem.statistics
   .\.venv\Scripts\python.exe -m schemamem.evaluate_split
   .\.venv\Scripts\python.exe -m schemamem.evaluate_merge
   .\.venv\Scripts\python.exe -m schemamem.multiversion_statistics
   .\.venv\Scripts\python.exe -m schemamem.evaluate_ambiguity
   .\.venv\Scripts\python.exe -m schemamem.measure_policy_overhead --repeats 20
   .\.venv\Scripts\python.exe -m schemamem.audit_evoschema
   .\.venv\Scripts\python.exe -m schemamem.component_ablation --validator legacy_flat --output results\schemamem\component_ablation.json --instances-output results\schemamem\component_ablation.instances.json
   .\.venv\Scripts\python.exe -m schemamem.component_ablation --validator current --output results\schemamem\component_ablation_scope_refined.json --instances-output results\schemamem\component_ablation_scope_refined.instances.json
   .\.venv\Scripts\python.exe -m schemamem.duckdb_portability --validator legacy_flat
   .\.venv\Scripts\python.exe -m schemamem.qualitative_failure_examples
   ```

5. Run tests:

   ```powershell
   .\.venv\Scripts\python.exe -m pytest -q
   ```

6. Generate figures and audit reported claims:

   ```powershell
   .\.venv\Scripts\python.exe scripts\plot_schemamem_results.py
   .\.venv\Scripts\python.exe scripts\plot_system_overview.py
   .\.venv\Scripts\python.exe scripts\plot_multiversion_results.py
   .\.venv\Scripts\python.exe scripts\plot_tool_agent_results.py
   .\.venv\Scripts\python.exe scripts\plot_external_replication.py
   .\.venv\Scripts\python.exe scripts\verify_paper_claims.py
   .\.venv\Scripts\python.exe scripts\verify_bibliography.py --online
   ```

7. Run the downstream paired analysis with the appropriate local model server:

   ```powershell
   .\.venv\Scripts\python.exe -m schemamem.agent_experiment --per-stratum 3 --model-label qwen2.5-coder-7b-q4 --workers 1 --output results\schemamem\agent_runs_7b.jsonl
   .\.venv\Scripts\python.exe -m schemamem.agent_statistics --runs results\schemamem\agent_runs_7b.jsonl --output results\schemamem\agent_statistics_7b_clustered.json
   ```

8. Audit source annotations and run direct LLM memory repair through an
   OpenAI-compatible local inference server:

   ```powershell
   .\.venv\Scripts\python.exe -m schemamem.audit_evoschema
   .\.venv\Scripts\python.exe -m schemamem.llm_repair_experiment --scenarios column_rename table_rename table_split --per-scenario 20 --model-label qwen2.5-coder-7b-q4 --output results\schemamem\llm_repair_runs_7b.jsonl
   .\.venv\Scripts\python.exe -m schemamem.llm_repair_statistics results\schemamem\llm_repair_runs_7b.jsonl --output results\schemamem\llm_repair_7b_expanded.statistics.json
   .\.venv\Scripts\python.exe -m schemamem.llm_repair_experiment --scenarios table_merge --per-scenario 20 --model-label qwen2.5-coder-7b-q4 --output results\schemamem\llm_repair_runs_qwen7_merge.jsonl
   .\.venv\Scripts\python.exe -m schemamem.llm_gate_experiment --per-class 10 --prompt-mode conservative --model-label qwen2.5-coder-7b-q4 --output results\schemamem\llm_gate_runs_7b.jsonl
   .\.venv\Scripts\python.exe -m schemamem.error_taxonomy results\schemamem\llm_repair_runs_7b.jsonl --output results\schemamem\llm_repair_7b_expanded.errors.json
   ```

9. Run the genuine schema-inspection / SQL-execution agent protocol on the
   frozen different-question targets:

   ```powershell
   .\.venv\Scripts\python.exe -m schemamem.tool_agent_experiment --model-label qwen2.5-coder-7b-q4-expanded-v4 --targets data\schemamem-agent-targets-expanded78.json --max-calls 8 --workers 1 --output results\schemamem\tool_agent_runs_qwen7_v4_expanded.jsonl
   .\.venv\Scripts\python.exe -m schemamem.tool_agent_statistics --runs results\schemamem\tool_agent_runs_qwen7_v4_expanded.jsonl --conditions no_memory stale_memory version_filter reexplore_on_change execution_guided_memory schema_aware_memory policy_memory --output results\schemamem\tool_agent_runs_qwen7_v4_expanded.statistics.json
   .\.venv\Scripts\python.exe -m schemamem.execution_guided_statistics --runs results\schemamem\tool_agent_runs_qwen7_v4_expanded.jsonl --output results\schemamem\tool_agent_runs_qwen7_v4_expanded.maintenance.json
   .\.venv\Scripts\python.exe -m schemamem.verify_tool_agent_run --runs results\schemamem\tool_agent_runs_qwen7_v4_expanded.jsonl --targets data\schemamem-agent-targets-expanded78.json --conditions no_memory stale_memory version_filter reexplore_on_change execution_guided_memory schema_aware_memory policy_memory --output results\schemamem\tool_agent_runs_qwen7_v4_expanded.integrity.json
   ```

   The expanded protocol adds all 56 affected-memory pairs, two seeded
   unaffected controls per database, and a failure-triggered execution-guided
   maintenance baseline. Its exact command and hash are recorded in
   `research/expanded_tool_protocol.md` and `ARTIFACT.md`.

   This primary run is deliberately serial. Rows from the discarded
   two-slot throughput diagnostic are kept separate because concurrent decoding
   was not deterministic for identical prompts.

10. Rebuild and audit the preregistered Dr.Spider transfer after obtaining the
    official Dr.Spider and Spider archives:

    ```powershell
    .\.venv\Scripts\python.exe -m schemamem.build_drspider_benchmark --drspider <extracted-drspider-data> --spider-databases <extracted-spider-database-dir> --output data\schemamem-drspider-v1 --targets-output data\schemamem-drspider-targets-v1.json
    .\.venv\Scripts\python.exe -m schemamem.verify_tool_agent_run --runs results\schemamem\tool_agent_runs_qwen7_drspider_v1.jsonl --targets data\schemamem-drspider-targets-v1.json --conditions no_memory stale_memory execution_guided_memory schema_aware_memory policy_memory --output results\schemamem\tool_agent_runs_qwen7_drspider_v1.integrity.json
    .\.venv\Scripts\python.exe -m schemamem.tool_agent_statistics --runs results\schemamem\tool_agent_runs_qwen7_drspider_v1.jsonl --conditions no_memory stale_memory execution_guided_memory schema_aware_memory policy_memory --output results\schemamem\tool_agent_runs_qwen7_drspider_v1.statistics.json
    .\.venv\Scripts\python.exe -m schemamem.execution_guided_statistics --runs results\schemamem\tool_agent_runs_qwen7_drspider_v1.jsonl --benchmark data\schemamem-drspider-v1 --output results\schemamem\tool_agent_runs_qwen7_drspider_v1.execution_guided_audit.json
    .\.venv\Scripts\python.exe -m schemamem.policy_memory_statistics --runs results\schemamem\tool_agent_runs_qwen7_drspider_v1.jsonl --benchmark data\schemamem-drspider-v1 --output results\schemamem\tool_agent_runs_qwen7_drspider_v1.policy_audit.json
    .\.venv\Scripts\python.exe -m schemamem.maintenance_outcome_analysis --runs results\schemamem\tool_agent_runs_qwen7_drspider_v1.jsonl --maintenance-audit results\schemamem\tool_agent_runs_qwen7_drspider_v1.execution_guided_audit.json --output results\schemamem\tool_agent_runs_qwen7_drspider_v1.maintenance_outcomes.json
    .\.venv\Scripts\python.exe -m schemamem.verify_tool_agent_run --runs results\schemamem\tool_agent_runs_qwen7_drspider_scope_refined_v2.jsonl --targets data\schemamem-drspider-targets-v1.json --conditions policy_memory --output results\schemamem\tool_agent_runs_qwen7_drspider_scope_refined_v2.integrity.json
    .\.venv\Scripts\python.exe -m schemamem.policy_memory_statistics --runs results\schemamem\tool_agent_runs_qwen7_drspider_scope_refined_v2.jsonl --benchmark data\schemamem-drspider-v1 --output results\schemamem\tool_agent_runs_qwen7_drspider_scope_refined_v2.policy_audit.json
    .\.venv\Scripts\python.exe -m schemamem.scope_refinement_statistics
    ```

    The exact inference command and all pre-outcome rules are frozen in
    `research/drspider_preregistration.md`. The factorized audit, validator
    refinement, adaptive rerun, and portability rules are separately frozen in
    `research/ablation_portability_preregistration.md` and
    `research/scope_validator_refinement.md`. The supplement includes derived
    JSON metadata and sanitized run traces but not the third-party SQLite
    databases.

The local experiments use `llama-server` with Qwen2.5-Coder-1.5B-Instruct and
7B-Instruct Q4, Mistral-7B-Instruct-v0.3 Q4 as an independent-family control,
and an exploratory Qwen2.5-Coder-14B Q3 scale control. Inference uses the Vulkan
backend on an RTX 2060; the 14B model is partially CPU-offloaded. Model weights
and inference binaries are intentionally excluded from version control.

The exact 22-target 14B tool control is a negative robustness result: runtime
policy and builder repair reach 45.5% execution accuracy, stale memory,
filtering, and re-exploration reach 50.0%, and execution-guided memory and no
memory reach 40.9%. Policy versus stale has one improvement and two
degradations; its database-cluster interval is [-18.2, 9.1] points with
sign-flip p=1.0. Different quantization and partial CPU offload preclude a clean
scaling interpretation.

## Research-integrity notes

- No proprietary product data, code, architecture, or metrics are used.
- EvoSchema's released labels are not treated as executable ground truth.
- A candidate transformation is retained only after result-equivalence checks on
  physically migrated databases.
- Benchmark construction and the runtime lifecycle policy use independent
  rewrite implementations; ambiguity results are not a shared-code-path test.
- Generative AI materially assisted this project. A disclosure is included in
  the paper draft, and human authors remain responsible for every claim.
