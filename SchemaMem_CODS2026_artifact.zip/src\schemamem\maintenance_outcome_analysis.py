"""Relate stored-memory maintenance correctness to downstream agent outcomes."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--maintenance-audit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.runs.read_text(encoding="utf-8").splitlines()]
    audit = json.loads(args.maintenance_audit.read_text(encoding="utf-8"))
    maintenance = {
        (row["scenario"], row["db_id"], row["target_question_id"]): row
        for row in audit["instances"]
    }
    grouped: dict[bool, list[dict]] = defaultdict(list)
    instances = []
    for row in rows:
        if row["condition"] != "execution_guided_memory":
            continue
        key = (row["scenario"], row["db_id"], row["question_id"])
        memory = maintenance[key]
        item = {
            "scenario": row["scenario"],
            "db_id": row["db_id"],
            "cluster_id": row.get("cluster_id", row["db_id"]),
            "question_id": row["question_id"],
            "maintenance_correct": memory["maintenance_correct"],
            "maintenance_executable": memory["maintenance_exec_ok"],
            "downstream_correct": row["correct"],
        }
        grouped[item["maintenance_correct"]].append(item)
        instances.append(item)

    def summarize(group: list[dict]) -> dict:
        downstream_correct = sum(row["downstream_correct"] for row in group)
        return {
            "n": len(group),
            "downstream_correct": downstream_correct,
            "downstream_accuracy": downstream_correct / len(group) if group else None,
        }

    report = {
        "maintenance_correct": summarize(grouped[True]),
        "maintenance_incorrect_or_failed": summarize(grouped[False]),
        "analysis_note": (
            "post-hoc mechanism analysis; maintenance semantics are scored with gold "
            "only after the frozen downstream run"
        ),
        "instances": instances,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "instances"}, indent=2))


if __name__ == "__main__":
    main()
