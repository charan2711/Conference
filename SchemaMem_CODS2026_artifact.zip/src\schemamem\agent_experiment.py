"""Downstream experiment: different-query procedural memories after migration."""

from __future__ import annotations

import argparse
import json
import random
import re
import sqlite3
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .build_benchmark import execute, result_equivalent, sqlite_schema
from .memory_policy import decide_rename


def identifiers(sql: str) -> tuple[set[str], set[str]]:
    import sqlglot
    from sqlglot import exp

    tree = sqlglot.parse_one(sql, read="sqlite")
    return (
        {table.name.casefold() for table in tree.find_all(exp.Table)},
        {column.name.casefold() for column in tree.find_all(exp.Column)},
    )


def jaccard(left: set, right: set) -> float:
    return len(left & right) / len(left | right) if left | right else 0.0


def pair_memories(group: list[dict]) -> dict[int, dict]:
    texts = [row["question"] for row in group]
    similarities = cosine_similarity(TfidfVectorizer().fit_transform(texts))
    deps = [identifiers(row["old_sql"]) for row in group]
    pairs = {}
    for i, target in enumerate(group):
        best_score, best = -1.0, None
        for j, candidate in enumerate(group):
            if i == j:
                continue
            table_score = jaccard(deps[i][0], deps[j][0])
            column_score = jaccard(deps[i][1], deps[j][1])
            score = 2.0 * table_score + column_score + 0.25 * similarities[i, j]
            if score > best_score:
                best_score, best = score, candidate
        pairs[target["question_id"]] = {**best, "retrieval_score": best_score}
    return pairs


def ddl_for(path: Path, sqls: list[str]) -> str:
    table_names = set()
    for sql in sqls:
        try:
            table_names |= identifiers(sql)[0]
        except Exception:
            pass
    with sqlite3.connect(path) as conn:
        names = [
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            )
            if row[0].casefold() in table_names
        ]
        selected = []
        for name in names:
            columns = [row[1] for row in conn.execute(f'PRAGMA table_info("{name}")')]
            selected.append(f'{name}({", ".join(columns)})')
    return "\n".join(selected)


def prompt(target: dict, schema: str, memory: dict | None, memory_sql: str | None) -> list[dict]:
    memory_text = "No prior procedural memory is available."
    if memory and memory_sql:
        memory_text = (
            "A previously successful trajectory for a DIFFERENT question is available. "
            "Use it only as a structural example and adapt it to the current question and schema.\n"
            f"Previous question: {memory['question']}\n"
            f"Previous successful SQL: {memory_sql}"
        )
    user = f"""Current SQLite schema:
{schema}

{memory_text}

Current question: {target['question']}
Domain evidence: {target.get('evidence', '')}

Return one executable SQLite SELECT query for the current question. Return SQL only."""
    return [
        {
            "role": "system",
            "content": (
                "You are a careful data agent. Ground every identifier in the current schema. "
                "A prior memory may be absent, useful, or stale. Return only SQL without markdown."
            ),
        },
        {"role": "user", "content": user},
    ]


def call_model(url: str, messages: list[dict], max_tokens: int) -> str:
    response = requests.post(
        url,
        json={
            "model": "local",
            "messages": messages,
            "temperature": 0,
            "max_tokens": max_tokens,
            "seed": 42,
        },
        timeout=180,
    )
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"].strip()


def extract_sql(text: str) -> str:
    fenced = re.search(r"```(?:sql)?\s*(.*?)```", text, flags=re.I | re.S)
    if fenced:
        text = fenced.group(1).strip()
    match = re.search(r"\b(?:SELECT|WITH)\b.*", text, flags=re.I | re.S)
    return match.group(0).strip() if match else text.strip()


def summarize(rows: list[dict]) -> dict:
    report = {"n_runs": len(rows), "conditions": {}}
    for condition in sorted({row["condition"] for row in rows}):
        group = [row for row in rows if row["condition"] == condition]
        report["conditions"][condition] = {
            "n": len(group),
            "execution_accuracy": sum(row["correct"] for row in group) / len(group),
            "valid_sql_rate": sum(row["exec_ok"] for row in group) / len(group),
            "mean_output_chars": sum(len(row["prediction"]) for row in group) / len(group),
        }
        provided = [row for row in group if "memory_provided" in row]
        if provided:
            report["conditions"][condition]["memory_provided_rate"] = sum(
                row["memory_provided"] for row in provided
            ) / len(provided)
        for status in (True, False):
            subset = [row for row in group if row["memory_affected"] is status]
            if subset:
                report["conditions"][condition][f"memory_affected_{status}"] = {
                    "n": len(subset),
                    "execution_accuracy": sum(row["correct"] for row in subset) / len(subset),
                }
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", type=Path, default=Path("data/schemamem-bench-v1"))
    parser.add_argument(
        "--url", default="http://127.0.0.1:8080/v1/chat/completions"
    )
    parser.add_argument("--per-stratum", type=int, default=2)
    parser.add_argument("--targets", type=Path)
    parser.add_argument("--model-label", default="local-model")
    parser.add_argument("--max-tokens", type=int, default=384)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument(
        "--conditions",
        nargs="+",
        choices=(
            "no_memory",
            "stale_memory",
            "version_filter",
            "schema_aware_memory",
            "policy_memory",
        ),
        default=(
            "no_memory",
            "stale_memory",
            "version_filter",
            "schema_aware_memory",
            "policy_memory",
        ),
        help="Conditions to execute; the default preserves the full current protocol.",
    )
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/agent_runs.jsonl"))
    args = parser.parse_args()
    instances = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    instances = [row for row in instances if row["execution_equivalent"]]
    groups: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in instances:
        groups[(row["scenario"], row["db_id"])].append(row)

    rng = random.Random(42)
    migrations = json.loads((args.benchmark / "migrations.json").read_text(encoding="utf-8"))
    original_root = Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases")
    tasks = []
    if args.targets:
        specs = json.loads(args.targets.read_text(encoding="utf-8"))
        index = {
            (row["scenario"], row["db_id"], row["question_id"]): row
            for row in instances
        }
        for spec in specs:
            prefix = (spec["scenario"], spec["db_id"])
            target = index[(*prefix, spec["question_id"])]
            memory = {
                **index[(*prefix, spec["memory_question_id"])],
                "retrieval_score": spec["retrieval_score"],
            }
            tasks.append((target, memory))
    else:
        for key, group in sorted(groups.items()):
            pairs = pair_memories(group)
            for status in (False, True):
                candidates = [row for row in group if row["affected"] is status]
                rng.shuffle(candidates)
                for target in candidates[: args.per_stratum]:
                    tasks.append((target, pairs[target["question_id"]]))

    completed = set()
    existing = []
    if args.output.exists():
        for line in args.output.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            existing.append(row)
            completed.add((row["scenario"], row["db_id"], row["question_id"], row["condition"]))
    args.output.parent.mkdir(parents=True, exist_ok=True)

    with args.output.open("a", encoding="utf-8") as handle:
        for target, memory in tasks:
            path = (
                args.benchmark
                / "databases"
                / target["scenario"]
                / target["db_id"]
                / f'{target["db_id"]}.sqlite'
            )
            schema = ddl_for(path, [target["new_sql"], memory["new_sql"]])
            gold_ok, gold = execute(path, target["new_sql"])
            if not gold_ok:
                continue
            migration = migrations[target["db_id"]]
            column_candidates = (
                {
                    key: [value]
                    for key, value in migration["column_rename"].items()
                }
                if target["scenario"] == "column_rename"
                else {}
            )
            table_candidates = (
                {
                    key: [value]
                    for key, value in migration["table_rename"].items()
                }
                if target["scenario"] == "table_rename"
                else {}
            )
            manifest = {
                "operator": "rename",
                "write_set": [*column_candidates, *table_candidates],
                "column_candidates": column_candidates,
                "table_candidates": table_candidates,
            }
            old_path = original_root / target["db_id"] / f'{target["db_id"]}.sqlite'
            policy_decision = decide_rename(
                memory["old_sql"],
                sqlite_schema(old_path),
                sqlite_schema(path),
                manifest,
            )
            policy_memory = (
                (memory, policy_decision.sql)
                if policy_decision.action in {"reuse", "migrate"} and policy_decision.sql
                else (None, None)
            )
            conditions = {
                "no_memory": (None, None),
                "stale_memory": (memory, memory["old_sql"]),
                "version_filter": (
                    (None, None) if memory["affected"] else (memory, memory["old_sql"])
                ),
                "schema_aware_memory": (memory, memory["new_sql"]),
                "policy_memory": policy_memory,
            }
            pending = [
                (condition, memory_record, memory_sql)
                for condition, (memory_record, memory_sql) in conditions.items()
                if condition in args.conditions
                if (target["scenario"], target["db_id"], target["question_id"], condition) not in completed
            ]

            def run_condition(item: tuple) -> dict:
                condition, memory_record, memory_sql = item
                raw = call_model(args.url, prompt(target, schema, memory_record, memory_sql), args.max_tokens)
                prediction = extract_sql(raw)
                exec_ok, result = execute(path, prediction)
                return {
                    "model_label": args.model_label,
                    "scenario": target["scenario"],
                    "db_id": target["db_id"],
                    "question_id": target["question_id"],
                    "condition": condition,
                    "target_affected": target["affected"],
                    "memory_question_id": memory["question_id"],
                    "memory_affected": memory["affected"],
                    "memory_provided": memory_record is not None,
                    "policy_action": (
                        policy_decision.action if condition == "policy_memory" else None
                    ),
                    "retrieval_score": memory["retrieval_score"],
                    "prediction": prediction,
                    "exec_ok": exec_ok,
                    "correct": exec_ok and result_equivalent(result, gold, target["new_sql"]),
                    "error": None if exec_ok else result,
                }

            with ThreadPoolExecutor(max_workers=args.workers) as executor:
                futures = [executor.submit(run_condition, item) for item in pending]
                for future in as_completed(futures):
                    row = future.result()
                    handle.write(json.dumps(row) + "\n")
                    handle.flush()
                    existing.append(row)
    report = summarize(existing)
    report["model_label"] = args.model_label
    args.output.with_suffix(".summary.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
