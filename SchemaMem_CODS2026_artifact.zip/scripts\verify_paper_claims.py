"""Audit the quantitative claims reported in the SchemaMem paper.

The paper deliberately reports rounded values.  This script checks the
underlying, unrounded quantities against the frozen result files and writes a
machine-readable audit.  A non-zero exit code means that at least one source
file is missing or a reported claim no longer agrees with its source.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results" / "schemamem"
DATA = ROOT / "data"
BIRD_QUESTIONS = (
    DATA / "bird-mini-dev" / "package" / "minidev" / "MINIDEV"
    / "mini_dev_sqlite.json"
)


def load(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


class Audit:
    def __init__(self) -> None:
        self.checks: list[dict[str, Any]] = []

    def equal(self, claim: str, actual: Any, expected: Any, source: str) -> None:
        passed = actual == expected
        self.checks.append(
            {"claim": claim, "source": source, "actual": actual,
             "expected": expected, "passed": passed}
        )

    def close(
        self,
        claim: str,
        actual: float,
        expected: float,
        source: str,
        *,
        tolerance: float = 1e-12,
    ) -> None:
        passed = math.isclose(actual, expected, rel_tol=0.0, abs_tol=tolerance)
        self.checks.append(
            {"claim": claim, "source": source, "actual": actual,
             "expected": expected, "tolerance": tolerance, "passed": passed}
        )

    def contains(self, claim: str, text: str, fragment: str, source: str) -> None:
        self.equal(claim, fragment in text, True, source)

    def absent(self, claim: str, text: str, fragment: str, source: str) -> None:
        self.equal(claim, fragment not in text, True, source)


def audit_claims() -> Audit:
    audit = Audit()

    baselines = load(RESULTS / "baselines.json")
    baseline_stats = load(RESULTS / "statistics.json")
    src = "results/schemamem/baselines.json"
    audit.equal("rename benchmark size", baselines["n"], 988, src)
    bird = load(BIRD_QUESTIONS)
    src = "data/bird-mini-dev/package/minidev/MINIDEV/mini_dev_sqlite.json"
    audit.equal("BIRD Mini-Dev questions", len(bird), 500, src)
    audit.equal("BIRD Mini-Dev databases", len({row["db_id"] for row in bird}), 11, src)
    src = "results/schemamem/baselines.json"
    for method, expected in {
        "stale_raw": 0.4848178137651822,
        "version_filter": 0.4848178137651822,
        "naive_string": 0.8006072874493927,
        "boundary_string": 0.8917004048582996,
        "schema_aware_repair": 1.0,
    }.items():
        audit.close(
            f"rename accuracy: {method}",
            baselines["methods"][method]["correct_rate"], expected, src,
        )
    for method, coverage, precision in (
        ("global_flush", 0.0, 1.0),
        ("stale_raw", 1.0, 0.4848178137651822),
        ("version_filter", 0.4848178137651822, 1.0),
        ("naive_string", 1.0, 0.8006072874493927),
        ("boundary_string", 1.0, 0.8917004048582996),
        ("schema_aware_repair", 1.0, 1.0),
    ):
        audit.close(f"rename coverage: {method}", baselines["methods"][method]["coverage"], coverage, src)
        audit.close(f"rename precision: {method}", baselines["methods"][method]["precision_when_returned"], precision, src)
    paired = baseline_stats["paired_vs_schema_aware"]["boundary_string"]
    src = "results/schemamem/statistics.json"
    audit.equal("structural vs boundary improvements", paired["improved"], 107, src)
    audit.equal("structural vs boundary degradations", paired["degraded"], 0, src)
    audit.close(
        "structural vs boundary McNemar p",
        paired["exact_mcnemar_p"], 1.2325951644078309e-32, src,
    )

    for filename in ("split_baselines.json", "merge_baselines.json"):
        suite = load(RESULTS / filename)
        src = f"results/schemamem/{filename}"
        audit.equal(f"{filename} size", suite["n"], 397, src)
        audit.close(
            f"{filename} stale accuracy",
            suite["methods"]["stale_raw"]["correct_rate"],
            0.4659949622166247,
            src,
        )
        audit.close(
            f"{filename} structural accuracy",
            suite["methods"]["schema_aware_repair"]["correct_rate"], 1.0, src,
        )

    rename_summary = load(DATA / "schemamem-bench-v1" / "summary.json")
    src = "data/schemamem-bench-v1/summary.json"
    audit.equal("rename candidates", rename_summary["instances"], 1000, src)
    audit.close("rename old-query execution", rename_summary["old_exec_rate"], 0.996, src)
    audit.close("rename migrated-query execution", rename_summary["new_exec_rate"], 0.989, src)
    audit.close("rename result equivalence", rename_summary["equivalence_rate"], 0.988, src)
    audit.close("column-rename affected rate", rename_summary["by_scenario"]["column_rename"]["affected_rate"], 0.472, src)
    audit.close("table-rename affected rate", rename_summary["by_scenario"]["table_rename"]["affected_rate"], 0.566, src)

    split_summary = load(DATA / "schemamem-split-v1" / "summary.json")
    src = "data/schemamem-split-v1/summary.json"
    audit.equal("split databases", split_summary["databases"], 10, src)
    audit.equal("split candidates", split_summary["instances"], 460, src)
    audit.equal("split validated", split_summary["validated"], 397, src)
    audit.close("split validation rate", split_summary["equivalence_rate"], 0.8630434782608696, src)
    split_rows = load(DATA / "schemamem-split-v1" / "instances.json")
    src = "data/schemamem-split-v1/instances.json"
    nested = sum("nested query excluded" in str(row.get("new_error")) for row in split_rows)
    star = sum("star projection excluded" in str(row.get("new_error")) for row in split_rows)
    execution_failures = sum(
        row["old_exec_ok"] and not row["new_exec_ok"] for row in split_rows
    )
    equivalence_failures = sum(
        row["old_exec_ok"] and row["new_exec_ok"] and not row["execution_equivalent"]
        for row in split_rows
    )
    audit.equal("split nested-query exclusions", nested, 52, src)
    audit.equal("split star-projection exclusions", star, 6, src)
    audit.equal("split migrated execution failures", execution_failures, 3, src)
    audit.equal("split executable equivalence failures", equivalence_failures, 2, src)

    multiversion = load(RESULTS / "multiversion_statistics.json")
    src = "results/schemamem/multiversion_statistics.json"
    transition = multiversion["transition_level"]
    lifecycle = multiversion["full_lifecycle"]
    for claim, actual, expected in (
        ("multi-version transitions", transition["n"], 1191),
        ("multi-version transition policy accuracy", transition["treatment_accuracy"], 1.0),
        ("multi-version transition stale accuracy", transition["control_accuracy"], 0.4634760705289673),
        ("multi-version transition cluster CI low", transition["cluster_bootstrap_95"][0], 0.46717817561807334),
        ("multi-version transition cluster CI high", transition["cluster_bootstrap_95"][1], 0.5949934086403649),
        ("multi-version lifecycles", lifecycle["n"], 397),
        ("multi-version lifecycle policy accuracy", lifecycle["treatment_accuracy"], 1.0),
        ("multi-version lifecycle stale accuracy", lifecycle["control_accuracy"], 0.30982367758186397),
        ("multi-version lifecycle cluster CI low", lifecycle["cluster_bootstrap_95"][0], 0.6165787824598407),
        ("multi-version lifecycle cluster CI high", lifecycle["cluster_bootstrap_95"][1], 0.760564258368164),
        ("multi-version transition sign-flip p", transition["cluster_signflip_p"], 0.001953125),
        ("multi-version lifecycle sign-flip p", lifecycle["cluster_signflip_p"], 0.001953125),
    ):
        if isinstance(expected, int):
            audit.equal(claim, actual, expected, src)
        else:
            audit.close(claim, actual, expected, src)

    real = load(DATA / "schemamem-real-migrations-v1" / "summary.json")
    src = "data/schemamem-real-migrations-v1/summary.json"
    for claim, key, expected in (
        ("public migration cases", "cases", 26),
        ("public migration repositories", "repositories", 7),
        ("public migration source files", "unique_source_files", 21),
        ("public migration verified files", "source_files_verified", 21),
        ("public migration policy decisions", "policy_decisions_correct", 26),
        ("public migration stale outcomes", "stale_outcomes_correct", 3),
    ):
        audit.equal(claim, real[key], expected, src)
    audit.equal("public column renames", real["by_operator"]["column_rename"]["n"], 14, src)
    audit.equal("public table renames", real["by_operator"]["table_rename"]["n"], 7, src)
    audit.equal("public destructive events", real["by_operator"]["drop_add"]["n"], 2, src)
    audit.equal(
        "public non-schema events",
        real["by_operator"]["metadata_only"]["n"] + real["by_operator"]["value_only"]["n"],
        3,
        src,
    )

    ambiguity = load(RESULTS / "ambiguity.json")
    src = "results/schemamem/ambiguity.json"
    audit.equal("ambiguity suite size", ambiguity["n"], 450, src)
    schemamem = ambiguity["policies"]["schemamem"]
    audit.close("safe coverage", schemamem["safe_case_coverage"], 0.985, src)
    audit.close("safe coverage Wilson low", schemamem["safe_case_coverage_95ci"][0], 0.9568342712073097, src)
    audit.close("safe coverage Wilson high", schemamem["safe_case_coverage_95ci"][1], 0.9948857622067417, src)
    audit.close("unsafe return rate", schemamem["unsafe_return_rate"], 0.0, src)
    audit.close("unsafe Wilson upper bound", schemamem["unsafe_return_rate_95ci"][1], 0.015133299495444574, src)
    audit.equal("safe cases returned", round(200 * schemamem["safe_case_coverage"]), 197, src)
    audit.equal("unsafe cases returned", round(250 * schemamem["unsafe_return_rate"]), 0, src)
    audit.close("version-filter safe coverage", ambiguity["policies"]["version_filter"]["safe_case_coverage"], 0.25, src)
    audit.close("optimistic unsafe return", ambiguity["policies"]["optimistic_reuse"]["unsafe_return_rate"], 1.0, src)

    evoschema = load(RESULTS / "evoschema_audit.json")
    src = "results/schemamem/evoschema_audit.json"
    audit.equal(
        "EvoSchema literal mutations",
        evoschema["rename_columns"]["literal_mutation_count"]
        + evoschema["rename_tables"]["literal_mutation_count"],
        14,
        src,
    )
    audit.equal("EvoSchema unique column mappings", evoschema["rename_columns"]["unique_column_mappings"], 885, src)
    audit.equal("EvoSchema mapped names absent from new DDL", evoschema["rename_columns"]["unique_mapped_name_missing_from_new_ddl"], 115, src)
    audit.equal("EvoSchema retained old names", evoschema["rename_columns"]["unique_old_name_retained_in_new_ddl"], 61, src)

    repair_specs = (
        ("llm_repair_1.5b.statistics.json", 15, 5, 10, 5, 0, 0.0625),
        ("llm_repair_7b_expanded.statistics.json", 58, 46, 47, 4, 3, 1.0),
        ("llm_repair_mistral7.statistics.json", 29, 16, 22, 6, 0, 0.03125),
        ("llm_repair_14b.statistics.json", 15, 13, 14, 1, 0, 1.0),
        ("llm_repair_runs_qwen7_merge.statistics.json", 20, 16, 18, 2, 0, 0.5),
        ("llm_repair_runs_mistral7_merge.statistics.json", 20, 12, 14, 2, 0, 0.5),
    )
    for filename, n, schema, manifest, improved, degraded, p_value in repair_specs:
        values = load(RESULTS / filename)["all"]
        src = f"results/schemamem/{filename}"
        audit.equal(f"{filename}: n", values["n"], n, src)
        audit.equal(f"{filename}: schema-only correct", values["schema_only_correct"], schema, src)
        audit.equal(f"{filename}: manifest correct", values["manifest_correct"], manifest, src)
        audit.equal(f"{filename}: improvements", values["improved"], improved, src)
        audit.equal(f"{filename}: degradations", values["degraded"], degraded, src)
        audit.close(f"{filename}: McNemar p", values["exact_mcnemar_p"], p_value, src)

    q7_repair = load(RESULTS / "llm_repair_7b_expanded.statistics.json")
    src = "results/schemamem/llm_repair_7b_expanded.statistics.json"
    audit.equal("Qwen-7B table renames schema-only", q7_repair["by_scenario"]["table_rename"]["schema_only_correct"], 19, src)
    audit.equal("Qwen-7B table renames manifest", q7_repair["by_scenario"]["table_rename"]["manifest_correct"], 19, src)
    audit.equal("Qwen-7B splits schema-only", q7_repair["by_scenario"]["table_split"]["schema_only_correct"], 10, src)
    audit.equal("Qwen-7B splits manifest", q7_repair["by_scenario"]["table_split"]["manifest_correct"], 9, src)
    q7_errors = load(RESULTS / "llm_repair_7b_expanded.errors.json")["overall"]
    src = "results/schemamem/llm_repair_7b_expanded.errors.json"
    audit.equal("Qwen-7B unknown-column failures", q7_errors["unknown_column"], 20, src)
    audit.equal("Qwen-7B silent-wrong failures", q7_errors["silent_wrong_result"], 3, src)
    mistral_repair = load(RESULTS / "llm_repair_mistral7.statistics.json")
    src = "results/schemamem/llm_repair_mistral7.statistics.json"
    audit.equal("Mistral-7B manifest split repairs", mistral_repair["by_scenario"]["table_split"]["manifest_correct"], 6, src)
    q14_errors = load(RESULTS / "llm_repair_14b.errors.json")["groups"]
    src = "results/schemamem/llm_repair_14b.errors.json"
    audit.equal("Qwen-14B schema-only silent wrong", q14_errors["schema_only"]["categories"]["silent_wrong_result"], 1, src)
    audit.equal("Qwen-14B manifest silent wrong", q14_errors["explicit_manifest"]["categories"]["silent_wrong_result"], 1, src)
    for filename in ("llm_repair_runs_qwen7_merge.errors.json", "llm_repair_runs_mistral7_merge.errors.json"):
        errors = load(RESULTS / filename)["groups"]["explicit_manifest"]["categories"]
        src = f"results/schemamem/{filename}"
        audit.equal(f"{filename}: manifest silent wrong", errors["silent_wrong_result"], 1, src)

    for filename, safe_coverage, unsafe_rate in (
        ("llm_gate_runs_7b.summary.json", 0.0, 0.0),
        ("llm_gate_runs_7b_balanced.summary.json", 1 / 30, 0.0),
        ("llm_gate_runs_7b_structured.summary.json", 0.3, 1.0),
    ):
        gate = load(RESULTS / filename)
        src = f"results/schemamem/{filename}"
        audit.equal(f"{filename}: n", gate["n"], 70, src)
        audit.close(f"{filename}: safe correct coverage", gate["safe_correct_coverage"], safe_coverage, src)
        audit.close(f"{filename}: unsafe return", gate["unsafe_return_rate"], unsafe_rate, src)

    q7_agent = load(RESULTS / "agent_runs_7b.summary.json")
    src = "results/schemamem/agent_runs_7b.summary.json"
    for condition, expected in {
        "policy_memory": 0.4690265486725664,
        "schema_aware_memory": 0.4778761061946903,
        "stale_memory": 0.37168141592920356,
        "no_memory": 0.36283185840707965,
        "version_filter": 0.415929203539823,
    }.items():
        values = q7_agent["conditions"][condition]
        audit.equal(f"Qwen-7B agent {condition}: n", values["n"], 113, src)
        audit.close(f"Qwen-7B agent {condition}: accuracy", values["execution_accuracy"], expected, src)
    audit.close("Qwen-7B policy memory provided", q7_agent["conditions"]["policy_memory"]["memory_provided_rate"], 0.9646017699115044, src)
    audit.close("Qwen-7B affected policy accuracy", q7_agent["conditions"]["policy_memory"]["memory_affected_True"]["execution_accuracy"], 0.44642857142857145, src)
    audit.close("Qwen-7B affected stale accuracy", q7_agent["conditions"]["stale_memory"]["memory_affected_True"]["execution_accuracy"], 0.25, src)
    audit.close("Qwen-7B unaffected policy accuracy", q7_agent["conditions"]["policy_memory"]["memory_affected_False"]["execution_accuracy"], 0.49122807017543857, src)
    audit.close("Qwen-7B unaffected stale accuracy", q7_agent["conditions"]["stale_memory"]["memory_affected_False"]["execution_accuracy"], 0.49122807017543857, src)

    pilot_agent = load(RESULTS / "agent_runs.summary.json")
    src = "results/schemamem/agent_runs.summary.json"
    for condition, expected in {
        "no_memory": 0.2571428571428571,
        "stale_memory": 0.2571428571428571,
        "version_filter": 0.2857142857142857,
        "schema_aware_memory": 0.2857142857142857,
    }.items():
        audit.equal(f"Qwen-1.5B downstream {condition}: n", pilot_agent["conditions"][condition]["n"], 35, src)
        audit.close(f"Qwen-1.5B downstream {condition}: accuracy", pilot_agent["conditions"][condition]["execution_accuracy"], expected, src)

    q7_stats = load(RESULTS / "agent_statistics_7b_clustered.json")["comparisons"]["all"]["policy_vs_stale"]
    src = "results/schemamem/agent_statistics_7b_clustered.json"
    for claim, key, expected in (
        ("Qwen-7B policy-stale paired difference", "paired_difference", 0.09734513274336283),
        ("Qwen-7B policy-stale improvements", "improved", 12),
        ("Qwen-7B policy-stale degradations", "degraded", 1),
        ("Qwen-7B policy-stale McNemar p", "exact_mcnemar_p", 0.00341796875),
        ("Qwen-7B policy-stale cluster sign-flip p", "cluster_signflip_p", 0.03125),
    ):
        if isinstance(expected, int):
            audit.equal(claim, q7_stats[key], expected, src)
        else:
            audit.close(claim, q7_stats[key], expected, src)
    for index, expected in enumerate((0.04424778761061947, 0.1592920353982301)):
        audit.close(f"Qwen-7B policy-stale target CI {index}", q7_stats["paired_bootstrap_95"][index], expected, src)
    for index, expected in enumerate((0.034782608695652174, 0.1693548387096774)):
        audit.close(f"Qwen-7B policy-stale cluster CI {index}", q7_stats["cluster_bootstrap_95"][index], expected, src)
    q7_no_memory = load(RESULTS / "agent_statistics_7b_expanded.json")["comparisons"]["all"]["policy_vs_no_memory"]
    src = "results/schemamem/agent_statistics_7b_expanded.json"
    audit.close("Qwen-7B policy-no-memory difference", q7_no_memory["paired_difference"], 0.10619469026548672, src)
    audit.close("Qwen-7B policy-no-memory CI low", q7_no_memory["paired_bootstrap_95"][0], 0.035398230088495575, src)
    audit.close("Qwen-7B policy-no-memory CI high", q7_no_memory["paired_bootstrap_95"][1], 0.18584070796460178, src)
    audit.close("Qwen-7B policy-no-memory McNemar p", q7_no_memory["exact_mcnemar_p"], 0.01181793212890625, src)

    mistral_summary = load(RESULTS / "agent_runs_mistral7.summary.json")
    src = "results/schemamem/agent_runs_mistral7.summary.json"
    for condition, expected in {
        "policy_memory": 0.3055555555555556,
        "schema_aware_memory": 0.3055555555555556,
        "stale_memory": 0.25,
        "no_memory": 0.19444444444444445,
        "version_filter": 0.2777777777777778,
    }.items():
        audit.equal(f"Mistral downstream {condition}: n", mistral_summary["conditions"][condition]["n"], 36, src)
        audit.close(f"Mistral downstream {condition}: accuracy", mistral_summary["conditions"][condition]["execution_accuracy"], expected, src)

    mistral_agent = load(RESULTS / "agent_statistics_mistral7.json")["comparisons"]["all"]
    src = "results/schemamem/agent_statistics_mistral7.json"
    for name, expected in {
        "policy_vs_stale": (0.3055555555555556, 0.25, 0.05555555555555555, 0.0, 0.1388888888888889, 2, 0, 0.5),
        "policy_vs_no_memory": (0.3055555555555556, 0.19444444444444445, 0.1111111111111111, 0.027777777777777776, 0.2222222222222222, 4, 0, 0.125),
    }.items():
        values = mistral_agent[name]
        treatment, control, diff, low, high, improved, degraded, p_value = expected
        for suffix, actual, wanted in (
            ("treatment", values["treatment_accuracy"], treatment),
            ("control", values["control_accuracy"], control),
            ("difference", values["paired_difference"], diff),
            ("CI low", values["paired_bootstrap_95"][0], low),
            ("CI high", values["paired_bootstrap_95"][1], high),
            ("McNemar p", values["exact_mcnemar_p"], p_value),
        ):
            audit.close(f"Mistral agent {name}: {suffix}", actual, wanted, src)
        audit.equal(f"Mistral agent {name}: improvements", values["improved"], improved, src)
        audit.equal(f"Mistral agent {name}: degradations", values["degraded"], degraded, src)

    tool = load(RESULTS / "tool_agent_runs_qwen7_v4_expanded.statistics.json")
    src = "results/schemamem/tool_agent_runs_qwen7_v4_expanded.statistics.json"
    audit.equal("expanded tool-agent targets", tool["complete_targets"], 78, src)
    for condition, expected in {
        "policy_memory": 0.358974358974359,
        "schema_aware_memory": 0.358974358974359,
        "no_memory": 0.3333333333333333,
        "version_filter": 0.32051282051282054,
        "stale_memory": 0.3076923076923077,
        "reexplore_on_change": 0.3076923076923077,
        "execution_guided_memory": 0.3076923076923077,
    }.items():
        audit.equal(f"tool-agent {condition}: n", tool["conditions"][condition]["n"], 78, src)
        audit.close(f"tool-agent {condition}: accuracy", tool["conditions"][condition]["execution_accuracy"], expected, src)
    for comparison, cluster_high in (("policy_vs_stale", 0.10227272727272728), ("policy_vs_execution_guided", 0.10309278350515463)):
        values = tool["comparisons"]["all"][comparison]["accuracy"]
        audit.close(f"tool-agent {comparison}: difference", values["paired_difference"], 0.05128205128205128, src)
        audit.close(f"tool-agent {comparison}: target CI low", values["paired_bootstrap_95"][0], 0.01282051282051282, src)
        audit.close(f"tool-agent {comparison}: target CI high", values["paired_bootstrap_95"][1], 0.10256410256410256, src)
        audit.close(f"tool-agent {comparison}: cluster CI low", values["cluster_bootstrap_95"][0], 0.0, src)
        audit.close(f"tool-agent {comparison}: cluster CI high", values["cluster_bootstrap_95"][1], cluster_high, src)
        audit.close(f"tool-agent {comparison}: cluster sign-flip p", values["cluster_signflip_p"], 0.25, src)
        audit.equal(f"tool-agent {comparison}: improvements", values["improved"], 4, src)
        audit.equal(f"tool-agent {comparison}: degradations", values["degraded"], 0, src)
        audit.close(f"tool-agent {comparison}: McNemar p", values["exact_mcnemar_p"], 0.125, src)
    affected = tool["comparisons"]["memory_affected"]["policy_vs_stale"]["accuracy"]
    audit.equal("affected tool-agent targets", affected["n"], 56, src)
    audit.close("affected tool-agent policy accuracy", affected["treatment_accuracy"], 0.32142857142857145, src)
    audit.close("affected tool-agent stale accuracy", affected["control_accuracy"], 0.25, src)
    unaffected = tool["comparisons"]["memory_unaffected"]["policy_vs_stale"]["accuracy"]
    audit.equal("unaffected tool-agent targets", unaffected["n"], 22, src)
    audit.close("unaffected tool-agent policy accuracy", unaffected["treatment_accuracy"], 0.45454545454545453, src)
    audit.close("unaffected tool-agent stale accuracy", unaffected["control_accuracy"], 0.45454545454545453, src)

    policy = tool["conditions"]["policy_memory"]
    guided = tool["conditions"]["execution_guided_memory"]
    for claim, actual, expected in (
        ("policy total model calls", policy["mean_total_model_calls_with_maintenance"], 5.67948717948718),
        ("policy total tool calls", policy["mean_total_tool_calls_with_maintenance"], 4.8076923076923075),
        ("policy total tokens", policy["mean_total_tokens_with_maintenance"], 3278.2948717948716),
        ("execution-guided total model calls", guided["mean_total_model_calls_with_maintenance"], 9.564102564102564),
        ("execution-guided total tool calls", guided["mean_total_tool_calls_with_maintenance"], 9.025641025641026),
        ("execution-guided total tokens", guided["mean_total_tokens_with_maintenance"], 5468.807692307692),
    ):
        audit.close(claim, actual, expected, src)
    maintenance = load(RESULTS / "tool_agent_runs_qwen7_v4_expanded.maintenance.json")
    src = "results/schemamem/tool_agent_runs_qwen7_v4_expanded.maintenance.json"
    audit.equal("execution-guided affected repairs", maintenance["memory_affected"]["correct"], 35, src)
    audit.equal("execution-guided affected repair attempts", maintenance["memory_affected"]["n"], 56, src)
    audit.equal("execution-guided silent-wrong repairs", maintenance["memory_affected"]["silent_wrong"], 6, src)

    drspider = load(RESULTS / "tool_agent_runs_qwen7_drspider_v1.statistics.json")
    src = "results/schemamem/tool_agent_runs_qwen7_drspider_v1.statistics.json"
    audit.equal("DrSpider complete targets", drspider["complete_targets"], 32, src)
    audit.equal("DrSpider database clusters", drspider["database_clusters"], 16, src)
    for condition, expected in {
        "policy_memory": 0.75,
        "schema_aware_memory": 0.78125,
        "execution_guided_memory": 0.53125,
        "no_memory": 0.5,
        "stale_memory": 0.4375,
    }.items():
        audit.equal(f"DrSpider {condition}: n", drspider["conditions"][condition]["n"], 32, src)
        audit.close(
            f"DrSpider {condition}: accuracy",
            drspider["conditions"][condition]["execution_accuracy"],
            expected,
            src,
        )
    for name, expected in {
        "policy_vs_stale": (0.3125, 0.125, 0.5, 0.015625, 10, 0),
        "policy_vs_no_memory": (0.25, 0.125, 0.40625, 0.015625, 8, 0),
        "policy_vs_execution_guided": (0.21875, 0.0, 0.4375, 0.1484375, 9, 2),
    }.items():
        values = drspider["comparisons"]["all"][name]["accuracy"]
        difference, low, high, p_value, improved, degraded = expected
        audit.close(f"DrSpider {name}: difference", values["paired_difference"], difference, src)
        audit.close(f"DrSpider {name}: cluster CI low", values["cluster_bootstrap_95"][0], low, src)
        audit.close(f"DrSpider {name}: cluster CI high", values["cluster_bootstrap_95"][1], high, src)
        audit.close(f"DrSpider {name}: sign-flip p", values["cluster_signflip_p"], p_value, src)
        audit.equal(f"DrSpider {name}: improvements", values["improved"], improved, src)
        audit.equal(f"DrSpider {name}: degradations", values["degraded"], degraded, src)
    dr_policy = drspider["conditions"]["policy_memory"]
    dr_guided = drspider["conditions"]["execution_guided_memory"]
    for claim, actual, expected in (
        ("DrSpider policy total model calls", dr_policy["mean_total_model_calls_with_maintenance"], 4.875),
        ("DrSpider policy total tokens", dr_policy["mean_total_tokens_with_maintenance"], 1996.125),
        ("DrSpider guided total model calls", dr_guided["mean_total_model_calls_with_maintenance"], 10.5),
        ("DrSpider guided total tokens", dr_guided["mean_total_tokens_with_maintenance"], 4644.71875),
    ):
        audit.close(claim, actual, expected, src)

    dr_policy_audit = load(RESULTS / "tool_agent_runs_qwen7_drspider_v1.policy_audit.json")
    src = "results/schemamem/tool_agent_runs_qwen7_drspider_v1.policy_audit.json"
    audit.equal("DrSpider policy migrated memories", dr_policy_audit["actions"]["migrate"], 25, src)
    audit.equal("DrSpider policy withheld memories", dr_policy_audit["actions"]["explore"], 7, src)
    audit.equal("DrSpider policy returned correct", dr_policy_audit["returned_semantically_correct"], 25, src)
    audit.equal("DrSpider policy unsafe returns", dr_policy_audit["unsafe_returns"], 0, src)
    audit.close("DrSpider policy Wilson lower", dr_policy_audit["returned_semantic_wilson_95"][0], 0.8668077490609516, src)
    dr_guided_audit = load(RESULTS / "tool_agent_runs_qwen7_drspider_v1.execution_guided_audit.json")
    src = "results/schemamem/tool_agent_runs_qwen7_drspider_v1.execution_guided_audit.json"
    audit.equal("DrSpider guided correct memories", dr_guided_audit["all"]["correct"], 19, src)
    audit.equal("DrSpider guided silent-wrong memories", dr_guided_audit["all"]["silent_wrong"], 8, src)
    dr_outcomes = load(RESULTS / "tool_agent_runs_qwen7_drspider_v1.maintenance_outcomes.json")
    src = "results/schemamem/tool_agent_runs_qwen7_drspider_v1.maintenance_outcomes.json"
    audit.equal("DrSpider downstream after correct maintenance n", dr_outcomes["maintenance_correct"]["n"], 19, src)
    audit.equal("DrSpider downstream after correct maintenance correct", dr_outcomes["maintenance_correct"]["downstream_correct"], 16, src)
    audit.equal("DrSpider downstream after incorrect maintenance n", dr_outcomes["maintenance_incorrect_or_failed"]["n"], 13, src)
    audit.equal("DrSpider downstream after incorrect maintenance correct", dr_outcomes["maintenance_incorrect_or_failed"]["downstream_correct"], 1, src)
    dr_integrity = load(RESULTS / "tool_agent_runs_qwen7_drspider_v1.integrity.json")
    src = "results/schemamem/tool_agent_runs_qwen7_drspider_v1.integrity.json"
    audit.equal("DrSpider run integrity passed", dr_integrity["passed"], True, src)
    audit.equal("DrSpider run rows", dr_integrity["rows"], 160, src)
    audit.equal("DrSpider complete integrity targets", dr_integrity["complete_targets"], 32, src)
    dr_summary = load(RESULTS / "tool_agent_runs_qwen7_drspider_v1.summary.json")
    src = "results/schemamem/tool_agent_runs_qwen7_drspider_v1.summary.json"
    audit.equal(
        "DrSpider frozen target hash",
        dr_summary["protocol"]["target_manifest_sha256"],
        "d42db885dcf04bc03f4fd8c39d185b6ff960fb0a5a6a04eea783eb578bbc39fe",
        src,
    )

    legacy_ablation = load(RESULTS / "component_ablation.json")
    src = "results/schemamem/component_ablation.json"
    audit.equal("legacy ablation compatible cases", legacy_ablation["compatible"]["n"], 1782, src)
    audit.close(
        "legacy flat-validator compatible coverage",
        legacy_ablation["compatible"]["methods"]["full_fail_closed"]["coverage"],
        0.978675645342312,
        src,
    )
    audit.close(
        "legacy first-candidate unsafe-return rate",
        legacy_ablation["uncertainty"]["methods"]["first_candidate_execution"]["unsafe_return_rate"],
        0.584,
        src,
    )
    audit.close(
        "legacy full-policy unsafe-return rate",
        legacy_ablation["uncertainty"]["methods"]["full_fail_closed"]["unsafe_return_rate"],
        0.0,
        src,
    )

    refined_ablation = load(RESULTS / "component_ablation_scope_refined.json")
    src = "results/schemamem/component_ablation_scope_refined.json"
    audit.equal("refined ablation compatible cases", refined_ablation["compatible"]["n"], 1782, src)
    for method in ("ast_unvalidated", "schema_validated", "execution_validated", "full_fail_closed"):
        audit.close(
            f"refined {method} compatible correctness",
            refined_ablation["compatible"]["methods"][method]["correct_rate"],
            1.0,
            src,
        )
    refined_full = refined_ablation["uncertainty"]["methods"]["full_fail_closed"]
    audit.close("refined safe-case coverage", refined_full["safe_case_coverage"], 1.0, src)
    audit.close("refined unsafe-return rate", refined_full["unsafe_return_rate"], 0.0, src)
    audit.close(
        "refined first-candidate schema unsafe-return rate",
        refined_ablation["uncertainty"]["methods"]["first_candidate_schema"]["unsafe_return_rate"],
        0.6,
        src,
    )
    audit.close(
        "refined first-candidate execution unsafe-return rate",
        refined_ablation["uncertainty"]["methods"]["first_candidate_execution"]["unsafe_return_rate"],
        0.6,
        src,
    )

    portability = load(RESULTS / "duckdb_portability.json")
    src = "results/schemamem/duckdb_portability.json"
    for claim, actual, expected in (
        ("DuckDB input cases", portability["input_cases"], 1782),
        ("DuckDB input databases", portability["input_databases"], 11),
        ("DuckDB eligible cases", portability["eligible_cases"], 1318),
        ("DuckDB eligible databases", portability["eligible_databases"], 11),
        ("DuckDB correct cases", portability["correct"], 1318),
        ("DuckDB gold mismatches", portability["exclusions"]["cross_engine_gold_mismatch"], 248),
        ("DuckDB gold failures", portability["exclusions"]["duckdb_gold_failed"], 178),
        ("DuckDB legacy withholds", portability["exclusions"]["full_policy_withheld"], 38),
    ):
        audit.equal(claim, actual, expected, src)
    audit.close("DuckDB portability rate", portability["result_equivalent_rate"], 1.0, src)
    audit.close(
        "DuckDB portability Wilson lower",
        portability["result_equivalent_wilson_95"][0],
        0.9970938581211386,
        src,
    )

    refined_policy_audit = load(
        RESULTS / "tool_agent_runs_qwen7_drspider_scope_refined_v2.policy_audit.json"
    )
    src = "results/schemamem/tool_agent_runs_qwen7_drspider_scope_refined_v2.policy_audit.json"
    audit.equal("refined DrSpider returned memories", refined_policy_audit["returned"], 26, src)
    audit.equal(
        "refined DrSpider correct returned memories",
        refined_policy_audit["returned_semantically_correct"],
        26,
        src,
    )
    audit.equal("refined DrSpider unsafe returns", refined_policy_audit["unsafe_returns"], 0, src)
    audit.close(
        "refined DrSpider Wilson lower",
        refined_policy_audit["returned_semantic_wilson_95"][0],
        0.8712710781407847,
        src,
    )
    refined_integrity = load(
        RESULTS / "tool_agent_runs_qwen7_drspider_scope_refined_v2.integrity.json"
    )
    src = "results/schemamem/tool_agent_runs_qwen7_drspider_scope_refined_v2.integrity.json"
    audit.equal("refined DrSpider integrity passed", refined_integrity["passed"], True, src)
    audit.equal("refined DrSpider rows", refined_integrity["rows"], 32, src)

    scope_stats = load(RESULTS / "scope_refinement_statistics.json")
    src = "results/schemamem/scope_refinement_statistics.json"
    audit.equal("scope refinement changed targets", scope_stats["changed_targets"], 1, src)
    audit.equal("scope refinement legacy returned", scope_stats["legacy"]["memory_returned"], 25, src)
    audit.equal("scope refinement new returned", scope_stats["refined"]["memory_returned"], 26, src)
    audit.close("scope refinement legacy accuracy", scope_stats["legacy"]["execution_accuracy"], 0.75, src)
    audit.close("scope refinement new accuracy", scope_stats["refined"]["execution_accuracy"], 0.75, src)
    audit.close("scope refinement new tokens", scope_stats["refined"]["mean_total_tokens"], 2016.71875, src)

    qualitative = load(RESULTS / "qualitative_failure_examples.json")
    src = "results/schemamem/qualitative_failure_examples.json"
    audit.equal(
        "qualitative execution-guided silent-wrong candidates",
        qualitative["candidate_counts"]["execution_guided_executable_but_semantically_wrong"],
        8,
        src,
    )
    audit.equal(
        "qualitative ambiguous candidates",
        qualitative["candidate_counts"]["ambiguous_mapping_withheld"],
        150,
        src,
    )
    audit.equal(
        "qualitative correct-memory downstream failures",
        qualitative["candidate_counts"]["downstream_failure_after_correct_memory"],
        3,
        src,
    )
    audit.equal(
        "qualitative nested-scope candidates",
        qualitative["candidate_counts"]["unsupported_nested_scope_rejected"],
        31,
        src,
    )

    q14_tool = load(RESULTS / "tool_agent_runs_qwen14_v1_control22.statistics.json")
    src = "results/schemamem/tool_agent_runs_qwen14_v1_control22.statistics.json"
    audit.equal("Q14 tool complete targets", q14_tool["complete_targets"], 22, src)
    audit.equal("Q14 tool database clusters", q14_tool["database_clusters"], 11, src)
    for condition, expected in {
        "policy_memory": 0.45454545454545453,
        "schema_aware_memory": 0.45454545454545453,
        "stale_memory": 0.5,
        "version_filter": 0.5,
        "reexplore_on_change": 0.5,
        "execution_guided_memory": 0.4090909090909091,
        "no_memory": 0.4090909090909091,
    }.items():
        audit.equal(f"Q14 tool {condition}: n", q14_tool["conditions"][condition]["n"], 22, src)
        audit.close(
            f"Q14 tool {condition}: accuracy",
            q14_tool["conditions"][condition]["execution_accuracy"],
            expected,
            src,
        )
    q14_policy_stale = q14_tool["comparisons"]["all"]["policy_vs_stale"]["accuracy"]
    for claim, actual, expected in (
        ("Q14 policy-stale difference", q14_policy_stale["paired_difference"], -0.045454545454545456),
        ("Q14 policy-stale cluster CI low", q14_policy_stale["cluster_bootstrap_95"][0], -0.18181818181818182),
        ("Q14 policy-stale cluster CI high", q14_policy_stale["cluster_bootstrap_95"][1], 0.09090909090909091),
        ("Q14 policy-stale sign-flip p", q14_policy_stale["cluster_signflip_p"], 1.0),
    ):
        audit.close(claim, actual, expected, src)
    audit.equal("Q14 policy-stale improvements", q14_policy_stale["improved"], 1, src)
    audit.equal("Q14 policy-stale degradations", q14_policy_stale["degraded"], 2, src)
    q14_oracle_policy = q14_tool["comparisons"]["all"]["oracle_vs_policy"]["accuracy"]
    audit.close("Q14 builder-policy difference", q14_oracle_policy["paired_difference"], 0.0, src)
    audit.close(
        "Q14 policy total tokens",
        q14_tool["conditions"]["policy_memory"]["mean_total_tokens_with_maintenance"],
        2789.0,
        src,
    )
    audit.close(
        "Q14 execution-guided total tokens",
        q14_tool["conditions"]["execution_guided_memory"]["mean_total_tokens_with_maintenance"],
        4075.8636363636365,
        src,
    )

    q14_maintenance = load(RESULTS / "tool_agent_runs_qwen14_v1_control22.maintenance.json")
    src = "results/schemamem/tool_agent_runs_qwen14_v1_control22.maintenance.json"
    audit.equal("Q14 affected maintenance attempts", q14_maintenance["memory_affected"]["n"], 9, src)
    audit.equal("Q14 affected maintenance correct", q14_maintenance["memory_affected"]["correct"], 4, src)
    audit.equal("Q14 affected maintenance silent wrong", q14_maintenance["memory_affected"]["silent_wrong"], 2, src)

    q14_integrity = load(RESULTS / "tool_agent_runs_qwen14_v1_control22.integrity.json")
    src = "results/schemamem/tool_agent_runs_qwen14_v1_control22.integrity.json"
    audit.equal("Q14 run integrity passed", q14_integrity["passed"], True, src)
    audit.equal("Q14 run rows", q14_integrity["rows"], 154, src)
    audit.equal("Q14 run duplicate count", len(q14_integrity["duplicate_keys"]), 0, src)
    audit.equal(
        "Q14 unaffected trace failures",
        len(q14_integrity["unaffected_policy_stale_trace_invariant_failures"]),
        0,
        src,
    )

    q14_summary = load(RESULTS / "tool_agent_runs_qwen14_v1_control22.summary.json")
    src = "results/schemamem/tool_agent_runs_qwen14_v1_control22.summary.json"
    audit.equal("Q14 summary rows", q14_summary["n_runs"], 154, src)
    audit.equal("Q14 summary workers", q14_summary["protocol"]["workers"], 1, src)
    audit.equal("Q14 summary temperature", q14_summary["protocol"]["temperature"], 0, src)
    audit.equal("Q14 summary seed", q14_summary["protocol"]["seed"], 42, src)
    audit.equal(
        "Q14 target-manifest hash",
        q14_summary["protocol"]["target_manifest_sha256"],
        "7dbd7877543da9a6159d04b3bc8c1b503446020ae060ce8bb43b7511516eefb9",
        src,
    )

    q14_model_control = load(RESULTS / "tool_agent_model_control_qwen14_vs_qwen7.json")
    src = "results/schemamem/tool_agent_model_control_qwen14_vs_qwen7.json"
    q14_policy_control = q14_model_control["conditions"]["policy_memory"]["accuracy"]
    audit.equal("Q14-Q7 matched targets", q14_model_control["targets"], 22, src)
    audit.close("Q14 matched policy accuracy", q14_policy_control["treatment_accuracy"], 0.45454545454545453, src)
    audit.close("Q7 matched policy accuracy", q14_policy_control["control_accuracy"], 0.5, src)
    audit.equal("Q14-Q7 policy improvements", q14_policy_control["improved"], 3, src)
    audit.equal("Q14-Q7 policy degradations", q14_policy_control["degraded"], 4, src)

    overhead = load(RESULTS / "policy_overhead.json")
    src = "results/schemamem/policy_overhead.json"
    audit.equal("policy-overhead cases", overhead["n_cases"], 350, src)
    audit.equal("policy-overhead decisions", overhead["n_decisions"], 7000, src)
    audit.close("policy-overhead median milliseconds", overhead["median_ms"], 1.25515, src)
    audit.close("policy-overhead p95 milliseconds", overhead["p95_ms"], 6.2136, src)
    audit.close("policy-overhead mean milliseconds", overhead["mean_ms"], 2.090654614285714, src)

    clean_rebuild = load(RESULTS / "clean_rebuild_audit.json")
    src = "results/schemamem/clean_rebuild_audit.json"
    audit.equal("clean rebuild audit status", clean_rebuild["status"], "passed", src)
    audit.equal(
        "clean rebuild files match",
        [clean_rebuild["files_matched"], clean_rebuild["files_checked"]],
        [27, 27],
        src,
    )
    builder_source = (ROOT / "src" / "schemamem" / "build_benchmark.py").read_text(
        encoding="utf-8"
    )
    audit.contains(
        "rename builder fixes a 100M VM-step validation cap",
        builder_source,
        "BENCHMARK_VALIDATION_VM_STEPS = 100_000_000",
        "src/schemamem/build_benchmark.py",
    )

    bibliography = load(RESULTS / "bibliography_audit.json")
    src = "results/schemamem/bibliography_audit.json"
    audit.equal("bibliography audit status", bibliography["status"], "passed", src)
    audit.equal("bibliography audit is online", bibliography["online"], True, src)
    audit.equal("bibliography entries", bibliography["entries"], 22, src)
    audit.equal("bibliography cited keys", bibliography["cited_keys"], 22, src)
    audit.equal(
        "all bibliography registry checks pass",
        all(item["passed"] for item in bibliography["checks"]),
        True,
        src,
    )

    manuscript = (ROOT / "paper" / "main.tex").read_text(encoding="utf-8")
    src = "paper/main.tex"
    for claim, fragment in (
        ("manuscript reports ambiguity counts", "200/200 safe"),
        ("manuscript reports unsafe count", "0/250 unsafe"),
        ("manuscript reports transition count", "1,191"),
        ("manuscript reports Qwen-7B downstream accuracy", "46.9\\% execution"),
        ("manuscript reports Qwen-7B stale accuracy", "37.2\\%\nfor stale memory"),
        ("manuscript reports expanded tool targets", "targets over 11 databases"),
        ("manuscript reports tool policy accuracy", "both reach 35.9\\%"),
        ("manuscript reports tool stale accuracy", "30.8\\% for stale"),
        ("manuscript reports clustered null", "both sign-flip tests give $p=0.25$"),
        ("manuscript reports execution-guided repairs", "repairs 35/56"),
        ("manuscript reports execution-guided silent errors", "six additional repairs execute but are silently wrong"),
        ("manuscript reports policy interaction cost", "5.68, 4.81, and 3.28k"),
        ("manuscript reports execution-guided interaction cost", "9.56 model calls, 9.03 tool calls, and 5.47k"),
        ("manuscript reports Q14 negative scaling check", "policy reaches 45.5\\% versus 50.0\\% stale memory"),
        ("manuscript reports DrSpider policy accuracy", "24/32 (75.0\\%)"),
        ("manuscript reports DrSpider stale accuracy", "14/32 (43.8\\%)"),
        ("manuscript reports DrSpider no-memory accuracy", "16/32\n(50.0\\%)"),
        ("manuscript reports DrSpider guided accuracy", "17/32 (53.1\\%)"),
        ("manuscript reports DrSpider gold accuracy", "25/32 (78.1\\%)"),
        ("manuscript reports DrSpider stale clustered result", "interval is [12.5, 50.0]"),
        ("manuscript reports DrSpider primary null", "cluster interval reaches zero [0.0, 43.8] and $p=0.148$"),
        ("manuscript reports DrSpider safe returned memories", "all 26 execute and are semantically equivalent"),
        ("manuscript reports DrSpider silent repairs", "eight executable but silently wrong repairs"),
        ("manuscript reports DrSpider maintenance association", "correct on 16/19 targets following a correct repair and 1/13"),
        ("manuscript reports DrSpider calls", "10.50\nmodel calls"),
        ("manuscript reports DrSpider tokens", "4.64k tokens per target"),
        ("manuscript reports refined DrSpider tokens", "4.88 and 2.02k for refined"),
        ("manuscript reports scope ablation", "1,744/1,782"),
        ("manuscript reports refined compatible cases", "1,782/1,782 correctness"),
        ("manuscript reports first-candidate unsafe rate", "First candidate + execution & 1.000 & 0.600"),
        ("manuscript reports DuckDB eligible cases", "1,318 eligible"),
        ("manuscript reports DuckDB exclusions", "248 cross-engine gold-result"),
        ("manuscript cites DrSpider", "\\cite{chang2023drspider,yu2018spider}"),
        ("manuscript states 100M validation cap", "fixed 100-million-step SQLite"),
        ("manuscript states return invariants", "\\paragraph{Return invariant.}"),
        ("manuscript reports corrected nested exclusions", "exclude 52 nested-query and six star-"),
        ("manuscript reports corrected split execution failures", "three more candidates fail on ambiguous-column execution"),
        ("manuscript reports corrected split equivalence failures", "two execute but are not result-equivalent"),
        ("manuscript cites Skill-Pro", "\\cite{mi2026skillpro}"),
        ("manuscript cites Neural Procedural Memory", "\\cite{zhao2026npm}"),
        ("manuscript cites Shared Selective Persistent Memory", "\\cite{pedada2026shared}"),
    ):
        audit.contains(claim, manuscript, fragment, src)
    audit.absent("stale split timeout claim removed", manuscript, "four time out", src)
    audit.absent("stale all-nested split claim removed", manuscript, "Fifty-eight nested-query", src)
    audit.contains(
        "manuscript includes verified ACM CCS concept",
        manuscript,
        "10002951.10002952.10003190",
        src,
    )
    audit.equal(
        "every manuscript figure has an accessibility description",
        manuscript.count("\\Description{"),
        manuscript.count("\\begin{figure"),
        src,
    )
    audit.equal(
        "ACM title and keywords occur inside document",
        manuscript.index("\\begin{document}") < manuscript.index("\\title{")
        < manuscript.index("\\keywords{"),
        True,
        src,
    )
    audit.contains(
        "public-migration caption labels constructed replay",
        manuscript,
        "Public-history\n  statements are replayed on constructed fixtures",
        src,
    )

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    src = "README.md"
    for claim, fragment in (
        ("README reports expanded target count", "78 paired targets"),
        ("README reports tool policy accuracy", "35.9% execution accuracy"),
        ("README reports tool no-memory accuracy", "33.3%"),
        ("README reports tool stale accuracy", "30.8%"),
        ("README reports cluster sign-flip p", "sign-flip p-value is 0.25"),
        ("README reports execution-guided cost", "9.56 model calls, 9.03 tool calls, and 5.47k"),
        ("README reports policy cost", "5.68, 4.81, and 3.28k"),
        ("README reports Q14 policy accuracy", "policy and builder repair reach 45.5%"),
        ("README reports Q14 stale accuracy", "re-exploration reach 50.0%"),
        ("README reports Q14 cluster null", "sign-flip p=1.0"),
        ("README reports legacy scope coverage", "1,744/1,782 compatible repairs"),
        ("README reports refined safety", "0/250 unsafe ambiguity returns"),
        ("README reports adaptive downstream null", "unchanged at 24/32 (75.0%)"),
        ("README reports DuckDB portability", "all 1,318 repairs remain result-equivalent"),
    ):
        audit.contains(claim, readme, fragment, src)
    audit.contains(
        "README freezes primary direct-repair scenarios",
        readme,
        "--scenarios column_rename table_rename table_split --per-scenario 20 --model-label qwen2.5-coder-7b-q4",
        src,
    )
    audit.contains(
        "README freezes Qwen-7B downstream model label",
        readme,
        "--per-stratum 3 --model-label qwen2.5-coder-7b-q4 --workers 1",
        src,
    )
    audit.contains(
        "README reproduces paired deterministic statistics",
        readme,
        "-m schemamem.statistics",
        src,
    )
    audit.contains(
        "README reproduces EvoSchema audit",
        readme,
        "-m schemamem.audit_evoschema",
        src,
    )
    audit.equal(
        "README constructs split suite before evaluating it",
        readme.index("-m schemamem.split_benchmark")
        < readme.index("-m schemamem.evaluate_split"),
        True,
        src,
    )
    audit.contains(
        "README reproduces frozen legacy ablation",
        readme,
        "-m schemamem.component_ablation --validator legacy_flat",
        src,
    )
    audit.contains(
        "README reproduces refined ablation",
        readme,
        "-m schemamem.component_ablation --validator current",
        src,
    )
    audit.contains(
        "README reproduces DuckDB diagnostic",
        readme,
        "-m schemamem.duckdb_portability --validator legacy_flat",
        src,
    )

    artifact = (ROOT / "ARTIFACT.md").read_text(encoding="utf-8")
    src = "ARTIFACT.md"
    audit.contains(
        "artifact freezes lifecycle-gate model label",
        artifact,
        "--prompt-mode conservative --model-label qwen2.5-coder-7b-q4",
        src,
    )
    audit.contains(
        "artifact reproduces released downstream error path",
        artifact,
        "--output results/schemamem/agent_runs_7b_expanded.errors.json",
        src,
    )
    audit.contains(
        "artifact reproduces paired deterministic statistics",
        artifact,
        "-m schemamem.statistics",
        src,
    )
    audit.contains(
        "artifact reproduces EvoSchema audit",
        artifact,
        "-m schemamem.audit_evoschema",
        src,
    )
    audit.contains(
        "artifact freezes primary direct-repair scenarios",
        artifact,
        "--scenarios column_rename table_rename table_split --per-scenario 20 --model-label qwen2.5-coder-7b-q4",
        src,
    )
    audit.absent(
        "artifact omits stale downstream error path",
        artifact,
        "--output results/schemamem/agent_runs_7b.errors.json",
        src,
    )
    audit.contains(
        "artifact reproduces exact Q14 model control",
        artifact,
        "-m schemamem.model_control_statistics --smaller-runs results/schemamem/tool_agent_runs_qwen7_v3_final.jsonl --larger-runs results/schemamem/tool_agent_runs_qwen14_v1_control22.jsonl",
        src,
    )
    audit.contains(
        "artifact verifies submission PDF",
        artifact,
        "scripts\\verify_submission_pdf.py paper\\main.pdf",
        src,
    )
    audit.contains(
        "artifact reproduces frozen legacy ablation",
        artifact,
        "-m schemamem.component_ablation --validator legacy_flat",
        src,
    )
    audit.contains(
        "artifact reproduces refined ablation",
        artifact,
        "-m schemamem.component_ablation --validator current",
        src,
    )
    audit.contains(
        "artifact reproduces DuckDB diagnostic",
        artifact,
        "-m schemamem.duckdb_portability --validator legacy_flat",
        src,
    )
    audit.contains(
        "artifact audits refined policy-only run",
        artifact,
        "tool_agent_runs_qwen7_drspider_scope_refined_v2.policy_audit.json",
        src,
    )

    return audit


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=RESULTS / "paper_claims_audit.json",
        help="Path for the machine-readable audit report",
    )
    args = parser.parse_args()
    audit = audit_claims()
    failed = [check for check in audit.checks if not check["passed"]]
    report = {
        "status": "passed" if not failed else "failed",
        "checks": len(audit.checks),
        "passed": len(audit.checks) - len(failed),
        "failed": len(failed),
        "failures": failed,
        "all_checks": audit.checks,
        "scope_note": (
            "Checks quantitative claims in the evaluation section against "
            "unrounded frozen outputs; bibliographic and qualitative claims "
            "require separate human/source review."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"paper-claim audit: {report['status']} "
          f"({report['passed']}/{report['checks']} checks passed)")
    if failed:
        for item in failed:
            print(f"FAIL {item['claim']}: {item['actual']} != {item['expected']}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
