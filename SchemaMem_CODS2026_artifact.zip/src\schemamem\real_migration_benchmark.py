"""Replay commit-pinned open-source schema events on executable fixtures.

The source migrations are real, but the small SQLite fixtures and diagnostic
queries are constructed for controlled evaluation; this is not presented as a
production workload benchmark.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sqlite3
import urllib.request
from collections import Counter
from pathlib import Path

from .build_benchmark import execute, result_equivalent, rewrite_sql, sqlite_schema
from .memory_policy import decide_rename
from .split_benchmark import quote


def source_url(case: dict) -> str:
    return (
        f"https://raw.githubusercontent.com/{case['repo']}/{case['commit']}/"
        f"{case['path']}"
    )


def verify_source(case: dict) -> dict:
    request = urllib.request.Request(
        source_url(case), headers={"User-Agent": "SchemaMem-research"}
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = response.read()
    text = payload.decode("utf-8", errors="replace")
    return {
        "url": source_url(case),
        "sha256": hashlib.sha256(payload).hexdigest(),
        "mentions_old": case["old"] in text,
        "mentions_new": case["new"] in text,
        "verified": case["old"] in text and case["new"] in text,
    }


def create_old_fixture(path: Path, case: dict) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()
    operator = case["operator"]
    table = case["old"] if operator == "table_rename" else case["table"]
    with sqlite3.connect(path) as connection:
        if operator in {"column_rename", "drop_add"}:
            connection.execute(
                f"CREATE TABLE {quote(table)} "
                f"(id INTEGER PRIMARY KEY, {quote(case['old'])} TEXT, stable TEXT)"
            )
            connection.executemany(
                f"INSERT INTO {quote(table)} VALUES (?, ?, ?)",
                [(1, "alpha", "keep"), (2, "beta", "keep"), (3, "gamma", "old")],
            )
            return (
                f"SELECT t.{quote(case['old'])}, t.stable FROM {quote(table)} AS t "
                f"WHERE t.stable <> 'old' ORDER BY t.id"
            )
        connection.execute(
            f"CREATE TABLE {quote(table)} (id INTEGER PRIMARY KEY, value TEXT, stable TEXT)"
        )
        connection.executemany(
            f"INSERT INTO {quote(table)} VALUES (?, ?, ?)",
            [(1, "alpha", "keep"), (2, "beta", "keep"), (3, "gamma", "old")],
        )
        return (
            f"SELECT t.value, t.stable FROM {quote(table)} AS t "
            f"WHERE t.stable <> '{case['old']}' ORDER BY t.id"
        )


def migrate_fixture(old: Path, current: Path, case: dict) -> None:
    if current.exists():
        current.unlink()
    shutil.copy2(old, current)
    with sqlite3.connect(current) as connection:
        if case["operator"] == "table_rename":
            connection.execute(
                f"ALTER TABLE {quote(case['old'])} RENAME TO {quote(case['new'])}"
            )
        elif case["operator"] == "column_rename":
            connection.execute(
                f"ALTER TABLE {quote(case['table'])} RENAME COLUMN "
                f"{quote(case['old'])} TO {quote(case['new'])}"
            )
        elif case["operator"] == "drop_add":
            connection.execute(
                f"ALTER TABLE {quote(case['table'])} DROP COLUMN {quote(case['old'])}"
            )
            connection.execute(
                f"ALTER TABLE {quote(case['table'])} ADD COLUMN {quote(case['new'])} TEXT"
            )


def manifest(case: dict) -> dict:
    if case["operator"] == "table_rename":
        return {
            "operator": "rename",
            "write_set": [case["old"]],
            "column_candidates": {},
            "table_candidates": {case["old"]: [case["new"]]},
        }
    if case["operator"] == "column_rename":
        key = f"{case['table']}.{case['old']}"
        return {
            "operator": "rename",
            "write_set": [key],
            "column_candidates": {key: [case["new"]]},
            "table_candidates": {},
        }
    if case["operator"] == "drop_add":
        return {
            "operator": "drop",
            "write_set": [f"{case['table']}.{case['old']}"],
        }
    return {
        "operator": "metadata_or_value_change",
        "write_set": [f"__non_schema__.{case['old']}"],
    }


def build(args: argparse.Namespace) -> dict:
    cases = json.loads(args.sources.read_text(encoding="utf-8"))
    rows = []
    source_cache: dict[tuple[str, str, str], dict] = {}
    for case in cases:
        source_key = (case["repo"], case["commit"], case["path"])
        if args.verify_sources and source_key not in source_cache:
            source_cache[source_key] = verify_source(case)
        verification = source_cache.get(source_key, {
            "url": source_url(case), "sha256": None,
            "mentions_old": None, "mentions_new": None, "verified": None,
        })
        fixture = args.output / "fixtures" / case["id"]
        old_path, current_path = fixture / "old.sqlite", fixture / "current.sqlite"
        old_sql = create_old_fixture(old_path, case)
        migrate_fixture(old_path, current_path, case)
        old_schema, current_schema = sqlite_schema(old_path), sqlite_schema(current_path)
        old_ok, old_result = execute(old_path, old_sql)

        if case["operator"] in {"table_rename", "column_rename"}:
            column_map = (
                {(case["table"], case["old"]): case["new"]}
                if case["operator"] == "column_rename" else {}
            )
            table_map = (
                {case["old"]: case["new"]}
                if case["operator"] == "table_rename" else {}
            )
            gold_sql, _ = rewrite_sql(old_sql, old_schema, column_map, table_map)
            expected_action = "migrate"
        elif case["operator"] == "drop_add":
            gold_sql = None
            expected_action = "invalidate"
        else:
            gold_sql = old_sql
            expected_action = "reuse"

        decision = decide_rename(
            old_sql, old_schema, current_schema, manifest(case)
        )
        stale_ok, stale_result = execute(current_path, old_sql)
        policy_ok, policy_result = (
            execute(current_path, decision.sql) if decision.sql else (False, "withheld")
        )
        gold_ok, gold_result = (
            execute(current_path, gold_sql) if gold_sql else (False, "not_applicable")
        )
        policy_decision_correct = (
            expected_action == "invalidate" and decision.action == "invalidate"
        ) or (
            old_ok and gold_ok and policy_ok
            and result_equivalent(policy_result, gold_result, gold_sql or old_sql)
        )
        stale_outcome_correct = bool(
            old_ok and gold_ok and stale_ok
            and result_equivalent(stale_result, gold_result, gold_sql or old_sql)
        )
        rows.append({
            **case,
            "source": verification,
            "old_sql": old_sql,
            "gold_sql": gold_sql,
            "manifest": manifest(case),
            "expected_action": expected_action,
            "policy_action": decision.action,
            "policy_reason": decision.reason,
            "policy_sql": decision.sql,
            "policy_decision_correct": policy_decision_correct,
            "stale_exec_ok": stale_ok,
            "stale_outcome_correct": stale_outcome_correct,
        })

    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "instances.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    summary = {
        "cases": len(rows),
        "repositories": len({row["repo"] for row in rows}),
        "unique_source_files": len({(row["repo"], row["commit"], row["path"]) for row in rows}),
        "source_files_verified": sum(
            item.get("verified") is True for item in source_cache.values()
        ),
        "policy_decisions_correct": sum(row["policy_decision_correct"] for row in rows),
        "policy_decision_accuracy": sum(
            row["policy_decision_correct"] for row in rows
        ) / len(rows),
        "stale_outcomes_correct": sum(row["stale_outcome_correct"] for row in rows),
        "stale_outcome_accuracy": sum(
            row["stale_outcome_correct"] for row in rows
        ) / len(rows),
        "by_operator": {},
        "scope_note": (
            "commit-pinned real migration events replayed on constructed minimal "
            "SQLite fixtures and diagnostic queries; not production workloads"
        ),
    }
    for operator in sorted({row["operator"] for row in rows}):
        group = [row for row in rows if row["operator"] == operator]
        summary["by_operator"][operator] = {
            "n": len(group),
            "policy_decisions_correct": sum(
                row["policy_decision_correct"] for row in group
            ),
            "actions": dict(Counter(row["policy_action"] for row in group)),
        }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--sources", type=Path,
        default=Path("data/schemamem-real-migrations-v1/sources.json")
    )
    parser.add_argument(
        "--output", type=Path, default=Path("data/schemamem-real-migrations-v1")
    )
    parser.add_argument("--verify-sources", action="store_true")
    args = parser.parse_args()
    print(json.dumps(build(args), indent=2))


if __name__ == "__main__":
    main()
