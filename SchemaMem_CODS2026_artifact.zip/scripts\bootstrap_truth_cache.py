"""Build ce-metric-eval's STATS-CEB truth cache from inline true cards.

The enhanced public STATS-CEB mirror includes
``stats_CEB_sub_queries_with_truecard.sql`` with lines of the form
``SQL ;|| query_id || true_cardinality``. The original ce-metric-eval loader
normally recomputes these counts in DuckDB. This script makes the pilot faster
without changing either upstream baseline repository.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def normalize_sql(body: str) -> str:
    """Match the SQL normalization in ce_metric_eval.workload.parse_line."""
    return body.strip().rstrip(";").strip()


def build_cache(source: Path) -> dict[str, float]:
    cache: dict[str, float] = {}
    for line_number, line in enumerate(source.read_text().splitlines(), start=1):
        if not line.strip():
            continue
        try:
            sql, _query_id, true_cardinality = line.rsplit("||", 2)
            cache[normalize_sql(sql)] = float(true_cardinality.strip())
        except ValueError as exc:
            raise ValueError(f"Malformed line {line_number} in {source}") from exc
    return cache


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    cache = build_cache(args.source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(cache, sort_keys=True))
    print(f"wrote {len(cache)} distinct SQL cardinalities to {args.output}")


if __name__ == "__main__":
    main()

