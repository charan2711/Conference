"""Fail a release when filenames or contents expose identity or credentials."""

from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path, PurePosixPath


GENERIC_PATTERNS = {
    "windows_user_path": re.compile(rb"[A-Za-z]:\\Users\\[^\\\s]+", re.I),
    "unix_home_path": re.compile(rb"/(?:home|Users)/[^/\s]+", re.I),
    "email_address": re.compile(rb"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.I),
    "kaggle_token": re.compile(rb"KGAT_[A-Za-z0-9]{8,}"),
    "openai_key": re.compile(rb"sk-[A-Za-z0-9_-]{16,}"),
    "generic_secret_assignment": re.compile(
        rb"(?:api[_-]?key|api[_-]?token|access[_-]?token|secret)\s*[:=]\s*['\"]?[A-Za-z0-9_./+-]{12,}",
        re.I,
    ),
}


def load_denylist(path: Path | None, inline: list[str]) -> list[bytes]:
    terms = [item.strip() for item in inline if item.strip()]
    if path and path.is_file():
        terms.extend(
            line.strip() for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )
    return [term.encode("utf-8") for term in dict.fromkeys(terms)]


def check_payload(name: str, payload: bytes, denylist: list[bytes]) -> list[dict[str, str]]:
    failures: list[dict[str, str]] = []
    name_bytes = name.encode("utf-8", errors="ignore")
    for label, pattern in GENERIC_PATTERNS.items():
        if pattern.search(name_bytes) or pattern.search(payload):
            failures.append({"path": name, "rule": label})
    lowered_name = name_bytes.lower()
    lowered_payload = payload.lower()
    for index, term in enumerate(denylist, start=1):
        if term.lower() in lowered_name or term.lower() in lowered_payload:
            failures.append({"path": name, "rule": f"local_denylist_{index}"})
    return failures


def directory_payloads(root: Path):
    for path in sorted(root.rglob("*")):
        if path.is_file():
            name = path.relative_to(root).as_posix()
            if path.is_symlink():
                yield name, b"", "unsafe_symlink"
            else:
                yield name, path.read_bytes(), None


def zip_payloads(path: Path):
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = info.filename
            parsed = PurePosixPath(name)
            if parsed.is_absolute() or ".." in parsed.parts or "\\" in name:
                yield name, b"", "unsafe_archive_path"
            else:
                yield name, archive.read(info), None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact", type=Path, help="staging directory or ZIP")
    parser.add_argument("--denylist-file", type=Path)
    parser.add_argument("--deny", action="append", default=[])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    denylist = load_denylist(args.denylist_file, args.deny)
    if args.artifact.is_dir():
        payloads = directory_payloads(args.artifact)
    elif args.artifact.is_file() and args.artifact.suffix.lower() == ".zip":
        payloads = zip_payloads(args.artifact)
    else:
        parser.error("artifact must be a staging directory or ZIP file")

    failures: list[dict[str, str]] = []
    files = 0
    for name, payload, structural_failure in payloads:
        files += 1
        if structural_failure:
            failures.append({"path": name, "rule": structural_failure})
        failures.extend(check_payload(name, payload, denylist))
    report = {
        "status": "passed" if not failures else "failed",
        "files_scanned": files,
        "generic_rules": len(GENERIC_PATTERNS),
        "local_deny_terms": len(denylist),
        "failures": failures,
    }
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"anonymity audit: {report['status']} ({files} files scanned)")
    for item in failures:
        print(f"FAIL {item['path']}: {item['rule']}")
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
