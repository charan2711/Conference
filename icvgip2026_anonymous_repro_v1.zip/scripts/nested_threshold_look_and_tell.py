"""Nested participant-disjoint selective-prediction audit for Look and Tell.

For each outer participant fold, thresholds are selected only on inner
participant-disjoint out-of-fold predictions from the outer-training rows.
The selected threshold is then frozen while fitting the full outer-training
model and is applied to the untouched outer participants.  This avoids the
retrospective threshold optimism of an all-rows risk--coverage envelope.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler, normalize

from baseline_look_and_tell_classical_vision import (
    SEED,
    add_history,
    load_recording,
    new_model,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--derived-root", type=Path, default=Path("data/derived/look_and_tell"))
    parser.add_argument("--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json"))
    parser.add_argument("--full-frame-feature-cache", type=Path,
                        default=Path("data/derived/look_and_tell_full_frame_classical_cache.npz"))
    parser.add_argument("--output", type=Path,
                        default=Path("artifacts/baselines/look_and_tell_full_frame_nested_threshold.json"))
    parser.add_argument("--outer-folds", type=int, default=6)
    parser.add_argument("--inner-folds", type=int, default=5)
    parser.add_argument("--maximum-error", type=float, default=0.05)
    return parser.parse_args()


def load_rows_and_features(args: argparse.Namespace) -> tuple[list[dict], np.ndarray, dict, str]:
    spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows: list[dict] = []
    split_lengths: dict[str, int] = {}
    missing: list[str] = []
    for split in ("train", "val", "test"):
        before = len(rows)
        for recording in spec["splits"][split]["recordings"]:
            try:
                rows.extend(load_recording(args.derived_root, recording))
            except FileNotFoundError:
                missing.append(recording)
        split_lengths[split] = len(rows) - before
    frame_paths_by_split: dict[str, list[str]] = {}
    offset = 0
    for split in ("train", "val", "test"):
        end = offset + split_lengths[split]
        frame_paths_by_split[split] = [row["frame_path"] for row in rows[offset:end]]
        offset = end
    import hashlib
    signature = hashlib.sha256(json.dumps(frame_paths_by_split, sort_keys=True).encode("utf-8")).hexdigest()
    if not args.full_frame_feature_cache.exists():
        raise FileNotFoundError(f"Missing required full-frame feature cache: {args.full_frame_feature_cache}")
    with np.load(args.full_frame_feature_cache, allow_pickle=False) as cache:
        if "row_signature" not in cache or str(cache["row_signature"].item()) != signature:
            raise RuntimeError("Full-frame feature cache row signature mismatch")
        if "full_frame_raw" not in cache:
            raise RuntimeError("Full-frame feature cache lacks full_frame_raw")
        features = np.asarray(cache["full_frame_raw"])
    if features.shape[0] != len(rows):
        raise RuntimeError(f"Row/feature mismatch: rows={len(rows)}, features={features.shape}")
    return rows, features.astype(np.float32, copy=False), {"split_lengths": split_lengths, "missing_media_recordings": missing}, signature


def make_matrix(train_rows: list[dict], eval_rows: list[dict], train_raw: np.ndarray,
                eval_raw: np.ndarray) -> tuple[object, object]:
    frequencies = Counter(row["reference"] for row in train_rows)
    labels = sorted(frequencies)
    train_local = [dict(row) for row in train_rows]
    eval_local = [dict(row) for row in eval_rows]
    add_history(train_local, labels, frequencies)
    add_history(eval_local, labels, frequencies)
    text = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2,
                           max_features=20000, sublinear_tf=True)
    text_train = text.fit_transform(row.get("surface_text") or "" for row in train_local)
    text_eval = text.transform(row.get("surface_text") or "" for row in eval_local)
    history = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    history_train = history.fit_transform(np.asarray([[row["history_prediction"]] for row in train_local]))
    history_eval = history.transform(np.asarray([[row["history_prediction"]] for row in eval_local]))
    scaler = StandardScaler()
    train_visual = normalize(csr_matrix(scaler.fit_transform(train_raw)), norm="l2")
    eval_visual = normalize(csr_matrix(scaler.transform(eval_raw)), norm="l2")
    return (
        hstack([text_train, train_visual, history_train], format="csr"),
        hstack([text_eval, eval_visual, history_eval], format="csr"),
    )


def fit_predict(rows: list[dict], indices_train: np.ndarray, indices_eval: np.ndarray,
                features: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    train_rows = [rows[int(i)] for i in indices_train]
    eval_rows = [rows[int(i)] for i in indices_eval]
    train_matrix, eval_matrix = make_matrix(train_rows, eval_rows,
                                             features[indices_train], features[indices_eval])
    model = new_model()
    model.fit(train_matrix, np.asarray([row["reference"] for row in train_rows]))
    return model.predict(eval_matrix), model.predict_proba(eval_matrix).max(axis=1)


def select_threshold(targets: np.ndarray, predictions: np.ndarray, confidence: np.ndarray,
                     maximum_error: float) -> dict:
    candidates = np.unique(confidence)[::-1]
    feasible: list[tuple[int, float, float]] = []
    for threshold in candidates:
        accepted = confidence >= threshold
        if not accepted.any():
            continue
        error = float(np.mean(predictions[accepted] != targets[accepted]))
        if error <= maximum_error:
            feasible.append((int(accepted.sum()), float(threshold), error))
    if not feasible:
        # This should be reported transparently rather than silently tuning on
        # outer rows.  A singleton top-confidence point is the safe fallback.
        threshold = float(np.max(confidence))
        accepted = confidence >= threshold
        return {"feasible": False, "threshold": threshold,
                "accepted": int(accepted.sum()), "total": int(len(targets)),
                "coverage": float(accepted.mean()),
                "selective_error": float(np.mean(predictions[accepted] != targets[accepted]))}
    count, threshold, error = max(feasible, key=lambda item: (item[0], -item[1]))
    return {"feasible": True, "threshold": threshold, "accepted": count,
            "total": int(len(targets)), "coverage": float(count / len(targets)),
            "selective_error": error}


def outer_fold_metrics(rows: list[dict], indices: np.ndarray, predictions: np.ndarray,
                       confidence: np.ndarray, threshold: float) -> dict:
    targets = np.asarray([rows[int(i)]["reference"] for i in indices])
    accepted = confidence >= threshold
    coref = np.asarray([(rows[int(i)].get("mention_type") or "") == "pronoun/coref" for i in indices])
    result = {
        "n": int(len(indices)), "accuracy": float(accuracy_score(targets, predictions)),
        "threshold": float(threshold), "accepted": int(accepted.sum()),
        "coverage": float(accepted.mean()),
        "selective_error": float(np.mean(predictions[accepted] != targets[accepted])) if accepted.any() else None,
        "accepted_correct": int(np.sum(accepted & (predictions == targets))),
        "accepted_wrong": int(np.sum(accepted & (predictions != targets))),
        "mention_type": {},
    }
    for name, mask in (("explicit", ~coref), ("pronoun_coreference", coref)):
        sub = mask & accepted
        result["mention_type"][name] = {
            "n": int(mask.sum()), "accepted": int(sub.sum()),
            "coverage": float(sub.sum() / mask.sum()) if mask.any() else None,
            "selective_error": float(np.mean(predictions[sub] != targets[sub])) if sub.any() else None,
        }
    return result


def main() -> None:
    args = parse_args()
    rows, features, metadata, signature = load_rows_and_features(args)
    participants = sorted({row["participant_id"] for row in rows})
    rng = np.random.default_rng(SEED)
    shuffled = np.asarray(participants)[rng.permutation(len(participants))]
    outer_folds = [sorted(fold.tolist()) for fold in np.array_split(shuffled, args.outer_folds)]
    outer_results = []
    all_predictions = np.empty(len(rows), dtype=object)
    all_confidence = np.full(len(rows), np.nan, dtype=float)
    all_threshold = np.full(len(rows), np.nan, dtype=float)
    for outer_index, held_out in enumerate(outer_folds):
        held_mask = np.asarray([row["participant_id"] in held_out for row in rows])
        outer_train = np.flatnonzero(~held_mask)
        outer_test = np.flatnonzero(held_mask)
        inner_participants = sorted({rows[int(i)]["participant_id"] for i in outer_train})
        inner_rng = np.random.default_rng(SEED + outer_index + 1)
        inner_perm = np.asarray(inner_participants)[inner_rng.permutation(len(inner_participants))]
        inner_folds = [sorted(fold.tolist()) for fold in np.array_split(inner_perm, args.inner_folds)]
        oof_pred = np.empty(len(outer_train), dtype=object)
        oof_conf = np.full(len(outer_train), np.nan, dtype=float)
        for inner_held in inner_folds:
            local_held = np.asarray([rows[int(i)]["participant_id"] in inner_held for i in outer_train])
            train_local = np.flatnonzero(~local_held)
            eval_local = np.flatnonzero(local_held)
            pred, conf = fit_predict(rows, outer_train[train_local], outer_train[eval_local], features)
            oof_pred[eval_local] = pred
            oof_conf[eval_local] = conf
        if np.isnan(oof_conf).any():
            raise RuntimeError("Inner OOF confidence is incomplete")
        oof_targets = np.asarray([rows[int(i)]["reference"] for i in outer_train])
        selection = select_threshold(oof_targets, oof_pred, oof_conf, args.maximum_error)
        pred, conf = fit_predict(rows, outer_train, outer_test, features)
        outer_targets = np.asarray([rows[int(i)]["reference"] for i in outer_test])
        fold_metrics = outer_fold_metrics(rows, outer_test, pred, conf, selection["threshold"])
        fold_metrics["held_out_participants"] = held_out
        fold_metrics["outer_train_rows"] = int(len(outer_train))
        fold_metrics["inner_folds"] = inner_folds
        fold_metrics["inner_selection"] = selection
        fold_metrics["inner_oof_accuracy"] = float(accuracy_score(oof_targets, oof_pred))
        outer_results.append(fold_metrics)
        all_predictions[outer_test] = pred
        all_confidence[outer_test] = conf
        all_threshold[outer_test] = selection["threshold"]

    targets = np.asarray([row["reference"] for row in rows])
    accepted = all_confidence >= all_threshold
    coref = np.asarray([(row.get("mention_type") or "") == "pronoun/coref" for row in rows])
    aggregate = {
        "n": int(len(rows)), "accuracy": float(accuracy_score(targets, all_predictions)),
        "accepted": int(accepted.sum()), "coverage": float(accepted.mean()),
        "selective_error": float(np.mean(all_predictions[accepted] != targets[accepted])) if accepted.any() else None,
        "accepted_correct": int(np.sum(accepted & (all_predictions == targets))),
        "accepted_wrong": int(np.sum(accepted & (all_predictions != targets))),
        "thresholds": {
            "min": float(np.min([result["threshold"] for result in outer_results])),
            "max": float(np.max([result["threshold"] for result in outer_results])),
            "median": float(np.median([result["threshold"] for result in outer_results])),
            "unique": sorted({float(result["threshold"]) for result in outer_results}),
        },
        "mention_type": {},
    }
    for name, mask in (("explicit", ~coref), ("pronoun_coreference", coref)):
        sub = mask & accepted
        aggregate["mention_type"][name] = {
            "n": int(mask.sum()), "accepted": int(sub.sum()),
            "coverage": float(sub.sum() / mask.sum()) if mask.any() else None,
            "selective_error": float(np.mean(all_predictions[sub] != targets[sub])) if sub.any() else None,
        }
    output = {
        "protocol": "nested five-inner-fold participant-disjoint threshold transfer inside six outer participant folds",
        "seed": SEED, "maximum_error": args.maximum_error,
        "n_rows": len(rows), "n_participants": len(participants),
        "feature_cache_row_signature": signature, **metadata,
        "outer_folds": outer_results, "aggregate": aggregate,
        "caveats": [
            "The <=5% constraint is empirical on inner out-of-fold rows; it is not a finite-sample confidence guarantee.",
            "Thresholds are selected independently per outer fold and may vary across participant groups.",
            "The audit uses the frozen full-frame handcrafted descriptor and linear probe; it is not an end-to-end VLM evaluation.",
            "No outer-fold labels or confidences are used during threshold selection.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
