"""Six-fold participant-disjoint audit of gaze versus frame-center crops."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler, normalize

from baseline_look_and_tell_classical_vision import (
    SEED,
    add_history,
    full_frame_features,
    image_features,
    load_recording,
    new_model,
    paired_participant_difference,
    participant_ci,
    risk_coverage,
    selective_summary,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--derived-root", type=Path, default=Path("data/derived/look_and_tell")
    )
    parser.add_argument(
        "--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json")
    )
    parser.add_argument(
        "--feature-cache",
        type=Path,
        default=Path("data/derived/look_and_tell_feature_cache.npz"),
    )
    parser.add_argument(
        "--shuffled-feature-cache",
        type=Path,
        default=Path("data/derived/look_and_tell_shuffled_fixation_cache.npz"),
    )
    parser.add_argument(
        "--full-frame-feature-cache",
        type=Path,
        default=Path("data/derived/look_and_tell_full_frame_classical_cache.npz"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/baselines/look_and_tell_gaze_location_crossval.json"),
    )
    parser.add_argument(
        "--shuffle-fraction",
        type=float,
        default=0.5,
        help="Label-free cyclic donor offset as a fraction of valid rows per recording.",
    )
    return parser.parse_args()


def make_shuffled_fixation_rows(
    rows: list[dict], shuffle_fraction: float = 0.5
) -> tuple[list[dict], list[dict]]:
    """Permute valid fixations within recording while preserving availability."""
    if not 0.0 < shuffle_fraction < 1.0:
        raise ValueError("shuffle_fraction must lie strictly between zero and one")
    indices_by_recording: dict[str, list[int]] = {}
    for index, row in enumerate(rows):
        indices_by_recording.setdefault(row["recording_uid"], []).append(index)

    shuffled_rows = [dict(row) for row in rows]
    mapping: list[dict] = [None] * len(rows)  # type: ignore[list-item]
    for recording, indices in sorted(indices_by_recording.items()):
        valid_indices = [
            index
            for index in indices
            if rows[index].get("fix_x") is not None
            and rows[index].get("fix_y") is not None
        ]
        shift = (
            min(len(valid_indices) - 1, max(1, int(len(valid_indices) * shuffle_fraction)))
            if len(valid_indices) >= 2
            else 0
        )
        valid_positions = {index: position for position, index in enumerate(valid_indices)}
        for target_index in indices:
            target_has_fixation = target_index in valid_positions
            if target_has_fixation and len(valid_indices) >= 2:
                position = valid_positions[target_index]
                donor_index = valid_indices[(position + shift) % len(valid_indices)]
            else:
                # Missing rows remain missing. A lone valid row is recorded as
                # non-evaluable rather than changing the availability channel.
                donor_index = target_index
            donor = rows[donor_index]
            shuffled_rows[target_index]["fix_x"] = donor.get("fix_x")
            shuffled_rows[target_index]["fix_y"] = donor.get("fix_y")
            coordinates_changed = (
                rows[target_index].get("fix_x") != donor.get("fix_x")
                or rows[target_index].get("fix_y") != donor.get("fix_y")
            )
            mapping[target_index] = {
                "target_index": target_index,
                "donor_index": donor_index,
                "recording_uid": recording,
                "donor_fix_x": donor.get("fix_x"),
                "donor_fix_y": donor.get("fix_y"),
                "target_has_fixation": target_has_fixation,
                "coordinates_changed": coordinates_changed,
            }
    return shuffled_rows, mapping


def shuffled_fixation_signature(rows: list[dict], mapping: list[dict]) -> str:
    return hashlib.sha256(
        json.dumps(
            [
                {
                    "frame_path": row["frame_path"],
                    **entry,
                }
                for row, entry in zip(rows, mapping, strict=True)
            ],
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()


def main() -> None:
    args = parse_args()
    split_spec = json.loads(args.splits.read_text(encoding="utf-8"))
    split_names = ("train", "val", "test")
    rows = []
    split_lengths = {}
    missing = []
    for split in split_names:
        before = len(rows)
        for recording in split_spec["splits"][split]["recordings"]:
            try:
                rows.extend(load_recording(args.derived_root, recording))
            except FileNotFoundError:
                missing.append(recording)
        split_lengths[split] = len(rows) - before

    frame_paths_by_split = {}
    offset = 0
    for split in split_names:
        next_offset = offset + split_lengths[split]
        frame_paths_by_split[split] = [
            row["frame_path"] for row in rows[offset:next_offset]
        ]
        offset = next_offset
    expected_signature = hashlib.sha256(
        json.dumps(frame_paths_by_split, sort_keys=True).encode("utf-8")
    ).hexdigest()
    with np.load(args.feature_cache, allow_pickle=False) as cache:
        if (
            "row_signature" not in cache
            or str(cache["row_signature"].item()) != expected_signature
        ):
            raise RuntimeError("Classical feature cache row signature mismatch")
        gaze_raw = np.vstack([cache[f"classical_{split}"] for split in split_names])
        center_raw = np.vstack(
            [cache[f"center_classical_{split}"] for split in split_names]
        )
    if len(rows) != gaze_raw.shape[0] or gaze_raw.shape != center_raw.shape:
        raise RuntimeError(
            f"Row/feature mismatch: rows={len(rows)}, gaze={gaze_raw.shape}, "
            f"center={center_raw.shape}"
        )

    full_frame_raw = None
    if args.full_frame_feature_cache.exists():
        with np.load(args.full_frame_feature_cache, allow_pickle=False) as cache:
            if (
                "row_signature" in cache
                and str(cache["row_signature"].item()) == expected_signature
                and "full_frame_raw" in cache
                and cache["full_frame_raw"].shape == gaze_raw.shape
            ):
                full_frame_raw = cache["full_frame_raw"].copy()
    if full_frame_raw is None:
        full_frame_raw = np.vstack([full_frame_features(row) for row in rows])
        args.full_frame_feature_cache.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            args.full_frame_feature_cache,
            row_signature=np.asarray(expected_signature),
            full_frame_raw=full_frame_raw,
        )

    shuffled_rows, shuffle_mapping = make_shuffled_fixation_rows(
        rows, args.shuffle_fraction
    )
    shuffle_signature = shuffled_fixation_signature(rows, shuffle_mapping)
    shuffled_raw = None
    if args.shuffled_feature_cache.exists():
        with np.load(args.shuffled_feature_cache, allow_pickle=False) as cache:
            if (
                "shuffle_signature" in cache
                and str(cache["shuffle_signature"].item()) == shuffle_signature
                and "shuffled_raw" in cache
                and cache["shuffled_raw"].shape == gaze_raw.shape
            ):
                shuffled_raw = cache["shuffled_raw"].copy()
    if shuffled_raw is None:
        shuffled_raw = np.vstack([image_features(row) for row in shuffled_rows])
        args.shuffled_feature_cache.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            args.shuffled_feature_cache,
            shuffle_signature=np.asarray(shuffle_signature),
            shuffled_raw=shuffled_raw,
        )

    participants = sorted({row["participant_id"] for row in rows})
    rng = np.random.default_rng(SEED)
    shuffled = np.asarray(participants)[rng.permutation(len(participants))]
    folds = [sorted(fold.tolist()) for fold in np.array_split(shuffled, 6)]
    model_names = (
        "text_history",
        "text_full_frame_history",
        "text_center_history",
        "text_gaze_history",
        "text_shuffled_history",
    )
    out_of_fold = {name: np.empty(len(rows), dtype=object) for name in model_names}
    out_of_fold_confidence = {
        name: np.full(len(rows), np.nan, dtype=np.float64) for name in model_names
    }
    fold_results = []

    for fold_index, held_out in enumerate(folds):
        test_mask = np.asarray([row["participant_id"] in held_out for row in rows])
        train_mask = ~test_mask
        train_indices = np.flatnonzero(train_mask)
        test_indices = np.flatnonzero(test_mask)
        train_rows = [dict(rows[index]) for index in train_indices]
        test_rows = [dict(rows[index]) for index in test_indices]

        frequencies = Counter(row["reference"] for row in train_rows)
        labels = sorted(frequencies)
        add_history(train_rows, labels, frequencies)
        add_history(test_rows, labels, frequencies)

        text = TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(2, 5),
            min_df=2,
            max_features=20000,
            sublinear_tf=True,
        )
        text_train = text.fit_transform(row.get("surface_text") or "" for row in train_rows)
        text_test = text.transform(row.get("surface_text") or "" for row in test_rows)

        history = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
        history_train = history.fit_transform(
            np.asarray([[row["history_prediction"]] for row in train_rows])
        )
        history_test = history.transform(
            np.asarray([[row["history_prediction"]] for row in test_rows])
        )

        visual_matrices = {}
        for name, raw in (
            ("full_frame", full_frame_raw),
            ("center", center_raw),
            ("gaze", gaze_raw),
            ("shuffled", shuffled_raw),
        ):
            scaler = StandardScaler()
            train_dense = scaler.fit_transform(raw[train_indices])
            test_dense = scaler.transform(raw[test_indices])
            visual_matrices[name] = (
                normalize(csr_matrix(train_dense), norm="l2"),
                normalize(csr_matrix(test_dense), norm="l2"),
            )

        matrices = {
            "text_history": (
                hstack([text_train, history_train], format="csr"),
                hstack([text_test, history_test], format="csr"),
            ),
            "text_center_history": (
                hstack([text_train, visual_matrices["center"][0], history_train], format="csr"),
                hstack([text_test, visual_matrices["center"][1], history_test], format="csr"),
            ),
            "text_full_frame_history": (
                hstack(
                    [text_train, visual_matrices["full_frame"][0], history_train],
                    format="csr",
                ),
                hstack(
                    [text_test, visual_matrices["full_frame"][1], history_test],
                    format="csr",
                ),
            ),
            "text_gaze_history": (
                hstack([text_train, visual_matrices["gaze"][0], history_train], format="csr"),
                hstack([text_test, visual_matrices["gaze"][1], history_test], format="csr"),
            ),
            "text_shuffled_history": (
                hstack(
                    [text_train, visual_matrices["shuffled"][0], history_train],
                    format="csr",
                ),
                hstack(
                    [text_test, visual_matrices["shuffled"][1], history_test],
                    format="csr",
                ),
            ),
        }
        targets_train = np.asarray([row["reference"] for row in train_rows])
        targets_test = np.asarray([row["reference"] for row in test_rows])
        metrics = {}
        for name, (matrix_train, matrix_test) in matrices.items():
            model = new_model()
            model.fit(matrix_train, targets_train)
            predictions = model.predict(matrix_test)
            out_of_fold[name][test_indices] = predictions
            out_of_fold_confidence[name][test_indices] = model.predict_proba(
                matrix_test
            ).max(axis=1)
            metrics[name] = {
                "accuracy": float(accuracy_score(targets_test, predictions)),
                "macro_f1": float(
                    f1_score(targets_test, predictions, average="macro", zero_division=0)
                ),
            }
        fold_results.append(
            {
                "fold": fold_index,
                "held_out_participants": held_out,
                "n": len(test_rows),
                "metrics": metrics,
            }
        )

    targets = np.asarray([row["reference"] for row in rows])
    aggregate = {}
    for name in model_names:
        predictions = out_of_fold[name]
        coref = np.asarray(
            [(row.get("mention_type") or "") == "pronoun/coref" for row in rows]
        )
        aggregate[name] = {
            "accuracy": float(accuracy_score(targets, predictions)),
            "accuracy_participant_bootstrap_95ci": participant_ci(
                rows, targets, predictions
            ),
            "macro_f1": float(
                f1_score(targets, predictions, average="macro", zero_division=0)
            ),
            "coref_accuracy": float(accuracy_score(targets[coref], predictions[coref])),
        }

    comparisons = {
        "full_frame_minus_text_history": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_full_frame_history"],
            out_of_fold["text_history"],
        ),
        "center_minus_full_frame": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_center_history"],
            out_of_fold["text_full_frame_history"],
        ),
        "gaze_minus_full_frame": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_gaze_history"],
            out_of_fold["text_full_frame_history"],
        ),
        "gaze_minus_center": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_gaze_history"],
            out_of_fold["text_center_history"],
        ),
        "gaze_minus_text_history": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_gaze_history"],
            out_of_fold["text_history"],
        ),
        "center_minus_text_history": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_center_history"],
            out_of_fold["text_history"],
        ),
        "shuffled_minus_text_history": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_shuffled_history"],
            out_of_fold["text_history"],
        ),
        "gaze_minus_shuffled": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_gaze_history"],
            out_of_fold["text_shuffled_history"],
        ),
        "center_minus_shuffled": paired_participant_difference(
            rows,
            targets,
            out_of_fold["text_center_history"],
            out_of_fold["text_shuffled_history"],
        ),
    }
    available_fixation_mask = np.asarray(
        [row.get("fix_x") is not None and row.get("fix_y") is not None for row in rows]
    )
    nontrivial_shuffle_mask = np.asarray(
        [mapping["coordinates_changed"] for mapping in shuffle_mapping]
    )
    for suffix, mask in (
        ("available_fixations", available_fixation_mask),
        ("nontrivial_shuffle", nontrivial_shuffle_mask),
    ):
        subset_rows = [row for row, selected in zip(rows, mask) if selected]
        comparisons[f"gaze_minus_shuffled_{suffix}"] = paired_participant_difference(
            subset_rows,
            targets[mask],
            out_of_fold["text_gaze_history"][mask],
            out_of_fold["text_shuffled_history"][mask],
        )
    distances = np.asarray(
        [
            np.hypot((row.get("fix_x") or 704.0) / 1408.0 - 0.5,
                     (row.get("fix_y") or 704.0) / 1408.0 - 0.5)
            for row in rows
        ]
    )
    edges = np.quantile(distances, (0.0, 0.25, 0.5, 0.75, 1.0))
    distance_quartiles = []
    for quartile in range(4):
        lower, upper = edges[quartile], edges[quartile + 1]
        mask = (distances >= lower) & (
            distances <= upper if quartile == 3 else distances < upper
        )
        subset_rows = [row for row, selected in zip(rows, mask) if selected]
        subset_targets = targets[mask]
        center_predictions = out_of_fold["text_center_history"][mask]
        gaze_predictions = out_of_fold["text_gaze_history"][mask]
        shuffled_predictions = out_of_fold["text_shuffled_history"][mask]
        distance_quartiles.append(
            {
                "quartile": quartile + 1,
                "distance_range_normalized": [float(lower), float(upper)],
                "n": int(mask.sum()),
                "center_accuracy": float(
                    accuracy_score(subset_targets, center_predictions)
                ),
                "gaze_accuracy": float(accuracy_score(subset_targets, gaze_predictions)),
                "shuffled_accuracy": float(
                    accuracy_score(subset_targets, shuffled_predictions)
                ),
                "gaze_minus_center": paired_participant_difference(
                    subset_rows,
                    subset_targets,
                    gaze_predictions,
                    center_predictions,
                ),
                "gaze_minus_shuffled": paired_participant_difference(
                    subset_rows,
                    subset_targets,
                    gaze_predictions,
                    shuffled_predictions,
                ),
            }
        )

    mention_subgroups = {}
    for mention_type in sorted({row.get("mention_type") or "unknown" for row in rows}):
        mask = np.asarray(
            [(row.get("mention_type") or "unknown") == mention_type for row in rows]
        )
        subset_rows = [row for row, selected in zip(rows, mask) if selected]
        subset_targets = targets[mask]
        text_predictions = out_of_fold["text_history"][mask]
        center_predictions = out_of_fold["text_center_history"][mask]
        gaze_predictions = out_of_fold["text_gaze_history"][mask]
        shuffled_predictions = out_of_fold["text_shuffled_history"][mask]
        mention_subgroups[mention_type] = {
            "n": int(mask.sum()),
            "text_history_accuracy": float(
                accuracy_score(subset_targets, text_predictions)
            ),
            "full_frame_accuracy": float(
                accuracy_score(
                    subset_targets,
                    out_of_fold["text_full_frame_history"][mask],
                )
            ),
            "center_accuracy": float(accuracy_score(subset_targets, center_predictions)),
            "gaze_accuracy": float(accuracy_score(subset_targets, gaze_predictions)),
            "shuffled_accuracy": float(
                accuracy_score(subset_targets, shuffled_predictions)
            ),
            "center_minus_text_history": paired_participant_difference(
                subset_rows, subset_targets, center_predictions, text_predictions
            ),
            "full_frame_minus_text_history": paired_participant_difference(
                subset_rows,
                subset_targets,
                out_of_fold["text_full_frame_history"][mask],
                text_predictions,
            ),
            "center_minus_full_frame": paired_participant_difference(
                subset_rows,
                subset_targets,
                center_predictions,
                out_of_fold["text_full_frame_history"][mask],
            ),
            "gaze_minus_text_history": paired_participant_difference(
                subset_rows, subset_targets, gaze_predictions, text_predictions
            ),
            "gaze_minus_center": paired_participant_difference(
                subset_rows, subset_targets, gaze_predictions, center_predictions
            ),
            "gaze_minus_shuffled": paired_participant_difference(
                subset_rows, subset_targets, gaze_predictions, shuffled_predictions
            ),
        }

    def transition_counts(candidate: np.ndarray, mask: np.ndarray) -> dict[str, int]:
        """Count when a visual candidate repairs or breaks the text-history result."""
        text_correct = out_of_fold["text_history"][mask] == targets[mask]
        candidate_correct = candidate[mask] == targets[mask]
        return {
            "n": int(mask.sum()),
            "both_correct": int(np.sum(text_correct & candidate_correct)),
            "both_wrong": int(np.sum(~text_correct & ~candidate_correct)),
            "visual_repairs_text_error": int(np.sum(~text_correct & candidate_correct)),
            "visual_breaks_text_success": int(np.sum(text_correct & ~candidate_correct)),
        }

    all_rows = np.ones(len(rows), dtype=bool)
    correction_analysis = {
        "all": {
            "full_frame": transition_counts(
                out_of_fold["text_full_frame_history"], all_rows
            ),
            "center": transition_counts(
                out_of_fold["text_center_history"], all_rows
            ),
            "gaze": transition_counts(out_of_fold["text_gaze_history"], all_rows),
            "shuffled": transition_counts(
                out_of_fold["text_shuffled_history"], all_rows
            ),
        },
        "mention_type": {},
    }
    for mention_type in sorted({row.get("mention_type") or "unknown" for row in rows}):
        mask = np.asarray(
            [(row.get("mention_type") or "unknown") == mention_type for row in rows]
        )
        correction_analysis["mention_type"][mention_type] = {
            "full_frame": transition_counts(
                out_of_fold["text_full_frame_history"], mask
            ),
            "center": transition_counts(out_of_fold["text_center_history"], mask),
            "gaze": transition_counts(out_of_fold["text_gaze_history"], mask),
            "shuffled": transition_counts(
                out_of_fold["text_shuffled_history"], mask
            ),
        }

    center_predictions = out_of_fold["text_center_history"]
    gaze_predictions = out_of_fold["text_gaze_history"]
    disagreement = center_predictions != gaze_predictions
    crop_disagreement = {
        "n": int(disagreement.sum()),
        "rate": float(disagreement.mean()),
        "center_correct_gaze_wrong": int(
            np.sum(disagreement & (center_predictions == targets))
        ),
        "gaze_correct_center_wrong": int(
            np.sum(disagreement & (gaze_predictions == targets))
        ),
        "both_wrong_different_labels": int(
            np.sum(
                disagreement
                & (center_predictions != targets)
                & (gaze_predictions != targets)
            )
        ),
    }
    shuffled_predictions = out_of_fold["text_shuffled_history"]
    gaze_shuffle_disagreement = gaze_predictions != shuffled_predictions
    gaze_shuffle_analysis = {
        "n": int(gaze_shuffle_disagreement.sum()),
        "rate": float(gaze_shuffle_disagreement.mean()),
        "gaze_correct_shuffled_wrong": int(
            np.sum(gaze_shuffle_disagreement & (gaze_predictions == targets))
        ),
        "shuffled_correct_gaze_wrong": int(
            np.sum(gaze_shuffle_disagreement & (shuffled_predictions == targets))
        ),
        "both_wrong_different_labels": int(
            np.sum(
                gaze_shuffle_disagreement
                & (gaze_predictions != targets)
                & (shuffled_predictions != targets)
            )
        ),
    }
    coordinate_collisions = sum(
        rows[index].get("fix_x") == mapping["donor_fix_x"]
        and rows[index].get("fix_y") == mapping["donor_fix_y"]
        for index, mapping in enumerate(shuffle_mapping)
    )
    available_coordinate_collisions = int(
        np.sum(available_fixation_mask & ~nontrivial_shuffle_mask)
    )
    available_same_row_donors = sum(
        mapping["target_has_fixation"]
        and mapping["target_index"] == mapping["donor_index"]
        for mapping in shuffle_mapping
    )
    missing_same_row_donors = sum(
        not mapping["target_has_fixation"]
        and mapping["target_index"] == mapping["donor_index"]
        for mapping in shuffle_mapping
    )
    coref_mask = np.asarray(
        [(row.get("mention_type") or "") == "pronoun/coref" for row in rows]
    )
    explicit_mask = ~coref_mask
    selective_analysis = {}
    for subset_name, mask in (
        ("all", np.ones(len(rows), dtype=bool)),
        ("explicit", explicit_mask),
        ("pronoun_coreference", coref_mask),
    ):
        subset_targets = targets[mask]
        selective_analysis[subset_name] = {
            "n": int(mask.sum()),
            "models": {},
        }
        for name in model_names:
            predictions = out_of_fold[name][mask]
            confidence = out_of_fold_confidence[name][mask]
            if np.isnan(confidence).any():
                raise RuntimeError(f"Missing out-of-fold confidence for {name}")
            selective_analysis[subset_name]["models"][name] = {
                "risk_coverage": risk_coverage(
                    subset_targets, predictions, confidence
                ),
                **selective_summary(subset_targets, predictions, confidence),
            }
    output = {
        "protocol": "six-fold participant-disjoint out-of-fold evaluation",
        "seed": SEED,
        "shuffle_fraction": args.shuffle_fraction,
        "n_rows": len(rows),
        "n_participants": len(participants),
        "split_lengths": split_lengths,
        "missing_media_recordings": missing,
        "shuffled_fixation_control": {
            "construction": (
                "Within each chronological recording, valid fixation coordinates are "
                f"borrowed from a valid row {args.shuffle_fraction:.6g} of a sequence "
                "away under a deterministic "
                "cyclic shift. Missing rows remain missing, preserving the availability "
                "channel exactly; labels are never consulted."
            ),
            "cache_signature": shuffle_signature,
            "available_fixation_rows": int(available_fixation_mask.sum()),
            "nontrivial_shuffled_rows": int(nontrivial_shuffle_mask.sum()),
            "changed_coordinates_available_fixations": int(
                nontrivial_shuffle_mask.sum()
            ),
            "unchanged_coordinates_available_fixations": available_coordinate_collisions,
            "same_row_donors": int(
                sum(mapping["target_index"] == mapping["donor_index"] for mapping in shuffle_mapping)
            ),
            "same_row_donors_available_fixations": int(available_same_row_donors),
            "same_row_donors_missing_fixations": int(missing_same_row_donors),
            "exact_coordinate_collisions": int(coordinate_collisions),
            "exact_coordinate_collisions_all_rows": int(coordinate_collisions),
            "exact_coordinate_collisions_available_fixations": available_coordinate_collisions,
        },
        "folds": fold_results,
        "aggregate": aggregate,
        "paired_participant_differences": comparisons,
        "subgroups": {
            "fixation_distance_quartiles": distance_quartiles,
            "mention_type": mention_subgroups,
        },
        "error_analysis": {
            "text_to_visual_transitions": correction_analysis,
            "center_gaze_disagreement": crop_disagreement,
            "gaze_shuffled_disagreement": gaze_shuffle_analysis,
        },
        "selective_analysis": selective_analysis,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
