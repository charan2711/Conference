# Local Model Control Rationale

Checked 2026-07-13.

The model matrix is designed for scientific controls, not leaderboard coverage:

- **Qwen2.5-Coder-1.5B-Instruct Q4**: low-cost pilot and lower-capability scale.
- **Qwen2.5-Coder-7B-Instruct Q4**: primary local coder; expanded paired repair
  and downstream experiments.
- **Mistral-7B-Instruct-v0.3 Q4**: independent architecture/family at similar
  parameter scale. Official model page:
  https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3
- **Qwen2.5-Coder-14B-Instruct Q3_K_M**: exploratory within-family scale control.
  Q3 was necessary to run with partial CPU offload on 6 GB VRAM; it is not a
  clean full-precision scaling comparison. Official GGUF page:
  https://huggingface.co/Qwen/Qwen2.5-Coder-14B-Instruct-GGUF

Hardware is an RTX 2060 (6 GB), Intel i7-9750H, and 15.8 GB system RAM. Qwen-7B
and Mistral-7B fit through the Vulkan backend; Qwen-14B uses 7.34 GB quantized
weights and therefore partially offloads to CPU. A newer CUDA build is
incompatible with the installed NVIDIA 512.59 driver, so the study uses Vulkan.
No driver or system configuration was changed.
The recorded binary is llama.cpp build 9982 (`99f3dc322`), compiled with Clang
20.1.8 for Windows x86_64.

Interpretation rules:

1. Do not compare raw accuracy across quantization levels as if it isolated
   parameter count.
2. Treat Mistral as the stronger independence check because it changes family
   while keeping quantization and scale approximately matched.
3. Treat Qwen-14B as exploratory evidence about whether the identified failures
   trivially disappear with a larger local model.
4. The deterministic policy result must not depend on any model result.

## Completed 14B tool-control outcome

The serial 22-target, seven-condition Qwen-14B Q3 run contains all 154 expected
cells and passes its target, duplicate, and unaffected-trace invariants. Runtime
policy and builder repair reach 10/22 (45.5%), stale memory, filtering, and
re-exploration reach 11/22 (50.0%), and execution-guided memory and no memory
reach 9/22 (40.9%). Policy versus stale has one improvement and two
degradations; the database-cluster 95% interval is [-18.2, 9.1] points and the
sign-flip p-value is 1.0. On the same manifest, Qwen-7B policy reaches 11/22.
This fails to reproduce the directional expanded-7B gain and is reported as a
negative robustness result, not concealed or interpreted as parameter scaling.
