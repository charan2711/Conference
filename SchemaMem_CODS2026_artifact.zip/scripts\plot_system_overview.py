from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "paper" / "figures"
OUT.mkdir(parents=True, exist_ok=True)


def box(ax, xy, width, height, text, color, *, fontsize=8, linewidth=1.0):
    patch = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.025,rounding_size=0.025",
        facecolor=color,
        edgecolor="#333333",
        linewidth=linewidth,
    )
    ax.add_patch(patch)
    ax.text(
        xy[0] + width / 2,
        xy[1] + height / 2,
        text,
        ha="center",
        va="center",
        fontsize=fontsize,
        color="#111111",
    )
    return patch


def arrow(ax, start, end, *, label=None, color="#444444", style="-|>", rad=0):
    ax.add_patch(
        FancyArrowPatch(
            start,
            end,
            arrowstyle=style,
            mutation_scale=10,
            linewidth=1.0,
            color=color,
            connectionstyle=f"arc3,rad={rad}",
        )
    )
    if label:
        ax.text(
            (start[0] + end[0]) / 2,
            (start[1] + end[1]) / 2 + 0.045,
            label,
            ha="center",
            va="bottom",
            fontsize=6.7,
            color=color,
        )


fig, ax = plt.subplots(figsize=(7.2, 2.35))
ax.set_xlim(0, 10)
ax.set_ylim(0, 3.1)
ax.axis("off")

blue = "#DCEAF7"
orange = "#FBE4D5"
green = "#DCEFD9"
gray = "#EEEEEE"
red = "#F4D6D7"

box(ax, (0.10, 1.72), 1.55, 0.72, "Successful prior\nquestion + SQL", blue)
box(ax, (2.02, 1.72), 1.55, 0.72, "AST dependencies\n+ schema version", blue)
box(ax, (3.95, 1.72), 1.35, 0.72, "Procedural\nmemory store", blue)
arrow(ax, (1.65, 2.08), (2.02, 2.08))
arrow(ax, (3.57, 2.08), (3.95, 2.08))

box(ax, (2.02, 0.35), 1.55, 0.72, "DDL / migration\nmanifest", orange)
box(ax, (3.95, 0.35), 1.35, 0.72, "Dependency\nimpact analysis", orange)
arrow(ax, (3.57, 0.71), (3.95, 0.71))
arrow(ax, (4.62, 1.72), (4.62, 1.07))

box(ax, (5.78, 1.72), 1.55, 0.72, "Unique affected map\nrewrite + validate", green)
arrow(ax, (5.30, 0.90), (5.78, 1.88))
box(
    ax,
    (5.78, 0.35),
    1.55,
    0.72,
    "Ambiguous / destructive\nexplore\nor invalidate",
    red,
    fontsize=6.6,
)
arrow(ax, (5.30, 0.71), (5.78, 0.71))

box(ax, (5.78, 2.66), 1.55, 0.28, "Unaffected: reuse", green, fontsize=6.8)
arrow(ax, (5.18, 1.07), (5.78, 2.80))
box(ax, (7.80, 1.72), 1.95, 0.72, "Safe retrieved memory\nfor a new question", green)
arrow(ax, (7.33, 2.08), (7.80, 2.08))
arrow(ax, (7.33, 2.80), (7.80, 2.35))

box(ax, (7.80, 0.35), 1.95, 0.72, "Tool agent: list / inspect\nexecute / observe / final", gray)
arrow(ax, (8.78, 1.72), (8.78, 1.07))
arrow(ax, (7.33, 0.71), (7.80, 0.71))

ax.text(0.10, 2.82, "Memory write path", fontsize=8.5, weight="bold", color="#244A6A")
ax.text(0.10, 0.72, "Schema change", fontsize=8.5, weight="bold", color="#8A4B20")

fig.tight_layout(pad=0.15)
fig.savefig(OUT / "system_overview.pdf", bbox_inches="tight", facecolor="white")
fig.savefig(OUT / "system_overview.png", dpi=260, bbox_inches="tight", facecolor="white")
plt.close(fig)
