# Component ablation, scope refinement, and DuckDB portability results

Status: completed under
`research/ablation_portability_preregistration.md` and the adaptive refinement
protocol in `research/scope_validator_refinement.md`.

## Mechanism ablation

The compatible suite contains 1,782 frozen execution-equivalent cases across 11
databases: 490 column renames, 498 table renames, 397 vertical splits, and 397
reverse consolidations.

- Filter-only returns 47.64% and is correct on the same fraction.
- AST rewriting without the released flat validator returns and correctly
  maintains 1,782/1,782.
- The released flat-scope validator returns 1,744/1,782 (97.87%), withholding
  17 column-renames and 21 table-renames; every returned program is correct.
- The failure root is generic: derived-table outputs and aliases were treated as
  unresolved physical columns.

On the 450-case uncertainty suite, the released flat validator plus a
deterministic first-candidate rule returns 197/200 safe cases but also returns
146/250 ambiguous/unsafe cases (58.4%). Adding an execution dry run changes
nothing: all 146 execute and happen to match the finite fixture. Full fail-closed
SchemaMem returns 197/200 safe cases and 0/250 unsafe cases. Thus schema or
execution validity does not establish that an ambiguous event supplies the
right mapping; the explicit uniqueness gate is necessary.

## Scope-aware refinement

The adaptive protocol inspected only the lexicographically first legacy
withhold before freezing a generic SQLGlot scope-qualification replacement.
After the change:

- compatible coverage and correctness are 1,782/1,782 in every operator family;
- safe-case coverage is 200/200;
- unsafe returns remain 0/250;
- first-candidate plus schema or execution validation now returns all 150
  ambiguous cases, so its unsafe-return rate is 60.0%; and
- all 35 unit tests pass, including frozen-flat, derived-output, missing-output, and
  ambiguous-column regressions.

The refinement therefore passes all frozen adoption gates. The legacy 38-case
availability loss remains recorded as the motivating ablation.

On the independent Dr.Spider maintenance audit, the refined policy changes one
decision and returns 26 rather than 25 memories. All 26 execute and are
semantically correct; unsafe returns remain zero. A complete adaptive rerun of
all 32 downstream policy targets changes exactly that target's memory input and
prediction, but not its correctness: both legacy and refined policy score 24/32
(75.0%). Mean tokens rise from 1,996.1 to 2,016.7. This is an implementation
coverage improvement, not a downstream-accuracy gain.

## DuckDB portability

Every compatible case was automatically translated from SQLite to DuckDB SQL
with SQLGlot and executed by DuckDB 1.5.4 over read-only scanner-attached data.
No query-specific edit was permitted.

- Inputs: 1,782 cases, 11 databases.
- Portability-eligible: 1,318 cases (74.0%), all 11 databases.
- Result-equivalent repaired programs: 1,318/1,318 (100.0%; Wilson 95% interval
  [99.71%, 100%]).
- Exclusions: 248 cases where the supplied gold result itself differed between
  engines, 178 where the translated gold failed in DuckDB, and 38 legacy-policy
  withholds. The portability run preceded the scope refinement, so the 38
  legacy withholds remain exclusions rather than being retroactively rescored.

This supports engine portability only for the automatically eligible subset. It
does not establish universal SQL-dialect portability, transaction semantics, or
enterprise concurrency behavior.

## Post-change reproducibility audit

The executable exposes `--validator legacy_flat` and `--validator current` so
the prerefinement and adopted policies remain separately reproducible. Against
the saved instance records, the frozen-flat mode has 0/2,232 target-level policy
decision mismatches; the current-mode aggregate and instance JSON are
canonical-value identical to the saved refined files. A fresh full DuckDB replay
under `legacy_flat` is canonical-value identical to both saved portability
files, including 1,318 eligible cases and every exclusion count. Unaffected
memories bypass validation in both frozen modes, preserving the specified reuse
semantics.

## Deterministic qualitative selection

The frozen selector found eight execution-guided executable-but-wrong repairs,
150 ambiguous mappings withheld by the full policy, three downstream failures
after a certified-correct memory, and 31 nested-scope rejections. It stores the
lexicographically first example in each class in
`results/schemamem/qualitative_failure_examples.json`; no favorable example was
chosen manually.

## Frontier-model gate

No OpenAI, Anthropic, Google/Gemini, or Azure OpenAI API credential is present
in the environment. The frontier replication was therefore not run. The prior
quantized 14B result is not relabeled as a frontier-model control, and the user
Kaggle credential remains unused.
