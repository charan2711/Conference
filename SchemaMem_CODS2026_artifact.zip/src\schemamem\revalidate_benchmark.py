"""Recheck excluded rename candidates with the current semantic comparator."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .build_benchmark import (
    BENCHMARK_VALIDATION_VM_STEPS,
    execute,
    result_equivalent,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--benchmark", type=Path, default=Path("data/schemamem-bench-v1")
    )
    parser.add_argument(
        "--originals",
        type=Path,
        default=Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases"),
    )
    args = parser.parse_args()
    path = args.benchmark / "instances.json"
    rows = json.loads(path.read_text(encoding="utf-8"))
    rechecked = recovered = 0
    for row in rows:
        if row["execution_equivalent"]:
            continue
        rechecked += 1
        original = args.originals / row["db_id"] / f'{row["db_id"]}.sqlite'
        migrated = (
            args.benchmark
            / "databases"
            / row["scenario"]
            / row["db_id"]
            / f'{row["db_id"]}.sqlite'
        )
        old_ok, old_result = execute(
            original,
            row["old_sql"],
            vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
        )
        new_ok, new_result = execute(
            migrated,
            row["new_sql"],
            vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
        )
        equivalent = old_ok and new_ok and result_equivalent(
            old_result, new_result, row["old_sql"]
        )
        recovered += int(equivalent)
        row.update(
            {
                "old_exec_ok": old_ok,
                "new_exec_ok": new_ok,
                "execution_equivalent": equivalent,
                "old_error": None if old_ok else old_result,
                "new_error": None if new_ok else new_result,
            }
        )
    path.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    by_scenario = {}
    for scenario in sorted({row["scenario"] for row in rows}):
        group = [row for row in rows if row["scenario"] == scenario]
        by_scenario[scenario] = {
            "n": len(group),
            "affected_rate": sum(row["affected"] for row in group) / len(group),
            "equivalence_rate": sum(row["execution_equivalent"] for row in group) / len(group),
        }
    summary = {
        "instances": len(rows),
        "old_exec_rate": sum(row["old_exec_ok"] for row in rows) / len(rows),
        "new_exec_rate": sum(row["new_exec_ok"] for row in rows) / len(rows),
        "equivalence_rate": sum(row["execution_equivalent"] for row in rows) / len(rows),
        "affected_rate": sum(row["affected"] for row in rows) / len(rows),
        "by_scenario": by_scenario,
        "revalidation": {"rechecked": rechecked, "recovered": recovered},
    }
    (args.benchmark / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
