# Adaptive scope-aware validator refinement

Status: frozen before aggregate evaluation of the refinement.

The preregistered component ablation found 38/1,782 compatible cases withheld by
the released flat-scope schema validator: 17 column renames and 21 table
renames, all with reason `candidate_failed_schema_validation`. The first failure
under the frozen lexicographic order was inspected to diagnose the class of
problem. Its outer query references the output aliases `School` and `rnk` of a
derived table. The released validator combines every physical table across all
query scopes and therefore cannot recognize derived-table output columns.

No other failed SQL was inspected before this protocol was written.

## Fixed refinement

Replace only the schema-validation predicate with SQLGlot's generic scope-aware
qualification pass:

- parse as SQLite;
- supply the complete current physical schema with unknown scalar types;
- qualify physical, CTE, and derived-table columns by scope;
- require `validate_qualify_columns=True`;
- treat any parse, schema, optimization, or unresolved/ambiguous-column error as
  validation failure.

No query-, database-, alias-, or benchmark-specific exception is allowed. The
structural rewriters, impact analysis, ambiguity gates, manifests, and execution
evaluator remain unchanged.

## Frozen evaluation and adoption gates

Recompute decisions and execution results on all 1,782 compatible cases and all
450 uncertainty cases from the earlier ablation. Report the released flat
validator as `flat_schema_legacy` and the candidate as
`scope_schema_validated`.

Adopt the refinement only if all conditions hold:

1. compatible returned-program precision remains 100%;
2. compatible coverage does not decrease in any operator family;
3. full fail-closed unsafe returns remain exactly 0/250;
4. safe-case coverage does not decrease from 197/200; and
5. all existing and new validator regression tests pass.

The same 32-target Dr.Spider policy-maintenance audit will be recomputed without
rerunning the downstream model. This is a decision/maintenance holdout only:
report changes in returned count and semantic correctness, but do not infer new
downstream accuracy for newly returned memories without a new model run.

If adopted, the earlier 38-withhold result remains reported as the motivating
legacy ablation rather than being deleted.

## Adaptive downstream rerun (frozen before outcomes)

Because the adopted validator changes exactly one of the 32 Dr.Spider
maintenance decisions, rerun the complete `policy_memory` condition rather than
only that target. Freeze the existing target manifest SHA-256
`d42db885dcf04bc03f4fd8c39d185b6ff960fb0a5a6a04eea783eb578bbc39fe`;
Qwen2.5-Coder-7B-Instruct Q4; llama.cpp build 9982 Vulkan; one serial worker;
temperature 0; seed 42; 4,096-token context; eight calls; 256 generated tokens
per call; and the existing named-table schema/read-only SQL tools. Use model
label `qwen2.5-coder-7b-q4-drspider-scope-refined-v2` and a new output file.

This is an adaptive robustness rerun, not a replacement confirmatory trial.
Compare its 32 outcomes to the original policy condition and report every
changed target. Do not recompute the preregistered comparisons against stale,
no-memory, or execution-guided conditions as if the refinement had been frozen
before the original Dr.Spider study. Adopt the new downstream result only if the
run is complete, passes target/integrity checks, and the 26 returned memories
recompute as semantically correct.
