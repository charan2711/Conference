"""Audit ALFRED trajectories for visually verifiable smart-home actions.

The script uses only Python's standard library. It extracts human-authored
high-level instructions aligned with state-changing simulator actions without
copying worker identifiers into the derived manifest.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


RELEVANT_ACTIONS = {"ToggleObject", "OpenObject", "CloseObject"}


def object_type(object_id: str | None) -> str | None:
    if not object_id:
        return None
    return object_id.split("|", 1)[0]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data-root",
        type=Path,
        default=Path("third_party/alfred/data/json_2.1.0"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data/manifests/alfred_state_actions.jsonl"),
    )
    parser.add_argument(
        "--summary",
        type=Path,
        default=Path("artifacts/audits/alfred_state_actions_summary.json"),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    trajectory_files = sorted(args.data_root.glob("**/traj_data.json"))
    records: list[dict] = []
    malformed: list[str] = []
    all_action_counts: Counter[str] = Counter()
    split_trajectory_counts: Counter[str] = Counter()

    for path in trajectory_files:
        try:
            trajectory = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            malformed.append(path.as_posix())
            continue

        split = path.relative_to(args.data_root).parts[0]
        split_trajectory_counts[split] += 1
        annotations = trajectory.get("turk_annotations", {}).get("anns", [])
        floor_plan = trajectory.get("scene", {}).get("floor_plan")

        for high_action in trajectory.get("plan", {}).get("high_pddl", []):
            discrete = high_action.get("discrete_action", {})
            action = discrete.get("action")
            if action:
                all_action_counts[action] += 1
            if action not in RELEVANT_ACTIONS:
                continue

            high_idx = high_action.get("high_idx")
            planner = high_action.get("planner_action", {})
            target_id = planner.get("objectId")
            target_type = object_type(target_id)
            if target_type is None:
                action_args = discrete.get("args") or []
                target_type = action_args[0] if action_args else None

            aligned_instructions = []
            task_descriptions = []
            for annotation in annotations:
                descriptions = annotation.get("high_descs") or []
                if isinstance(high_idx, int) and high_idx < len(descriptions):
                    text = descriptions[high_idx].strip()
                    if text:
                        aligned_instructions.append(text)
                task_text = (annotation.get("task_desc") or "").strip()
                if task_text:
                    task_descriptions.append(task_text)

            records.append(
                {
                    "source": path.relative_to(args.data_root).as_posix(),
                    "split": split,
                    "task_id": trajectory.get("task_id"),
                    "task_type": trajectory.get("task_type"),
                    "floor_plan": floor_plan,
                    "action": action,
                    "high_idx": high_idx,
                    "target_object_id": target_id,
                    "target_object_type": target_type,
                    "instructions": sorted(set(aligned_instructions)),
                    "task_descriptions": sorted(set(task_descriptions)),
                }
            )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")

    by_action = Counter(record["action"] for record in records)
    by_split = Counter(record["split"] for record in records)
    by_target = Counter(record["target_object_type"] for record in records)
    scenes_by_split: dict[str, set[str]] = defaultdict(set)
    for record in records:
        if record["floor_plan"]:
            scenes_by_split[record["split"]].add(record["floor_plan"])

    summary = {
        "trajectory_files": len(trajectory_files),
        "malformed_files": malformed,
        "relevant_action_records": len(records),
        "records_with_aligned_human_instruction": sum(bool(record["instructions"]) for record in records),
        "aligned_human_instruction_variants": sum(len(record["instructions"]) for record in records),
        "trajectory_counts_by_split": dict(sorted(split_trajectory_counts.items())),
        "relevant_records_by_split": dict(sorted(by_split.items())),
        "relevant_records_by_action": dict(sorted(by_action.items())),
        "relevant_records_by_target": dict(by_target.most_common()),
        "unique_scenes_by_split": {key: len(value) for key, value in sorted(scenes_by_split.items())},
        "all_high_level_action_counts": dict(all_action_counts.most_common()),
        "manifest": args.output.as_posix(),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
