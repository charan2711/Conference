"""Create deterministic participant-disjoint splits from non-empty references."""

from __future__ import annotations

import argparse
import csv
import json
import random
from collections import Counter
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, default=Path("data/raw/look_and_tell"))
    parser.add_argument("--output", type=Path, default=Path("data/manifests/look_and_tell_splits.json"))
    # par_01 was used for media-pipeline development before freezing splits, so
    # use a seed that places it in train rather than the untouched test group.
    parser.add_argument("--seed", type=int, default=20260713)
    return parser.parse_args()


def recording_id(path: Path) -> tuple[str, str]:
    return path.parts[-5], path.parts[-2]


def main() -> None:
    args = parse_args()
    files = sorted(args.raw_root.glob("data/par_*/annotations/v1/rec_*/references.csv"))
    files = [path for path in files if path.stat().st_size > 0]
    participants = sorted({recording_id(path)[0] for path in files})
    shuffled = participants.copy()
    random.Random(args.seed).shuffle(shuffled)

    # 24 currently usable participants -> 16/4/4. The proportional fallback
    # keeps roughly the same allocation if the upstream release is repaired.
    n_test = max(1, round(len(shuffled) / 6))
    n_val = max(1, round(len(shuffled) / 6))
    assignment = {
        "test": set(shuffled[:n_test]),
        "val": set(shuffled[n_test : n_test + n_val]),
        "train": set(shuffled[n_test + n_val :]),
    }

    split_data = {}
    for split_name, split_participants in assignment.items():
        recordings = []
        mention_types: Counter[str] = Counter()
        labels: Counter[str] = Counter()
        row_count = 0
        for path in files:
            participant, recording = recording_id(path)
            if participant not in split_participants:
                continue
            with path.open(encoding="utf-8-sig", newline="") as stream:
                rows = list(csv.DictReader(stream))
            row_count += len(rows)
            mention_types.update(row.get("mention_type") or "unknown" for row in rows)
            labels.update(row.get("reference") or "unknown" for row in rows)
            recordings.append(f"{participant}_{recording}")
        split_data[split_name] = {
            "participants": sorted(split_participants),
            "recordings": sorted(recordings),
            "rows": row_count,
            "mention_types": dict(sorted(mention_types.items())),
            "unique_labels": len(labels),
        }

    output = {
        "source": "annadeichler/KTH-ARIA-referential",
        "source_revision": "main",
        "selection": "all currently downloadable non-empty v1 references.csv files",
        "seed": args.seed,
        "group_unit": "participant",
        "splits": split_data,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
