"""Compare the adaptive scope-refined policy rerun with the frozen legacy run."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def rows(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    ]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(row: dict) -> tuple:
    return row["scenario"], row["db_id"], row["question_id"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--refined", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    legacy = {
        key(row): row for row in rows(args.legacy) if row["condition"] == "policy_memory"
    }
    refined = {key(row): row for row in rows(args.refined)}
    if set(legacy) != set(refined):
        raise ValueError("legacy/refined target sets differ")

    comparison_fields = (
        "memory_provided",
        "policy_action",
        "prediction",
        "finalized",
        "exec_ok",
        "correct",
        "model_calls",
        "tool_calls",
        "prompt_tokens",
        "completion_tokens",
    )
    changed = []
    for target in sorted(legacy):
        before, after = legacy[target], refined[target]
        differences = {
            field: {"legacy": before.get(field), "refined": after.get(field)}
            for field in comparison_fields
            if before.get(field) != after.get(field)
        }
        if differences:
            changed.append(
                {
                    "scenario": target[0],
                    "db_id": target[1],
                    "cluster_id": after.get("cluster_id", after["db_id"]),
                    "question_id": target[2],
                    "memory_question_id": after["memory_question_id"],
                    "differences": differences,
                }
            )

    def summary(group: dict[tuple, dict]) -> dict:
        values = list(group.values())
        return {
            "n": len(values),
            "memory_returned": sum(row["memory_provided"] for row in values),
            "correct": sum(row["correct"] for row in values),
            "execution_accuracy": sum(row["correct"] for row in values) / len(values),
            "valid_sql": sum(row["exec_ok"] for row in values),
            "finalized": sum(row["finalized"] for row in values),
            "mean_model_calls": sum(row["model_calls"] for row in values) / len(values),
            "mean_tool_calls": sum(row["tool_calls"] for row in values) / len(values),
            "mean_total_tokens": sum(
                row["prompt_tokens"] + row["completion_tokens"] for row in values
            )
            / len(values),
        }

    report = {
        "protocol": "research/scope_validator_refinement.md",
        "legacy_sha256": sha256(args.legacy),
        "refined_sha256": sha256(args.refined),
        "legacy": summary(legacy),
        "refined": summary(refined),
        "changed_targets": len(changed),
        "changes": changed,
        "interpretation": (
            "adaptive full-condition rerun; not part of the original preregistered "
            "Dr.Spider hypothesis tests"
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "changes"}, indent=2))


if __name__ == "__main__":
    main()
