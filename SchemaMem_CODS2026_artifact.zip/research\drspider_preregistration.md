# Dr.Spider external lifecycle replication: preregistration

Frozen on **2026-07-14 Asia/Calcutta**, before running any SchemaMem, stale,
execution-guided, no-memory, or oracle condition on Dr.Spider.

## Motivation and status

The existing BIRD Mini-Dev experiment has 11 database clusters and uses
internally constructed, execution-validated migrations. This external study asks
whether the lifecycle decision and repair protocol transfers to schema changes
authored independently by the ICLR 2023 Dr.Spider team. Spider 1.0 is a legacy
base dataset; this study is therefore an external schema-perturbation replication,
not evidence of current warehouse scale.

The 2026 BIRD-Critic-SQLite release was audited first. Its public 500-task file
omits `sol_sql` and `test_cases`; the official repository distributes those fields
only by email auto-reply. No model output will be substituted for missing ground
truth. BIRD-Critic may be added later only from the official complete package and
will be reported separately.

## Frozen sources

- Official Spider distribution: `tmp/spider_data.zip`, SHA-256
  `00636695dabed6b5f4b8328a16b13e069a2f16591d5efcce57660669c85b121b`.
- AWS Dr.Spider repository commit
  `c64694a4a278ab0faff08ce7a3501d46f458b431`.
- Dr.Spider `data.tar.gz`, SHA-256
  `d0f47e4d2c9202f4fd2d956a34e9dd1ff8180c1c9e58cf5b530c13fefaaa3ba9`.
- Dr.Spider code is Apache-2.0; its annotations carry CC BY 4.0 terms in
  `LICENSE-ANNOTATIONS`.

## Eligible perturbations

Only `DB_schema_synonym` and `DB_schema_abbreviation` are eligible. They provide
parallel questions, gold SQL, and physically perturbed SQLite databases and fall
within SchemaMem's declared rename operator. `DB_DBcontent_equivalence` is
excluded prospectively because it can alter value representation or decompose a
logical attribute (for example, one name into first and last names), which is not
a rename and is outside the current policy contract. NLQ-only and SQL-only
perturbations are also out of scope.

An event is eligible only if all of the following hold:

1. pre/post records have the same Dr.Spider question identifier and natural
   language question;
2. the original and perturbed SQLite schemas differ only through one-to-one
   identifier renames at fixed table/column ordinals, with no type, table-count,
   or column-count change;
3. the independently supplied pre and post gold SQL both execute under the fixed
   100-million SQLite VM-step validation budget and return equivalent results;
4. the old SQL has at least one dependency in the derived rename write set; and
5. both target and retrieved memory are different, eligible questions.

No eligibility decision may use an agent prediction or a condition outcome.

## Event and target selection

The independent cluster is the **base Spider database**, never a suffixed
Dr.Spider variant. Select at most one event per base database:

1. prefer `DB_schema_synonym` when an eligible event exists, because a complete
   synonym is more deployment-plausible than an abbreviation;
2. otherwise use `DB_schema_abbreviation`;
3. within the chosen perturbation, select the event with the largest number of
   eligible affected questions; break ties lexicographically by post database ID.

Within each selected event, compute the existing frozen retrieval score over
eligible questions: `2 * table Jaccard + column Jaccard + 0.25 * TF-IDF cosine`.
For every target, retrieve the highest-scoring different question. Retain only
pairs whose memory depends on the rename. Order candidate targets by SHA-256 of
`20260714|perturbation|post_db_id|question_id` and retain the first two. There is
no replacement. The intended sample is 40 targets over 20 base databases; the
minimum viable sample is 30 targets over at least 15 databases.

## Frozen agent protocol

- Model: the identical Qwen2.5-Coder-7B-Instruct Q4_K_M files and llama.cpp
  server configuration used by the existing expanded study.
- Temperature 0, seed 42, at most 8 model calls, at most 256 generated tokens
  per call, one serial worker for the primary run.
- Tools: list relations, inspect one named relation, and execute read-only
  `SELECT`/`WITH` SQL. Gold SQL is never exposed to the agent.
- Conditions, run for every frozen target:
  `no_memory`, `stale_memory`, `execution_guided_memory`,
  `schema_aware_memory`, and `policy_memory`.
- `policy_memory` receives only the declared one-to-one migration manifest and
  must pass current-schema validation. `schema_aware_memory` is an oracle upper
  bound. Execution-guided maintenance receives no manifest and repairs only
  after an observable execution failure, exactly as in the existing study.

## Endpoints and inference

The primary accuracy contrast is `policy_memory - execution_guided_memory` on
the frozen affected-memory set. The principal secondary contrasts are policy
versus stale and policy versus no memory. The primary efficiency contrast is
total tokens including maintenance for policy versus execution-guided memory;
model calls and tool calls are secondary costs.

Report paired target differences, target bootstrap intervals, and whole-base-
database cluster bootstrap intervals. The randomization test flips the aggregate
difference of each base database, not each Dr.Spider variant. Report McNemar's
exact test descriptively. No claim will be based only on target-level
significance.

The prior 11-database BIRD result and this external result are reported
separately. A pooled 31-database estimate may appear only as an explicitly
exploratory stratified sensitivity analysis; it is not a new confirmatory test.

## Viability and reporting rules

- If fewer than 15 base databases or 30 targets survive eligibility, label the
  study a feasibility audit and do not use it to raise the acceptance claim.
- If policy accuracy is more than two points below execution-guided maintenance,
  treat external transfer as failed and foreground the failure.
- If policy is not more accurate but is materially cheaper, report a cost/safety
  trade-off without an accuracy claim.
- Report every exclusion count, every integrity failure, all raw traces, and the
  exact selected manifest. Do not change event preference, target count, seed,
  conditions, or endpoints after inspecting outcomes.
- The existing verified PDF and artifact remain the fallback release until a
  revised package passes the complete claim, anonymity, manifest, test, compile,
  and page-render audits.
