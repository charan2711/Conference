from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "results" / "schemamem" / "tool_agent_runs_qwen7_v4_expanded.statistics.json"
OUT = ROOT / "paper" / "figures"

report = json.loads(RESULT.read_text(encoding="utf-8"))
conditions = [
    "no_memory",
    "stale_memory",
    "version_filter",
    "reexplore_on_change",
    "execution_guided_memory",
    "schema_aware_memory",
    "policy_memory",
]
labels = [
    "No mem.",
    "Stale",
    "Filter",
    "Re-explore",
    "Exec.-guided",
    "Builder repair",
    "SchemaMem",
]
colors = ["#BDBDBD", "#D6604D", "#92C5DE", "#F4A582", "#9970AB", "#4393C3", "#2166AC"]
metrics = report["conditions"]

accuracy = [metrics[name]["execution_accuracy"] for name in conditions]
tokens = [
    metrics[name]["mean_total_tokens_with_maintenance"] / 1000
    for name in conditions
]
x = np.arange(len(conditions))

fig, axes = plt.subplots(
    1,
    2,
    figsize=(7.2, 2.85),
    gridspec_kw={"wspace": 0.28},
    layout="constrained",
)
bars = axes[0].bar(x, accuracy, color=colors, edgecolor="white", linewidth=0.5)
axes[0].bar_label(bars, labels=[f"{value:.0%}" for value in accuracy], padding=2, fontsize=7)
axes[0].set_ylim(0, max(0.55, max(accuracy) + 0.14))
axes[0].set_ylabel("Execution accuracy")
axes[0].set_title("Final SQL correctness", fontsize=9)

bars = axes[1].bar(x, tokens, color=colors, edgecolor="white", linewidth=0.5)
axes[1].bar_label(bars, labels=[f"{value:.1f}k" for value in tokens], padding=2, fontsize=7)
axes[1].set_ylim(0, max(tokens) * 1.22)
axes[1].set_ylabel("Mean tokens per target")
axes[1].set_title("Total interaction cost", fontsize=9)

for ax in axes:
    ax.set_xticks(x, labels, rotation=28, ha="right")
    ax.grid(axis="y", color="#DDDDDD", linewidth=0.65)
    ax.spines[["top", "right"]].set_visible(False)

fig.savefig(OUT / "tool_agent_results.pdf", bbox_inches="tight", facecolor="white")
fig.savefig(OUT / "tool_agent_results.png", dpi=260, bbox_inches="tight", facecolor="white")
plt.close(fig)
