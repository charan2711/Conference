"""Evaluate memory policies on validated table-split migrations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from sqlglot import parse_one

from .build_benchmark import execute, result_equivalent, sqlite_schema
from .memory_policy import decide_split


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--benchmark", type=Path, default=Path("data/schemamem-split-v1")
    )
    parser.add_argument(
        "--output", type=Path, default=Path("results/schemamem/split_baselines.json")
    )
    parser.add_argument(
        "--original-databases",
        type=Path,
        default=Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases"),
    )
    args = parser.parse_args()
    rows = [
        row
        for row in json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
        if row["execution_equivalent"]
    ]
    specs = json.loads((args.benchmark / "migrations.json").read_text(encoding="utf-8"))
    methods = {
        "stale_raw": {"returned": 0, "correct": 0, "exec_error": 0, "silent_wrong": 0},
        "version_filter": {"returned": 0, "correct": 0, "exec_error": 0, "silent_wrong": 0},
        "schema_aware_repair": {"returned": 0, "correct": 0, "exec_error": 0, "silent_wrong": 0},
    }
    instances = []
    schema_cache: dict[str, tuple[dict, dict]] = {}
    for row in rows:
        db_path = args.benchmark / "databases" / row["db_id"] / f'{row["db_id"]}.sqlite'
        old_path = args.original_databases / row["db_id"] / f'{row["db_id"]}.sqlite'
        if row["db_id"] not in schema_cache:
            schema_cache[row["db_id"]] = (
                sqlite_schema(old_path), sqlite_schema(db_path)
            )
        old_schema, current_schema = schema_cache[row["db_id"]]
        spec = specs[row["db_id"]]
        decision = decide_split(
            row["old_sql"], old_schema, current_schema, spec,
            [[(key, key) for key in spec["primary_key"]]],
        )
        # Construction already proved that the structurally repaired SQL is
        # executable and equivalent. Re-execute only affected stale programs;
        # repeating every expensive gold query three times adds no evidence.
        if row["affected"]:
            stale_ok, stale_result = execute(db_path, row["old_sql"])
            if stale_ok:
                gold_ok, gold = execute(db_path, row["new_sql"], timeout_seconds=10)
                stale_correct = gold_ok and result_equivalent(
                    stale_result, gold, row["new_sql"]
                )
            else:
                stale_correct = False
        else:
            stale_ok, stale_correct = True, True
        repair_returned = decision.sql is not None
        structurally_identical = repair_returned and (
            parse_one(decision.sql, read="sqlite")
            == parse_one(row["new_sql"], read="sqlite")
        )
        if structurally_identical:
            repair_ok = repair_correct = True
        elif repair_returned:
            gold_ok, gold = execute(db_path, row["new_sql"], timeout_seconds=10)
            repair_ok, repair_result = execute(
                db_path, decision.sql, timeout_seconds=10
            )
            repair_correct = repair_ok and gold_ok and result_equivalent(
                repair_result, gold, row["new_sql"]
            )
        else:
            repair_ok = repair_correct = False
        outcomes = {
            "stale_raw": {"returned": True, "exec_ok": stale_ok, "correct": stale_correct},
            "version_filter": {
                "returned": not row["affected"],
                "exec_ok": not row["affected"],
                "correct": not row["affected"],
            },
            "schema_aware_repair": {
                "returned": repair_returned,
                "exec_ok": repair_ok,
                "correct": repair_correct,
                "action": decision.action,
                "reason": decision.reason,
                "ast_matches_builder": structurally_identical,
            },
        }
        for name, outcome in outcomes.items():
            methods[name]["returned"] += int(outcome["returned"])
            methods[name]["correct"] += int(outcome["correct"])
            methods[name]["exec_error"] += int(outcome["returned"] and not outcome["exec_ok"])
            methods[name]["silent_wrong"] += int(outcome["exec_ok"] and not outcome["correct"])
        instances.append(
            {"db_id": row["db_id"], "question_id": row["question_id"], "affected": row["affected"], "methods": outcomes}
        )
    n = len(rows)
    report = {"n": n, "methods": {}}
    for name, counts in methods.items():
        returned = counts["returned"]
        report["methods"][name] = {
            **counts,
            "coverage": returned / n,
            "correct_rate": counts["correct"] / n,
            "precision_returned": counts["correct"] / returned if returned else 1.0,
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    args.output.with_name("split_baseline_instances.json").write_text(
        json.dumps(instances, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
