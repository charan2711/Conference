"""Fetch selected Look and Tell ego videos and extract reference frames locally.

The source is CC BY-NC-ND 4.0. Generated frames are for local noncommercial
experiments only and must not be redistributed. The script records source URLs
and hashes so another researcher with dataset access can reproduce the subset.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from urllib.parse import quote

import cv2
import requests
from requests import HTTPError
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


REPOSITORY = "annadeichler/KTH-ARIA-referential"
REVISION = "main"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, default=Path("data/raw/look_and_tell"))
    parser.add_argument("--output-root", type=Path, default=Path("data/derived/look_and_tell"))
    parser.add_argument("--participants", nargs="+", default=["par_01"])
    parser.add_argument("--recordings", nargs="+", default=["rec_01"])
    parser.add_argument("--keep-video", action="store_true")
    return parser.parse_args()


def source_url(path: str) -> str:
    encoded = "/".join(quote(part) for part in path.split("/"))
    return f"https://huggingface.co/datasets/{REPOSITORY}/resolve/{REVISION}/{encoded}"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fetch(session: requests.Session, source_path: str, destination: Path) -> None:
    if destination.exists() and destination.stat().st_size:
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + ".part")
    partial.unlink(missing_ok=True)
    with session.get(source_url(source_path), stream=True, timeout=180) as response:
        response.raise_for_status()
        with partial.open("wb") as output:
            for block in response.iter_content(chunk_size=1024 * 1024):
                if block:
                    output.write(block)
    partial.replace(destination)


def extract_recording(
    participant: str,
    recording: str,
    raw_root: Path,
    output_root: Path,
    session: requests.Session,
    keep_video: bool,
) -> dict:
    recording_uid = f"{participant}_{recording}"
    manifest_path = output_root / participant / recording / "manifest.jsonl"
    if manifest_path.exists() and manifest_path.stat().st_size > 0:
        return {
            "recording_uid": recording_uid,
            "status": "already_prepared",
            "manifest_path": str(manifest_path),
        }
    reference_path = (
        raw_root / "data" / participant / "annotations" / "v1" / recording / "references.csv"
    )
    if not reference_path.exists() or reference_path.stat().st_size == 0:
        return {"recording_uid": recording_uid, "status": "missing_references"}

    video_source_path = f"data/{participant}/raw/{recording}/ego_video.mp4"
    video_path = raw_root / video_source_path
    try:
        fetch(session, video_source_path, video_path)
    except HTTPError as error:
        if error.response is not None and error.response.status_code == 404:
            return {
                "recording_uid": recording_uid,
                "status": "missing_video",
                "source_url": source_url(video_source_path),
            }
        raise

    with reference_path.open(encoding="utf-8-sig", newline="") as stream:
        references = list(csv.DictReader(stream))
    requested_frames = sorted(
        {
            int((int(row["frame_idx_rgb_start"]) + int(row["frame_idx_rgb_end"])) // 2)
            for row in references
            if row.get("frame_idx_rgb_start") and row.get("frame_idx_rgb_end")
        }
    )

    capture = cv2.VideoCapture(str(video_path))
    if not capture.isOpened():
        raise RuntimeError(f"OpenCV could not open {video_path}")
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = float(capture.get(cv2.CAP_PROP_FPS))

    frame_dir = output_root / participant / recording / "mention_midpoints"
    frame_dir.mkdir(parents=True, exist_ok=True)
    extracted = set()
    for frame_index in requested_frames:
        if frame_index < 0 or frame_index >= frame_count:
            continue
        capture.set(cv2.CAP_PROP_POS_FRAMES, frame_index)
        ok, frame = capture.read()
        if not ok:
            continue
        destination = frame_dir / f"frame_{frame_index:06d}.jpg"
        if not cv2.imwrite(str(destination), frame, [cv2.IMWRITE_JPEG_QUALITY, 95]):
            raise RuntimeError(f"Failed to write {destination}")
        extracted.add(frame_index)
    capture.release()

    manifest_rows = []
    for row in references:
        start = int(row["frame_idx_rgb_start"])
        end = int(row["frame_idx_rgb_end"])
        midpoint = (start + end) // 2
        manifest_rows.append(
            {
                "recording_uid": f"{participant}_{recording}",
                "mention_id": row.get("mention_id"),
                "mention_type": row.get("mention_type"),
                "reference": row.get("reference"),
                "surface_text": row.get("tsv_words"),
                "frame_index": midpoint,
                "frame_path": str(frame_dir / f"frame_{midpoint:06d}.jpg"),
                "fix_x": float(row["fix_x"]) if row.get("fix_x") else None,
                "fix_y": float(row["fix_y"]) if row.get("fix_y") else None,
                "linked_temporally": row.get("linked_temporally") == "True",
                "chain_id": row.get("chain_id"),
                "antecedent_id": row.get("antecedent_id") or None,
            }
        )
    manifest_path.write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in manifest_rows),
        encoding="utf-8",
    )

    result = {
        "recording_uid": f"{participant}_{recording}",
        "status": "prepared",
        "source_url": source_url(video_source_path),
        "source_sha256": sha256(video_path),
        "video_bytes": video_path.stat().st_size,
        "width": width,
        "height": height,
        "fps": fps,
        "video_frames": frame_count,
        "reference_rows": len(references),
        "requested_frames": len(requested_frames),
        "extracted_frames": len(extracted),
        "manifest_path": str(manifest_path),
    }
    if not keep_video:
        video_path.unlink()
        result["video_retained"] = False
    else:
        result["video_retained"] = True
    return result


def main() -> None:
    args = parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    retry = Retry(
        total=5,
        connect=5,
        read=5,
        backoff_factor=1.0,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=("GET",),
    )
    session.mount("https://", HTTPAdapter(max_retries=retry))
    results = [
        extract_recording(
            participant,
            recording,
            args.raw_root,
            args.output_root,
            session,
            args.keep_video,
        )
        for participant in args.participants
        for recording in args.recordings
    ]
    summary = {
        "repository": REPOSITORY,
        "revision": REVISION,
        "license": "CC BY-NC-ND 4.0",
        "redistribution_warning": "Do not redistribute generated frames or modified media.",
        "recordings": results,
    }
    summary_path = args.output_root / "pilot_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
