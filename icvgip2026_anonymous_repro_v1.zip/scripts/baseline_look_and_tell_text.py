"""Transparent text-only baselines for Look and Tell reference classification."""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


TOKEN_RE = re.compile(r"[a-z0-9]+")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, default=Path("data/raw/look_and_tell"))
    parser.add_argument("--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json"))
    parser.add_argument(
        "--output", type=Path, default=Path("artifacts/baselines/look_and_tell_text.json")
    )
    return parser.parse_args()


def tokens(text: str) -> set[str]:
    return set(TOKEN_RE.findall(text.lower()))


def load_recording(raw_root: Path, recording_uid: str) -> list[dict]:
    participant, _, recording_number = recording_uid.partition("_rec_")
    path = (
        raw_root
        / "data"
        / participant
        / "annotations"
        / "v1"
        / f"rec_{recording_number}"
        / "references.csv"
    )
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return [row for row in csv.DictReader(stream) if (row.get("reference") or "").strip()]


def lexical_prediction(surface: str, labels: list[str], frequencies: Counter[str]) -> str | None:
    query = tokens(surface)
    if not query:
        return None
    scored = []
    for label in labels:
        label_tokens = tokens(label)
        overlap = len(query & label_tokens)
        if overlap:
            score = overlap / len(query | label_tokens)
            scored.append((score, overlap, frequencies[label], label))
    if not scored:
        return None
    return max(scored)[-1]


def macro_f1(targets: list[str], predictions: list[str]) -> float:
    labels = sorted(set(targets) | set(predictions))
    scores = []
    for label in labels:
        tp = sum(t == label and p == label for t, p in zip(targets, predictions))
        fp = sum(t != label and p == label for t, p in zip(targets, predictions))
        fn = sum(t == label and p != label for t, p in zip(targets, predictions))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        scores.append(2 * precision * recall / (precision + recall) if precision + recall else 0.0)
    return sum(scores) / len(scores) if scores else 0.0


def metrics(rows: list[dict], predictions: list[str]) -> dict:
    targets = [row["reference"] for row in rows]
    result = {
        "n": len(rows),
        "accuracy": sum(t == p for t, p in zip(targets, predictions)) / len(rows),
        "macro_f1": macro_f1(targets, predictions),
        "by_mention_type": {},
    }
    grouped: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped[row.get("mention_type") or "unknown"].append(index)
    for mention_type, indices in sorted(grouped.items()):
        result["by_mention_type"][mention_type] = {
            "n": len(indices),
            "accuracy": sum(targets[i] == predictions[i] for i in indices) / len(indices),
        }
    return result


def main() -> None:
    args = parse_args()
    split_spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows_by_split: dict[str, list[dict]] = {}
    for split_name, split in split_spec["splits"].items():
        rows = []
        for recording_uid in split["recordings"]:
            for row in load_recording(args.raw_root, recording_uid):
                row["recording_uid"] = recording_uid
                rows.append(row)
        rows_by_split[split_name] = rows

    train_frequency = Counter(row["reference"] for row in rows_by_split["train"])
    labels = sorted(train_frequency)
    majority = train_frequency.most_common(1)[0][0]
    results = {}
    for split_name in ("val", "test"):
        rows = rows_by_split[split_name]
        majority_predictions = [majority] * len(rows)
        lexical_predictions = [
            lexical_prediction(row.get("tsv_words") or "", labels, train_frequency) or majority
            for row in rows
        ]

        memory_predictions = []
        previous_by_recording: dict[str, str] = {}
        for row in rows:
            recording_uid = row["recording_uid"]
            lexical = lexical_prediction(row.get("tsv_words") or "", labels, train_frequency)
            prediction = lexical or previous_by_recording.get(recording_uid) or majority
            memory_predictions.append(prediction)
            if lexical is not None:
                previous_by_recording[recording_uid] = lexical

        results[split_name] = {
            "majority": metrics(rows, majority_predictions),
            "lexical_closed_set": metrics(rows, lexical_predictions),
            "lexical_plus_last_explicit": metrics(rows, memory_predictions),
        }

    output = {
        "task": "canonical reference label prediction; empty reference rows excluded",
        "train_labels": len(labels),
        "train_majority_label": majority,
        "baselines": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
