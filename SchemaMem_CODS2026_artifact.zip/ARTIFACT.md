# SchemaMem Artifact Guide

This artifact reproduces the benchmark construction, deterministic policies,
local-model experiments, statistics, figures, and paper. It intentionally does
not redistribute BIRD databases, EvoSchema's repository, model weights, or
inference binaries.

## External inputs

1. BIRD Mini-Dev from https://github.com/bird-bench/mini_dev, placed at
   `data/bird-mini-dev/package/minidev/MINIDEV`.
2. EvoSchema from https://github.com/zhangtianshu/EvoSchema, placed at
   `baselines/EvoSchema` (needed only for the annotation audit and candidate
   identifier-name source).
3. Dr.Spider from https://github.com/awslabs/diagnostic-robustness-text-to-sql
   and Spider 1.0 from https://yale-lily.github.io/spider, needed only to rebuild
   the external transfer suite. Their extracted data/database directories are
   passed explicitly to `schemamem.build_drspider_benchmark`.
4. An OpenAI-compatible local inference server for model experiments. Model
   choices and quantization caveats are documented in
   `research/model_controls.md`.
5. Tectonic 0.16.9 (tested) or another ACM-compatible LaTeX installation for
   rebuilding the manuscript. The saved PDF is included, so TeX is not required
   for running the evaluation code.

No Kaggle credential is required.

Third-party data provenance and license information is recorded in
`THIRD_PARTY.md`. The artifact does not include model weights or BIRD databases.

## Environment

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
$env:PYTHONPATH = "src"
```

`requirements-lock.txt` records the exact Python environment used for the saved
runs; `requirements.txt` contains the minimal direct dependencies.

The recorded run used Python 3.12.6, SQLite 3.45.3, DuckDB 1.5.4, SQLGlot 30.12,
scikit-learn 1.9, Windows, an Intel i7-9750H, 15.8 GB RAM, and an RTX 2060 6 GB
through llama.cpp's Vulkan backend.
The inference binary reports llama.cpp build 9982 (`99f3dc322`), compiled with
Clang 20.1.8 for Windows x86_64.

## Deterministic pipeline

```powershell
.\.venv\Scripts\python.exe -m schemamem.build_benchmark
.\.venv\Scripts\python.exe -m schemamem.revalidate_benchmark
.\.venv\Scripts\python.exe -m schemamem.evaluate_benchmark
.\.venv\Scripts\python.exe -m schemamem.statistics
.\.venv\Scripts\python.exe -m schemamem.split_benchmark
.\.venv\Scripts\python.exe -m schemamem.evaluate_split
.\.venv\Scripts\python.exe -m schemamem.merge_benchmark
.\.venv\Scripts\python.exe -m schemamem.evaluate_merge
.\.venv\Scripts\python.exe -m schemamem.multiversion_benchmark
.\.venv\Scripts\python.exe -m schemamem.multiversion_statistics
.\.venv\Scripts\python.exe -m schemamem.real_migration_benchmark --verify-sources
.\.venv\Scripts\python.exe -m schemamem.audit_evoschema
.\.venv\Scripts\python.exe -m schemamem.build_ambiguity_benchmark --per-class 50
.\.venv\Scripts\python.exe -m schemamem.evaluate_ambiguity
.\.venv\Scripts\python.exe -m schemamem.measure_policy_overhead --repeats 20
.\.venv\Scripts\python.exe -m schemamem.component_ablation --validator legacy_flat --output results\schemamem\component_ablation.json --instances-output results\schemamem\component_ablation.instances.json
.\.venv\Scripts\python.exe -m schemamem.component_ablation --validator current --output results\schemamem\component_ablation_scope_refined.json --instances-output results\schemamem\component_ablation_scope_refined.instances.json
.\.venv\Scripts\python.exe -m schemamem.duckdb_portability --validator legacy_flat
.\.venv\Scripts\python.exe -m schemamem.qualitative_failure_examples
.\.venv\Scripts\python.exe -m pytest -q
```

To compare an isolated rebuild against the frozen release JSON (timing output
is intentionally excluded), run from the release root:

```powershell
.\.venv\Scripts\python.exe scripts\verify_clean_rebuild.py --candidate-root <clean-rebuild-root> --output results\schemamem\clean_rebuild_audit.json
```

Benchmark construction and the runtime policy deliberately use independent
rewriter implementations. The lifecycle suite is balanced by construction and
must not be interpreted as a real-world class distribution.

## Local-model experiments

The Qwen-1.5B, Qwen-7B, and Mistral-7B runs used the following single-slot
server shape (replace the placeholder with the appropriate official GGUF):

```powershell
llama-server -m <model.gguf> -ngl 99 -c 4096 -np 1 --host 127.0.0.1 --port 8080
```

The Qwen-14B Q3 runs omitted `-ngl 99`, allowing llama.cpp to fit GPU layers
automatically and offload the remainder to CPU:

```powershell
llama-server -m <qwen14-q3.gguf> -c 4096 -np 1 --host 127.0.0.1 --port 8080
```

Requests set temperature 0 and seed 42. With the relevant server listening on
port 8080, the recorded commands are:

```powershell
.\.venv\Scripts\python.exe -m schemamem.agent_experiment --per-stratum 1 --conditions no_memory stale_memory version_filter schema_aware_memory --model-label qwen2.5-coder-1.5b-q4 --workers 1 --output results/schemamem/agent_runs.jsonl
.\.venv\Scripts\python.exe -m schemamem.agent_statistics --runs results/schemamem/agent_runs.jsonl --output results/schemamem/agent_statistics.json
.\.venv\Scripts\python.exe -m schemamem.llm_repair_experiment --scenarios column_rename table_rename table_split --per-scenario 5 --model-label qwen2.5-coder-1.5b-q4 --output results/schemamem/llm_repair_1.5b.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_repair_statistics results/schemamem/llm_repair_1.5b.jsonl --output results/schemamem/llm_repair_1.5b.statistics.json
.\.venv\Scripts\python.exe -m schemamem.agent_experiment --per-stratum 3 --model-label qwen2.5-coder-7b-q4 --workers 1 --output results/schemamem/agent_runs_7b.jsonl
.\.venv\Scripts\python.exe -m schemamem.agent_statistics --runs results/schemamem/agent_runs_7b.jsonl --output results/schemamem/agent_statistics_7b_expanded.json
.\.venv\Scripts\python.exe -m schemamem.agent_statistics --runs results/schemamem/agent_runs_7b.jsonl --output results/schemamem/agent_statistics_7b_clustered.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/agent_runs_7b.jsonl --output results/schemamem/agent_runs_7b_expanded.errors.json
.\.venv\Scripts\python.exe -m schemamem.llm_repair_experiment --scenarios column_rename table_rename table_split --per-scenario 20 --model-label qwen2.5-coder-7b-q4 --output results/schemamem/llm_repair_runs_7b.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_repair_statistics results/schemamem/llm_repair_runs_7b.jsonl --output results/schemamem/llm_repair_7b_expanded.statistics.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/llm_repair_runs_7b.jsonl --output results/schemamem/llm_repair_7b_expanded.errors.json
.\.venv\Scripts\python.exe -m schemamem.llm_gate_experiment --per-class 10 --prompt-mode conservative --model-label qwen2.5-coder-7b-q4 --output results/schemamem/llm_gate_runs_7b.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_gate_experiment --per-class 10 --prompt-mode balanced --model-label qwen2.5-coder-7b-q4-balanced --output results/schemamem/llm_gate_runs_7b_balanced.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_gate_experiment --per-class 10 --prompt-mode structured --model-label qwen2.5-coder-7b-q4-structured --output results/schemamem/llm_gate_runs_7b_structured.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_repair_experiment --scenarios table_merge --per-scenario 20 --model-label qwen2.5-coder-7b-q4 --output results/schemamem/llm_repair_runs_qwen7_merge.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_repair_statistics results/schemamem/llm_repair_runs_qwen7_merge.jsonl --output results/schemamem/llm_repair_runs_qwen7_merge.statistics.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/llm_repair_runs_qwen7_merge.jsonl --output results/schemamem/llm_repair_runs_qwen7_merge.errors.json
.\.venv\Scripts\python.exe -m schemamem.tool_agent_experiment --model-label qwen2.5-coder-7b-q4 --targets data/schemamem-agent-targets-balanced22.json --conditions no_memory stale_memory version_filter reexplore_on_change schema_aware_memory policy_memory --max-calls 8 --workers 1 --output results/schemamem/tool_agent_runs_qwen7_v3_final.jsonl
.\.venv\Scripts\python.exe -m schemamem.tool_agent_statistics --runs results/schemamem/tool_agent_runs_qwen7_v3_final.jsonl --conditions no_memory stale_memory version_filter reexplore_on_change schema_aware_memory policy_memory --output results/schemamem/tool_agent_runs_qwen7_v3_final.statistics.json
.\.venv\Scripts\python.exe -m schemamem.verify_tool_agent_run --runs results/schemamem/tool_agent_runs_qwen7_v3_final.jsonl --targets data/schemamem-agent-targets-balanced22.json --output results/schemamem/tool_agent_runs_qwen7_v3_final.integrity.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/tool_agent_runs_qwen7_v3_final.jsonl --output results/schemamem/tool_agent_runs_qwen7_v3_final.errors.json
.\.venv\Scripts\python.exe -m schemamem.tool_agent_experiment --model-label qwen2.5-coder-7b-q4-expanded-v4 --targets data/schemamem-agent-targets-expanded78.json --max-calls 8 --workers 1 --output results/schemamem/tool_agent_runs_qwen7_v4_expanded.jsonl
.\.venv\Scripts\python.exe -m schemamem.tool_agent_statistics --runs results/schemamem/tool_agent_runs_qwen7_v4_expanded.jsonl --conditions no_memory stale_memory version_filter reexplore_on_change execution_guided_memory schema_aware_memory policy_memory --output results/schemamem/tool_agent_runs_qwen7_v4_expanded.statistics.json
.\.venv\Scripts\python.exe -m schemamem.execution_guided_statistics --runs results/schemamem/tool_agent_runs_qwen7_v4_expanded.jsonl --output results/schemamem/tool_agent_runs_qwen7_v4_expanded.maintenance.json
.\.venv\Scripts\python.exe -m schemamem.verify_tool_agent_run --runs results/schemamem/tool_agent_runs_qwen7_v4_expanded.jsonl --targets data/schemamem-agent-targets-expanded78.json --conditions no_memory stale_memory version_filter reexplore_on_change execution_guided_memory schema_aware_memory policy_memory --output results/schemamem/tool_agent_runs_qwen7_v4_expanded.integrity.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/tool_agent_runs_qwen7_v4_expanded.jsonl --output results/schemamem/tool_agent_runs_qwen7_v4_expanded.errors.json
.\.venv\Scripts\python.exe -m schemamem.tool_agent_experiment --model-label qwen2.5-coder-14b-q3-control --targets data/schemamem-agent-targets-balanced22.json --max-calls 8 --workers 1 --output results/schemamem/tool_agent_runs_qwen14_v1_control22.jsonl
.\.venv\Scripts\python.exe -m schemamem.tool_agent_statistics --runs results/schemamem/tool_agent_runs_qwen14_v1_control22.jsonl --conditions no_memory stale_memory version_filter reexplore_on_change execution_guided_memory schema_aware_memory policy_memory --output results/schemamem/tool_agent_runs_qwen14_v1_control22.statistics.json
.\.venv\Scripts\python.exe -m schemamem.execution_guided_statistics --runs results/schemamem/tool_agent_runs_qwen14_v1_control22.jsonl --output results/schemamem/tool_agent_runs_qwen14_v1_control22.maintenance.json
.\.venv\Scripts\python.exe -m schemamem.verify_tool_agent_run --runs results/schemamem/tool_agent_runs_qwen14_v1_control22.jsonl --targets data/schemamem-agent-targets-balanced22.json --conditions no_memory stale_memory version_filter reexplore_on_change execution_guided_memory schema_aware_memory policy_memory --output results/schemamem/tool_agent_runs_qwen14_v1_control22.integrity.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/tool_agent_runs_qwen14_v1_control22.jsonl --output results/schemamem/tool_agent_runs_qwen14_v1_control22.errors.json
.\.venv\Scripts\python.exe -m schemamem.model_control_statistics --smaller-runs results/schemamem/tool_agent_runs_qwen7_v3_final.jsonl --larger-runs results/schemamem/tool_agent_runs_qwen14_v1_control22.jsonl --targets data/schemamem-agent-targets-balanced22.json --conditions no_memory stale_memory version_filter reexplore_on_change schema_aware_memory policy_memory --output results/schemamem/tool_agent_model_control_qwen14_vs_qwen7.json
```

The preregistered Dr.Spider transfer uses the Qwen-7B server shape above. First
rebuild the paired benchmark from official archives, then reproduce or audit the
saved run:

```powershell
.\.venv\Scripts\python.exe -m schemamem.build_drspider_benchmark --drspider <extracted-drspider-data> --spider-databases <extracted-spider-database-dir> --output data/schemamem-drspider-v1 --targets-output data/schemamem-drspider-targets-v1.json
.\.venv\Scripts\python.exe -m schemamem.tool_agent_experiment --benchmark data/schemamem-drspider-v1 --targets data/schemamem-drspider-targets-v1.json --model-label qwen2.5-coder-7b-q4-drspider-v1 --conditions no_memory stale_memory execution_guided_memory schema_aware_memory policy_memory --max-calls 8 --max-tokens 256 --workers 1 --output results/schemamem/tool_agent_runs_qwen7_drspider_v1.jsonl
.\.venv\Scripts\python.exe -m schemamem.verify_tool_agent_run --runs results/schemamem/tool_agent_runs_qwen7_drspider_v1.jsonl --targets data/schemamem-drspider-targets-v1.json --conditions no_memory stale_memory execution_guided_memory schema_aware_memory policy_memory --output results/schemamem/tool_agent_runs_qwen7_drspider_v1.integrity.json
.\.venv\Scripts\python.exe -m schemamem.tool_agent_statistics --runs results/schemamem/tool_agent_runs_qwen7_drspider_v1.jsonl --conditions no_memory stale_memory execution_guided_memory schema_aware_memory policy_memory --output results/schemamem/tool_agent_runs_qwen7_drspider_v1.statistics.json
.\.venv\Scripts\python.exe -m schemamem.execution_guided_statistics --runs results/schemamem/tool_agent_runs_qwen7_drspider_v1.jsonl --benchmark data/schemamem-drspider-v1 --output results/schemamem/tool_agent_runs_qwen7_drspider_v1.execution_guided_audit.json
.\.venv\Scripts\python.exe -m schemamem.policy_memory_statistics --runs results/schemamem/tool_agent_runs_qwen7_drspider_v1.jsonl --benchmark data/schemamem-drspider-v1 --output results/schemamem/tool_agent_runs_qwen7_drspider_v1.policy_audit.json
.\.venv\Scripts\python.exe -m schemamem.maintenance_outcome_analysis --runs results/schemamem/tool_agent_runs_qwen7_drspider_v1.jsonl --maintenance-audit results/schemamem/tool_agent_runs_qwen7_drspider_v1.execution_guided_audit.json --output results/schemamem/tool_agent_runs_qwen7_drspider_v1.maintenance_outcomes.json
.\.venv\Scripts\python.exe -m schemamem.tool_agent_experiment --benchmark data/schemamem-drspider-v1 --targets data/schemamem-drspider-targets-v1.json --model-label qwen2.5-coder-7b-q4-drspider-scope-refined-v2 --conditions policy_memory --max-calls 8 --max-tokens 256 --workers 1 --output results/schemamem/tool_agent_runs_qwen7_drspider_scope_refined_v2.jsonl
.\.venv\Scripts\python.exe -m schemamem.verify_tool_agent_run --runs results/schemamem/tool_agent_runs_qwen7_drspider_scope_refined_v2.jsonl --targets data/schemamem-drspider-targets-v1.json --conditions policy_memory --output results/schemamem/tool_agent_runs_qwen7_drspider_scope_refined_v2.integrity.json
.\.venv\Scripts\python.exe -m schemamem.policy_memory_statistics --runs results/schemamem/tool_agent_runs_qwen7_drspider_scope_refined_v2.jsonl --benchmark data/schemamem-drspider-v1 --output results/schemamem/tool_agent_runs_qwen7_drspider_scope_refined_v2.policy_audit.json
.\.venv\Scripts\python.exe -m schemamem.scope_refinement_statistics
```

The target manifest SHA-256 is
`d42db885dcf04bc03f4fd8c39d185b6ff960fb0a5a6a04eea783eb578bbc39fe`.
All selection and stopping rules were written before outcomes in
`research/drspider_preregistration.md`. The factorized replay and portability
diagnostic are frozen in `research/ablation_portability_preregistration.md`;
the generic scope-validator change and adaptive rerun are frozen before their
outcomes in `research/scope_validator_refinement.md`. The supplement excludes
the third-party SQLite files; sanitized saved traces and derived statistics
remain directly auditable.

With the Qwen2.5-Coder-14B Q3 server, the exploratory direct-repair control used:

```powershell
.\.venv\Scripts\python.exe -m schemamem.llm_repair_experiment --scenarios column_rename table_rename table_split --per-scenario 5 --model-label qwen2.5-coder-14b-q3 --output results/schemamem/llm_repair_runs_14b.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_repair_statistics results/schemamem/llm_repair_runs_14b.jsonl --output results/schemamem/llm_repair_14b.statistics.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/llm_repair_runs_14b.jsonl --output results/schemamem/llm_repair_14b.errors.json
```

For the independent Mistral-7B server, the downstream control used:

```powershell
.\.venv\Scripts\python.exe -m schemamem.agent_experiment --per-stratum 1 --model-label mistral-7b-instruct-v0.3-q4 --workers 1 --output results/schemamem/agent_runs_mistral7.jsonl
.\.venv\Scripts\python.exe -m schemamem.agent_statistics --runs results/schemamem/agent_runs_mistral7.jsonl --output results/schemamem/agent_statistics_mistral7.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/agent_runs_mistral7.jsonl --output results/schemamem/agent_runs_mistral7.errors.json
.\.venv\Scripts\python.exe -m schemamem.llm_repair_experiment --scenarios column_rename table_rename table_split --per-scenario 10 --model-label mistral-7b-instruct-v0.3-q4 --output results/schemamem/llm_repair_runs_mistral7.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_repair_statistics results/schemamem/llm_repair_runs_mistral7.jsonl --output results/schemamem/llm_repair_mistral7.statistics.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/llm_repair_runs_mistral7.jsonl --output results/schemamem/llm_repair_mistral7.errors.json
.\.venv\Scripts\python.exe -m schemamem.llm_repair_experiment --scenarios table_merge --per-scenario 20 --model-label mistral-7b-instruct-v0.3-q4 --output results/schemamem/llm_repair_runs_mistral7_merge.jsonl
.\.venv\Scripts\python.exe -m schemamem.llm_repair_statistics results/schemamem/llm_repair_runs_mistral7_merge.jsonl --output results/schemamem/llm_repair_runs_mistral7_merge.statistics.json
.\.venv\Scripts\python.exe -m schemamem.error_taxonomy results/schemamem/llm_repair_runs_mistral7_merge.jsonl --output results/schemamem/llm_repair_runs_mistral7_merge.errors.json
```

JSONL experiments append and checkpoint after every response. Repeating a
command with the same model label and output path skips completed keys.
Each experiment command also writes its matching `.summary.json` beside the
JSONL file; the statistics, maintenance, integrity, and taxonomy commands write
the explicitly named secondary aggregates.
The confirmatory tool-agent run is serial. A two-slot throughput diagnostic is
excluded because identical prompts occasionally decoded differently under
concurrent batching; its rows must never be mixed with the confirmatory file.

## Figures and paper

```powershell
.\.venv\Scripts\python.exe scripts\plot_schemamem_results.py
.\.venv\Scripts\python.exe scripts\plot_system_overview.py
.\.venv\Scripts\python.exe scripts\plot_tool_agent_results.py
.\.venv\Scripts\python.exe scripts\plot_external_replication.py
.\.venv\Scripts\python.exe scripts\plot_multiversion_results.py
.\.venv\Scripts\python.exe scripts\verify_paper_claims.py
.\.venv\Scripts\python.exe scripts\verify_bibliography.py --online
.\.venv\Scripts\python.exe scripts\verify_submission_pdf.py paper\main.pdf
.\.venv\Scripts\python.exe scripts\verify_anonymity.py output\SchemaMem_CODS2026_artifact.zip
Push-Location paper
tectonic -X compile main.tex
Pop-Location
powershell -ExecutionPolicy Bypass -File scripts\build_release_artifact.ps1
.\.venv\Scripts\python.exe scripts\verify_artifact_manifest.py output\SchemaMem_CODS2026_artifact.zip
```

Primary aggregate results are under `results/schemamem`; the ACM manuscript is
`paper/main.pdf`. The verified 2026 archival limit is eight content pages plus
two reference pages. As checked on July 14, 2026, the public CFP lists August 13
AoE, while the live OpenReview invitation displays August 2 at 11:59 UTC; an
author should resolve this discrepancy with the chairs and use the earlier date
operationally. The OpenReview form hides authors and requires anonymized
supplementary material and certification that no AI-generated or hallucinated
content remains unverified.
