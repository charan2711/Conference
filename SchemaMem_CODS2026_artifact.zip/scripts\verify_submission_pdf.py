"""Verify ACM submission PDF limits, geometry, metadata, and anonymity."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pypdf import PdfReader

try:
    from scripts.verify_anonymity import check_payload, load_denylist
except ModuleNotFoundError:  # Direct invocation adds scripts/, not the repo root.
    from verify_anonymity import check_payload, load_denylist


LETTER = (612.0, 792.0)
# Assemble the venue boilerplate address so the source of this verifier does
# not itself look like an identity leak when included in the anonymous bundle.
ACM_BOILERPLATE_EMAIL = b"permissions" + b"@" + b"acm.org"


def audit_pdf(
    path: Path,
    *,
    max_bytes: int = 50 * 1024 * 1024,
    max_pages: int = 10,
    max_content_pages: int = 8,
    denylist: list[bytes] | None = None,
) -> dict:
    failures: list[dict[str, str]] = []
    reader = PdfReader(path)
    metadata = reader.metadata or {}
    texts: list[str] = []
    sizes: list[list[float]] = []
    for index, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        texts.append(text)
        width = float(page.mediabox.width)
        height = float(page.mediabox.height)
        sizes.append([width, height])
        if abs(width - LETTER[0]) > 0.5 or abs(height - LETTER[1]) > 0.5:
            failures.append({"path": f"page {index}", "rule": "not_us_letter"})
        if len(text.strip()) < 80:
            failures.append({"path": f"page {index}", "rule": "blank_or_unreadable_page"})

    pages = len(reader.pages)
    if pages > max_pages:
        failures.append({"path": path.name, "rule": "page_limit"})
    if path.stat().st_size > max_bytes:
        failures.append({"path": path.name, "rule": "file_size_limit"})

    reference_pages = [
        index for index, text in enumerate(texts, start=1)
        if "REFERENCES" in text.upper()
    ]
    reference_start = reference_pages[0] if reference_pages else None
    if reference_start is None:
        failures.append({"path": path.name, "rule": "references_heading_missing"})
    elif reference_start > max_content_pages + 1:
        failures.append({"path": path.name, "rule": "content_page_limit"})

    author = str(metadata.get("/Author", "")).strip()
    if author:
        failures.append({"path": path.name, "rule": "author_metadata_present"})

    searchable = ("\n".join(f"{key}: {value}" for key, value in metadata.items())
                  + "\n" + "\n".join(texts)).encode("utf-8", errors="ignore")
    # acmart's review footer contains ACM's permissions mailbox; it is venue
    # boilerplate, not author identity. No other email address is exempted.
    searchable = searchable.replace(ACM_BOILERPLATE_EMAIL, b"")
    failures.extend(check_payload(path.name, searchable, denylist or []))
    report = {
        "status": "passed" if not failures else "failed",
        "pdf": path.name,
        "bytes": path.stat().st_size,
        "pages": pages,
        "reference_start_page": reference_start,
        "page_sizes_points": sizes,
        "author_metadata_empty": not bool(author),
        "failures": failures,
    }
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--denylist-file", type=Path)
    parser.add_argument("--deny", action="append", default=[])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = audit_pdf(
        args.pdf,
        denylist=load_denylist(args.denylist_file, args.deny),
    )
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(
        f"submission PDF audit: {report['status']} "
        f"({report['pages']} pages, {report['bytes']} bytes)"
    )
    for failure in report["failures"]:
        print(f"FAIL {failure['path']}: {failure['rule']}")
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
