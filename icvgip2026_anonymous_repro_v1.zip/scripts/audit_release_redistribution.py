"""Audit anonymous-supplement contents against upstream redistribution boundaries."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from build_anonymous_supplement import ROOT, selected_files


OUTPUT = ROOT / "artifacts" / "audits" / "release_redistribution.json"
ALLOWED_SUFFIXES = {".bib", ".json", ".md", ".py", ".tex", ".txt"}
FORBIDDEN_SUFFIXES = {
    ".avi", ".bmp", ".csv", ".gif", ".jpeg", ".jpg", ".mkv", ".mov",
    ".mp3", ".mp4", ".npz", ".onnx", ".parquet", ".pkl", ".png",
    ".pt", ".pth", ".safetensors", ".tsv", ".vrs", ".wav", ".webp",
}
FORBIDDEN_PARTS = {".kaggle", "raw", "derived", "third_party", "tmp"}
ONLY_PERMITTED_DATA_FILE = "data/manifests/look_and_tell_splits.json"


SOURCES = [
    {
        "name": "Look and Tell / KTH-ARIA Referential",
        "official_source": "https://huggingface.co/datasets/annadeichler/KTH-ARIA-referential",
        "license": "CC BY-NC-ND 4.0",
        "used": "annotations and locally extracted fixation/center frames",
        "redistribution": "exclude source annotations and all raw/transformed media; include only participant split IDs and aggregate results",
    },
    {
        "name": "ALFRED",
        "official_source": "https://github.com/askforalfred/alfred",
        "license": "MIT",
        "used": "official trajectory annotations for an auxiliary lamp-target text experiment",
        "redistribution": "exclude downloaded source data; include only code and aggregate results",
    },
    {
        "name": "HD-EPIC",
        "official_source": "https://hd-epic.github.io/site/",
        "license": "CC BY-NC 4.0",
        "used": "official annotations for a feasibility/count audit only",
        "redistribution": "exclude annotations and media; include only aggregate audit counts",
    },
    {
        "name": "OpenAI CLIP ViT-B/32",
        "official_source": "https://github.com/openai/CLIP",
        "license": "MIT (repository)",
        "used": "frozen model revision 3d74acf9a28c67741b2f4f2ea7635f0aaf6f0268",
        "redistribution": "exclude weights and embedding caches; include model identifier/revision and aggregate results",
    },
    {
        "name": "Google SigLIP 2 base patch16-224",
        "official_source": "https://huggingface.co/google/siglip2-base-patch16-224",
        "license": "Apache-2.0",
        "used": "frozen model revision 02c35f2c035e0ed4a367fb10a892c1fe2a3f364e",
        "redistribution": "exclude weights and embedding caches; include model identifier/revision and aggregate results",
    },
    {
        "name": "Alibaba GTE-ModernBERT-base",
        "official_source": "https://huggingface.co/Alibaba-NLP/gte-modernbert-base",
        "license": "Apache-2.0",
        "used": "frozen model revision e7f32e3c00f91d699e8c43b53106206bcc72bb22",
        "redistribution": "exclude weights and embedding cache; include model identifier/revision, code, and aggregate results",
    },
    {
        "name": "Hugging Face SmolVLM-256M-Instruct",
        "official_source": "https://huggingface.co/HuggingFaceTB/SmolVLM-256M-Instruct",
        "license": "Apache-2.0",
        "used": "parameter-efficient audit at revision 7e3e67edbbed1bf9888184d9df282b700a323964",
        "redistribution": "exclude weights and row-level fold artifacts; include code, hashes, model identifier/revision, and aggregate results",
    },
    {
        "name": "ONNX Model Zoo ResNet-50 v2 opset 7",
        "official_source": "https://github.com/onnx/models/tree/main/validated/vision/classification/resnet",
        "license": "Apache-2.0",
        "used": "checkpoint SHA-256 79102261eb6e5fd7af5d27f41316293e388c5cb691e5d25bfb035c4f64fefe31",
        "redistribution": "exclude checkpoint and feature cache; include checksum and aggregate results",
    },
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    paths = selected_files()
    relative_paths = [path.relative_to(ROOT).as_posix() for path in paths]
    errors: list[str] = []

    for relative, path in zip(relative_paths, paths, strict=True):
        parts = set(Path(relative).parts)
        if path.suffix.lower() not in ALLOWED_SUFFIXES:
            errors.append(f"unapproved suffix: {relative}")
        if path.suffix.lower() in FORBIDDEN_SUFFIXES:
            errors.append(f"forbidden payload type: {relative}")
        if parts & FORBIDDEN_PARTS:
            errors.append(f"forbidden path component: {relative}")
        if relative.startswith("data/") and relative != ONLY_PERMITTED_DATA_FILE:
            errors.append(f"unapproved dataset payload: {relative}")
        if path.name.lower() == ".env" or "credential" in path.name.lower():
            errors.append(f"credential-like file: {relative}")

    look = json.loads((ROOT / "artifacts/audits/look_and_tell_summary.json").read_text())
    clip = json.loads((ROOT / "artifacts/baselines/look_and_tell_clip.json").read_text())
    siglip = json.loads((ROOT / "artifacts/baselines/look_and_tell_siglip2.json").read_text())
    modernbert = json.loads(
        (ROOT / "artifacts/baselines/look_and_tell_modernbert.json").read_text()
    )
    vlm = json.loads(
        (ROOT / "artifacts/audits/look_and_tell_smolvlm_crossval.json").read_text()
    )
    classical = json.loads(
        (ROOT / "artifacts/baselines/look_and_tell_classical_vision.json").read_text()
    )
    expected = {
        "look_and_tell_license": (look.get("license"), "CC BY-NC-ND 4.0"),
        "look_and_tell_source": (look.get("source"), "annadeichler/KTH-ARIA-referential"),
        "clip_model": (clip.get("model"), "openai/clip-vit-base-patch32"),
        "clip_revision": (
            clip.get("model_revision"),
            "3d74acf9a28c67741b2f4f2ea7635f0aaf6f0268",
        ),
        "siglip_model": (siglip.get("model"), "google/siglip2-base-patch16-224"),
        "siglip_revision": (
            siglip.get("model_revision"),
            "02c35f2c035e0ed4a367fb10a892c1fe2a3f364e",
        ),
        "modernbert_model": (
            modernbert.get("model"),
            "Alibaba-NLP/gte-modernbert-base",
        ),
        "modernbert_revision": (
            modernbert.get("model_revision"),
            "e7f32e3c00f91d699e8c43b53106206bcc72bb22",
        ),
        "modernbert_license": (modernbert.get("model_license"), "Apache-2.0"),
        "smolvlm_model": (
            vlm.get("configuration", {}).get("model_id"),
            "HuggingFaceTB/SmolVLM-256M-Instruct",
        ),
        "smolvlm_revision": (
            vlm.get("configuration", {}).get("model_revision"),
            "7e3e67edbbed1bf9888184d9df282b700a323964",
        ),
        "smolvlm_license": (
            vlm.get("configuration", {}).get("model_license"),
            "Apache-2.0",
        ),
        "resnet_sha256": (
            classical.get("resnet50_onnx", {}).get("sha256"),
            "79102261eb6e5fd7af5d27f41316293e388c5cb691e5d25bfb035c4f64fefe31",
        ),
    }
    for label, (actual, wanted) in expected.items():
        if actual != wanted:
            errors.append(f"provenance mismatch {label}: {actual!r} != {wanted!r}")

    report = {
        "status": "passed" if not errors else "failed",
        "policy": {
            "supplement_scope": "code, manuscript source, frozen split IDs, and aggregate numerical artifacts",
            "only_permitted_data_file": ONLY_PERMITTED_DATA_FILE,
            "note": "This engineering audit records conservative release boundaries; it is not legal advice.",
        },
        "selected_file_count": len(paths),
        "selected_files": relative_paths,
        "sources": SOURCES,
        "errors": errors,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if errors:
        raise RuntimeError("release redistribution audit failed: " + "; ".join(errors))
    if not args.quiet:
        print(
            "release redistribution audit passed: "
            f"{len(paths)} selected files, no media/weights/source annotations/credentials"
        )


if __name__ == "__main__":
    main()
