"""Audit control-like actions in the official HD-EPIC CVPR 2025 annotations."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import pandas as pd


CONTROL_VERBS = {"turn-on", "turn-off", "open", "close", "switch"}
APPLIANCE_NOUNS = {
    "tap",
    "fridge",
    "hob",
    "kettle",
    "oven",
    "maker:coffee",
    "dishwasher",
    "blender",
    "microwave",
    "freezer",
    "light",
    "machine:washing",
    "processor:food",
    "cooker:slow",
    "fan:extractor",
    "toaster",
    "tv",
    "machine:sous:vide",
    "heater",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--annotations-root", type=Path, default=Path("third_party/hd-epic-annotations")
    )
    parser.add_argument(
        "--output", type=Path, default=Path("artifacts/audits/hd_epic_controls_summary.json")
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    path = args.annotations_root / "narrations-and-action-segments" / "HD_EPIC_Narrations.pkl"
    frame = pd.read_pickle(path)
    pair_counts: Counter[str] = Counter()
    verb_counts: Counter[str] = Counter()
    noun_counts: Counter[str] = Counter()
    relevant_indices = set()
    for index, row in frame.iterrows():
        for verb, noun in row["pairs"]:
            if verb in CONTROL_VERBS and noun in APPLIANCE_NOUNS:
                relevant_indices.add(index)
                pair_counts[f"{verb}::{noun}"] += 1
                verb_counts[verb] += 1
                noun_counts[noun] += 1

    relevant = frame.loc[sorted(relevant_indices)]
    priming_path = args.annotations_root / "eye-gaze-priming" / "priming_info.json"
    priming = json.loads(priming_path.read_text(encoding="utf-8"))
    summary = {
        "source": "hd-epic/hd-epic-annotations",
        "release": "CVPR 2025; gaze intermediate data updated January 2026",
        "license": "CC BY-NC 4.0 per the official dataset page",
        "total_narrations": int(len(frame)),
        "control_like_appliance_narrations": int(len(relevant)),
        "participants_with_control_like_actions": int(relevant["participant_id"].nunique()),
        "videos_with_control_like_actions": int(relevant["video_id"].nunique()),
        "verb_counts_over_pairs": dict(verb_counts.most_common()),
        "noun_counts_over_pairs": dict(noun_counts.most_common()),
        "pair_counts": dict(pair_counts.most_common()),
        "videos_with_gaze_priming_annotations": len(priming),
        "important_scope_note": (
            "Narrations describe observed physical actions, not spoken smart-home commands. "
            "Use HD-EPIC only for real-home visual/gaze transfer and never relabel it as IoT control."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
