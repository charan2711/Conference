"""Measure local lifecycle-policy latency after schemas are loaded."""

from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

from .build_benchmark import sqlite_schema
from .memory_policy import decide_rename, decide_split


def percentile(values: list[float], quantile: float) -> float:
    ordered = sorted(values)
    index = min(len(ordered) - 1, round((len(ordered) - 1) * quantile))
    return ordered[index]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", type=Path, default=Path("data/schemamem-ambiguity-v1"))
    parser.add_argument("--repeats", type=int, default=20)
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/policy_overhead.json"))
    args = parser.parse_args()
    rows = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    originals = Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases")
    rename_root = Path("data/schemamem-bench-v1")
    split_root = Path("data/schemamem-split-v1")
    prepared = []
    for row in rows:
        old_path = originals / row["db_id"] / f'{row["db_id"]}.sqlite'
        if row["scenario"] == "table_split":
            current_path = split_root / "databases" / row["db_id"] / f'{row["db_id"]}.sqlite'
        else:
            current_path = rename_root / "databases" / row["scenario"] / row["db_id"] / f'{row["db_id"]}.sqlite'
        prepared.append((row, sqlite_schema(old_path), sqlite_schema(current_path)))

    def decide(item: tuple) -> None:
        row, old_schema, current_schema = item
        if row["scenario"] == "table_split":
            decide_split(row["old_sql"], old_schema, current_schema, row["split_spec"], row["join_candidates"])
        else:
            decide_rename(row["old_sql"], old_schema, current_schema, row["manifest"])

    for item in prepared:
        decide(item)
    latencies_ms = []
    for _ in range(args.repeats):
        for item in prepared:
            start = time.perf_counter_ns()
            decide(item)
            latencies_ms.append((time.perf_counter_ns() - start) / 1_000_000)
    report = {
        "n_cases": len(prepared),
        "repeats": args.repeats,
        "n_decisions": len(latencies_ms),
        "mean_ms": statistics.fmean(latencies_ms),
        "median_ms": statistics.median(latencies_ms),
        "p95_ms": percentile(latencies_ms, 0.95),
        "p99_ms": percentile(latencies_ms, 0.99),
        "max_ms": max(latencies_ms),
        "scope": "warm in-process policy latency; schema loading and database execution excluded",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
