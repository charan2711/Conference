"""Verify the frozen venue snapshot and copy-ready OpenReview metadata."""

from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def section(markdown: str, heading: str) -> str:
    match = re.search(
        rf"^## {re.escape(heading)}\s*$\n(.*?)(?=^## |\Z)",
        markdown,
        flags=re.MULTILINE | re.DOTALL,
    )
    if not match:
        raise AssertionError(f"Missing metadata section: {heading}")
    return " ".join(match.group(1).strip().split())


def main() -> None:
    venue = json.loads(
        (ROOT / "artifacts/audits/icvgip2026_openreview_form.json").read_text(
            encoding="utf-8"
        )
    )
    assert venue["status"] == "verified"
    assert venue["conference_group"] == "ICVGIP.in/2026/Conference"
    assert venue["deadline"]["duedate_unix_ms"] == 1785456000000
    assert venue["deadline"]["due_utc"] == "2026-07-31T00:00:00Z"
    assert venue["deadline"]["due_ist"] == "2026-07-31T05:30:00+05:30"
    assert (
        venue["deadline"]["expdate_unix_ms"]
        - venue["deadline"]["duedate_unix_ms"]
        == 1_800_000
    )

    form = venue["submission_fields"]
    assert form["required"] == [
        "title", "authors/authorids", "keywords", "abstract", "pdf"
    ]
    assert form["optional"] == ["TLDR"]
    assert form["title_max_characters"] == 250
    assert form["tldr_max_characters"] == 250
    assert form["abstract_max_characters"] == 5000
    assert form["portal_pdf_max_megabytes"] == 50
    for absent in (
        "supplement_field_present",
        "code_or_data_field_present",
        "generative_ai_disclosure_field_present",
        "subject_area_field_present",
    ):
        assert form[absent] is False
    assert venue["controlling_limits"]["paper_pdf_max_megabytes"] == 20

    paper = (ROOT / "paper/main.tex").read_text(encoding="utf-8")
    title_match = re.search(r"\\title\{([^{}]+)\}", paper)
    if not title_match:
        raise AssertionError("Could not extract manuscript title")
    title = " ".join(title_match.group(1).split())

    metadata = (ROOT / "docs/openreview_submission_fields.md").read_text(
        encoding="utf-8"
    )
    copied_title = section(metadata, "Title")
    if copied_title != title:
        raise AssertionError(f"OpenReview title drift: {copied_title!r} != {title!r}")

    tldr = section(metadata, "TL;DR (optional)")
    if not tldr or len(tldr) > form["tldr_max_characters"]:
        raise AssertionError(f"Unexpected TL;DR length: {len(tldr)}")

    abstract = section(metadata, "Abstract")
    if len(abstract) > form["abstract_max_characters"]:
        raise AssertionError(f"Abstract exceeds form limit: {len(abstract)}")
    for claim in (
        "2,596", "2,376", "595", "2,330", "80.64%", "82.88%",
        "+2.23-point", "+3.24 points", "81.85%", "81.76%",
        "57.47%", "57.29%", "31.18%", "20.22%",
        "neither validates gaze localization",
    ):
        if claim not in abstract:
            raise AssertionError(f"OpenReview abstract is missing: {claim}")

    print(
        "submission metadata audit passed: "
        f"deadline={venue['deadline']['due_ist']}, tldr={len(tldr)}, "
        f"abstract={len(abstract)} characters"
    )


if __name__ == "__main__":
    main()
