"""Tool-using downstream data-agent evaluation under schema evolution.

Unlike the one-shot protocol, the model is not given the current schema. It can
inspect the read-only database, execute candidate SELECT queries, observe
results/errors, and then return a final query. Every interaction is retained.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests

from .agent_experiment import extract_sql
from .build_benchmark import execute, result_equivalent, sqlite_schema
from .freeze_agent_targets import balanced_sample
from .memory_policy import decide_rename


CONDITIONS = (
    "no_memory",
    "stale_memory",
    "version_filter",
    "reexplore_on_change",
    "execution_guided_memory",
    "schema_aware_memory",
    "policy_memory",
)


def schema_text(schema: dict[str, set[str]]) -> str:
    return "\n".join(
        f'{table}({", ".join(sorted(columns, key=str.casefold))})'
        for table, columns in sorted(schema.items(), key=lambda item: item[0].casefold())
    )


def parse_action(text: str) -> dict[str, str]:
    """Parse the agent's JSON action, with a conservative SQL-only fallback."""
    cleaned = text.strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", cleaned, flags=re.I | re.S)
    if fenced:
        cleaned = fenced.group(1).strip()
    match = re.search(r"\{.*\}", cleaned, flags=re.S)
    if match:
        try:
            payload = json.loads(match.group(0))
            action = str(payload.get("action", "")).casefold().strip()
            aliases = {
                "schema": "inspect_schema",
                "list_schema": "inspect_schema",
                "inspect": "inspect_schema",
                "execute": "execute_sql",
                "run_sql": "execute_sql",
                "answer": "final",
            }
            action = aliases.get(action, action)
            if action in {"inspect_schema", "execute_sql", "final"}:
                return {
                    "action": action,
                    "sql": str(payload.get("sql", "")).strip(),
                    "table": str(payload.get("table", "")).strip(),
                }
        except (json.JSONDecodeError, TypeError):
            pass
    sql = extract_sql(cleaned)
    if re.match(r"^\s*(SELECT|WITH)\b", sql, flags=re.I):
        return {"action": "final", "sql": sql, "table": ""}
    return {"action": "invalid", "sql": "", "table": ""}


def read_only_execute(path: Path, sql: str) -> tuple[bool, list | str]:
    if not re.match(r"^\s*(SELECT|WITH)\b", sql, flags=re.I):
        return False, "Only read-only SELECT or WITH queries are allowed."
    return execute(path, sql)


def observation(ok: bool, result: list | str) -> str:
    if not ok:
        return f"ERROR: {result}"
    rows = result if isinstance(result, list) else []
    sample = repr(rows[:5])
    if len(sample) > 1200:
        sample = sample[:1200] + "..."
    return f"OK. row_count={len(rows)}; first_rows={sample}"


def initial_messages(
    target: dict,
    memory: dict | None,
    memory_sql: str | None,
    *,
    force_reexplore: bool,
    table_listing: str,
    repair_sql: str | None = None,
    initial_observation: str | None = None,
) -> list[dict]:
    memory_text = "No prior procedural memory is available."
    if memory is not None and memory_sql:
        memory_text = (
            "A previously successful trajectory for a DIFFERENT question is available. "
            "It is only a structural example; adapt it to the current question and database.\n"
            f"Previous question: {memory['question']}\n"
            f"Previous SQL: {memory_sql}"
        )
    reexplore = ""
    if force_reexplore:
        reexplore = (
            "\nA schema migration affected the retrieved memory, so that memory was discarded. "
            "The current table list is supplied below as a tool observation. You must inspect "
            "any needed tables, execute at "
            "least one candidate query and use its observation before finalizing.\n"
            f"TOOL inspect_schema RESULT:\n{table_listing}\n"
        )
    if repair_sql is not None:
        user = f"""Stored question: {target['question']}
Domain evidence: {target.get('evidence', '')}

The following previously successful stored SQL was validated against the current
database and failed. Repair it without access to a migration manifest.
Stored SQL: {repair_sql}
TOOL execute_sql RESULT:
{initial_observation or 'ERROR: validation failed'}

Inspect the current schema, execute at least one repaired candidate, and return
the repaired SQL through the final action."""
    else:
        user = f"""Current question: {target['question']}
Domain evidence: {target.get('evidence', '')}

{memory_text}
{reexplore}
Use tools as needed and return the final SQL through the final action."""
    system = """You are a tool-using SQLite data agent. The database is read-only.
At every turn return exactly one JSON object, with no markdown or explanation:
{"action":"inspect_schema"}
{"action":"inspect_schema","table":"table_name"}
{"action":"execute_sql","sql":"SELECT ..."}
{"action":"final","sql":"SELECT ..."}
First use inspect_schema without a table to list relations, then inspect only
the named tables you need. Use execute_sql to observe rows or errors and repair
the query. Treat an empty result or an all-NULL aggregate as evidence to recheck
joins and filters before finalizing. Observed rows are diagnostic only: the
final SQL must compute its answer from database tables and must never hard-code
an observed result. Never issue data-changing SQL."""
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def call_model(url: str, messages: list[dict], max_tokens: int) -> tuple[str, dict, float]:
    started = time.perf_counter()
    response = requests.post(
        url,
        json={
            "model": "local",
            "messages": messages,
            "temperature": 0,
            "max_tokens": max_tokens,
            "seed": 42,
            "response_format": {"type": "json_object"},
        },
        timeout=240,
    )
    response.raise_for_status()
    payload = response.json()
    return (
        payload["choices"][0]["message"]["content"].strip(),
        payload.get("usage", {}),
        time.perf_counter() - started,
    )


def run_agent(
    *,
    url: str,
    path: Path,
    target: dict,
    memory: dict | None,
    memory_sql: str | None,
    force_reexplore: bool,
    max_calls: int,
    max_tokens: int,
    repair_sql: str | None = None,
    initial_observation: str | None = None,
    require_candidate_execution: bool = False,
) -> dict:
    schema = sqlite_schema(path)
    folded_tables = {table.casefold(): table for table in schema}
    table_listing = "TABLES: " + ", ".join(sorted(schema, key=str.casefold))
    messages = initial_messages(
        target,
        memory,
        memory_sql,
        force_reexplore=force_reexplore,
        table_listing=table_listing,
        repair_sql=repair_sql,
        initial_observation=initial_observation,
    )
    trace: list[dict] = []
    if repair_sql is not None:
        trace.append(
            {
                "call": 0,
                "raw": "",
                "action": "preflight_execute",
                "sql": repair_sql,
                "table": "",
                "observation": initial_observation or "ERROR: validation failed",
            }
        )
    last_sql = ""
    executed = int(repair_sql is not None)
    candidate_executed = 0
    inspected = int(force_reexplore)
    model_calls = 0
    prompt_tokens = completion_tokens = 0
    model_seconds = 0.0
    finalized = False

    for call_index in range(max_calls):
        raw, usage, elapsed = call_model(url, messages, max_tokens)
        model_calls += 1
        prompt_tokens += int(usage.get("prompt_tokens", 0) or 0)
        completion_tokens += int(usage.get("completion_tokens", 0) or 0)
        model_seconds += elapsed
        action = parse_action(raw)
        event = {"call": call_index + 1, "raw": raw, **action}
        messages.append({"role": "assistant", "content": raw})

        if action["action"] == "inspect_schema":
            inspected += 1
            requested = action.get("table", "").casefold()
            if requested:
                canonical = folded_tables.get(requested)
                result = (
                    schema_text({canonical: schema[canonical]})
                    if canonical else
                    f"Unknown table {action['table']!r}. {table_listing}"
                )
            else:
                result = table_listing
            event["observation"] = result
            messages.append({"role": "user", "content": f"TOOL inspect_schema RESULT:\n{result}"})
        elif action["action"] in {"execute_sql", "final"} and action["sql"]:
            last_sql = action["sql"]
            must_execute = force_reexplore or require_candidate_execution
            if action["action"] == "final" and not (must_execute and candidate_executed == 0):
                finalized = True
                trace.append(event)
                break
            ok, result = read_only_execute(path, action["sql"])
            executed += 1
            candidate_executed += 1
            result_text = observation(ok, result)
            event["observation"] = result_text
            messages.append(
                {"role": "user", "content": f"TOOL execute_sql RESULT:\n{result_text}"}
            )
        else:
            event["observation"] = "Invalid action. Return one of the three JSON contracts."
            messages.append({"role": "user", "content": event["observation"]})
        trace.append(event)

    return {
        "prediction": last_sql,
        "finalized": finalized,
        "model_calls": model_calls,
        "tool_calls": inspected + executed,
        "schema_inspections": inspected,
        "sql_executions": executed,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "model_seconds": model_seconds,
        "trace": trace,
    }


def execution_guided_repair(
    *,
    url: str,
    path: Path,
    memory: dict,
    max_calls: int,
    max_tokens: int,
) -> dict:
    """Validate a stored program and repair only observable execution failures.

    The deployable baseline never sees a migration manifest or gold result.  An
    executable stale program is retained even when it is silently wrong; a
    failed program is handed to the same bounded schema/SQL tool loop used by
    the downstream agent.
    """
    ok, result = read_only_execute(path, memory["old_sql"])
    if ok:
        return {
            "prediction": memory["old_sql"],
            "exec_ok": True,
            "action": "reuse_on_execution_success",
            "model_calls": 0,
            "tool_calls": 1,
            "sql_executions": 1,
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "model_seconds": 0.0,
            "trace": [
                {
                    "call": 0,
                    "raw": "",
                    "action": "preflight_execute",
                    "sql": memory["old_sql"],
                    "table": "",
                    "observation": observation(True, result),
                }
            ],
        }
    initial = observation(False, result)
    agent = run_agent(
        url=url,
        path=path,
        target=memory,
        memory=None,
        memory_sql=None,
        force_reexplore=False,
        max_calls=max_calls,
        max_tokens=max_tokens,
        repair_sql=memory["old_sql"],
        initial_observation=initial,
        require_candidate_execution=True,
    )
    repaired_ok, _ = read_only_execute(path, agent["prediction"])
    return {
        **agent,
        "exec_ok": repaired_ok,
        "action": "repair_on_execution_failure",
    }


def migration_manifest(target: dict, migration: dict) -> dict:
    column_candidates = (
        {key: [value] for key, value in migration["column_rename"].items()}
        if target["scenario"] == "column_rename"
        else {}
    )
    table_candidates = (
        {key: [value] for key, value in migration["table_rename"].items()}
        if target["scenario"] == "table_rename"
        else {}
    )
    return {
        "operator": "rename",
        "write_set": [*column_candidates, *table_candidates],
        "column_candidates": column_candidates,
        "table_candidates": table_candidates,
    }


def summarize(rows: list[dict], model_label: str, protocol: dict | None = None) -> dict:
    report = {
        "model_label": model_label,
        "n_runs": len(rows),
        "protocol": protocol or {},
        "conditions": {},
    }
    for condition in sorted({row["condition"] for row in rows}):
        group = [row for row in rows if row["condition"] == condition]
        report["conditions"][condition] = {
            "n": len(group),
            "execution_accuracy": sum(row["correct"] for row in group) / len(group),
            "valid_sql_rate": sum(row["exec_ok"] for row in group) / len(group),
            "finalization_rate": sum(row["finalized"] for row in group) / len(group),
            "mean_model_calls": sum(row["model_calls"] for row in group) / len(group),
            "mean_tool_calls": sum(row["tool_calls"] for row in group) / len(group),
            "mean_sql_executions": sum(row["sql_executions"] for row in group) / len(group),
            "mean_prompt_tokens": sum(row["prompt_tokens"] for row in group) / len(group),
            "mean_completion_tokens": sum(row["completion_tokens"] for row in group) / len(group),
            "mean_total_tokens": sum(
                row["prompt_tokens"] + row["completion_tokens"] for row in group
            ) / len(group),
            "mean_model_seconds": sum(row["model_seconds"] for row in group) / len(group),
            "mean_maintenance_model_calls": sum(
                row.get("maintenance_model_calls", 0) for row in group
            ) / len(group),
            "mean_total_model_calls": sum(
                row["model_calls"] + row.get("maintenance_model_calls", 0)
                for row in group
            ) / len(group),
            "mean_total_tokens_with_maintenance": sum(
                row["prompt_tokens"]
                + row["completion_tokens"]
                + row.get("maintenance_prompt_tokens", 0)
                + row.get("maintenance_completion_tokens", 0)
                for row in group
            ) / len(group),
        }
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", type=Path, default=Path("data/schemamem-bench-v1"))
    parser.add_argument(
        "--original-root",
        type=Path,
        help=(
            "original database root; defaults to BENCHMARK/original_databases "
            "when present, otherwise the BIRD Mini-Dev root"
        ),
    )
    parser.add_argument("--targets", type=Path, default=Path("data/schemamem-agent-targets-v1.json"))
    parser.add_argument("--url", default="http://127.0.0.1:8080/v1/chat/completions")
    parser.add_argument("--model-label", required=True)
    parser.add_argument("--max-calls", type=int, default=8)
    parser.add_argument("--max-tokens", type=int, default=256)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--limit", type=int)
    parser.add_argument(
        "--per-db",
        type=int,
        help="sample at most this many targets per database",
    )
    parser.add_argument("--sample-seed", type=int, default=42)
    parser.add_argument(
        "--conditions",
        nargs="+",
        choices=CONDITIONS,
        default=list(CONDITIONS),
        help="condition subset; useful for focused affected-memory expansions",
    )
    parser.add_argument(
        "--output", type=Path, default=Path("results/schemamem/tool_agent_runs.jsonl")
    )
    args = parser.parse_args()

    instances = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    index = {
        (row["scenario"], row["db_id"], row["question_id"]): row
        for row in instances
        if row["execution_equivalent"]
    }
    target_specs = json.loads(args.targets.read_text(encoding="utf-8"))
    if args.per_db:
        target_specs = balanced_sample(target_specs, args.per_db, args.sample_seed)
    if args.limit:
        target_specs = target_specs[: args.limit]
    tasks = []
    for spec in target_specs:
        prefix = (spec["scenario"], spec["db_id"])
        tasks.append(
            (
                index[(*prefix, spec["question_id"])],
                index[(*prefix, spec["memory_question_id"])],
            )
        )

    migrations = json.loads((args.benchmark / "migrations.json").read_text(encoding="utf-8"))
    bundled_originals = args.benchmark / "original_databases"
    original_root = args.original_root or (
        bundled_originals
        if bundled_originals.is_dir()
        else Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases")
    )
    completed = set()
    existing = []
    if args.output.exists():
        for line in args.output.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            existing.append(row)
            completed.add((row["scenario"], row["db_id"], row["question_id"], row["condition"]))
    args.output.parent.mkdir(parents=True, exist_ok=True)

    with args.output.open("a", encoding="utf-8") as handle:
        for target, memory in tasks:
            path = args.benchmark / "databases" / target["scenario"] / target["db_id"] / f'{target["db_id"]}.sqlite'
            # Gold execution is an evaluator precondition, not an agent tool.
            # Some valid BIRD joins slightly exceed the generic 3 s guard on
            # this workstation. Use a generous evaluator-only guard so a cold
            # join is not mistaken for invalid ground truth.
            gold_ok, gold = execute(path, target["new_sql"], timeout_seconds=30)
            if not gold_ok:
                print(
                    "gold_validation_skip "
                    f"scenario={target['scenario']} db_id={target['db_id']} "
                    f"question_id={target['question_id']} reason={gold}",
                    flush=True,
                )
                continue
            manifest = migration_manifest(target, migrations[target["db_id"]])
            old_path = original_root / target["db_id"] / f'{target["db_id"]}.sqlite'
            policy = decide_rename(memory["old_sql"], sqlite_schema(old_path), sqlite_schema(path), manifest)
            policy_pair = (
                (memory, policy.sql)
                if policy.action in {"reuse", "migrate"} and policy.sql
                else (None, None)
            )
            conditions = {
                "no_memory": (None, None, False, None),
                "stale_memory": (memory, memory["old_sql"], False, None),
                "version_filter": ((None, None, False, None) if memory["affected"] else (memory, memory["old_sql"], False, None)),
                "reexplore_on_change": ((None, None, True, None) if memory["affected"] else (memory, memory["old_sql"], False, None)),
                "execution_guided_memory": (memory, memory["old_sql"], False, "execution_guided"),
                "schema_aware_memory": (memory, memory["new_sql"], False, None),
                "policy_memory": (*policy_pair, False, None),
            }
            pending = [
                (name, *values)
                for name, values in conditions.items()
                if name in args.conditions
                if (target["scenario"], target["db_id"], target["question_id"], name) not in completed
            ]

            def run_condition(item: tuple) -> dict:
                condition, memory_record, memory_sql, force_reexplore, maintenance_mode = item
                base = {
                    "model_label": args.model_label,
                    "scenario": target["scenario"],
                    "db_id": target["db_id"],
                    "cluster_id": target.get("cluster_id", target["db_id"]),
                    "question_id": target["question_id"],
                    "condition": condition,
                    "target_affected": target["affected"],
                    "memory_question_id": memory["question_id"],
                    "memory_affected": memory["affected"],
                    "memory_provided": memory_record is not None,
                    "policy_action": policy.action if condition == "policy_memory" else None,
                    "retrieval_score": next(
                        spec["retrieval_score"]
                        for spec in target_specs
                        if spec["scenario"] == target["scenario"]
                        and spec["db_id"] == target["db_id"]
                        and spec["question_id"] == target["question_id"]
                    ),
                }
                try:
                    maintenance = None
                    if maintenance_mode == "execution_guided":
                        maintenance = execution_guided_repair(
                            url=args.url,
                            path=path,
                            memory=memory,
                            max_calls=args.max_calls,
                            max_tokens=args.max_tokens,
                        )
                        if maintenance["exec_ok"] and maintenance["prediction"]:
                            memory_record, memory_sql = memory, maintenance["prediction"]
                        else:
                            memory_record, memory_sql = None, None
                        base["memory_provided"] = memory_record is not None
                    agent = run_agent(
                        url=args.url,
                        path=path,
                        target=target,
                        memory=memory_record,
                        memory_sql=memory_sql,
                        force_reexplore=force_reexplore,
                        max_calls=args.max_calls,
                        max_tokens=args.max_tokens,
                    )
                    exec_ok, result = read_only_execute(path, agent["prediction"])
                    maintenance_fields = {
                        "maintenance_action": maintenance["action"] if maintenance else None,
                        "maintenance_prediction": maintenance["prediction"] if maintenance else None,
                        "maintenance_exec_ok": maintenance["exec_ok"] if maintenance else None,
                        "maintenance_model_calls": maintenance["model_calls"] if maintenance else 0,
                        "maintenance_tool_calls": maintenance["tool_calls"] if maintenance else 0,
                        "maintenance_sql_executions": maintenance["sql_executions"] if maintenance else 0,
                        "maintenance_prompt_tokens": maintenance["prompt_tokens"] if maintenance else 0,
                        "maintenance_completion_tokens": maintenance["completion_tokens"] if maintenance else 0,
                        "maintenance_model_seconds": maintenance["model_seconds"] if maintenance else 0.0,
                        "maintenance_trace": maintenance["trace"] if maintenance else [],
                    }
                    return {
                        **base,
                        **agent,
                        **maintenance_fields,
                        "exec_ok": exec_ok,
                        "correct": exec_ok and result_equivalent(result, gold, target["new_sql"]),
                        "error": None if exec_ok else result,
                    }
                except Exception as error:
                    return {
                        **base,
                        "prediction": "",
                        "finalized": False,
                        "model_calls": 0,
                        "tool_calls": 0,
                        "schema_inspections": 0,
                        "sql_executions": 0,
                        "prompt_tokens": 0,
                        "completion_tokens": 0,
                        "model_seconds": 0.0,
                        "trace": [],
                        "maintenance_action": None,
                        "maintenance_prediction": None,
                        "maintenance_exec_ok": None,
                        "maintenance_model_calls": 0,
                        "maintenance_tool_calls": 0,
                        "maintenance_sql_executions": 0,
                        "maintenance_prompt_tokens": 0,
                        "maintenance_completion_tokens": 0,
                        "maintenance_model_seconds": 0.0,
                        "maintenance_trace": [],
                        "exec_ok": False,
                        "correct": False,
                        "error": f"{type(error).__name__}: {error}",
                    }

            with ThreadPoolExecutor(max_workers=args.workers) as executor:
                futures = [executor.submit(run_condition, item) for item in pending]
                for future in as_completed(futures):
                    row = future.result()
                    handle.write(json.dumps(row) + "\n")
                    handle.flush()
                    existing.append(row)

    report = summarize(
        existing,
        args.model_label,
        {
            "target_manifest": str(args.targets),
            "target_manifest_sha256": hashlib.sha256(args.targets.read_bytes()).hexdigest(),
            "selected_targets": len(target_specs),
            "conditions": args.conditions,
            "max_calls": args.max_calls,
            "max_tokens_per_call": args.max_tokens,
            "workers": args.workers,
            "temperature": 0,
            "seed": 42,
            "schema_tool": "list_tables_then_named_table_columns",
            "read_only_execution": True,
            "original_database_root": str(original_root),
        },
    )
    args.output.with_suffix(".summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
