"""Verify every derived Look and Tell row against its released source CSV."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "look_and_tell" / "data"
DERIVED = ROOT / "data" / "derived" / "look_and_tell"
OUTPUT = ROOT / "artifacts" / "audits" / "look_and_tell_raw_derived_alignment.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def normalized_optional(value: str | None) -> str | None:
    if value is None or not value.strip():
        return None
    return value


def normalized_float(value: str | float | None) -> float | None:
    if value is None or value == "":
        return None
    result = float(value)
    return None if math.isnan(result) else result


def same_float(left: float | None, right: float | None) -> bool:
    if left is None or right is None:
        return left is None and right is None
    return math.isclose(left, right, rel_tol=0.0, abs_tol=1e-6)


def sha256_paths(paths: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths):
        digest.update(path.relative_to(ROOT).as_posix().encode())
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def source_path(recording_uid: str) -> Path:
    participant, rec_prefix, rec_number = recording_uid.rsplit("_", 2)
    recording = f"{rec_prefix}_{rec_number}"
    return RAW / participant / "annotations" / "v1" / recording / "references.csv"


def main() -> None:
    args = parse_args()
    manifests = sorted(DERIVED.glob("par_*/rec_*/manifest.jsonl"))
    require(bool(manifests), "No derived Look and Tell manifests found")

    source_indexes: dict[Path, dict[str, dict[str, str]]] = {}
    used_sources: set[Path] = set()
    dimensions: Counter[str] = Counter()
    mention_types: Counter[str] = Counter()
    missing_fixations = 0
    empty_target_rows = 0
    row_ids: list[str] = []

    for manifest in manifests:
        lines = manifest.read_text(encoding="utf-8").splitlines()
        for line_number, line in enumerate(lines, 1):
            row = json.loads(line)
            if not (row.get("reference") or "").strip():
                empty_target_rows += 1
                continue
            recording = row["recording_uid"]
            source = source_path(recording)
            require(source.is_file(), f"Missing source CSV for {recording}")
            if source not in source_indexes:
                with source.open(encoding="utf-8-sig", newline="") as stream:
                    source_rows = list(csv.DictReader(stream))
                ids = [candidate["mention_id"] for candidate in source_rows if candidate["mention_id"]]
                require(len(ids) == len(set(ids)), f"Duplicate source mention IDs: {source}")
                source_indexes[source] = {
                    candidate["mention_id"]: candidate
                    for candidate in source_rows
                    if candidate["mention_id"]
                }
            used_sources.add(source)

            mention_id = row["mention_id"]
            require(mention_id in source_indexes[source], f"Missing source row: {recording}/{mention_id}")
            original = source_indexes[source][mention_id]
            prefix = f"{recording}/{mention_id} ({manifest.name}:{line_number})"
            require(row["surface_text"] == original["tsv_words"], f"Surface text drift: {prefix}")
            require(row["reference"] == original["reference"], f"Target drift: {prefix}")
            require(row["mention_type"] == original["mention_type"], f"Mention type drift: {prefix}")
            require(
                normalized_optional(row.get("antecedent_id"))
                == normalized_optional(original.get("antecedent_id")),
                f"Antecedent drift: {prefix}",
            )
            require(row["chain_id"] == original["chain_id"], f"Chain drift: {prefix}")
            expected_frame = (
                int(original["frame_idx_rgb_start"]) + int(original["frame_idx_rgb_end"])
            ) // 2
            require(row["frame_index"] == expected_frame, f"Midpoint frame drift: {prefix}")
            require(
                same_float(normalized_float(row.get("fix_x")), normalized_float(original.get("fix_x"))),
                f"Fixation-x drift: {prefix}",
            )
            require(
                same_float(normalized_float(row.get("fix_y")), normalized_float(original.get("fix_y"))),
                f"Fixation-y drift: {prefix}",
            )

            frame = ROOT / row["frame_path"]
            require(frame.is_file(), f"Missing midpoint frame: {prefix}: {frame}")
            require(frame.name == f"frame_{expected_frame:06d}.jpg", f"Frame filename drift: {prefix}")
            with Image.open(frame) as image:
                dimensions[f"{image.width}x{image.height}"] += 1
            mention_types[row["mention_type"]] += 1
            if row.get("fix_x") is None or row.get("fix_y") is None:
                missing_fixations += 1
            row_ids.append(f"{recording}|{mention_id}|{expected_frame}")

    require(len(row_ids) == len(set(row_ids)), "Duplicate derived row identities")
    require(len(row_ids) == 2330, f"Expected 2,330 matched-media rows, found {len(row_ids)}")
    require(missing_fixations == 192, f"Expected 192 missing fixations, found {missing_fixations}")
    require(dimensions == {"1408x1408": 2330}, f"Unexpected frame dimensions: {dimensions}")

    artifact = {
        "audit": "full raw references.csv to derived matched-media manifest alignment",
        "derived_manifest_files": len(manifests),
        "source_reference_files": len(used_sources),
        "rows_checked": len(row_ids),
        "unique_row_identities": len(set(row_ids)),
        "mention_types": dict(sorted(mention_types.items())),
        "missing_fixations": missing_fixations,
        "excluded_empty_target_rows": empty_target_rows,
        "frame_dimensions": dict(sorted(dimensions.items())),
        "source_csv_sha256": sha256_paths(list(used_sources)),
        "derived_manifest_sha256": sha256_paths(manifests),
        "checks": [
            "surface_text equals released tsv_words",
            "canonical target, mention type, antecedent, and chain match source",
            "frame index is floor midpoint of released RGB interval",
            "fixation coordinates match source within 1e-6",
            "every midpoint frame exists and is 1408x1408",
        ],
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(artifact, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if not args.quiet:
        print(
            "raw-derived alignment audit passed: "
            f"{len(row_ids)} rows, {len(used_sources)} source files, "
            f"{missing_fixations} missing fixations"
        )


if __name__ == "__main__":
    main()
