"""Machine-check the nested Look and Tell threshold-transfer artifact."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact", type=Path,
                        default=Path("artifacts/baselines/look_and_tell_full_frame_nested_threshold.json"))
    args = parser.parse_args()
    artifact = json.loads(args.artifact.read_text(encoding="utf-8"))
    assert artifact["protocol"].startswith("nested")
    folds = artifact["outer_folds"]
    assert len(folds) == 6, len(folds)
    held_out = [participant for fold in folds for participant in fold["held_out_participants"]]
    assert len(held_out) == len(set(held_out)) == artifact["n_participants"]
    for fold in folds:
        selection = fold["inner_selection"]
        assert selection["feasible"] is True
        assert selection["selective_error"] <= artifact["maximum_error"] + 1e-12
        assert fold["threshold"] == selection["threshold"]
        assert 0.0 <= fold["coverage"] <= 1.0
        assert fold["accepted"] <= fold["n"]
    aggregate = artifact["aggregate"]
    assert aggregate["accepted"] == aggregate["accepted_correct"] + aggregate["accepted_wrong"]
    assert aggregate["accepted"] <= aggregate["n"]
    assert abs(aggregate["coverage"] - aggregate["accepted"] / aggregate["n"]) < 1e-12
    assert 0.0 <= aggregate["selective_error"] <= 1.0
    print(json.dumps({
        "status": "pass",
        "outer_folds": len(folds),
        "participants": len(set(held_out)),
        "aggregate_coverage": aggregate["coverage"],
        "aggregate_selective_error": aggregate["selective_error"],
    }, indent=2))


if __name__ == "__main__":
    main()
