"""Evaluate lifecycle policies on executable table-consolidation migrations."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from sqlglot import parse_one

from .build_benchmark import execute, result_equivalent, sqlite_schema
from .memory_policy import decide_merge


def main() -> None:
    parser = argparse.ArgumentParser()
    root = Path("data/bird-mini-dev/package/minidev/MINIDEV")
    parser.add_argument("--benchmark", type=Path, default=Path("data/schemamem-merge-v1"))
    parser.add_argument("--old-databases", type=Path, default=Path("data/schemamem-split-v1/databases"))
    parser.add_argument("--current-databases", type=Path, default=root / "dev_databases")
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/merge_baselines.json"))
    args = parser.parse_args()

    rows = [
        row for row in json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
        if row["execution_equivalent"]
    ]
    specs = json.loads((args.benchmark / "migrations.json").read_text(encoding="utf-8"))
    method_names = ["stale_raw", "version_filter", "schema_aware_repair"]
    methods = {
        name: {"returned": 0, "correct": 0, "exec_error": 0, "silent_wrong": 0}
        for name in method_names
    }
    instances = []
    schema_cache: dict[str, tuple[dict, dict]] = {}
    for row in rows:
        db_id = row["db_id"]
        old_db = args.old_databases / db_id / f"{db_id}.sqlite"
        current_db = args.current_databases / db_id / f"{db_id}.sqlite"
        if db_id not in schema_cache:
            schema_cache[db_id] = (sqlite_schema(old_db), sqlite_schema(current_db))
        old_schema, current_schema = schema_cache[db_id]
        spec = specs[db_id]
        join = [[(key, key) for key in spec["primary_key"]]]
        decision = decide_merge(row["old_sql"], old_schema, current_schema, spec, join)

        # An affected historical program necessarily references the removed
        # details relation; an unaffected one is byte-for-byte the validated
        # original modulo SQLGlot formatting.
        stale_ok = not row["affected"]
        stale_correct = not row["affected"]
        repair_returned = decision.sql is not None
        structurally_identical = repair_returned and (
            parse_one(decision.sql, read="sqlite")
            == parse_one(row["new_sql"], read="sqlite")
        )
        if structurally_identical:
            # Inherits the benchmark's successful execution and equivalence
            # gate because this is the same AST as its validated current SQL.
            repair_ok = repair_correct = True
        elif repair_returned:
            gold_ok, gold = execute(current_db, row["new_sql"], timeout_seconds=10)
            repair_ok, repair_result = execute(
                current_db, decision.sql, timeout_seconds=10
            )
            repair_correct = repair_ok and gold_ok and result_equivalent(
                repair_result, gold, row["new_sql"]
            )
        else:
            repair_ok = repair_correct = False
        outcomes = {
            "stale_raw": {"returned": True, "exec_ok": stale_ok, "correct": stale_correct},
            "version_filter": {
                "returned": not row["affected"], "exec_ok": not row["affected"],
                "correct": not row["affected"],
            },
            "schema_aware_repair": {
                "returned": repair_returned, "exec_ok": repair_ok, "correct": repair_correct,
                "action": decision.action, "reason": decision.reason,
            },
        }
        for name, outcome in outcomes.items():
            methods[name]["returned"] += int(outcome["returned"])
            methods[name]["correct"] += int(outcome["correct"])
            methods[name]["exec_error"] += int(outcome["returned"] and not outcome["exec_ok"])
            methods[name]["silent_wrong"] += int(outcome["exec_ok"] and not outcome["correct"])
        instances.append({"db_id": db_id, "question_id": row["question_id"], "affected": row["affected"], "methods": outcomes})

    n = len(rows)
    report = {"n": n, "affected": sum(row["affected"] for row in rows), "methods": {}}
    for name, counts in methods.items():
        returned = counts["returned"]
        report["methods"][name] = {
            **counts,
            "coverage": returned / n,
            "correct_rate": counts["correct"] / n,
            "precision_returned": counts["correct"] / returned if returned else 1.0,
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    args.output.with_name("merge_baseline_instances.json").write_text(json.dumps(instances, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
