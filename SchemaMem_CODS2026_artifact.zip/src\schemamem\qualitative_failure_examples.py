"""Deterministically select preregistered qualitative examples from frozen data."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .build_benchmark import sqlite_schema
from .memory_policy import decide_split


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/schemamem/qualitative_failure_examples.json"),
    )
    args = parser.parse_args()

    run_path = Path("results/schemamem/tool_agent_runs_qwen7_drspider_v1.jsonl")
    runs = jsonl(run_path)
    run_index = {
        (row["db_id"], row["question_id"], row["memory_question_id"], row["condition"]): row
        for row in runs
    }
    benchmark_rows = read(Path("data/schemamem-drspider-v1/instances.json"))
    benchmark_index = {
        (row["db_id"], row["question_id"]): row for row in benchmark_rows
    }

    maintenance_audit = read(
        Path(
            "results/schemamem/"
            "tool_agent_runs_qwen7_drspider_v1.execution_guided_audit.json"
        )
    )["instances"]
    maintenance_candidates = sorted(
        (row for row in maintenance_audit if row["maintenance_silent_wrong"]),
        key=lambda row: (
            row["db_id"],
            row["target_question_id"],
            row["memory_question_id"],
            "execution_guided_memory",
        ),
    )
    maintenance = maintenance_candidates[0]
    maintenance_run = run_index[
        (
            maintenance["db_id"],
            maintenance["target_question_id"],
            maintenance["memory_question_id"],
            "execution_guided_memory",
        )
    ]
    maintenance_target = benchmark_index[
        (maintenance["db_id"], maintenance["target_question_id"])
    ]
    maintenance_memory = benchmark_index[
        (maintenance["db_id"], maintenance["memory_question_id"])
    ]

    ambiguity_rows = read(Path("results/schemamem/ambiguity_instances.json"))
    ambiguity_candidates = sorted(
        (
            row
            for row in ambiguity_rows
            if row["class"].startswith("ambiguous_")
            and row["decision"]["action"] == "explore"
        ),
        key=lambda row: (
            row["db_id"],
            row["question_id"],
            "",
            "full_fail_closed",
        ),
    )
    ambiguity = ambiguity_candidates[0]

    policy_audit = read(
        Path("results/schemamem/tool_agent_runs_qwen7_drspider_v1.policy_audit.json")
    )["instances"]
    downstream_candidates = []
    for audit in policy_audit:
        if not audit["returned_sql_semantically_correct"]:
            continue
        key = (
            audit["db_id"],
            audit["target_question_id"],
            audit["memory_question_id"],
            "policy_memory",
        )
        run = run_index[key]
        if not run["correct"]:
            downstream_candidates.append((audit, run))
    downstream_candidates.sort(
        key=lambda pair: (
            pair[0]["cluster_id"],
            pair[0]["db_id"],
            pair[0]["target_question_id"],
            "policy_memory",
        )
    )
    downstream_audit, downstream_run = downstream_candidates[0]
    downstream_target = benchmark_index[
        (downstream_audit["db_id"], downstream_audit["target_question_id"])
    ]

    split_rows = read(Path("data/schemamem-split-v1/instances.json"))
    split_specs = read(Path("data/schemamem-split-v1/migrations.json"))
    unsupported_candidates = []
    for row in split_rows:
        if row.get("new_error") != "ValueError: nested query excluded from split pilot":
            continue
        spec = split_specs[row["db_id"]]
        old_path = (
            Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases")
            / row["db_id"]
            / f"{row['db_id']}.sqlite"
        )
        current_path = (
            Path("data/schemamem-split-v1/databases")
            / row["db_id"]
            / f"{row['db_id']}.sqlite"
        )
        decision = decide_split(
            row["old_sql"],
            sqlite_schema(old_path),
            sqlite_schema(current_path),
            spec,
            [[(key, key) for key in spec["primary_key"]]],
        )
        if decision.action == "explore":
            unsupported_candidates.append((row, decision))
    unsupported_candidates.sort(
        key=lambda pair: (pair[0]["db_id"], pair[0]["question_id"], "", "policy")
    )
    unsupported, unsupported_decision = unsupported_candidates[0]

    examples = [
        {
            "category": "execution_guided_executable_but_semantically_wrong",
            "selection_key": [
                maintenance["db_id"],
                maintenance["target_question_id"],
                maintenance["memory_question_id"],
                "execution_guided_memory",
            ],
            "target_question": maintenance_target["question"],
            "memory_question": maintenance_memory["question"],
            "old_memory_sql": maintenance_memory["old_sql"],
            "maintenance_sql": maintenance_run["maintenance_prediction"],
            "maintenance_executable": maintenance["maintenance_exec_ok"],
            "maintenance_semantically_correct": maintenance["maintenance_correct"],
        },
        {
            "category": "ambiguous_mapping_withheld",
            "selection_key": [
                ambiguity["db_id"],
                ambiguity["question_id"],
                None,
                "full_fail_closed",
            ],
            "class": ambiguity["class"],
            "old_sql": ambiguity["old_sql"],
            "candidate_count": len(
                ambiguity.get("join_candidates", [])
                or next(
                    iter(ambiguity.get("manifest", {}).get("column_candidates", {}).values()),
                    [],
                )
            ),
            "decision_action": ambiguity["decision"]["action"],
            "decision_reason": ambiguity["decision"]["reason"],
        },
        {
            "category": "downstream_failure_after_correct_memory",
            "selection_key": [
                downstream_audit["cluster_id"],
                downstream_audit["db_id"],
                downstream_audit["target_question_id"],
                "policy_memory",
            ],
            "target_question": downstream_target["question"],
            "maintained_memory_semantically_correct": True,
            "agent_prediction": downstream_run["prediction"],
            "agent_prediction_executable": downstream_run["exec_ok"],
            "agent_prediction_correct": downstream_run["correct"],
            "agent_finalized": downstream_run["finalized"],
        },
        {
            "category": "unsupported_nested_scope_rejected",
            "selection_key": [
                unsupported["db_id"],
                unsupported["question_id"],
                None,
                "policy",
            ],
            "question": unsupported["question"],
            "old_sql": unsupported["old_sql"],
            "builder_exclusion": unsupported["new_error"],
            "decision_action": unsupported_decision.action,
            "decision_reason": unsupported_decision.reason,
        },
    ]
    report = {
        "protocol": "research/ablation_portability_preregistration.md",
        "selection_rule": (
            "lexicographically first frozen record after each preregistered predicate"
        ),
        "candidate_counts": {
            "execution_guided_executable_but_semantically_wrong": len(
                maintenance_candidates
            ),
            "ambiguous_mapping_withheld": len(ambiguity_candidates),
            "downstream_failure_after_correct_memory": len(downstream_candidates),
            "unsupported_nested_scope_rejected": len(unsupported_candidates),
        },
        "examples": examples,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({**report, "examples": [e["category"] for e in examples]}, indent=2))


if __name__ == "__main__":
    main()
