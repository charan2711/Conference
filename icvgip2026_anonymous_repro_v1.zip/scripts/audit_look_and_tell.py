"""Audit the 2025 Look and Tell annotations downloaded from Hugging Face."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("data/raw/look_and_tell"))
    parser.add_argument(
        "--summary",
        type=Path,
        default=Path("artifacts/audits/look_and_tell_summary.json"),
    )
    return parser.parse_args()


def truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in {"true", "1", "yes"}


def main() -> None:
    args = parse_args()
    upstream = args.root / "data"
    metadata_path = upstream / "manifests" / "metadata.csv"
    with metadata_path.open(encoding="utf-8", newline="") as handle:
        metadata = list(csv.DictReader(handle))

    reference_files = sorted(upstream.glob("par_*/annotations/v1/rec_*/references.csv"))
    mention_types: Counter[str] = Counter()
    references: Counter[str] = Counter()
    ingredients: Counter[str] = Counter()
    total_reference_rows = 0
    pronoun_rows = 0
    distractor_rows = 0
    temporally_linked_rows = 0

    for path in reference_files:
        with path.open(encoding="utf-8", newline="") as handle:
            for row in csv.DictReader(handle):
                total_reference_rows += 1
                mention_types[row.get("mention_type") or "unknown"] += 1
                references[(row.get("reference") or "").strip()] += 1
                ingredients[(row.get("ingredient_id") or "").strip()] += 1
                pronoun_rows += int("pronoun" in (row.get("mention_type") or "").lower())
                distractor_rows += int(truthy(row.get("is_distractor")))
                temporally_linked_rows += int(truthy(row.get("linked_temporally")))

    participant_ids = sorted({row["participant_id"] for row in metadata})
    recording_uids = sorted({row["recording_uid"] for row in metadata})
    reference_recording_uids = {
        f"{path.parts[-5]}_{path.parts[-2]}" for path in reference_files
    }
    metadata_reference_total = sum(int(float(row.get("n_references") or 0)) for row in metadata)
    durations = [float(row["duration_sec"]) for row in metadata if row.get("duration_sec")]
    summary = {
        "source": "annadeichler/KTH-ARIA-referential",
        "release_context": "NeurIPS 2025 SpaVLE Workshop",
        "license": "CC BY-NC-ND 4.0",
        "metadata_rows": len(metadata),
        "participants": len(participant_ids),
        "participant_ids": participant_ids,
        "recordings": len(recording_uids),
        "recordings_with_downloaded_reference_file": len(reference_recording_uids),
        "reference_files": len(reference_files),
        "reference_rows_downloaded": total_reference_rows,
        "reference_rows_claimed_by_metadata": metadata_reference_total,
        "duration_hours": sum(durations) / 3600,
        "mention_types": dict(mention_types.most_common()),
        "pronoun_or_coreference_rows": pronoun_rows,
        "distractor_rows": distractor_rows,
        "temporally_linked_rows": temporally_linked_rows,
        "unique_reference_labels": len([key for key in references if key]),
        "unique_ingredient_ids": len([key for key in ingredients if key]),
        "most_common_reference_labels": references.most_common(20),
        "missing_reference_recordings": sorted(set(recording_uids) - reference_recording_uids),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
