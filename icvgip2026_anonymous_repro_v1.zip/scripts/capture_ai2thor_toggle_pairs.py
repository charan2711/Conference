"""Capture egocentric before/after toggle pairs from AI2-THOR.

This script is intended for Linux with AI2-THOR CloudRendering (for example,
Kaggle or Colab). It avoids ALFRED's obsolete training dependencies and emits
an auditable JSONL manifest plus RGB frames.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from ai2thor.controller import Controller
from PIL import Image


DEFAULT_TARGETS = {"DeskLamp", "FloorLamp", "Television", "Laptop", "LightSwitch"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenes", nargs="+", default=["FloorPlan201", "FloorPlan301"])
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts/captures/ai2thor_toggle"))
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--cloud-rendering", action="store_true")
    parser.add_argument("--local-executable-path", type=Path)
    parser.add_argument("--max-targets-per-scene", type=int, default=8)
    return parser.parse_args()


def squared_distance(a: dict, b: dict) -> float:
    return (a["x"] - b["x"]) ** 2 + (a["z"] - b["z"]) ** 2


def yaw_toward(camera: dict, target: dict) -> float:
    return math.degrees(math.atan2(target["x"] - camera["x"], target["z"] - camera["z"])) % 360


def find_object(event, object_id: str) -> dict:
    return next(obj for obj in event.metadata["objects"] if obj["objectId"] == object_id)


def bbox_for(event, object_id: str) -> list[int] | None:
    box = event.instance_detections2D.get(object_id)
    return [int(value) for value in box] if box is not None else None


def save_frame(event, path: Path) -> None:
    Image.fromarray(event.frame).save(path)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frames_dir = args.output_dir / "frames"
    frames_dir.mkdir(parents=True, exist_ok=True)

    controller_kwargs = {
        "width": args.width,
        "height": args.height,
        "renderInstanceSegmentation": True,
        "renderDepthImage": False,
        "visibilityDistance": 1.5,
    }
    if args.cloud_rendering:
        from ai2thor.platform import CloudRendering

        controller_kwargs["platform"] = CloudRendering
    if args.local_executable_path:
        controller_kwargs["local_executable_path"] = str(args.local_executable_path)

    controller = Controller(**controller_kwargs)
    records: list[dict] = []
    try:
        for scene in args.scenes:
            event = controller.reset(scene)
            targets = [
                obj
                for obj in event.metadata["objects"]
                if obj.get("toggleable") and obj.get("objectType") in DEFAULT_TARGETS
            ][: args.max_targets_per_scene]

            reachable_event = controller.step(action="GetReachablePositions")
            reachable = reachable_event.metadata["actionReturn"] or []
            for target_index, target in enumerate(targets):
                target_id = target["objectId"]
                target_position = target["position"]
                camera_position = min(reachable, key=lambda point: squared_distance(point, target_position))
                rotation = yaw_toward(camera_position, target_position)
                controller.step(
                    action="TeleportFull",
                    x=camera_position["x"],
                    y=camera_position["y"],
                    z=camera_position["z"],
                    rotation={"x": 0, "y": rotation, "z": 0},
                    horizon=0,
                    standing=True,
                    forceAction=True,
                )

                controller.step(action="ToggleObjectOff", objectId=target_id, forceAction=True)
                before = controller.last_event
                before_target = find_object(before, target_id)
                before_box = bbox_for(before, target_id)
                stem = f"{scene}_{target_index:02d}_{before_target['objectType']}"
                before_path = frames_dir / f"{stem}_before.png"
                save_frame(before, before_path)

                after = controller.step(action="ToggleObjectOn", objectId=target_id, forceAction=True)
                after_target = find_object(after, target_id)
                after_box = bbox_for(after, target_id)
                after_path = frames_dir / f"{stem}_after.png"
                save_frame(after, after_path)

                gaze_box = before_box or after_box
                gaze = None
                if gaze_box:
                    x1, y1, x2, y2 = gaze_box
                    gaze = {
                        "x": ((x1 + x2) / 2) / args.width,
                        "y": ((y1 + y2) / 2) / args.height,
                        "source": "target_bbox_center",
                    }

                records.append(
                    {
                        "scene": scene,
                        "target_object_id": target_id,
                        "target_object_type": before_target["objectType"],
                        "requested_action": "ToggleObjectOn",
                        "before_state": bool(before_target.get("isToggled")),
                        "after_state": bool(after_target.get("isToggled")),
                        "action_success": bool(after.metadata["lastActionSuccess"]),
                        "error_message": after.metadata["errorMessage"],
                        "before_bbox_xyxy": before_box,
                        "after_bbox_xyxy": after_box,
                        "gaze_normalized_xy": gaze,
                        "before_image": before_path.relative_to(args.output_dir).as_posix(),
                        "after_image": after_path.relative_to(args.output_dir).as_posix(),
                        "camera_position": camera_position,
                        "camera_yaw": rotation,
                    }
                )
    finally:
        controller.stop()

    manifest_path = args.output_dir / "manifest.jsonl"
    with manifest_path.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True) + "\n")
    summary = {
        "scenes_requested": args.scenes,
        "pairs_captured": len(records),
        "successful_transitions": sum(
            record["action_success"] and record["before_state"] is False and record["after_state"] is True
            for record in records
        ),
        "visible_before": sum(record["before_bbox_xyxy"] is not None for record in records),
        "target_types": sorted({record["target_object_type"] for record in records}),
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
