"""Post-hoc semantic audit of failure-triggered memory maintenance outputs."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from scipy.stats import binomtest

from .build_benchmark import execute, result_equivalent


def interval(successes: int, n: int) -> list[float | None]:
    if not n:
        return [None, None]
    estimate = binomtest(successes, n).proportion_ci(method="wilson")
    return [float(estimate.low), float(estimate.high)]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument(
        "--benchmark", type=Path, default=Path("data/schemamem-bench-v1")
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    instances = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    index = {
        (row["scenario"], row["db_id"], row["question_id"]): row
        for row in instances if row["execution_equivalent"]
    }
    audited = []
    for line in args.runs.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if row["condition"] != "execution_guided_memory":
            continue
        memory = index[(row["scenario"], row["db_id"], row["memory_question_id"])]
        path = (
            args.benchmark / "databases" / row["scenario"] / row["db_id"]
            / f"{row['db_id']}.sqlite"
        )
        gold_ok, gold = execute(path, memory["new_sql"], timeout_seconds=10)
        pred_ok, prediction = execute(
            path, row.get("maintenance_prediction") or "", timeout_seconds=10
        )
        correct = bool(
            gold_ok and pred_ok
            and result_equivalent(prediction, gold, memory["new_sql"])
        )
        audited.append({
            "scenario": row["scenario"],
            "db_id": row["db_id"],
            "target_question_id": row["question_id"],
            "memory_question_id": row["memory_question_id"],
            "memory_affected": row["memory_affected"],
            "maintenance_action": row.get("maintenance_action"),
            "maintenance_exec_ok": pred_ok,
            "maintenance_correct": correct,
            "maintenance_silent_wrong": bool(pred_ok and not correct),
            "maintenance_model_calls": row.get("maintenance_model_calls", 0),
            "maintenance_total_tokens": (
                row.get("maintenance_prompt_tokens", 0)
                + row.get("maintenance_completion_tokens", 0)
            ),
        })

    def summarize(rows: list[dict]) -> dict:
        n = len(rows)
        executable = sum(row["maintenance_exec_ok"] for row in rows)
        correct = sum(row["maintenance_correct"] for row in rows)
        return {
            "n": n,
            "executable": executable,
            "executable_rate": executable / n if n else None,
            "executable_wilson_95": interval(executable, n),
            "correct": correct,
            "correct_rate": correct / n if n else None,
            "correct_wilson_95": interval(correct, n),
            "silent_wrong": sum(row["maintenance_silent_wrong"] for row in rows),
            "actions": dict(Counter(row["maintenance_action"] for row in rows)),
            "mean_model_calls": (
                sum(row["maintenance_model_calls"] for row in rows) / n if n else None
            ),
            "mean_total_tokens": (
                sum(row["maintenance_total_tokens"] for row in rows) / n if n else None
            ),
        }

    report = {
        "all": summarize(audited),
        "memory_affected": summarize([row for row in audited if row["memory_affected"]]),
        "memory_unaffected": summarize([row for row in audited if not row["memory_affected"]]),
        "audit_note": (
            "gold results are used only after the frozen run to score maintenance; "
            "they never select which executable repair enters downstream memory"
        ),
        "instances": audited,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "instances"}, indent=2))


if __name__ == "__main__":
    main()
