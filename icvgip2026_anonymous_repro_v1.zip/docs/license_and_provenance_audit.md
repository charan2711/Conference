# License and provenance audit

Verified 2026-07-13 against upstream project pages. This is a conservative
engineering release policy, not legal advice. Human authors should review it
before public release.

| Resource | Upstream license evidence | Reproducibility identifier | Supplement decision |
|---|---|---|---|
| Look and Tell / KTH-ARIA Referential | [Official dataset card](https://huggingface.co/datasets/annadeichler/KTH-ARIA-referential): CC BY-NC-ND 4.0 | Repository name plus locally recorded per-file provenance | Exclude annotations, video, audio, gaze files, and extracted/transformed frames. Include participant split IDs and aggregate metrics only. |
| ALFRED | [Official repository license](https://github.com/askforalfred/alfred/blob/master/LICENSE): MIT | Official repository and audited action counts | Exclude downloaded trajectories; include experiment code and aggregate metrics. |
| HD-EPIC | [Official dataset page](https://hd-epic.github.io/site/): CC BY-NC 4.0 | Official annotation repository and January 2026 release note | Exclude annotations/media; include aggregate feasibility counts only. |
| OpenAI CLIP ViT-B/32 | [Official repository](https://github.com/openai/CLIP): MIT | Hugging Face model `openai/clip-vit-base-patch32`, revision `3d74acf9a28c67741b2f4f2ea7635f0aaf6f0268` | Exclude weights and cached embeddings; include identifier, revision, code, and metrics. |
| Google SigLIP 2 base patch16-224 | [Official model card](https://huggingface.co/google/siglip2-base-patch16-224): Apache-2.0 | Revision `02c35f2c035e0ed4a367fb10a892c1fe2a3f364e` | Exclude weights and cached embeddings; include identifier, revision, code, and metrics. |
| Alibaba GTE-ModernBERT-base | [Official model card](https://huggingface.co/Alibaba-NLP/gte-modernbert-base): Apache-2.0 | Revision `e7f32e3c00f91d699e8c43b53106206bcc72bb22` | Exclude weights and cached embeddings; include identifier, revision, code, and metrics. |
| Hugging Face SmolVLM-256M-Instruct | [Official model card](https://huggingface.co/HuggingFaceTB/SmolVLM-256M-Instruct): Apache-2.0 | Revision `7e3e67edbbed1bf9888184d9df282b700a323964`; six fold-artifact SHA-256 digests | Exclude weights and row-level fold artifacts; include code, hashes, identifier, revision, and aggregate metrics. |
| ONNX Model Zoo ResNet-50 v2 opset 7 | [Official model directory](https://github.com/onnx/models/tree/main/validated/vision/classification/resnet): Apache-2.0 | SHA-256 `79102261eb6e5fd7af5d27f41316293e388c5cb691e5d25bfb035c4f64fefe31` | Exclude checkpoint and feature cache; include checksum, code, and metrics. |

Look and Tell is the strictest boundary. Its dataset card allows sharing the
original material for noncommercial use but prohibits distribution of modified
material. Accordingly, derived frames and caches remain local. The split file
contains only participant/recording identifiers and does not reproduce the
annotations, speech, gaze streams, or visual content.

The release gate executes `scripts/audit_release_redistribution.py`. It scans
the exact supplement selection, rejects media, model-weight, cache, tabular
source-annotation, credential, and restricted-path payloads, and cross-checks
the frozen model revisions and ResNet checksum against experiment artifacts.
Its machine-readable result is
`artifacts/audits/release_redistribution.json`.

No license is asserted here for the authors' newly written project code. The
human authors should choose a project license (or retain copyright) before any
public repository release; that decision does not affect anonymous review.
