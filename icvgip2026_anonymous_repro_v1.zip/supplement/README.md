# Anonymous reproducibility supplement

This bundle accompanies the anonymous manuscript *Does Gaze Help? Selective
Reference Resolution for Wearable Assistants*. It contains code, frozen split
manifests, and numerical artifacts. It intentionally excludes raw Look and Tell
media, transformed frames, ALFRED source data, model weights, credentials, and
Kaggle account metadata.

As of the 2026-07-13 OpenReview form audit, ICVGIP exposes no supplementary-file
field. Preserve this bundle for an anonymous repository, rebuttal, or a later
form revision; do not assume that the current portal accepts it.

## Environment

- Python 3.12.6
- Packages pinned in `requirements-research.txt`
- CPU execution is sufficient for the classical, cross-validation, calibration,
  and ALFRED experiments. The frozen CLIP feature extraction is slower on CPU.

The PyTorch CPU wheels should be installed from the official CPU index before
installing the remaining requirements.

## Artifact map

- `artifacts/audits/`: dataset counts and availability audits.
- `artifacts/baselines/`: frozen metrics, confidence intervals, calibration,
  risk--coverage points, subgroup results, and error transitions.
- `data/manifests/look_and_tell_splits.json`: participant-disjoint split.
- `scripts/verify_paper_claims.py`: checks key manuscript numbers against JSON.
- `scripts/verify_submission_metadata.py`: checks the frozen venue deadline and
  form schema plus the copy-ready title, TL;DR length, and abstract claims.
- `scripts/audit_leakage_integrity.py`: verifies split isolation, causal
  history, chronological rows, cache signatures, train-only preprocessing
  markers, and complete out-of-fold coverage.
- `scripts/audit_raw_derived_alignment.py`: with the licensed source data
  present, verifies every derived row, target, mention link, midpoint frame, and
  fixation coordinate against the released CSV annotations.
- `scripts/audit_release_redistribution.py`: scans the exact bundle selection,
  rejects restricted media/annotations/weights/caches/credentials, and checks
  frozen upstream model identifiers.
- `docs/license_and_provenance_audit.md`: upstream license evidence and the
  conservative redistribution decision for every external resource.
- `scripts/generate_paper_assets.py`: deterministically emits the plotted
  risk--coverage coordinates from JSON and detects stale figure data.
- `scripts/crossval_look_and_tell_gaze_location.py`: six-fold participant audit
  with an availability-preserving, within-recording shuffled-fixation control
  constructed without target labels.
- `scripts/crossval_look_and_tell_fixation_metadata_ablation.py`: matched
  six-fold audit that removes the four explicit fixation/availability metadata
  dimensions while retaining the same gaze, center, full-frame, and shuffled
  image crops (`artifacts/baselines/look_and_tell_fixation_metadata_ablation.json`).
- `scripts/nested_threshold_look_and_tell.py`: nested five-inner-fold threshold
  transfer inside six outer participant folds; thresholds never use outer-fold
  labels (`artifacts/baselines/look_and_tell_full_frame_nested_threshold.json`).
- `scripts/summarize_shuffle_sensitivity.py`: aggregates all five predeclared
  cyclic offsets without selecting a favorable shuffled-fixation realization.
- `scripts/baseline_look_and_tell_modernbert.py`: pinned 2025 frozen-language
  audit under the same six participant folds.
- `paper/main.tex`: anonymous manuscript source.

`MANIFEST.json` records the SHA-256 and byte size of every included file. The
archive builder fixes ZIP timestamps and file ordering, so rebuilding from an
unchanged workspace produces identical bytes.

## Verification without restricted media

From the repository root:

```powershell
.\.venv\Scripts\python.exe scripts\verify_paper_claims.py
.\.venv\Scripts\python.exe scripts\verify_submission_metadata.py
.\.venv\Scripts\python.exe scripts\verify_submission_pdf.py output/pdf/icvgip2026_draft_v33.pdf
$files = Get-ChildItem scripts -Filter *.py | ForEach-Object FullName
.\.venv\Scripts\python.exe -m py_compile @files
```

These checks validate claim/artifact consistency and Python syntax. They do not
recompute image features because Look and Tell media cannot be redistributed.
From the full workspace, `scripts/run_submission_checks.py` runs these gates and
also verifies deterministic ZIP contents in one command.

## Full recomputation

After downloading Look and Tell under its upstream terms, run the annotation
audit and media-preparation scripts, then:

```powershell
.\.venv\Scripts\python.exe scripts\baseline_look_and_tell_classical_vision.py --evaluate val test
.\.venv\Scripts\python.exe scripts\audit_raw_derived_alignment.py
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_gaze_location.py
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_fixation_metadata_ablation.py
.\.venv\Scripts\python.exe scripts\nested_threshold_look_and_tell.py
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_gaze_location.py --shuffle-fraction 0.20 --shuffled-feature-cache data\derived\look_and_tell_shuffled_fixation_cache_f020.npz --output tmp\shuffle_sensitivity\f020.json
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_gaze_location.py --shuffle-fraction 0.35 --shuffled-feature-cache data\derived\look_and_tell_shuffled_fixation_cache_f035.npz --output tmp\shuffle_sensitivity\f035.json
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_gaze_location.py --shuffle-fraction 0.65 --shuffled-feature-cache data\derived\look_and_tell_shuffled_fixation_cache_f065.npz --output tmp\shuffle_sensitivity\f065.json
.\.venv\Scripts\python.exe scripts\crossval_look_and_tell_gaze_location.py --shuffle-fraction 0.80 --shuffled-feature-cache data\derived\look_and_tell_shuffled_fixation_cache_f080.npz --output tmp\shuffle_sensitivity\f080.json
.\.venv\Scripts\python.exe scripts\summarize_shuffle_sensitivity.py
.\.venv\Scripts\python.exe scripts\baseline_look_and_tell_modernbert.py
.\.venv\Scripts\python.exe scripts\baseline_look_and_tell_clip.py
.\.venv\Scripts\python.exe scripts\baseline_look_and_tell_siglip2.py
```

For ALFRED, obtain the official trajectory data and run:

```powershell
.\.venv\Scripts\python.exe scripts\audit_alfred_state_actions.py
.\.venv\Scripts\python.exe scripts\baseline_alfred_toggle_text.py
```

Three Look and Tell recordings were unavailable upstream during the study:
`par_11_rec_02`, `par_11_rec_04`, and `par_14_rec_01`. Their absence is encoded
in the numerical artifacts and must not be silently replaced.

## Scope

The primary task is closed-set canonical reference prediction, not object-box
localization or device actuation. The ALFRED result is a two-class lamp-target
transfer test. The failed AI2-THOR rendering attempt is documented in the paper
but is not presented as an experimental result.
