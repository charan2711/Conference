"""Post-hoc six-fold SigLIP 2 crop-representation audit for Look and Tell."""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from collections import Counter
from pathlib import Path

import cv2
import numpy as np
import torch
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import OneHotEncoder, StandardScaler, normalize
from transformers import AutoModel, AutoProcessor

from baseline_look_and_tell_classical_vision import (
    SEED,
    add_history,
    gaze_crop,
    load_recording,
    new_model,
    paired_participant_difference,
    participant_ci,
)


MODEL_NAME = "google/siglip2-base-patch16-224"
MODEL_REVISION = "02c35f2c035e0ed4a367fb10a892c1fe2a3f364e"
MODEL_PARAMETER_COUNT = 375_187_970


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--derived-root", type=Path, default=Path("data/derived/look_and_tell")
    )
    parser.add_argument(
        "--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json")
    )
    parser.add_argument("--cache-dir", type=Path, default=Path("third_party/hf"))
    parser.add_argument(
        "--embedding-cache",
        type=Path,
        default=Path("data/derived/look_and_tell_siglip2_embeddings.npz"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/baselines/look_and_tell_siglip2.json"),
    )
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--allow-download", action="store_true")
    parser.add_argument(
        "--smoke-limit",
        type=int,
        default=0,
        help="Embed this many rows per location and exit without saving.",
    )
    return parser.parse_args()


def load_rows(root: Path, spec: dict) -> tuple[list[dict], dict[str, int], list[str]]:
    rows: list[dict] = []
    lengths: dict[str, int] = {}
    missing: list[str] = []
    for split in ("train", "val", "test"):
        before = len(rows)
        for recording in spec["splits"][split]["recordings"]:
            try:
                rows.extend(load_recording(root, recording))
            except FileNotFoundError:
                missing.append(recording)
        lengths[split] = len(rows) - before
    return rows, lengths, missing


def row_signature(rows: list[dict]) -> str:
    payload = "\n".join(
        f"{row['recording_uid']}|{row.get('frame_path')}|{row.get('reference')}"
        for row in rows
    ).encode()
    return hashlib.sha256(payload).hexdigest()


def crop_rgb(row: dict, centered: bool) -> np.ndarray:
    frame = cv2.imread(row["frame_path"], cv2.IMREAD_COLOR)
    if frame is None:
        raise FileNotFoundError(row["frame_path"])
    crop = gaze_crop(
        frame,
        None if centered else row.get("fix_x"),
        None if centered else row.get("fix_y"),
    )
    return cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)


def embed_rows(
    rows: list[dict],
    centered: bool,
    model: torch.nn.Module,
    processor: object,
    batch_size: int,
) -> np.ndarray:
    batches: list[np.ndarray] = []
    started = time.perf_counter()
    with torch.inference_mode():
        for start in range(0, len(rows), batch_size):
            images = [crop_rgb(row, centered) for row in rows[start : start + batch_size]]
            inputs = processor(images=images, return_tensors="pt")
            features = model.get_image_features(**inputs)
            if not isinstance(features, torch.Tensor):
                features = features.pooler_output
            features = torch.nn.functional.normalize(features, dim=1)
            batches.append(features.cpu().numpy().astype(np.float32))
            if start == 0 or (start // batch_size + 1) % 20 == 0:
                elapsed = time.perf_counter() - started
                done = min(start + batch_size, len(rows))
                location = "center" if centered else "gaze"
                print(f"{location}: embedded {done}/{len(rows)} in {elapsed:.1f}s", flush=True)
    return np.vstack(batches)


def evaluate(rows: list[dict], center: np.ndarray, gaze: np.ndarray) -> dict:
    participants = sorted({row["participant_id"] for row in rows})
    rng = np.random.default_rng(SEED)
    shuffled = np.asarray(participants)[rng.permutation(len(participants))]
    folds = [sorted(part.tolist()) for part in np.array_split(shuffled, 6)]
    model_names = ("text_history", "text_center_history", "text_gaze_history")
    oof = {name: np.empty(len(rows), dtype=object) for name in model_names}
    fold_results = []

    for fold_index, held_out in enumerate(folds):
        test_mask = np.asarray([row["participant_id"] in held_out for row in rows])
        train_indices = np.flatnonzero(~test_mask)
        test_indices = np.flatnonzero(test_mask)
        train_rows = [dict(rows[index]) for index in train_indices]
        test_rows = [dict(rows[index]) for index in test_indices]

        frequencies = Counter(row["reference"] for row in train_rows)
        labels = sorted(frequencies)
        add_history(train_rows, labels, frequencies)
        add_history(test_rows, labels, frequencies)

        text = TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(2, 5),
            min_df=2,
            max_features=20000,
            sublinear_tf=True,
        )
        text_train = text.fit_transform(row.get("surface_text") or "" for row in train_rows)
        text_test = text.transform(row.get("surface_text") or "" for row in test_rows)
        history = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
        history_train = history.fit_transform(
            np.asarray([[row["history_prediction"]] for row in train_rows])
        )
        history_test = history.transform(
            np.asarray([[row["history_prediction"]] for row in test_rows])
        )

        visual = {}
        for name, raw in (("center", center), ("gaze", gaze)):
            scaler = StandardScaler()
            train_features = normalize(
                csr_matrix(scaler.fit_transform(raw[train_indices])), norm="l2"
            )
            test_features = normalize(
                csr_matrix(scaler.transform(raw[test_indices])), norm="l2"
            )
            visual[name] = (train_features, test_features)
        matrices = {
            "text_history": (
                hstack([text_train, history_train], format="csr"),
                hstack([text_test, history_test], format="csr"),
            ),
            "text_center_history": (
                hstack([text_train, visual["center"][0], history_train], format="csr"),
                hstack([text_test, visual["center"][1], history_test], format="csr"),
            ),
            "text_gaze_history": (
                hstack([text_train, visual["gaze"][0], history_train], format="csr"),
                hstack([text_test, visual["gaze"][1], history_test], format="csr"),
            ),
        }
        target_train = np.asarray([row["reference"] for row in train_rows])
        target_test = np.asarray([row["reference"] for row in test_rows])
        metrics = {}
        for name, (matrix_train, matrix_test) in matrices.items():
            classifier = new_model()
            classifier.fit(matrix_train, target_train)
            prediction = classifier.predict(matrix_test)
            oof[name][test_indices] = prediction
            metrics[name] = {
                "accuracy": float(accuracy_score(target_test, prediction)),
                "macro_f1": float(
                    f1_score(target_test, prediction, average="macro", zero_division=0)
                ),
            }
        fold_results.append(
            {
                "fold": fold_index,
                "held_out_participants": held_out,
                "n": len(test_indices),
                "metrics": metrics,
            }
        )

    targets = np.asarray([row["reference"] for row in rows])
    coref = np.asarray([(row.get("mention_type") or "") == "pronoun/coref" for row in rows])
    aggregate = {}
    for name in model_names:
        aggregate[name] = {
            "accuracy": float(accuracy_score(targets, oof[name])),
            "accuracy_participant_bootstrap_95ci": participant_ci(rows, targets, oof[name]),
            "macro_f1": float(
                f1_score(targets, oof[name], average="macro", zero_division=0)
            ),
            "coref_accuracy": float(accuracy_score(targets[coref], oof[name][coref])),
        }
    comparisons = {
        "center_minus_text_history": paired_participant_difference(
            rows, targets, oof["text_center_history"], oof["text_history"]
        ),
        "gaze_minus_text_history": paired_participant_difference(
            rows, targets, oof["text_gaze_history"], oof["text_history"]
        ),
        "gaze_minus_center": paired_participant_difference(
            rows, targets, oof["text_gaze_history"], oof["text_center_history"]
        ),
    }

    distances = np.asarray(
        [
            np.hypot(
                (704.0 if row.get("fix_x") is None else float(row["fix_x"])) / 1408.0
                - 0.5,
                (704.0 if row.get("fix_y") is None else float(row["fix_y"])) / 1408.0
                - 0.5,
            )
            for row in rows
        ]
    )
    edges = np.quantile(distances, (0.0, 0.25, 0.5, 0.75, 1.0))
    distance_quartiles = []
    for quartile in range(4):
        lower, upper = edges[quartile], edges[quartile + 1]
        mask = (distances >= lower) & (
            distances <= upper if quartile == 3 else distances < upper
        )
        subset_rows = [row for row, selected in zip(rows, mask) if selected]
        subset_targets = targets[mask]
        center_predictions = oof["text_center_history"][mask]
        gaze_predictions = oof["text_gaze_history"][mask]
        distance_quartiles.append(
            {
                "quartile": quartile + 1,
                "distance_range_normalized": [float(lower), float(upper)],
                "n": int(mask.sum()),
                "center_accuracy": float(
                    accuracy_score(subset_targets, center_predictions)
                ),
                "gaze_accuracy": float(accuracy_score(subset_targets, gaze_predictions)),
                "gaze_minus_center": paired_participant_difference(
                    subset_rows, subset_targets, gaze_predictions, center_predictions
                ),
            }
        )

    mention_subgroups = {}
    for mention_type in sorted({row.get("mention_type") or "unknown" for row in rows}):
        mask = np.asarray(
            [(row.get("mention_type") or "unknown") == mention_type for row in rows]
        )
        subset_rows = [row for row, selected in zip(rows, mask) if selected]
        subset_targets = targets[mask]
        text_predictions = oof["text_history"][mask]
        center_predictions = oof["text_center_history"][mask]
        gaze_predictions = oof["text_gaze_history"][mask]
        mention_subgroups[mention_type] = {
            "n": int(mask.sum()),
            "text_history_accuracy": float(
                accuracy_score(subset_targets, text_predictions)
            ),
            "center_accuracy": float(accuracy_score(subset_targets, center_predictions)),
            "gaze_accuracy": float(accuracy_score(subset_targets, gaze_predictions)),
            "center_minus_text_history": paired_participant_difference(
                subset_rows, subset_targets, center_predictions, text_predictions
            ),
            "gaze_minus_text_history": paired_participant_difference(
                subset_rows, subset_targets, gaze_predictions, text_predictions
            ),
            "gaze_minus_center": paired_participant_difference(
                subset_rows, subset_targets, gaze_predictions, center_predictions
            ),
        }

    def transition_counts(candidate: np.ndarray, mask: np.ndarray) -> dict[str, int]:
        text_correct = oof["text_history"][mask] == targets[mask]
        candidate_correct = candidate[mask] == targets[mask]
        return {
            "n": int(mask.sum()),
            "both_correct": int(np.sum(text_correct & candidate_correct)),
            "both_wrong": int(np.sum(~text_correct & ~candidate_correct)),
            "visual_repairs_text_error": int(np.sum(~text_correct & candidate_correct)),
            "visual_breaks_text_success": int(np.sum(text_correct & ~candidate_correct)),
        }

    all_rows = np.ones(len(rows), dtype=bool)
    transitions = {
        "all": {
            "center": transition_counts(oof["text_center_history"], all_rows),
            "gaze": transition_counts(oof["text_gaze_history"], all_rows),
        },
        "mention_type": {},
    }
    for mention_type in mention_subgroups:
        mask = np.asarray(
            [(row.get("mention_type") or "unknown") == mention_type for row in rows]
        )
        transitions["mention_type"][mention_type] = {
            "center": transition_counts(oof["text_center_history"], mask),
            "gaze": transition_counts(oof["text_gaze_history"], mask),
        }

    center_predictions = oof["text_center_history"]
    gaze_predictions = oof["text_gaze_history"]
    disagreement = center_predictions != gaze_predictions
    crop_disagreement = {
        "n": int(disagreement.sum()),
        "rate": float(disagreement.mean()),
        "center_correct_gaze_wrong": int(
            np.sum(disagreement & (center_predictions == targets))
        ),
        "gaze_correct_center_wrong": int(
            np.sum(disagreement & (gaze_predictions == targets))
        ),
        "both_wrong_different_labels": int(
            np.sum(
                disagreement
                & (center_predictions != targets)
                & (gaze_predictions != targets)
            )
        ),
    }
    return {
        "folds": fold_results,
        "aggregate": aggregate,
        "comparisons": comparisons,
        "subgroups": {
            "fixation_distance_quartiles": distance_quartiles,
            "mention_type": mention_subgroups,
        },
        "error_analysis": {
            "text_to_visual_transitions": transitions,
            "center_gaze_disagreement": crop_disagreement,
        },
    }


def main() -> None:
    args = parse_args()
    torch.set_num_threads(max(1, min(8, torch.get_num_threads())))
    spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows, split_lengths, missing = load_rows(args.derived_root, spec)
    signature = row_signature(rows)

    cached = None
    if not args.smoke_limit and args.embedding_cache.exists():
        with np.load(args.embedding_cache, allow_pickle=False) as archive:
            if (
                str(archive["row_signature"].item()) == signature
                and archive["center"].shape[0] == len(rows)
                and archive["gaze"].shape[0] == len(rows)
            ):
                cached = (archive["center"].copy(), archive["gaze"].copy())

    if cached is None:
        local_only = not args.allow_download
        processor = AutoProcessor.from_pretrained(
            MODEL_NAME,
            revision=MODEL_REVISION,
            cache_dir=args.cache_dir,
            local_files_only=local_only,
        )
        model = AutoModel.from_pretrained(
            MODEL_NAME,
            revision=MODEL_REVISION,
            cache_dir=args.cache_dir,
            local_files_only=local_only,
        ).eval()
        parameter_count = sum(parameter.numel() for parameter in model.parameters())
        if parameter_count != MODEL_PARAMETER_COUNT:
            raise RuntimeError(
                f"Pinned model parameter drift: {parameter_count} != "
                f"{MODEL_PARAMETER_COUNT}"
            )
        if args.smoke_limit:
            sample = rows[: args.smoke_limit]
            for centered in (False, True):
                matrix = embed_rows(sample, centered, model, processor, args.batch_size)
                print(f"smoke {'center' if centered else 'gaze'} shape={matrix.shape}")
            return
        gaze = embed_rows(rows, False, model, processor, args.batch_size)
        center = embed_rows(rows, True, model, processor, args.batch_size)
        args.embedding_cache.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            args.embedding_cache,
            row_signature=np.asarray(signature),
            center=center,
            gaze=gaze,
        )
        del model
    else:
        center, gaze = cached
        parameter_count = MODEL_PARAMETER_COUNT

    results = evaluate(rows, center, gaze)
    output = {
        "protocol": "post-hoc fixed six-fold participant-disjoint out-of-fold audit",
        "seed": SEED,
        "model": MODEL_NAME,
        "model_revision": MODEL_REVISION,
        "parameter_count": parameter_count,
        "n_rows": len(rows),
        "split_lengths": split_lengths,
        "missing_media_recordings": missing,
        **results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
