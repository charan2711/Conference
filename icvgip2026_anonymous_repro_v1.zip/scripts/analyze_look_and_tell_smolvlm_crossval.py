"""Audit and aggregate six participant-disjoint SmolVLM fold artifacts."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, f1_score

from analyze_look_and_tell_smolvlm_pilot import (
    load_rows,
    paired_summary,
    text_history_baseline,
)
from baseline_look_and_tell_classical_vision import SEED


CONDITIONS = ("full", "center", "gaze", "shuffled")
ROOT = Path(__file__).resolve().parents[1]


def portable_path(path: Path) -> str:
    """Keep release artifacts machine-independent when inputs are inside the repo."""
    resolved = path.resolve()
    try:
        return resolved.relative_to(ROOT).as_posix()
    except ValueError:
        return path.as_posix()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("folds", nargs="+", type=Path)
    parser.add_argument(
        "--derived-root", type=Path, default=Path("data/derived/look_and_tell")
    )
    parser.add_argument(
        "--splits", type=Path, default=Path("data/manifests/look_and_tell_splits.json")
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/audits/look_and_tell_smolvlm_crossval.json"),
    )
    parser.add_argument("--bootstrap-draws", type=int, default=5000)
    parser.add_argument("--min-train-per-fold", type=int, default=96)
    parser.add_argument("--min-eval-per-fold", type=int, default=96)
    return parser.parse_args()


def metrics(predictions: list[dict]) -> dict:
    targets = np.asarray([row["target"] for row in predictions])
    predicted = np.asarray([row["prediction"] for row in predictions])
    correct = (targets == predicted).astype(float)
    coreference = np.asarray(
        [row.get("mention_type") == "pronoun/coref" for row in predictions], dtype=bool
    )
    confidences = np.asarray([row["confidence"] for row in predictions], dtype=float)
    if np.any(~np.isfinite(confidences)) or np.any((confidences < 0) | (confidences > 1)):
        raise RuntimeError("Invalid confidence values")
    ece = 0.0
    for lower, upper in zip(np.linspace(0, 1, 11)[:-1], np.linspace(0, 1, 11)[1:]):
        mask = (confidences >= lower) & (
            (confidences <= upper) if upper == 1.0 else (confidences < upper)
        )
        if mask.any():
            ece += float(mask.mean() * abs(confidences[mask].mean() - correct[mask].mean()))
    order = np.argsort(-confidences, kind="stable")
    cumulative_risk = 1.0 - np.cumsum(correct[order]) / np.arange(1, len(correct) + 1)
    aurc = float(np.mean(cumulative_risk))
    return {
        "n": len(predictions),
        "accuracy": float(accuracy_score(targets, predicted)),
        "macro_f1": float(f1_score(targets, predicted, average="macro", zero_division=0)),
        "coreference_n": int(coreference.sum()),
        "coreference_accuracy": (
            float(accuracy_score(targets[coreference], predicted[coreference]))
            if coreference.any()
            else None
        ),
        "ece_10_bin": ece,
        "aurc": aurc,
    }


def accuracy_cluster_ci(predictions: list[dict], draws: int) -> list[float]:
    participants = sorted({row["participant_id"] for row in predictions})
    grouped = {
        participant: [row for row in predictions if row["participant_id"] == participant]
        for participant in participants
    }
    rng = np.random.default_rng(SEED)
    values = np.empty(draws, dtype=float)
    for draw in range(draws):
        sampled = rng.choice(participants, size=len(participants), replace=True)
        rows = [row for participant in sampled for row in grouped[participant]]
        values[draw] = np.mean([row["prediction"] == row["target"] for row in rows])
    return [float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))]


def main() -> None:
    args = parse_args()
    if args.bootstrap_draws < 1000:
        raise ValueError("--bootstrap-draws must be at least 1000")
    fold_bytes = [path.read_bytes() for path in args.folds]
    folds = [json.loads(payload) for payload in fold_bytes]
    by_index = {fold["protocol"]["fold_index"]: fold for fold in folds}
    if len(by_index) != len(folds) or set(by_index) != set(range(6)):
        raise RuntimeError("Exactly one artifact for each fold index 0..5 is required")
    folds = [by_index[index] for index in range(6)]

    split_digest = hashlib.sha256(args.splits.read_bytes()).hexdigest()
    all_participants: set[str] = set()
    all_row_ids: set[int] = set()
    combined = {condition: [] for condition in CONDITIONS}
    per_fold: dict[str, dict] = {}
    reference_config = None
    for index, fold in enumerate(folds):
        protocol = fold["protocol"]
        model = fold["model"]
        if fold["status"] != "pilot_only_not_for_paper_claims":
            raise RuntimeError(f"Unexpected status in fold {index}")
        if protocol["split_manifest_sha256"] != split_digest:
            raise RuntimeError(f"Split-manifest mismatch in fold {index}")
        if model["adaptation_scope"] != "end_to_end_lora":
            raise RuntimeError(f"Fold {index} is not end-to-end LoRA")
        counts = model["parameter_counts"]
        if min(counts["vision_lora"], counts["text_lora"], counts["connector"]) <= 0:
            raise RuntimeError(f"Fold {index} does not train all three modality stacks")
        if set(protocol["conditions"]) != set(CONDITIONS):
            raise RuntimeError(f"Fold {index} lacks a matched condition")
        if protocol["sampled_train_rows"] < args.min_train_per_fold:
            raise RuntimeError(f"Fold {index} is below the training-size gate")
        if protocol["sampled_eval_rows"] < args.min_eval_per_fold:
            raise RuntimeError(f"Fold {index} is below the evaluation-size gate")
        held_out = set(protocol["held_out_participants"])
        outer_train = set(protocol["outer_train_participants"])
        if held_out & outer_train:
            raise RuntimeError(f"Participant leakage in fold {index}")
        if all_participants & held_out:
            raise RuntimeError(f"Participant appears in multiple test folds: {index}")
        all_participants |= held_out

        config = {
            "model_id": model["id"],
            "model_revision": model["revision"],
            "model_license": model["license"],
            "parameter_counts": counts,
            "lora": model["lora"],
            "train_rows": protocol["sampled_train_rows"],
            "eval_rows": protocol["sampled_eval_rows"],
            "epochs": protocol["epochs"],
            "learning_rate": protocol["learning_rate"],
            "image_size": protocol["image_size"],
        }
        if reference_config is None:
            reference_config = config
        elif config != reference_config:
            raise RuntimeError(f"Configuration mismatch in fold {index}")

        full_ids = {row["row_index"] for row in fold["predictions"]["full"]}
        if len(full_ids) != protocol["sampled_eval_rows"]:
            raise RuntimeError(f"Duplicate or missing evaluation rows in fold {index}")
        if all_row_ids & full_ids:
            raise RuntimeError(f"Evaluation row appears in multiple folds: {index}")
        all_row_ids |= full_ids
        for condition in CONDITIONS:
            predictions = fold["predictions"][condition]
            if {row["row_index"] for row in predictions} != full_ids:
                raise RuntimeError(f"Condition-row mismatch in fold {index}: {condition}")
            if any(row["participant_id"] not in held_out for row in predictions):
                raise RuntimeError(f"Held-out participant violation in fold {index}")
            combined[condition].extend(predictions)
        per_fold[str(index)] = {
            condition: metrics(fold["predictions"][condition])
            for condition in CONDITIONS
        }

    spec = json.loads(args.splits.read_text(encoding="utf-8"))
    rows = load_rows(args.derived_root, spec)
    text_predictions: list[dict] = []
    for fold in folds:
        held_out = set(fold["protocol"]["held_out_participants"])
        ids = {row["row_index"] for row in fold["predictions"]["full"]}
        _, predictions = text_history_baseline(rows, held_out, ids)
        for row in predictions:
            row["confidence"] = 0.0
        text_predictions.extend(predictions)

    aggregate = {}
    for condition in CONDITIONS:
        aggregate[condition] = metrics(combined[condition])
        aggregate[condition]["participant_cluster_95ci_accuracy"] = accuracy_cluster_ci(
            combined[condition], args.bootstrap_draws
        )
    aggregate["text_history"] = metrics(text_predictions)
    aggregate["text_history"].pop("ece_10_bin")
    aggregate["text_history"].pop("aurc")
    aggregate["text_history"]["participant_cluster_95ci_accuracy"] = accuracy_cluster_ci(
        text_predictions, args.bootstrap_draws
    )

    comparisons = {
        name: paired_summary(combined[first], combined[second], args.bootstrap_draws)
        for name, first, second in (
            ("full_minus_center", "full", "center"),
            ("full_minus_gaze", "full", "gaze"),
            ("full_minus_shuffled", "full", "shuffled"),
            ("gaze_minus_center", "gaze", "center"),
            ("gaze_minus_shuffled", "gaze", "shuffled"),
        )
    }
    comparisons["full_minus_text_history"] = paired_summary(
        combined["full"], text_predictions, args.bootstrap_draws
    )

    output = {
        "status": "pass_complete_six_fold_subsampled_end_to_end_vlm_audit",
        "scope_boundary": (
            "Measured six-fold participant-disjoint evidence on the deterministic "
            "balanced subsample only; do not describe it as full-dataset training or evaluation."
        ),
        "configuration": reference_config,
        "fold_artifacts": [
            {
                "path": portable_path(path),
                "sha256": hashlib.sha256(payload).hexdigest(),
            }
            for path, payload in zip(args.folds, fold_bytes, strict=True)
        ],
        "sample": {
            "n": len(all_row_ids),
            "participants": sorted(all_participants),
            "participant_counts": dict(
                sorted(Counter(row["participant_id"] for row in combined["full"]).items())
            ),
        },
        "aggregate": aggregate,
        "per_fold": per_fold,
        "paired_comparisons": comparisons,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2, sort_keys=True))
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
