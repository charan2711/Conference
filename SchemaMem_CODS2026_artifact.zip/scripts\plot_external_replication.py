from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
BIRD = ROOT / "results" / "schemamem" / "tool_agent_runs_qwen7_v4_expanded.statistics.json"
DRSPIDER = ROOT / "results" / "schemamem" / "tool_agent_runs_qwen7_drspider_v1.statistics.json"
OUT = ROOT / "paper" / "figures"

conditions = [
    "no_memory",
    "stale_memory",
    "execution_guided_memory",
    "schema_aware_memory",
    "policy_memory",
]
labels = ["No mem.", "Stale", "Exec.-guided", "Gold repair", "SchemaMem"]
reports = [
    ("BIRD lifecycle", json.loads(BIRD.read_text(encoding="utf-8"))),
    ("Dr.Spider external", json.loads(DRSPIDER.read_text(encoding="utf-8"))),
]
colors = ["#8C8C8C", "#2166AC"]
hatches = ["//", ""]

x = np.arange(len(conditions))
width = 0.36
fig, axes = plt.subplots(
    1,
    2,
    figsize=(7.2, 2.75),
    gridspec_kw={"wspace": 0.26},
    layout="constrained",
)

for offset, ((name, report), color, hatch) in enumerate(zip(reports, colors, hatches)):
    shift = (offset - 0.5) * width
    accuracy = [report["conditions"][condition]["execution_accuracy"] for condition in conditions]
    tokens = [
        report["conditions"][condition]["mean_total_tokens_with_maintenance"] / 1000
        for condition in conditions
    ]
    acc_bars = axes[0].bar(
        x + shift,
        accuracy,
        width,
        label=name,
        color=color,
        hatch=hatch,
        edgecolor="white",
        linewidth=0.5,
    )
    token_bars = axes[1].bar(
        x + shift,
        tokens,
        width,
        label=name,
        color=color,
        hatch=hatch,
        edgecolor="white",
        linewidth=0.5,
    )
    axes[0].bar_label(
        acc_bars,
        labels=[f"{value:.0%}" for value in accuracy],
        padding=2,
        fontsize=6.4,
        rotation=90,
    )
    axes[1].bar_label(
        token_bars,
        labels=[f"{value:.1f}" for value in tokens],
        padding=2,
        fontsize=6.4,
        rotation=90,
    )

axes[0].set_ylim(0, 0.94)
axes[0].set_ylabel("Execution accuracy")
axes[0].set_title("Downstream correctness", fontsize=9)
axes[1].set_ylim(0, 6.5)
axes[1].set_ylabel("Mean total tokens (thousands)")
axes[1].set_title("Maintenance + agent cost", fontsize=9)

for ax in axes:
    ax.set_xticks(x, labels, rotation=26, ha="right")
    ax.grid(axis="y", color="#DDDDDD", linewidth=0.65)
    ax.spines[["top", "right"]].set_visible(False)

handles, legend_labels = axes[0].get_legend_handles_labels()
fig.legend(
    handles,
    legend_labels,
    loc="upper center",
    bbox_to_anchor=(0.5, 1.13),
    ncol=2,
    frameon=False,
    fontsize=8,
)
OUT.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT / "external_replication.pdf", bbox_inches="tight", facecolor="white")
fig.savefig(OUT / "external_replication.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
