"""Build a frozen external rename-lifecycle study from Dr.Spider.

Dr.Spider authored the schema synonym/abbreviation perturbations independently
of SchemaMem.  This adapter accepts only pure one-to-one column renames,
executes the supplied pre/post gold SQL on the corresponding physical SQLite
databases, and freezes targets without consulting any agent outcome.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sqlite3
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

from .agent_experiment import pair_memories
from .build_benchmark import (
    BENCHMARK_VALIDATION_VM_STEPS,
    execute,
    refs,
    result_equivalent,
    sqlite_schema,
)


PERTURBATIONS = ("DB_schema_synonym", "DB_schema_abbreviation")
SELECTION_SEED = "20260714"


@dataclass(frozen=True)
class Variant:
    perturbation: str
    base_db_id: str
    post_db_id: str
    original_path: Path
    post_path: Path
    column_map: dict[tuple[str, str], str]
    instances: list[dict]


def ordered_schema(path: Path) -> dict[str, list[tuple]]:
    """Return table columns in physical ordinal order for rename auditing."""
    with sqlite3.connect(path) as conn:
        tables = [
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
        ]
        return {
            table: [tuple(row) for row in conn.execute(f'PRAGMA table_info("{table}")')]
            for table in tables
        }


def pure_column_rename_map(old_path: Path, new_path: Path) -> dict[tuple[str, str], str]:
    """Infer fixed-ordinal one-to-one renames or reject the schema pair."""
    old = ordered_schema(old_path)
    new = ordered_schema(new_path)
    new_tables = {name.casefold(): name for name in new}
    if set(name.casefold() for name in old) != set(new_tables):
        raise ValueError("table_set_changed")
    mapping: dict[tuple[str, str], str] = {}
    for old_table, old_columns in old.items():
        new_table = new_tables[old_table.casefold()]
        if old_table.casefold() != new_table.casefold():
            raise ValueError("table_renamed")
        new_columns = new[new_table]
        if len(old_columns) != len(new_columns):
            raise ValueError("column_count_changed")
        for old_row, new_row in zip(old_columns, new_columns, strict=True):
            old_cid, old_name, old_type, old_notnull, old_default, old_pk = old_row
            new_cid, new_name, new_type, new_notnull, new_default, new_pk = new_row
            invariant_old = (
                old_cid,
                str(old_type).casefold(),
                old_notnull,
                old_default,
                old_pk,
            )
            invariant_new = (
                new_cid,
                str(new_type).casefold(),
                new_notnull,
                new_default,
                new_pk,
            )
            if invariant_old != invariant_new:
                raise ValueError("column_definition_changed")
            if old_name.casefold() != new_name.casefold():
                mapping[(old_table, old_name)] = new_name
    if not mapping:
        raise ValueError("no_identifier_change")
    scoped_targets = {
        (table.casefold(), value.casefold())
        for (table, _), value in mapping.items()
    }
    if len(scoped_targets) != len(mapping):
        raise ValueError("non_unique_targets_within_table")
    return mapping


def paired_records(directory: Path) -> list[tuple[dict, dict]]:
    pre = json.loads(
        (directory / "questions_pre_perturbation.json").read_text(encoding="utf-8")
    )
    post = json.loads(
        (directory / "questions_post_perturbation.json").read_text(encoding="utf-8")
    )
    if len(pre) != len(post):
        raise ValueError(f"unpaired question files in {directory}")
    pairs = []
    for old, new in zip(pre, post, strict=True):
        if old["q_id_spider_dev"] != new["q_id_spider_dev"]:
            raise ValueError("question identifier mismatch")
        if old["question"] != new["question"]:
            raise ValueError("natural-language question changed")
        pairs.append((old, new))
    return pairs


def inspect_variant(
    perturbation: str,
    pairs: list[tuple[dict, dict]],
    original_root: Path,
    post_root: Path,
    rejection_counts: Counter,
) -> Variant | None:
    post_db_ids = {new["db_id"] for _, new in pairs}
    base_db_ids = {old["db_id"] for old, _ in pairs}
    if len(post_db_ids) != 1 or len(base_db_ids) != 1:
        rejection_counts["variant_database_mismatch"] += len(pairs)
        return None
    post_db_id = post_db_ids.pop()
    base_db_id = base_db_ids.pop()
    original = original_root / base_db_id / f"{base_db_id}.sqlite"
    post = post_root / post_db_id / f"{post_db_id}.sqlite"
    if not original.is_file() or not post.is_file():
        rejection_counts["database_missing"] += len(pairs)
        return None
    try:
        column_map = pure_column_rename_map(original, post)
    except ValueError as error:
        rejection_counts[str(error)] += len(pairs)
        return None

    old_schema = sqlite_schema(original)
    write_set = set(column_map)
    accepted = []
    for old, new in pairs:
        try:
            _, dependencies = refs(old["query"], old_schema)
            affected = not dependencies.isdisjoint(write_set)
            if not affected:
                rejection_counts["old_sql_unaffected"] += 1
                continue
            old_ok, old_result = execute(
                original,
                old["query"],
                vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
            )
            new_ok, new_result = execute(
                post,
                new["query"],
                vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
            )
            if not old_ok:
                rejection_counts["old_gold_execution_failed"] += 1
                continue
            if not new_ok:
                rejection_counts["post_gold_execution_failed"] += 1
                continue
            if not result_equivalent(old_result, new_result, old["query"]):
                rejection_counts["gold_results_not_equivalent"] += 1
                continue
        except Exception:
            rejection_counts["validation_exception"] += 1
            continue
        accepted.append(
            {
                "scenario": "column_rename",
                "db_id": post_db_id,
                "cluster_id": base_db_id,
                "question_id": int(old["q_id_spider_dev"]),
                "question": old["question"],
                "SQL": old["query"],
                "evidence": "",
                "old_sql": old["query"],
                "new_sql": new["query"],
                "affected": True,
                "old_exec_ok": True,
                "new_exec_ok": True,
                "execution_equivalent": True,
                "old_error": None,
                "new_error": None,
                "source": "Dr.Spider",
                "source_perturbation": perturbation,
                "source_post_db_id": post_db_id,
            }
        )
    return Variant(
        perturbation=perturbation,
        base_db_id=base_db_id,
        post_db_id=post_db_id,
        original_path=original,
        post_path=post,
        column_map=column_map,
        instances=accepted,
    )


def candidate_variants(args: argparse.Namespace) -> tuple[list[Variant], Counter]:
    rejection_counts: Counter = Counter()
    variants = []
    for perturbation in PERTURBATIONS:
        directory = args.drspider / perturbation
        grouped: dict[str, list[tuple[dict, dict]]] = defaultdict(list)
        for old, new in paired_records(directory):
            grouped[new["db_id"]].append((old, new))
        for post_db_id in sorted(grouped):
            variant = inspect_variant(
                perturbation,
                grouped[post_db_id],
                args.spider_databases,
                directory / "database_post_perturbation",
                rejection_counts,
            )
            if variant and len(variant.instances) >= 2:
                variants.append(variant)
            elif variant:
                rejection_counts["fewer_than_two_eligible_questions"] += len(
                    variant.instances
                )
    return variants, rejection_counts


def select_variants(variants: list[Variant]) -> list[Variant]:
    by_base: dict[str, list[Variant]] = defaultdict(list)
    for variant in variants:
        by_base[variant.base_db_id].append(variant)
    selected = []
    for base_db_id in sorted(by_base):
        group = by_base[base_db_id]
        synonyms = [v for v in group if v.perturbation == "DB_schema_synonym"]
        pool = synonyms or [
            v for v in group if v.perturbation == "DB_schema_abbreviation"
        ]
        pool.sort(key=lambda v: (-len(v.instances), v.post_db_id))
        selected.append(pool[0])
    return selected


def target_order(row: dict) -> str:
    payload = "|".join(
        [
            SELECTION_SEED,
            row["source_perturbation"],
            row["db_id"],
            str(row["question_id"]),
        ]
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def freeze_targets(variants: list[Variant], per_database: int) -> list[dict]:
    targets = []
    for variant in variants:
        pairs = pair_memories(variant.instances)
        ordered = sorted(variant.instances, key=target_order)
        for target in ordered[:per_database]:
            memory = pairs[target["question_id"]]
            targets.append(
                {
                    "scenario": "column_rename",
                    "db_id": variant.post_db_id,
                    "cluster_id": variant.base_db_id,
                    "question_id": target["question_id"],
                    "memory_question_id": memory["question_id"],
                    "target_affected": True,
                    "memory_affected": True,
                    "retrieval_score": memory["retrieval_score"],
                    "source_perturbation": variant.perturbation,
                }
            )
    return targets


def copy_database(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def build(args: argparse.Namespace) -> dict:
    variants, rejections = candidate_variants(args)
    selected = select_variants(variants)
    targets = freeze_targets(selected, args.targets_per_database)
    args.output.mkdir(parents=True, exist_ok=True)

    instances = []
    migrations = {}
    for variant in selected:
        instances.extend(variant.instances)
        copy_database(
            variant.original_path,
            args.output
            / "original_databases"
            / variant.post_db_id
            / f"{variant.post_db_id}.sqlite",
        )
        copy_database(
            variant.post_path,
            args.output
            / "databases"
            / "column_rename"
            / variant.post_db_id
            / f"{variant.post_db_id}.sqlite",
        )
        migrations[variant.post_db_id] = {
            "cluster_id": variant.base_db_id,
            "source": "Dr.Spider",
            "source_perturbation": variant.perturbation,
            "column_rename": {
                f"{table}.{old}": new
                for (table, old), new in sorted(variant.column_map.items())
            },
            "table_rename": {},
        }

    (args.output / "instances.json").write_text(
        json.dumps(instances, indent=2), encoding="utf-8"
    )
    (args.output / "migrations.json").write_text(
        json.dumps(migrations, indent=2), encoding="utf-8"
    )
    args.targets_output.parent.mkdir(parents=True, exist_ok=True)
    args.targets_output.write_text(json.dumps(targets, indent=2), encoding="utf-8")
    summary = {
        "source": "Dr.Spider",
        "selection_seed": SELECTION_SEED,
        "candidate_variants": len(variants),
        "selected_variants": len(selected),
        "base_database_clusters": len({v.base_db_id for v in selected}),
        "eligible_instances_in_selected_variants": len(instances),
        "frozen_targets": len(targets),
        "targets_per_database": args.targets_per_database,
        "perturbations": dict(Counter(v.perturbation for v in selected)),
        "rejections": dict(sorted(rejections.items())),
        "selected": [
            {
                "base_db_id": v.base_db_id,
                "post_db_id": v.post_db_id,
                "perturbation": v.perturbation,
                "eligible_instances": len(v.instances),
                "renamed_columns": len(v.column_map),
            }
            for v in selected
        ],
    }
    (args.output / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--drspider", type=Path, default=Path("tmp/drspider_data_20260714")
    )
    parser.add_argument(
        "--spider-databases",
        type=Path,
        default=Path("tmp/spider_official_fast_20260714/spider_data/database"),
    )
    parser.add_argument(
        "--output", type=Path, default=Path("data/schemamem-drspider-v1")
    )
    parser.add_argument(
        "--targets-output",
        type=Path,
        default=Path("data/schemamem-drspider-targets-v1.json"),
    )
    parser.add_argument("--targets-per-database", type=int, default=2)
    args = parser.parse_args()
    if args.targets_per_database < 1:
        parser.error("--targets-per-database must be positive")
    print(json.dumps(build(args), indent=2))


if __name__ == "__main__":
    main()
