"""Can an LLM maintain a stored SQL memory across an explicit migration?"""

from __future__ import annotations

import argparse
import json
import random
import sqlite3
from collections import defaultdict
from pathlib import Path

from .agent_experiment import call_model, extract_sql, identifiers
from .build_benchmark import execute, result_equivalent


def schema_for(path: Path, sql: str) -> str:
    try:
        wanted = identifiers(sql)[0]
    except Exception:
        wanted = set()
    with sqlite3.connect(path) as conn:
        tables = [
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            )
        ]
        selected = []
        for table in tables:
            if wanted and table.casefold() not in wanted:
                continue
            columns = [row[1] for row in conn.execute(f'PRAGMA table_info("{table}")')]
            selected.append(f'{table}({", ".join(columns)})')
    return "\n".join(selected)


def migration_text(
    record: dict, rename_specs: dict, split_specs: dict, merge_specs: dict
) -> str:
    if record["scenario"] == "table_merge":
        spec = merge_specs[record["db_id"]]
        return (
            f'Tables {spec["table"]} and {spec["details_table"]} were consolidated '
            f'into {spec["table"]}; their declared join key was '
            f'{", ".join(spec["primary_key"])}.'
        )
    if record["scenario"] == "table_split":
        spec = split_specs[record["db_id"]]
        return (
            f'Table {spec["table"]} was split. Columns '
            f'{", ".join(spec["moved_columns"])} moved to {spec["details_table"]}; '
            f'the tables join on {", ".join(spec["primary_key"])}.'
        )
    mappings = rename_specs[record["db_id"]][record["scenario"]]
    return "; ".join(f"{old} -> {new}" for old, new in mappings.items())


def make_prompt(record: dict, old_schema: str, new_schema: str, manifest: str | None) -> list[dict]:
    change = manifest if manifest is not None else "No migration manifest is available. Infer changes conservatively from the schemas."
    user = f"""A successful SQL memory was stored under an old SQLite schema.

Old schema:
{old_schema}

Current schema:
{new_schema}

Migration information:
{change}

Original question: {record['question']}
Stored SQL memory: {record['old_sql']}

Repair the stored SQL so it preserves the same query semantics under the current schema. Return SQL only."""
    return [
        {
            "role": "system",
            "content": "You maintain executable SQL memories after database migrations. Do not change literals or query intent. Return one SQLite query only.",
        },
        {"role": "user", "content": user},
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="http://127.0.0.1:8080/v1/chat/completions")
    parser.add_argument("--per-scenario", type=int, default=10)
    parser.add_argument("--max-tokens", type=int, default=384)
    parser.add_argument("--model-label", default="local")
    parser.add_argument(
        "--scenarios",
        nargs="+",
        choices=("column_rename", "table_rename", "table_split", "table_merge"),
    )
    parser.add_argument(
        "--output", type=Path, default=Path("results/schemamem/llm_repair_runs.jsonl")
    )
    args = parser.parse_args()
    rename_root = Path("data/schemamem-bench-v1")
    split_root = Path("data/schemamem-split-v1")
    merge_root = Path("data/schemamem-merge-v1")
    rename_rows = json.loads((rename_root / "instances.json").read_text(encoding="utf-8"))
    split_rows = json.loads((split_root / "instances.json").read_text(encoding="utf-8"))
    merge_rows = json.loads((merge_root / "instances.json").read_text(encoding="utf-8"))
    rows = [
        row for row in [*rename_rows, *split_rows, *merge_rows]
        if row["affected"] and row["execution_equivalent"]
        and (not args.scenarios or row["scenario"] in args.scenarios)
    ]
    by_scenario: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        by_scenario[row["scenario"]].append(row)
    rng = random.Random(42)
    selected = []
    for scenario, group in sorted(by_scenario.items()):
        rng.shuffle(group)
        selected.extend(group[: args.per_scenario])
    rename_specs = json.loads((rename_root / "migrations.json").read_text(encoding="utf-8"))
    split_specs = json.loads((split_root / "migrations.json").read_text(encoding="utf-8"))
    merge_specs = json.loads((merge_root / "migrations.json").read_text(encoding="utf-8"))
    original_root = Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases")

    completed, existing = set(), []
    if args.output.exists():
        for line in args.output.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            existing.append(row)
            completed.add((row["scenario"], row["question_id"], row["condition"], row["model"]))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("a", encoding="utf-8") as handle:
        for record in selected:
            old_path = original_root / record["db_id"] / f'{record["db_id"]}.sqlite'
            if record["scenario"] == "table_merge":
                old_path = split_root / "databases" / record["db_id"] / f'{record["db_id"]}.sqlite'
                new_path = original_root / record["db_id"] / f'{record["db_id"]}.sqlite'
            elif record["scenario"] == "table_split":
                new_path = split_root / "databases" / record["db_id"] / f'{record["db_id"]}.sqlite'
            else:
                new_path = rename_root / "databases" / record["scenario"] / record["db_id"] / f'{record["db_id"]}.sqlite'
            old_schema = schema_for(old_path, record["old_sql"])
            new_schema = schema_for(new_path, record["new_sql"])
            manifest = migration_text(record, rename_specs, split_specs, merge_specs)
            gold_ok, gold = execute(new_path, record["new_sql"], timeout_seconds=10)
            if not gold_ok:
                continue
            for condition, info in {"schema_only": None, "explicit_manifest": manifest}.items():
                key = (record["scenario"], record["question_id"], condition, args.model_label)
                if key in completed:
                    continue
                raw = call_model(args.url, make_prompt(record, old_schema, new_schema, info), args.max_tokens)
                prediction = extract_sql(raw)
                exec_ok, result = execute(new_path, prediction, timeout_seconds=10)
                row = {
                    "model": args.model_label,
                    "scenario": record["scenario"],
                    "db_id": record["db_id"],
                    "question_id": record["question_id"],
                    "condition": condition,
                    "prediction": prediction,
                    "exec_ok": exec_ok,
                    "correct": exec_ok and result_equivalent(result, gold, record["new_sql"]),
                    "error": None if exec_ok else result,
                }
                handle.write(json.dumps(row) + "\n")
                handle.flush()
                existing.append(row)
    report = {"model": args.model_label, "n_runs": len(existing), "conditions": {}}
    for condition in ("schema_only", "explicit_manifest"):
        group = [row for row in existing if row["condition"] == condition and row["model"] == args.model_label]
        report["conditions"][condition] = {
            "n": len(group),
            "execution_accuracy": sum(row["correct"] for row in group) / len(group) if group else None,
            "valid_sql_rate": sum(row["exec_ok"] for row in group) / len(group) if group else None,
            "by_scenario": {
                scenario: {
                    "n": len(subset),
                    "execution_accuracy": sum(row["correct"] for row in subset) / len(subset),
                }
                for scenario in sorted({row["scenario"] for row in group})
                if (subset := [row for row in group if row["scenario"] == scenario])
            },
        }
    args.output.with_suffix(".summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
