"""Integrity checks for a frozen paired tool-agent run."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path


CONDITIONS = {
    "no_memory",
    "stale_memory",
    "version_filter",
    "reexplore_on_change",
    "execution_guided_memory",
    "schema_aware_memory",
    "policy_memory",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--targets", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--conditions", nargs="+", choices=sorted(CONDITIONS))
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.runs.read_text(encoding="utf-8").splitlines()]
    required_conditions = set(args.conditions or {row["condition"] for row in rows})
    targets = json.loads(args.targets.read_text(encoding="utf-8"))
    target_specs = {
        (row["scenario"], row["db_id"], row["question_id"]): row
        for row in targets
    }
    expected = set(target_specs)
    grouped: dict[tuple, dict[str, dict]] = defaultdict(dict)
    duplicate_keys = []
    for row in rows:
        target = (row["scenario"], row["db_id"], row["question_id"])
        condition = row["condition"]
        if condition in grouped[target]:
            duplicate_keys.append([*target, condition])
        grouped[target][condition] = row

    manifest_mismatches = []
    for row in rows:
        target = (row["scenario"], row["db_id"], row["question_id"])
        spec = target_specs.get(target)
        if spec is None:
            continue
        expected_cluster = spec.get("cluster_id", spec["db_id"])
        observed_cluster = row.get("cluster_id", row["db_id"])
        if (
            int(row["memory_question_id"]) != int(spec["memory_question_id"])
            or observed_cluster != expected_cluster
            or bool(row["memory_affected"]) != bool(spec["memory_affected"])
        ):
            manifest_mismatches.append(
                [*target, row["condition"], "memory_or_cluster_metadata"]
            )

    complete = {
        key: value for key, value in grouped.items()
        if set(value) == required_conditions
    }
    unexpected_targets = sorted(set(grouped) - expected)
    missing_targets = sorted(expected - set(complete))
    trace_pair_available = {"stale_memory", "policy_memory"}.issubset(
        required_conditions
    )
    unaffected = (
        [
            value
            for value in complete.values()
            if not value["stale_memory"]["memory_affected"]
        ]
        if trace_pair_available
        else []
    )

    def same_trace(pair: dict[str, dict]) -> bool:
        stale, policy = pair["stale_memory"], pair["policy_memory"]
        fields = (
            "prediction",
            "finalized",
            "model_calls",
            "tool_calls",
            "schema_inspections",
            "sql_executions",
            "prompt_tokens",
            "completion_tokens",
            "trace",
            "exec_ok",
            "correct",
            "error",
        )
        return all(stale.get(field) == policy.get(field) for field in fields)

    invariant_failures = [
        [pair["stale_memory"]["db_id"], pair["stale_memory"]["question_id"]]
        for pair in unaffected
        if not same_trace(pair)
    ]
    report = {
        "rows": len(rows),
        "expected_targets": len(expected),
        "complete_targets": len(complete),
        "required_conditions": sorted(required_conditions),
        "duplicate_keys": duplicate_keys,
        "unexpected_targets": [list(value) for value in unexpected_targets],
        "missing_or_incomplete_targets": [list(value) for value in missing_targets],
        "manifest_mismatches": manifest_mismatches,
        "unaffected_targets_checked": len(unaffected),
        "unaffected_policy_stale_trace_invariant_applicable": trace_pair_available,
        "unaffected_policy_stale_trace_invariant_failures": invariant_failures,
    }
    report["passed"] = not any(
        (
            duplicate_keys,
            unexpected_targets,
            missing_targets,
            invariant_failures,
            manifest_mismatches,
            set(grouped) - expected,
        )
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
