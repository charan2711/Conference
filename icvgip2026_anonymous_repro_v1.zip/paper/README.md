# Manuscript

`main.tex` is the live anonymous draft. On 2026-07-22 the official ICVGIP 2026
LaTeX ZIP became downloadable. Its `acmart.cls` and
`ACM-Reference-Format.bst` are byte-identical to the files already used here;
the official ZIP is preserved under `template_2026/` with SHA-256
`2856eff092d78ffe16c64e93adff02f4ca40ef0f5cf391d8c4776b0060a13c9d`.

The current verified build is `../output/pdf/icvgip2026_draft_v34.pdf`. It
contains only measured results and no result TODOs, including the completed
six-fold adapted-SmolVLM audit. It is seven pages total, with references
beginning on page six, and remains subject to independent author review; the
official limit is eight main pages plus references.
