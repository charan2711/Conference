"""Paired statistics for deterministic benchmark policies."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from scipy.stats import binomtest


def wilson(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    p = successes / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return center - half, center + half


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--instances", type=Path, default=Path("results/schemamem/baseline_instances.json")
    )
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/statistics.json"))
    args = parser.parse_args()
    rows = json.loads(args.instances.read_text(encoding="utf-8"))
    methods = sorted(rows[0]["methods"])
    report = {"n": len(rows), "wilson_95": {}, "paired_vs_schema_aware": {}}
    for method in methods:
        successes = sum(row["methods"][method]["correct"] for row in rows)
        low, high = wilson(successes, len(rows))
        report["wilson_95"][method] = {
            "successes": successes,
            "rate": successes / len(rows),
            "low": low,
            "high": high,
        }
        if method == "schema_aware_repair":
            continue
        improved = sum(
            row["methods"]["schema_aware_repair"]["correct"]
            and not row["methods"][method]["correct"]
            for row in rows
        )
        degraded = sum(
            row["methods"][method]["correct"]
            and not row["methods"]["schema_aware_repair"]["correct"]
            for row in rows
        )
        discordant = improved + degraded
        p_value = (
            binomtest(min(improved, degraded), discordant, 0.5, alternative="two-sided").pvalue
            if discordant
            else 1.0
        )
        report["paired_vs_schema_aware"][method] = {
            "improved": improved,
            "degraded": degraded,
            "exact_mcnemar_p": p_value,
        }
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
