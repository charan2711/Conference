"""Factorized SchemaMem mechanism audit on frozen compatible/uncertain suites."""

from __future__ import annotations

import argparse
import copy
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Callable

from sqlglot import exp, parse_one

from .build_benchmark import (
    BENCHMARK_VALIDATION_VM_STEPS,
    execute,
    result_equivalent,
    sqlite_schema,
)
from .evaluate_ambiguity import SAFE_ACTIONS, wilson_interval
from .memory_policy import (
    Decision,
    _migrate_merge,
    _migrate_rename,
    _migrate_split,
    _valid,
    decide_merge,
    decide_rename,
    decide_split,
)


ROOT = Path("data")
BIRD = ROOT / "bird-mini-dev/package/minidev/MINIDEV/dev_databases"
RENAME = ROOT / "schemamem-bench-v1"
SPLIT = ROOT / "schemamem-split-v1"
MERGE = ROOT / "schemamem-merge-v1"
AMBIGUITY = ROOT / "schemamem-ambiguity-v1"


def legacy_flat_valid(sql: str, schema: dict[str, set[str]]) -> bool:
    """Frozen pre-refinement validator used for the preregistered first replay.

    This intentionally models only physical tables and their aliases.  It is
    retained so the original 1,744/1,782 result remains exactly reproducible
    after the scope-aware validator was adopted.
    """
    try:
        tree = parse_one(sql, read="sqlite")
        folded_schema = {
            table.casefold(): {column.casefold() for column in columns}
            for table, columns in schema.items()
        }
        aliases: dict[str, str] = {}
        for table in tree.find_all(exp.Table):
            physical = table.name.casefold()
            if physical not in folded_schema:
                return False
            aliases[table.alias_or_name.casefold()] = physical
        for column in tree.find_all(exp.Column):
            name = column.name.casefold()
            if column.table:
                owner = aliases.get(column.table.casefold())
                if owner is None or name not in folded_schema[owner]:
                    return False
            else:
                owners = [
                    table for table in set(aliases.values())
                    if name in folded_schema[table]
                ]
                if len(owners) != 1:
                    return False
        return True
    except Exception:
        return False


def validator_for(mode: str) -> Callable[[str, dict[str, set[str]]], bool]:
    if mode == "legacy_flat":
        return legacy_flat_valid
    if mode == "current":
        return _valid
    raise ValueError(f"unknown validator mode: {mode}")


def _read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _rename_manifest(row: dict, migration: dict) -> dict:
    columns = migration["column_rename"] if row["scenario"] == "column_rename" else {}
    tables = migration["table_rename"] if row["scenario"] == "table_rename" else {}
    return {
        "operator": "rename",
        "write_set": [*columns, *tables],
        "column_candidates": {key: [value] for key, value in columns.items()},
        "table_candidates": {key: [value] for key, value in tables.items()},
    }


def _returned(decision: Decision) -> str | None:
    return decision.sql if decision.action in SAFE_ACTIONS and decision.sql else None


def _assess_methods(
    methods: dict[str, str | None], current_path: Path, gold_sql: str
) -> dict[str, dict]:
    """Execute gold once and cache identical candidate programs per case."""
    gold_ok, gold = execute(
        current_path,
        gold_sql,
        timeout_seconds=30,
        vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
    )
    if not gold_ok:
        raise RuntimeError(f"frozen gold failed: {current_path}: {gold}")
    cache: dict[str, tuple[bool, list | str]] = {}
    assessed = {}
    for name, sql in methods.items():
        if sql is None:
            assessed[name] = {
                "returned": False,
                "exec_ok": False,
                "correct": False,
                "exec_error": False,
                "silent_wrong": False,
            }
            continue
        if sql not in cache:
            cache[sql] = execute(
                current_path,
                sql,
                timeout_seconds=30,
                vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
            )
        ok, result = cache[sql]
        correct = bool(ok and result_equivalent(result, gold, gold_sql))
        assessed[name] = {
            "returned": True,
            "exec_ok": bool(ok),
            "correct": correct,
            "exec_error": not ok,
            "silent_wrong": bool(ok and not correct),
        }
    return assessed


def _aggregate_compatible(rows: list[dict]) -> dict:
    methods = sorted(rows[0]["methods"])

    def metrics(group: list[dict], method: str) -> dict:
        values = [row["methods"][method] for row in group]
        returned = [value for value in values if value["returned"]]
        correct = sum(value["correct"] for value in values)
        return {
            "n": len(values),
            "coverage": len(returned) / len(values),
            "correct_rate": correct / len(values),
            "precision_when_returned": (
                sum(value["correct"] for value in returned) / len(returned)
                if returned
                else 1.0
            ),
            "execution_error_rate": sum(value["exec_error"] for value in values)
            / len(values),
            "silent_wrong_rate": sum(value["silent_wrong"] for value in values)
            / len(values),
        }

    return {
        "n": len(rows),
        "databases": len({row["db_id"] for row in rows}),
        "methods": {method: metrics(rows, method) for method in methods},
        "by_scenario": {
            scenario: {
                method: metrics(
                    [row for row in rows if row["scenario"] == scenario], method
                )
                for method in methods
            }
            for scenario in sorted({row["scenario"] for row in rows})
        },
    }


def compatible_cases() -> list[dict]:
    cases: list[dict] = []
    rename_migrations = _read(RENAME / "migrations.json")
    for row in _read(RENAME / "instances.json"):
        if not row["execution_equivalent"]:
            continue
        current = (
            RENAME
            / "databases"
            / row["scenario"]
            / row["db_id"]
            / f"{row['db_id']}.sqlite"
        )
        old = BIRD / row["db_id"] / f"{row['db_id']}.sqlite"
        manifest = _rename_manifest(row, rename_migrations[row["db_id"]])
        old_schema, current_schema = sqlite_schema(old), sqlite_schema(current)

        def rewrite(
            sql=row["old_sql"],
            old_schema=old_schema,
            manifest=manifest,
        ):
            columns = {
                tuple(key.split(".", 1)): values[0]
                for key, values in manifest["column_candidates"].items()
            }
            tables = {
                key: values[0]
                for key, values in manifest["table_candidates"].items()
            }
            return _migrate_rename(sql, old_schema, columns, tables)

        cases.append(
            {
                **row,
                "current_path": current,
                "current_schema": current_schema,
                "rewrite": rewrite,
                "full": lambda row=row, old_schema=old_schema, current_schema=current_schema, manifest=manifest: decide_rename(
                    row["old_sql"], old_schema, current_schema, manifest
                ),
            }
        )

    split_specs = _read(SPLIT / "migrations.json")
    for row in _read(SPLIT / "instances.json"):
        if not row["execution_equivalent"]:
            continue
        old = BIRD / row["db_id"] / f"{row['db_id']}.sqlite"
        current = SPLIT / "databases" / row["db_id"] / f"{row['db_id']}.sqlite"
        spec = split_specs[row["db_id"]]
        old_schema, current_schema = sqlite_schema(old), sqlite_schema(current)
        joins = [[(key, key) for key in spec["primary_key"]]]
        cases.append(
            {
                **row,
                "current_path": current,
                "current_schema": current_schema,
                "rewrite": lambda row=row, old_schema=old_schema, spec=spec: _migrate_split(
                    row["old_sql"], old_schema, spec
                ),
                "full": lambda row=row, old_schema=old_schema, current_schema=current_schema, spec=spec, joins=joins: decide_split(
                    row["old_sql"], old_schema, current_schema, spec, joins
                ),
            }
        )

    merge_specs = _read(MERGE / "migrations.json")
    for row in _read(MERGE / "instances.json"):
        if not row["execution_equivalent"]:
            continue
        old = SPLIT / "databases" / row["db_id"] / f"{row['db_id']}.sqlite"
        current = BIRD / row["db_id"] / f"{row['db_id']}.sqlite"
        spec = merge_specs[row["db_id"]]
        old_schema, current_schema = sqlite_schema(old), sqlite_schema(current)
        joins = [[(key, key) for key in spec["primary_key"]]]
        cases.append(
            {
                **row,
                "current_path": current,
                "current_schema": current_schema,
                "rewrite": lambda row=row, spec=spec: _migrate_merge(
                    row["old_sql"], spec
                ),
                "full": lambda row=row, old_schema=old_schema, current_schema=current_schema, spec=spec, joins=joins: decide_merge(
                    row["old_sql"], old_schema, current_schema, spec, joins
                ),
            }
        )
    return cases


def run_compatible(validator_mode: str = "current") -> tuple[dict, list[dict]]:
    validate = validator_for(validator_mode)
    evaluated = []
    for case in compatible_cases():
        if case["affected"]:
            try:
                candidate, changed = case["rewrite"]()
                unvalidated = candidate if changed else None
            except Exception:
                unvalidated = None
            schema_validated = (
                unvalidated
                if unvalidated and validate(unvalidated, case["current_schema"])
                else None
            )
            if schema_validated:
                dry_ok, _ = execute(
                    case["current_path"],
                    schema_validated,
                    timeout_seconds=30,
                    vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
                )
                execution_validated = schema_validated if dry_ok else None
            else:
                execution_validated = None
            filter_only = None
        else:
            filter_only = unvalidated = schema_validated = execution_validated = case[
                "old_sql"
            ]
        full_sql = _returned(case["full"]())
        if case["affected"] and full_sql and not validate(full_sql, case["current_schema"]):
            full_sql = None
        methods = {
            "filter_only": filter_only,
            "ast_unvalidated": unvalidated,
            "schema_validated": schema_validated,
            "execution_validated": execution_validated,
            "full_fail_closed": full_sql,
        }
        evaluated.append(
            {
                "scenario": case["scenario"],
                "db_id": case["db_id"],
                "question_id": case["question_id"],
                "affected": case["affected"],
                "methods": _assess_methods(
                    methods, case["current_path"], case["new_sql"]
                ),
            }
        )
    return _aggregate_compatible(evaluated), evaluated


def _ambiguity_paths(row: dict) -> tuple[Path, Path]:
    old = BIRD / row["db_id"] / f"{row['db_id']}.sqlite"
    if row["scenario"] == "table_merge":
        old = SPLIT / "databases" / row["db_id"] / f"{row['db_id']}.sqlite"
        current = BIRD / row["db_id"] / f"{row['db_id']}.sqlite"
    elif row["scenario"] == "table_split":
        current = SPLIT / "databases" / row["db_id"] / f"{row['db_id']}.sqlite"
    else:
        current = (
            RENAME
            / "databases"
            / row["scenario"]
            / row["db_id"]
            / f"{row['db_id']}.sqlite"
        )
    return old, current


def _full_uncertain(row: dict, old_schema: dict, current_schema: dict) -> Decision:
    if row["scenario"] == "table_merge":
        return decide_merge(
            row["old_sql"],
            old_schema,
            current_schema,
            row["merge_spec"],
            row["join_candidates"],
        )
    if row["scenario"] == "table_split":
        return decide_split(
            row["old_sql"],
            old_schema,
            current_schema,
            row["split_spec"],
            row["join_candidates"],
        )
    return decide_rename(row["old_sql"], old_schema, current_schema, row["manifest"])


def _first_candidate(
    row: dict,
    old_schema: dict,
    current_schema: dict,
    validate: Callable[[str, dict[str, set[str]]], bool] = _valid,
) -> str | None:
    if row["class"] in {"referenced_drop", "unknown_change"}:
        return None
    if row["class"] == "unaffected":
        return row["old_sql"]
    try:
        if row["scenario"] == "table_merge":
            candidate, changed = _migrate_merge(row["old_sql"], row["merge_spec"])
        elif row["scenario"] == "table_split":
            spec = copy.deepcopy(row["split_spec"])
            first = [tuple(pair) for pair in row["join_candidates"][0]]
            if first and all(left.casefold() == right.casefold() for left, right in first):
                spec["primary_key"] = [left for left, _ in first]
            candidate, changed = _migrate_split(row["old_sql"], old_schema, spec)
        else:
            manifest = row["manifest"]
            columns = {
                tuple(key.split(".", 1)): values[0]
                for key, values in manifest.get("column_candidates", {}).items()
                if values
            }
            tables = {
                key: values[0]
                for key, values in manifest.get("table_candidates", {}).items()
                if values
            }
            candidate, changed = _migrate_rename(
                row["old_sql"], old_schema, columns, tables
            )
    except Exception:
        return None
    return candidate if changed and validate(candidate, current_schema) else None


def _aggregate_uncertain(rows: list[dict]) -> dict:
    methods = sorted(rows[0]["methods"])
    safe_total = sum(row["expected_action"] in SAFE_ACTIONS for row in rows)
    unsafe_total = len(rows) - safe_total
    report = {
        "n": len(rows),
        "safe_cases": safe_total,
        "unsafe_cases": unsafe_total,
        "methods": {},
        "by_class": {},
    }
    for method in methods:
        safe_returns = sum(
            row["methods"][method]["returned"]
            and row["expected_action"] in SAFE_ACTIONS
            for row in rows
        )
        unsafe_returns = sum(
            row["methods"][method]["returned"]
            and row["expected_action"] not in SAFE_ACTIONS
            for row in rows
        )
        returned = [row["methods"][method] for row in rows if row["methods"][method]["returned"]]
        report["methods"][method] = {
            "safe_case_coverage": safe_returns / safe_total,
            "safe_case_coverage_95ci": wilson_interval(safe_returns, safe_total),
            "unsafe_return_rate": unsafe_returns / unsafe_total,
            "unsafe_return_rate_95ci": wilson_interval(unsafe_returns, unsafe_total),
            "returned": len(returned),
            "returned_executable": sum(value["exec_ok"] for value in returned),
            "returned_semantically_correct": sum(value["correct"] for value in returned),
            "silent_wrong": sum(value["silent_wrong"] for value in returned),
        }
    for class_name in sorted({row["class"] for row in rows}):
        group = [row for row in rows if row["class"] == class_name]
        report["by_class"][class_name] = {
            method: {
                "returned": sum(row["methods"][method]["returned"] for row in group),
                "executable": sum(row["methods"][method]["exec_ok"] for row in group),
                "semantically_correct": sum(
                    row["methods"][method]["correct"] for row in group
                ),
            }
            for method in methods
        }
    return report


def run_uncertainty(validator_mode: str = "current") -> tuple[dict, list[dict]]:
    validate = validator_for(validator_mode)
    evaluated = []
    for row in _read(AMBIGUITY / "instances.json"):
        old, current = _ambiguity_paths(row)
        old_schema, current_schema = sqlite_schema(old), sqlite_schema(current)
        first = _first_candidate(row, old_schema, current_schema, validate)
        if first:
            first_exec_ok, _ = execute(
                current,
                first,
                timeout_seconds=30,
                vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
            )
            first_execution = first if first_exec_ok else None
        else:
            first_execution = None
        stale_ok, _ = execute(
            current,
            row["old_sql"],
            timeout_seconds=30,
            vm_step_budget=BENCHMARK_VALIDATION_VM_STEPS,
        )
        full_sql = _returned(_full_uncertain(row, old_schema, current_schema))
        if row["class"] != "unaffected" and full_sql and not validate(full_sql, current_schema):
            full_sql = None
        methods = {
            "filter_only": row["old_sql"] if row["class"] == "unaffected" else None,
            "execution_only_stale": row["old_sql"] if stale_ok else None,
            "first_candidate_schema": first,
            "first_candidate_execution": first_execution,
            "full_fail_closed": full_sql,
        }
        evaluated.append(
            {
                "scenario": row["scenario"],
                "db_id": row["db_id"],
                "question_id": row["question_id"],
                "class": row["class"],
                "expected_action": row["expected_action"],
                "methods": _assess_methods(methods, current, row["gold_new_sql"]),
            }
        )
    return _aggregate_uncertain(evaluated), evaluated


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=Path("results/schemamem/component_ablation.json")
    )
    parser.add_argument(
        "--instances-output",
        type=Path,
        default=Path("results/schemamem/component_ablation.instances.json"),
    )
    parser.add_argument(
        "--validator",
        choices=("legacy_flat", "current"),
        default="current",
        help="frozen flat validator or adopted scope-aware validator",
    )
    args = parser.parse_args()
    compatible, compatible_rows = run_compatible(args.validator)
    uncertainty, uncertainty_rows = run_uncertainty(args.validator)
    report = {
        "protocol": "research/ablation_portability_preregistration.md",
        "compatible": compatible,
        "uncertainty": uncertainty,
    }
    instances = {"compatible": compatible_rows, "uncertainty": uncertainty_rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    args.instances_output.write_text(
        json.dumps(instances, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
