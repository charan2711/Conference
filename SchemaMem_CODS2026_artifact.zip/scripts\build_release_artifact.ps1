param(
    [string]$Staging = "tmp\artifact_staging_release",
    [string]$Zip = "output\SchemaMem_CODS2026_artifact.zip"
)

$ErrorActionPreference = "Stop"
$Root = [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent))
$StagingPath = [IO.Path]::GetFullPath((Join-Path $Root $Staging))
$AllowedPrefix = [IO.Path]::GetFullPath((Join-Path $Root "tmp")) + [IO.Path]::DirectorySeparatorChar
if (-not $StagingPath.StartsWith($AllowedPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Staging must remain below $AllowedPrefix"
}
if (Test-Path -LiteralPath $StagingPath) {
    $Resolved = (Resolve-Path -LiteralPath $StagingPath).Path
    if (-not $Resolved.StartsWith($AllowedPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to remove staging path outside the workspace tmp directory"
    }
    Remove-Item -LiteralPath $Resolved -Recurse -Force
}
New-Item -ItemType Directory -Path $StagingPath -Force | Out-Null

function Copy-ArtifactFile {
    param([string]$Relative, [bool]$Required = $true)
    $Source = Join-Path $Root $Relative
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
        if ($Required) { throw "Required artifact file is missing: $Relative" }
        return
    }
    $Destination = Join-Path $StagingPath $Relative
    New-Item -ItemType Directory -Path (Split-Path $Destination -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
}

function Get-ArtifactRelativePath {
    param([string]$Base, [string]$Path)
    $BaseFull = [IO.Path]::GetFullPath($Base).TrimEnd("\", "/") + [IO.Path]::DirectorySeparatorChar
    $PathFull = [IO.Path]::GetFullPath($Path)
    if (-not $PathFull.StartsWith($BaseFull, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Path is outside the expected artifact root: $PathFull"
    }
    return $PathFull.Substring($BaseFull.Length)
}

@(
    "README.md",
    "ARTIFACT.md",
    "THIRD_PARTY.md",
    "requirements.txt",
    "requirements-lock.txt",
    "pytest.ini",
    "paper\main.tex",
    "paper\references.bib",
    "paper\main.pdf",
    "tests\test_schemamem.py",
    "research\model_controls.md",
    "research\expanded_tool_protocol.md",
    "research\drspider_preregistration.md",
    "research\drspider_results.md",
    "research\drspider_release_redaction.md",
    "research\ablation_portability_preregistration.md",
    "research\scope_validator_refinement.md",
    "research\ablation_portability_results.md"
) | ForEach-Object { Copy-ArtifactFile $_ }

Get-ChildItem -LiteralPath (Join-Path $Root "src\schemamem") -File -Filter "*.py" |
    ForEach-Object { Copy-ArtifactFile (Get-ArtifactRelativePath $Root $_.FullName) }
Get-ChildItem -LiteralPath (Join-Path $Root "scripts") -File |
    Where-Object { $_.Extension -in ".py", ".ps1" } |
    ForEach-Object { Copy-ArtifactFile (Get-ArtifactRelativePath $Root $_.FullName) }
Get-ChildItem -LiteralPath (Join-Path $Root "paper\figures") -File |
    Where-Object { $_.Extension -in ".pdf", ".png" } |
    ForEach-Object { Copy-ArtifactFile (Get-ArtifactRelativePath $Root $_.FullName) }

@(
    "data\schemamem-agent-targets-v1.json",
    "data\schemamem-agent-targets-balanced22.json",
    "data\schemamem-agent-targets-affected56.json",
    "data\schemamem-agent-targets-expanded78.json",
    "data\schemamem-drspider-targets-v1.json"
) | ForEach-Object { Copy-ArtifactFile $_ }

@(
    "data\schemamem-bench-v1",
    "data\schemamem-split-v1",
    "data\schemamem-merge-v1",
    "data\schemamem-ambiguity-v1",
    "data\schemamem-multiversion-v1",
    "data\schemamem-real-migrations-v1"
) | ForEach-Object {
    Get-ChildItem -LiteralPath (Join-Path $Root $_) -File -Filter "*.json" |
        ForEach-Object { Copy-ArtifactFile (Get-ArtifactRelativePath $Root $_.FullName) }
}

Get-ChildItem -LiteralPath (Join-Path $Root "data\schemamem-drspider-v1") -File -Filter "*.json" |
    ForEach-Object { Copy-ArtifactFile (Get-ArtifactRelativePath $Root $_.FullName) }

$ResultFiles = @(
    "EXPERIMENTS.md",
    "baselines.json",
    "baseline_instances.json",
    "split_baselines.json",
    "split_baseline_instances.json",
    "merge_baselines.json",
    "merge_baseline_instances.json",
    "statistics.json",
    "ambiguity.json",
    "ambiguity_instances.json",
    "multiversion_statistics.json",
    "paper_claims_audit.json",
    "bibliography_audit.json",
    "clean_rebuild_audit.json",
    "policy_overhead.json",
    "evoschema_audit.json",
    "llm_repair_1.5b.jsonl",
    "llm_repair_1.5b.summary.json",
    "llm_repair_1.5b.statistics.json",
    "llm_repair_runs_7b.jsonl",
    "llm_repair_runs_7b.summary.json",
    "llm_repair_7b_expanded.statistics.json",
    "llm_repair_7b_expanded.errors.json",
    "llm_repair_runs_mistral7.jsonl",
    "llm_repair_runs_mistral7.summary.json",
    "llm_repair_mistral7.statistics.json",
    "llm_repair_mistral7.errors.json",
    "llm_repair_runs_14b.jsonl",
    "llm_repair_runs_14b.summary.json",
    "llm_repair_14b.statistics.json",
    "llm_repair_14b.errors.json",
    "llm_repair_runs_qwen7_merge.jsonl",
    "llm_repair_runs_qwen7_merge.summary.json",
    "llm_repair_runs_qwen7_merge.statistics.json",
    "llm_repair_runs_qwen7_merge.errors.json",
    "llm_repair_runs_mistral7_merge.jsonl",
    "llm_repair_runs_mistral7_merge.summary.json",
    "llm_repair_runs_mistral7_merge.statistics.json",
    "llm_repair_runs_mistral7_merge.errors.json",
    "llm_gate_runs_7b.jsonl",
    "llm_gate_runs_7b.summary.json",
    "llm_gate_runs_7b_balanced.jsonl",
    "llm_gate_runs_7b_balanced.summary.json",
    "llm_gate_runs_7b_structured.jsonl",
    "llm_gate_runs_7b_structured.summary.json",
    "agent_runs.jsonl",
    "agent_runs.summary.json",
    "agent_statistics.json",
    "agent_runs_7b.jsonl",
    "agent_runs_7b.summary.json",
    "agent_statistics_7b_expanded.json",
    "agent_statistics_7b_clustered.json",
    "agent_runs_7b_expanded.errors.json",
    "agent_runs_mistral7.jsonl",
    "agent_runs_mistral7.summary.json",
    "agent_statistics_mistral7.json",
    "agent_runs_mistral7.errors.json",
    "tool_agent_runs_qwen7_v3_final.jsonl",
    "tool_agent_runs_qwen7_v3_final.summary.json",
    "tool_agent_runs_qwen7_v3_final.statistics.json",
    "tool_agent_runs_qwen7_v3_final.integrity.json",
    "tool_agent_runs_qwen7_v3_final.errors.json",
    "tool_agent_runs_qwen7_v4_expanded.jsonl",
    "tool_agent_runs_qwen7_v4_expanded.summary.json",
    "tool_agent_runs_qwen7_v4_expanded.statistics.json",
    "tool_agent_runs_qwen7_v4_expanded.maintenance.json",
    "tool_agent_runs_qwen7_v4_expanded.integrity.json",
    "tool_agent_runs_qwen7_v4_expanded.errors.json",
    "tool_agent_runs_qwen14_v1_control22.jsonl",
    "tool_agent_runs_qwen14_v1_control22.summary.json",
    "tool_agent_runs_qwen14_v1_control22.statistics.json",
    "tool_agent_runs_qwen14_v1_control22.maintenance.json",
    "tool_agent_runs_qwen14_v1_control22.integrity.json",
    "tool_agent_runs_qwen14_v1_control22.errors.json",
    "tool_agent_model_control_qwen14_vs_qwen7.json",
    "tool_agent_runs_qwen7_drspider_v1.summary.json",
    "tool_agent_runs_qwen7_drspider_v1.statistics.json",
    "tool_agent_runs_qwen7_drspider_v1.integrity.json",
    "tool_agent_runs_qwen7_drspider_v1.execution_guided_audit.json",
    "tool_agent_runs_qwen7_drspider_v1.policy_audit.json",
    "tool_agent_runs_qwen7_drspider_v1.maintenance_outcomes.json",
    "tool_agent_runs_qwen7_drspider_v1.errors.json",
    "component_ablation.json",
    "component_ablation.instances.json",
    "component_ablation_scope_refined.json",
    "component_ablation_scope_refined.instances.json",
    "duckdb_portability.json",
    "duckdb_portability.instances.json",
    "qualitative_failure_examples.json",
    "tool_agent_runs_qwen7_drspider_v1.policy_audit_scope_refined.json",
    "tool_agent_runs_qwen7_drspider_scope_refined_v2.summary.json",
    "tool_agent_runs_qwen7_drspider_scope_refined_v2.integrity.json",
    "tool_agent_runs_qwen7_drspider_scope_refined_v2.policy_audit.json",
    "scope_refinement_statistics.json"
)
$ResultFiles | ForEach-Object {
    Copy-ArtifactFile (Join-Path "results\schemamem" $_)
}

# Preserve the immutable raw run in the workspace while packaging an anonymous
# release copy whose only changes are email-shaped values returned by the public
# benchmark database inside diagnostic trace observations.
$Python = Join-Path $Root ".venv\Scripts\python.exe"
$DrSpiderRaw = Join-Path $Root "results\schemamem\tool_agent_runs_qwen7_drspider_v1.jsonl"
$DrSpiderRelease = Join-Path $StagingPath "results\schemamem\tool_agent_runs_qwen7_drspider_v1.jsonl"
$DrSpiderRedactionAudit = Join-Path $StagingPath "results\schemamem\tool_agent_runs_qwen7_drspider_v1.release_redaction.json"
New-Item -ItemType Directory -Path (Split-Path $DrSpiderRelease -Parent) -Force | Out-Null
& $Python (Join-Path $Root "scripts\sanitize_release_trace.py") $DrSpiderRaw $DrSpiderRelease --audit $DrSpiderRedactionAudit
if ($LASTEXITCODE -ne 0) { throw "Dr.Spider release-trace redaction failed" }
$RefinedRaw = Join-Path $Root "results\schemamem\tool_agent_runs_qwen7_drspider_scope_refined_v2.jsonl"
$RefinedRelease = Join-Path $StagingPath "results\schemamem\tool_agent_runs_qwen7_drspider_scope_refined_v2.jsonl"
$RefinedRedactionAudit = Join-Path $StagingPath "results\schemamem\tool_agent_runs_qwen7_drspider_scope_refined_v2.release_redaction.json"
& $Python (Join-Path $Root "scripts\sanitize_release_trace.py") $RefinedRaw $RefinedRelease --audit $RefinedRedactionAudit
if ($LASTEXITCODE -ne 0) { throw "Scope-refined Dr.Spider release-trace redaction failed" }
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) {
    throw "Artifact verification requires the project virtual environment: $Python"
}
$AnonymityArgs = @(
    (Join-Path $Root "scripts\verify_anonymity.py"),
    $StagingPath,
    "--output",
    (Join-Path $StagingPath "ANONYMITY_AUDIT.json")
)
$LocalDenylist = Join-Path $Root "tmp\anonymity_denylist.txt"
if (Test-Path -LiteralPath $LocalDenylist -PathType Leaf) {
    $AnonymityArgs += @("--denylist-file", $LocalDenylist)
}
$PdfAuditArgs = @(
    (Join-Path $Root "scripts\verify_submission_pdf.py"),
    (Join-Path $Root "paper\main.pdf"),
    "--output",
    (Join-Path $StagingPath "SUBMISSION_PDF_AUDIT.json")
)
if (Test-Path -LiteralPath $LocalDenylist -PathType Leaf) {
    $PdfAuditArgs += @("--denylist-file", $LocalDenylist)
}
& $Python @PdfAuditArgs
if ($LASTEXITCODE -ne 0) { throw "Submission PDF verification failed" }

& $Python @AnonymityArgs
if ($LASTEXITCODE -ne 0) { throw "Artifact anonymity verification failed" }

$ManifestPath = Join-Path $StagingPath "MANIFEST.sha256"
$ManifestLines = Get-ChildItem -LiteralPath $StagingPath -Recurse -File |
    Where-Object { $_.FullName -ne $ManifestPath } |
    Sort-Object FullName |
    ForEach-Object {
        $Relative = (Get-ArtifactRelativePath $StagingPath $_.FullName).Replace("\", "/")
        "{0}  {1}" -f (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant(), $Relative
    }
Set-Content -LiteralPath $ManifestPath -Value $ManifestLines -Encoding utf8

$ZipPath = [IO.Path]::GetFullPath((Join-Path $Root $Zip))
New-Item -ItemType Directory -Path (Split-Path $ZipPath -Parent) -Force | Out-Null
if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }
Compress-Archive -Path (Join-Path $StagingPath "*") -DestinationPath $ZipPath -CompressionLevel Optimal
& $Python (Join-Path $Root "scripts\verify_artifact_manifest.py") $ZipPath
if ($LASTEXITCODE -ne 0) { throw "Artifact manifest verification failed" }
$MaxSubmissionBytes = 50MB
if ((Get-Item -LiteralPath $ZipPath).Length -gt $MaxSubmissionBytes) {
    throw "Artifact exceeds the 50 MB supplementary-file limit"
}
$PaperPath = Join-Path $Root "paper\main.pdf"
if ((Get-Item -LiteralPath $PaperPath).Length -gt $MaxSubmissionBytes) {
    throw "Paper PDF exceeds the 50 MB submission limit"
}
$SubmissionPdfPath = Join-Path $Root "output\pdf\SchemaMem_CODS2026_anonymous.pdf"
New-Item -ItemType Directory -Path (Split-Path $SubmissionPdfPath -Parent) -Force | Out-Null
Copy-Item -LiteralPath $PaperPath -Destination $SubmissionPdfPath -Force
if ((Get-FileHash -LiteralPath $PaperPath -Algorithm SHA256).Hash -ne
    (Get-FileHash -LiteralPath $SubmissionPdfPath -Algorithm SHA256).Hash) {
    throw "Copied submission PDF does not match the audited manuscript"
}
$Hash = (Get-FileHash -LiteralPath $ZipPath -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Output "artifact=$ZipPath"
Write-Output "sha256=$Hash"
Write-Output "bytes=$((Get-Item -LiteralPath $ZipPath).Length)"
Write-Output "submission_pdf=$SubmissionPdfPath"
