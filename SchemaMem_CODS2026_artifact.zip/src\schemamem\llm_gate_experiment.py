"""Can an LLM safely decide whether a migrated SQL memory may be returned?"""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

from .agent_experiment import call_model, extract_sql
from .build_benchmark import execute, result_equivalent
from .llm_repair_experiment import schema_for


SAFE_ACTIONS = {"reuse", "migrate"}


def migration_text(row: dict) -> str:
    if row["scenario"] == "table_merge":
        spec = row["merge_spec"]
        return json.dumps(
            {
                "operator": "table_merge",
                "source_tables": [spec["table"], spec["details_table"]],
                "destination_table": spec["table"],
                "moved_columns": spec["moved_columns"],
                "primary_key": spec["primary_key"],
                "join_candidates": row["join_candidates"],
            }
        )
    if row["scenario"] == "table_split":
        spec = row["split_spec"]
        return json.dumps(
            {
                "operator": "table_split",
                "table": spec["table"],
                "details_table": spec["details_table"],
                "moved_columns": spec["moved_columns"],
                "primary_key": spec["primary_key"],
                "join_candidates": row["join_candidates"],
            }
        )
    return json.dumps(row["manifest"])


def make_prompt(row: dict, old_schema: str, current_schema: str, prompt_mode: str) -> list[dict]:
    output_contract = """Return exactly one of:
1. A single repaired SQLite query, only if the metadata determines one safe semantics-preserving repair.
2. ABSTAIN, if the mapping/join is ambiguous, unknown, unsupported, or cannot be validated.
3. INVALIDATE, if a referenced object was dropped with no declared replacement.
Do not guess among candidates. Return no explanation."""
    if prompt_mode == "structured":
        output_contract = """Return JSON only with this schema:
{"action":"REUSE|MIGRATE|EXPLORE|INVALIDATE","sql":"query or null"}
REUSE must include the stored SQL unchanged; MIGRATE must include the repaired SQL;
EXPLORE and INVALIDATE must use null. Do not include an explanation."""
    user = f"""A successful SQL memory was stored before a schema migration.

Old schema:
{old_schema}

Current schema:
{current_schema}

Migration metadata (candidate lists may be ambiguous):
{migration_text(row)}

Stored SQL memory:
{row['old_sql']}

{output_contract}"""
    if prompt_mode in {"balanced", "structured"}:
        system = (
            "You choose lifecycle actions for executable SQL memories. Return the old SQL unchanged "
            "when its dependencies are unaffected. Repair when every affected reference has exactly "
            "one declared candidate (and a split or merge has exactly one declared join). ABSTAIN only for "
            "multiple candidates, unknown/unsupported changes, or failed validation. INVALIDATE only "
            "for a referenced drop without replacement. Unnecessary abstention is an error."
        )
    else:
        system = (
            "You are a conservative lifecycle gate for executable SQL memories. "
            "Unsafe reuse is more costly than abstention."
        )
    return [
        {
            "role": "system",
            "content": system,
        },
        {"role": "user", "content": user},
    ]


def classify(text: str) -> tuple[str, str | None]:
    normalized = text.strip()
    fenced_json = re.search(r"```(?:json)?\s*(.*?)```", normalized, flags=re.I | re.S)
    json_text = fenced_json.group(1).strip() if fenced_json else normalized
    try:
        payload = json.loads(json_text)
        action = str(payload.get("action", "")).casefold()
        if action == "invalidate":
            return "invalidate", None
        if action in {"explore", "abstain"}:
            return "abstain", None
        if action in {"reuse", "migrate"} and payload.get("sql"):
            return "sql", extract_sql(str(payload["sql"]))
    except (json.JSONDecodeError, AttributeError, TypeError):
        pass
    if re.match(r"^INVALIDATE\b", normalized, flags=re.I):
        return "invalidate", None
    if re.match(r"^ABSTAIN\b", normalized, flags=re.I):
        return "abstain", None
    return "sql", extract_sql(normalized)


def summarize(rows: list[dict]) -> dict:
    safe = [row for row in rows if row["expected_action"] in SAFE_ACTIONS]
    unsafe = [row for row in rows if row["expected_action"] not in SAFE_ACTIONS]

    def correct(row: dict) -> bool:
        if row["expected_action"] in SAFE_ACTIONS:
            return row["correct_sql"]
        if row["expected_action"] == "invalidate":
            return row["response_type"] == "invalidate"
        return row["response_type"] in {"abstain", "invalidate"}

    report = {
        "n": len(rows),
        "lifecycle_success": sum(correct(row) for row in rows) / len(rows),
        "safe_return_rate": sum(row["response_type"] == "sql" for row in safe) / len(safe),
        "safe_correct_coverage": sum(row["correct_sql"] for row in safe) / len(safe),
        "unsafe_return_rate": sum(row["response_type"] == "sql" for row in unsafe) / len(unsafe),
        "by_class": {},
    }
    groups: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        groups[row["class"]].append(row)
    for name, group in sorted(groups.items()):
        report["by_class"][name] = {
            "n": len(group),
            "success": sum(correct(row) for row in group) / len(group),
            "sql_return_rate": sum(row["response_type"] == "sql" for row in group) / len(group),
        }
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", type=Path, default=Path("data/schemamem-ambiguity-v1"))
    parser.add_argument("--url", default="http://127.0.0.1:8080/v1/chat/completions")
    parser.add_argument("--per-class", type=int, default=10)
    parser.add_argument("--max-tokens", type=int, default=384)
    parser.add_argument("--model-label", default="local")
    parser.add_argument(
        "--prompt-mode",
        choices=("conservative", "balanced", "structured"),
        default="conservative",
    )
    parser.add_argument("--output", type=Path, default=Path("results/schemamem/llm_gate_runs.jsonl"))
    args = parser.parse_args()
    source = json.loads((args.benchmark / "instances.json").read_text(encoding="utf-8"))
    groups: dict[str, list[dict]] = defaultdict(list)
    for row in source:
        groups[row["class"]].append(row)
    selected = [row for name in sorted(groups) for row in groups[name][: args.per_class]]

    originals = Path("data/bird-mini-dev/package/minidev/MINIDEV/dev_databases")
    rename_root = Path("data/schemamem-bench-v1")
    split_root = Path("data/schemamem-split-v1")
    completed: set[tuple] = set()
    rows: list[dict] = []
    if args.output.exists():
        for line in args.output.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            rows.append(row)
            completed.add((row["class"], row["scenario"], row["question_id"], row["model"]))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("a", encoding="utf-8") as handle:
        for record in selected:
            key = (record["class"], record["scenario"], record["question_id"], args.model_label)
            if key in completed:
                continue
            old_path = originals / record["db_id"] / f'{record["db_id"]}.sqlite'
            if record["scenario"] == "table_merge":
                old_path = split_root / "databases" / record["db_id"] / f'{record["db_id"]}.sqlite'
                current_path = originals / record["db_id"] / f'{record["db_id"]}.sqlite'
            elif record["scenario"] == "table_split":
                current_path = split_root / "databases" / record["db_id"] / f'{record["db_id"]}.sqlite'
            else:
                current_path = rename_root / "databases" / record["scenario"] / record["db_id"] / f'{record["db_id"]}.sqlite'
            old_schema = schema_for(old_path, record["old_sql"])
            current_schema = schema_for(current_path, record["gold_new_sql"])
            raw = call_model(
                args.url,
                make_prompt(record, old_schema, current_schema, args.prompt_mode),
                args.max_tokens,
            )
            response_type, prediction = classify(raw)
            correct_sql = False
            exec_ok = False
            error = None
            if response_type == "sql" and prediction:
                gold_ok, gold = execute(current_path, record["gold_new_sql"], timeout_seconds=10)
                exec_ok, result = execute(current_path, prediction, timeout_seconds=10)
                correct_sql = bool(gold_ok and exec_ok and result_equivalent(result, gold, record["gold_new_sql"]))
                error = None if exec_ok else result
            row = {
                "model": args.model_label,
                "prompt_mode": args.prompt_mode,
                "class": record["class"],
                "scenario": record["scenario"],
                "db_id": record["db_id"],
                "question_id": record["question_id"],
                "expected_action": record["expected_action"],
                "response_type": response_type,
                "prediction": prediction,
                "exec_ok": exec_ok,
                "correct_sql": correct_sql,
                "error": error,
            }
            handle.write(json.dumps(row) + "\n")
            handle.flush()
            rows.append(row)
    model_rows = [row for row in rows if row["model"] == args.model_label]
    report = {"model": args.model_label, **summarize(model_rows)}
    args.output.with_suffix(".summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
